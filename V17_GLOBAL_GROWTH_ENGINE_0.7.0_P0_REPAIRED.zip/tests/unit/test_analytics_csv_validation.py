from pathlib import Path
import pytest
from v17_niche_intel.importers.analytics_csv import validate_analytics_csv


def test_valid_csv_returns_rows_and_summary(tmp_path: Path):
    p=tmp_path/'analytics.csv'
    p.write_text('date,video_id,views,watch_time_minutes\n2026-11-01,v1,100,25.5\n', encoding='utf-8')
    result=validate_analytics_csv(p)
    assert result.valid and result.row_count == 1
    assert result.rows[0]['views'] == 100


def test_duplicate_date_video_rows_are_rejected(tmp_path: Path):
    p=tmp_path/'analytics.csv'
    p.write_text('date,video_id,views\n2026-11-01,v1,100\n2026-11-01,v1,110\n', encoding='utf-8')
    result=validate_analytics_csv(p)
    assert not result.valid and any('duplicate' in e.lower() for e in result.errors)


def test_negative_metrics_are_rejected(tmp_path: Path):
    p=tmp_path/'analytics.csv'
    p.write_text('date,video_id,views\n2026-11-01,v1,-2\n', encoding='utf-8')
    assert not validate_analytics_csv(p).valid

def test_csv_size_and_missing_header_are_rejected(tmp_path: Path):
    p=tmp_path/'analytics.csv'; p.write_text('foo,bar\na,b\n',encoding='utf-8')
    assert not validate_analytics_csv(p).valid


def test_csv_rejects_non_finite_numeric_metrics(tmp_path):
    path = tmp_path / "analytics.csv"
    path.write_text("date,video_id,views\n2025-01-01,v1,nan\n", encoding="utf-8")
    result = validate_analytics_csv(path)
    assert not result.valid
    assert any("finite" in error for error in result.errors)


def test_csv_rejects_duplicate_normalized_headers(tmp_path):
    path = tmp_path / "duplicate-headers.csv"
    path.write_text("date,video_id,views, views\n2025-01-01,v1,10,11\n", encoding="utf-8")
    result = validate_analytics_csv(path)
    assert not result.valid
    assert any("duplicate header" in error.lower() for error in result.errors)


def test_csv_rejects_rows_with_more_cells_than_the_header(tmp_path):
    path = tmp_path / "extra-cells.csv"
    path.write_text("date,video_id,views\n2025-01-01,v1,10,unexpected\n", encoding="utf-8")
    result = validate_analytics_csv(path)
    assert not result.valid
    assert any("extra cells" in error.lower() for error in result.errors)


def test_csv_physical_row_limit_counts_invalid_rows_too(tmp_path, monkeypatch):
    from v17_niche_intel.importers import analytics_csv
    monkeypatch.setattr(analytics_csv, "MAX_ROWS", 2)
    path = tmp_path / "invalid-many-rows.csv"
    path.write_text("date,video_id\nnot-a-date,a\nnot-a-date,b\nnot-a-date,c\n", encoding="utf-8")
    result = analytics_csv.validate_analytics_csv(path)
    assert any("row limit" in error.lower() for error in result.errors)
