import json
from pathlib import Path
from v17_niche_intel.cli import main


def test_intelligence_cli_reads_evidence_bundle_and_writes_report(tmp_path, capsys):
    source = tmp_path / "evidence.json"
    output = tmp_path / "analysis.json"
    source.write_text(json.dumps({"keywords": ["how to brew coffee", "buy coffee grinder"]}), encoding="utf-8")
    assert main(["intelligence", str(source), "--output", str(output)]) == 0
    payload = json.loads(output.read_text(encoding="utf-8"))
    assert payload["search_intents"][0]["intent"] == "informational"
    assert payload["search_intents"][1]["intent"] == "transactional"
