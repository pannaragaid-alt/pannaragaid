from datetime import datetime, timezone
import pytest

from v17_niche_intel.services.global_market import (
    DEFAULT_MARKETS,
    FourLayerDecision,
    MarketProfile,
    build_localized_queries,
    score_four_layers,
)


def test_default_market_registry_covers_diverse_regions_and_locales():
    codes = {market.country_code for market in DEFAULT_MARKETS}
    assert {"US", "GB", "DE", "BR", "JP", "KR", "ID", "IN", "ZA", "AE"} <= codes
    assert all(m.language_code and m.locale and m.currency for m in DEFAULT_MARKETS)
    assert len(codes) < len(DEFAULT_MARKETS)
    assert len({market.market_id for market in DEFAULT_MARKETS}) == len(DEFAULT_MARKETS)
    assert {"IN-hi", "IN-en", "IN-ta", "CA-fr", "CH-it", "PH-tl", "AE-en"} <= {m.market_id for m in DEFAULT_MARKETS}


def test_localized_queries_keep_seed_and_dedupe_variants():
    market = MarketProfile("JP", "Japan", "ja", "ja-JP", "JPY", "Asia/Tokyo")
    result = build_localized_queries("home coffee", market, translated_query="自宅 コーヒー")
    assert result == ("home coffee", "自宅 コーヒー")


def test_four_layer_score_is_not_an_rpm_sort_and_requires_evidence():
    result = score_four_layers({
        "audience_demand": 80,
        "competitive_opening": 70,
        "monetization_economics": None,
        "creator_execution_fit": 60,
    })
    assert result.status == "scored"
    assert result.score == 70.0
    assert result.coverage == 0.75
    assert "monetization_economics" in result.missing_layers


def test_four_layer_score_refuses_insufficient_evidence_and_invalid_values():
    result = score_four_layers({"audience_demand": 80, "competitive_opening": 70})
    assert result.status == "insufficient_evidence"
    assert result.score is None
    try:
        score_four_layers({"audience_demand": 101})
    except ValueError:
        pass
    else:
        raise AssertionError("out-of-range layer score must fail")


def test_four_layer_decision_has_explicit_component_definitions():
    from v17_niche_intel.services.global_market import LAYER_COMPONENTS
    assert set(LAYER_COMPONENTS) == {
        "audience_demand", "competitive_opening", "monetization_economics", "creator_execution_fit"
    }
    assert all(sum(weights.values()) == 1.0 for weights in LAYER_COMPONENTS.values())


def test_ranker_excludes_unscored_markets_and_uses_confidence_as_tiebreaker():
    from v17_niche_intel.services.global_market import rank_market_decisions
    ranked = rank_market_decisions([
        {"country_code": "US", "decision": {"status": "scored", "score": 80, "coverage": 1.0}, "confidence": 0.5, "ranking_eligible": True, "eligibility": {"status": "eligible"}},
        {"country_code": "JP", "decision": {"status": "scored", "score": 80, "coverage": 1.0}, "confidence": 0.9, "ranking_eligible": True, "eligibility": {"status": "eligible"}},
        {"country_code": "ID", "decision": {"status": "insufficient_evidence", "score": None, "coverage": 0.5}, "confidence": 1.0, "ranking_eligible": False},
    ])
    assert [item["country_code"] for item in ranked] == ["JP", "US"]


def test_component_layer_scores_require_weighted_coverage_and_keep_missing_explicit():
    from v17_niche_intel.services.global_market import score_layer_components
    result = score_layer_components({
        "audience_demand": {"search_interest": 80, "demand_growth": 70, "seasonality_stability": 60, "audience_pain_evidence": 90},
        "monetization_economics": {"first_party_rpm": None, "advertiser_demand": 90},
    })
    assert result["layers"]["audience_demand"]["status"] == "scored"
    assert result["layers"]["monetization_economics"]["status"] == "insufficient_evidence"
    assert result["decision"]["status"] == "insufficient_evidence"


def test_global_discovery_isolates_country_failures_and_marks_machine_translation():
    from types import SimpleNamespace
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile

    class YouTube:
        def search_videos(self, keyword, region, **kwargs):
            if region == "JP":
                raise RuntimeError("region unavailable")
            return SimpleNamespace(status="ok", videos=(), failed_orders=(), detail_failures=0)

    markets = (
        MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York"),
        MarketProfile("JP", "Japan", "ja", "ja-JP", "JPY", "Asia/Tokyo"),
    )
    result = GlobalMarketDiscoveryService(youtube_provider=YouTube(),
        translator=lambda seed, language: f"translated:{language}:{seed}").discover(topic="coffee", markets=markets)
    assert result["markets"][0]["youtube"]["status"] == "ok"
    assert result["markets"][1]["youtube"]["status"] == "error"
    assert result["markets"][1]["localization"]["status"] == "machine_translated_native_review_required"


@pytest.mark.parametrize("minimum_coverage", [-0.01, 1.01, True, float("nan")])
def test_component_layer_scoring_rejects_invalid_coverage_threshold(minimum_coverage):
    from v17_niche_intel.services.global_market import score_layer_components
    with pytest.raises(ValueError):
        score_layer_components({}, minimum_coverage=minimum_coverage)


def test_global_discovery_prefers_fresh_native_reviewed_local_query_variant():
    from datetime import datetime, timezone
    from types import SimpleNamespace
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile

    class YouTube:
        def __init__(self): self.calls = []
        def search_videos(self, keyword, region, **kwargs):
            self.calls.append((keyword, region, kwargs))
            return SimpleNamespace(status="ok", videos=(), failed_orders=(), detail_failures=0)

    youtube = YouTube()
    market = MarketProfile("ID", "Indonesia", "id", "id-ID", "IDR", "Asia/Jakarta")
    reviewed_at = datetime.now(timezone.utc).isoformat()
    result = GlobalMarketDiscoveryService(youtube_provider=youtube,
        translator=lambda seed, language: "terjemahan otomatis").discover(
            topic="home coffee", markets=(market,),
            localized_query_variants={"ID-id": {
                "queries": ["cara seduh kopi di rumah", "resep kopi rumahan"],
                "review_status": "native_reviewed", "source_ref": "https://review.example/ID-id/v1",
                "reviewed_at": reviewed_at, "reviewer_ref": "reviewer:language-team",
                "dialect_reviewed": True, "accent_reviewed": True, "cultural_reviewed": True
            }}
        )
    localization = result["markets"][0]["localization"]
    assert youtube.calls[0][0] == "cara seduh kopi di rumah"
    assert localization["selected_query_source"] == "native_reviewed_curated"
    assert localization["native_validation_status"] == "native_reviewed"
    assert localization["query_review"]["source_ref"] == "https://review.example/ID-id/v1"
    assert localization["queries"] == ["home coffee", "cara seduh kopi di rumah", "resep kopi rumahan"]


def test_global_discovery_rejects_native_query_review_without_provenance():
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile
    market = MarketProfile("ID", "Indonesia", "id", "id-ID", "IDR", "Asia/Jakarta")
    with pytest.raises(ValueError, match="source_ref"):
        GlobalMarketDiscoveryService().discover(
            topic="coffee", markets=(market,), localized_query_variants={"ID-id": {
                "queries": ["kopi rumahan"], "review_status": "native_reviewed"
            }}
        )


def test_global_discovery_marks_stale_native_query_review_as_unverified():
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile
    market = MarketProfile("ID", "Indonesia", "id", "id-ID", "IDR", "Asia/Jakarta")
    result = GlobalMarketDiscoveryService().discover(
        topic="coffee", markets=(market,), localized_query_variants={"ID-id": {
            "queries": ["kopi rumahan"], "review_status": "native_reviewed",
            "source_ref": "https://review.example/old", "reviewed_at": "2020-01-01T00:00:00+00:00",
            "dialect_reviewed": True, "accent_reviewed": True, "cultural_reviewed": True
        }}
    )
    localization = result["markets"][0]["localization"]
    assert localization["native_validation_status"] == "stale"
    assert localization["status"] == "operator_curated_queries_review_stale"
    assert localization["native_review_required"] is True
    assert localization["selected_query_source"] == "operator_curated_unverified"


def test_global_discovery_rejects_malformed_query_order_and_boolean_limit():
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    with pytest.raises(ValueError, match="query_orders"):
        GlobalMarketDiscoveryService().discover(topic="coffee", markets=(market,), query_orders="relevance")
    with pytest.raises(ValueError, match="limit"):
        GlobalMarketDiscoveryService().discover(topic="coffee", markets=(market,), limit=True)


def test_four_layer_score_rejects_boolean_and_non_finite_coverage_thresholds():
    for threshold in (True, float("nan"), float("inf"), -0.1, 1.1):
        with pytest.raises(ValueError):
            score_four_layers({}, minimum_coverage=threshold)


def test_global_discovery_rejects_non_string_query_review_status():
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile
    market = MarketProfile("ID", "Indonesia", "id", "id-ID", "IDR", "Asia/Jakarta")
    with pytest.raises(ValueError, match="review_status"):
        GlobalMarketDiscoveryService().discover(
            topic="coffee", markets=(market,), localized_query_variants={"ID-id": {
                "queries": ["kopi rumahan"], "review_status": ["native_reviewed"]
            }}
        )


def test_global_discovery_bounds_google_trends_calls_and_withholds_partial_ranking():
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile
    class Trends:
        def interest_over_time(self, keyword, *, geo):
            return {"status": "ok", "points": []}
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    result = GlobalMarketDiscoveryService(trends_provider_factory=lambda _: Trends()).discover(
        topic="coffee", markets=(market,), trends_call_budget=0)
    assert result["status"] == "partial_quota_limited"
    assert result["ranked_markets"] == []
    assert result["markets"][0]["google_trends"]["status"] == "skipped_quota_budget"
    assert result["quota"]["trends_bucket"]["budget_limited"] is True


def test_global_discovery_downgrades_native_query_without_dialect_accent_and_cultural_gates():
    from datetime import datetime, timezone
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile
    market = MarketProfile("ID", "Indonesia", "id", "id-ID", "IDR", "Asia/Jakarta")
    result = GlobalMarketDiscoveryService().discover(topic="coffee", markets=(market,),
        localized_query_variants={"ID-id": {"queries": ["kopi rumahan"], "review_status": "native_reviewed",
            "source_ref": "https://review.example/ID-id", "reviewed_at": datetime.now(timezone.utc).isoformat(),
            "dialect_reviewed": True, "accent_reviewed": False, "cultural_reviewed": True}})
    item = result["markets"][0]["localization"]
    assert item["native_validation_status"] == "pending"
    assert item["native_review_required"] is True
    assert item["selected_query_source"] == "operator_curated_unverified"


def test_native_query_review_source_must_be_public_https():
    from datetime import datetime, timezone
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile
    market = MarketProfile("ID", "Indonesia", "id", "id-ID", "IDR", "Asia/Jakarta")
    with pytest.raises(ValueError, match="public HTTPS"):
        GlobalMarketDiscoveryService().discover(topic="coffee", markets=(market,),
            localized_query_variants={"ID-id": {"queries": ["kopi rumahan"], "review_status": "native_reviewed",
                "source_ref": "https://127.0.0.1/review", "reviewed_at": datetime.now(timezone.utc).isoformat(),
                "dialect_reviewed": True, "accent_reviewed": True, "cultural_reviewed": True}})


def test_discovery_exposes_explicit_market_coverage_and_not_attempted_states():
    from v17_niche_intel.services.global_market import GlobalMarketDiscoveryService, MarketProfile
    markets = (
        MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York"),
        MarketProfile("BR", "Brazil", "pt", "pt-BR", "BRL", "America/Sao_Paulo"),
    )
    from v17_niche_intel.domain.video import VideoRecord, VideoSearchBatch
    class Provider:
        def search_videos(self, query, region, **kwargs):
            if region == "BR":
                raise RuntimeError("quota")
            return VideoSearchBatch(videos=(VideoRecord(video_id="v1", title="Coffee", channel_id="c1",
                channel_title="Channel", published_at=datetime(2026, 1, 1, tzinfo=timezone.utc),
                views=100, likes=None, comments=None, duration_seconds=60, live_broadcast_content=None),),
                status="ok", requested_orders=("relevance",))
    result = GlobalMarketDiscoveryService(youtube_provider=Provider()).discover(
        topic="coffee", markets=markets, search_call_budget=1, query_variant_limit=1)
    assert result["market_coverage"]["expected_market_count"] == 2
    assert result["market_coverage"]["successful_market_count"] == 1
