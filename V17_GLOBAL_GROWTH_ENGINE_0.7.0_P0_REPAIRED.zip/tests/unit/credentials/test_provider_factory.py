from __future__ import annotations

import pytest

from v17_niche_intel.credentials import CredentialManager, MemorySecretStore, QuotaExhaustedError
from v17_niche_intel.credentials.providers import build_configured_youtube_data_api_provider
from v17_niche_intel.storage.database import Database


def test_configured_provider_never_falls_back_to_env_after_registered_project_quota_exhaustion(monkeypatch):
    import v17_niche_intel.credentials.providers as factory
    db = Database(":memory:")
    secrets = MemorySecretStore()
    manager = CredentialManager(db, secrets)
    manager.add_api_key("registered", project_id="project-a", use_case="market_research",
                        environment="local", secret="registered-secret")
    manager.consume_project_quota("project-a", units=10000, limit=10000, use_case="market_research")
    import v17_niche_intel.credentials.secrets as secret_module
    monkeypatch.setattr(secret_module, "KeyringSecretStore", lambda: secrets)
    monkeypatch.setenv("YOUTUBE_API_KEY", "fallback-secret")
    monkeypatch.setenv("YOUTUBE_API_PROJECT_ID", "project-b")
    with pytest.raises(QuotaExhaustedError):
        build_configured_youtube_data_api_provider(db)
    assert db.connection.execute("SELECT COUNT(*) FROM api_credentials").fetchone()[0] == 1
    db.close()


def test_env_api_key_requires_project_id_and_is_registered_with_project_quota_route(monkeypatch):
    import v17_niche_intel.credentials.providers as factory
    import v17_niche_intel.credentials.secrets as secret_module
    db = Database(":memory:")
    monkeypatch.setattr(secret_module, "KeyringSecretStore", lambda: (_ for _ in ()).throw(RuntimeError("no keyring")))
    monkeypatch.setattr(factory, "build_youtube_data_api_provider", lambda manager, **kwargs: manager)
    monkeypatch.setenv("YOUTUBE_API_KEY", "environment-secret")
    monkeypatch.setenv("YOUTUBE_API_PROJECT_ID", "project-env")
    manager = build_configured_youtube_data_api_provider(db)
    row = db.connection.execute("SELECT secret_ref,project_id FROM api_credentials").fetchone()
    assert row["secret_ref"] == "env://YOUTUBE_API_KEY"
    assert row["project_id"] == "project-env"
    assert manager.secrets.get(row["secret_ref"]) == "environment-secret"
    db.close()


def test_env_api_key_without_project_id_is_not_used(monkeypatch):
    import v17_niche_intel.credentials.providers as factory
    db = Database(":memory:")
    import v17_niche_intel.credentials.secrets as secret_module
    monkeypatch.setattr(secret_module, "KeyringSecretStore", lambda: (_ for _ in ()).throw(RuntimeError("no keyring")))
    monkeypatch.setenv("YOUTUBE_API_KEY", "environment-secret")
    monkeypatch.delenv("YOUTUBE_API_PROJECT_ID", raising=False)
    assert build_configured_youtube_data_api_provider(db) is None
    assert db.connection.execute("SELECT COUNT(*) FROM api_credentials").fetchone()[0] == 0
    db.close()


def test_invalid_key_rotation_stays_inside_the_same_project_route(monkeypatch):
    import v17_niche_intel.credentials.providers as factory
    from v17_niche_intel.providers.youtube_data_api import APIKeyInvalidError
    from v17_niche_intel.credentials.models import APIKeyCredential
    class Manager:
        def __init__(self): self.invalidated = []
        def secrets_get(self, ref): return ref
        class Secrets:
            @staticmethod
            def get(ref): return ref
        secrets = Secrets()
        def set_api_key_status(self, credential_id, status): self.invalidated.append((credential_id, status))
        def select_api_key(self, **kwargs):
            assert kwargs == {"use_case": "market_research", "environment": "local", "quota_limit": 10000}
            return APIKeyCredential("key-b", "youtube_data_api", "project-a", "market_research", "local", "secret-b")
    manager = Manager()
    credential = APIKeyCredential("key-a", "youtube_data_api", "project-a", "market_research", "local", "secret-a")
    attempts = []
    class FakeProvider:
        def __init__(self, api_key, **kwargs): self.api_key = api_key
        def search_videos(self, *args, **kwargs):
            attempts.append(self.api_key)
            if self.api_key == "secret-a": raise APIKeyInvalidError("invalid")
            return "ok"
    monkeypatch.setattr(factory, "YouTubeDataAPIProvider", FakeProvider)
    rotating = factory.RotatingYouTubeDataAPIProvider(manager, credential, use_case="market_research", environment="local")
    assert rotating.search_videos("coffee", "ID") == "ok"
    assert attempts == ["secret-a", "secret-b"]
    assert manager.invalidated == [("key-a", "invalid")]


def test_rotating_provider_routes_search_and_general_methods_to_separate_buckets(monkeypatch):
    import v17_niche_intel.credentials.providers as factory
    from v17_niche_intel.credentials.models import APIKeyCredential
    calls = []
    class Manager:
        class Secrets:
            @staticmethod
            def get(ref): return "api-key"
        secrets = Secrets()
        def consume_project_quota(self, project_id, **kwargs): calls.append((project_id, kwargs)); return 1
    class FakeProvider:
        def __init__(self, api_key, *, quota_callback, **kwargs): self.meter = quota_callback
        def search_videos(self, *args, **kwargs):
            self.meter("search.list", 1)
            self.meter("videos.list", 1)
            return "ok"
    monkeypatch.setattr(factory, "YouTubeDataAPIProvider", FakeProvider)
    credential = APIKeyCredential("key", "youtube_data_api", "project-a", "research", "local", "secret-ref")
    rotating = factory.RotatingYouTubeDataAPIProvider(Manager(), credential,
        use_case="research", environment="local", quota_limit=10000, search_quota_limit=100)
    assert rotating.search_videos("coffee", "US") == "ok"
    assert [(call[1]["bucket"], call[1]["limit"], call[1]["units"]) for call in calls] == [
        ("search.list", 100, 1), ("default", 10000, 1)]


def test_approved_quota_limits_are_loaded_from_environment(monkeypatch):
    import v17_niche_intel.credentials.providers as factory
    import v17_niche_intel.credentials.secrets as secret_module
    db = Database(":memory:")
    monkeypatch.setattr(secret_module, "KeyringSecretStore", lambda: (_ for _ in ()).throw(RuntimeError("no keyring")))
    monkeypatch.setenv("YOUTUBE_API_KEY", "environment-secret")
    monkeypatch.setenv("YOUTUBE_API_PROJECT_ID", "project-env")
    monkeypatch.setenv("YOUTUBE_DAILY_QUOTA_LIMIT", "20000")
    monkeypatch.setenv("YOUTUBE_SEARCH_DAILY_LIMIT", "250")
    captured = {}
    monkeypatch.setattr(factory, "build_youtube_data_api_provider",
        lambda manager, **kwargs: captured.update(kwargs) or manager)
    build_configured_youtube_data_api_provider(db)
    assert captured["quota_limit"] == 20000
    assert captured["search_quota_limit"] == 250
    db.close()
