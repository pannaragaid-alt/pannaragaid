from datetime import date
import pytest
from v17_niche_intel.providers.youtube_analytics import YouTubeAnalyticsProvider
from v17_niche_intel.storage.database import Database
from v17_niche_intel.storage.repositories import PrivateAnalyticsRepository


class FakeQuery:
    def __init__(self): self.params = None
    def query(self, **kwargs): self.params = kwargs; return self
    def filters(self, **kwargs): self.filter_params = kwargs; return self
    def execute(self):
        if self.params["dimensions"] == "day,video":
            return {"columnHeaders": [{"name": "day"}, {"name": "video"}, {"name": "views"}],
                    "rows": [["2025-01-01", "video-1", 42]]}
        return {"columnHeaders": [{"name": "day"}, {"name": "views"}],
                "rows": [["2025-01-01", 42]]}


class FakeClient:
    def __init__(self): self.query_obj = FakeQuery()
    def reports(self): return self.query_obj


def test_analytics_provider_returns_private_video_daily_rows():
    client = FakeClient()
    result = YouTubeAnalyticsProvider(client).query_daily(
        channel_id="UC_OWNER", start_date=date(2025, 1, 1), end_date=date(2025, 1, 2), video_ids=("video-1",))
    assert result["private_data"] is True
    assert result["records"] == [{"day": "2025-01-01", "video": "video-1", "views": 42}]
    assert client.query_obj.params["ids"] == "channel==UC_OWNER"
    assert client.query_obj.params["dimensions"] == "day"
    assert client.query_obj.filter_params["filters"] == "video==video-1"
    assert result["records"][0]["video"] == "video-1"


def test_private_analytics_rows_are_stored_separately_from_public_evidence():
    db = Database(":memory:")
    records = [{"date": "2025-01-01", "video_id": "video-1", "views": 42}]
    inserted = PrivateAnalyticsRepository(db).import_rows(channel_id="UC_OWNER", rows=tuple(records))
    assert inserted == 1
    assert db.connection.execute("SELECT COUNT(*) FROM channel_analytics_private").fetchone()[0] == 1
    assert db.connection.execute("SELECT COUNT(*) FROM source_observations").fetchone()[0] == 0
    db.close()


def test_channel_daily_report_uses_only_supported_day_dimension():
    client = FakeClient()
    result = YouTubeAnalyticsProvider(client).query_daily(
        channel_id="UC_OWNER", start_date=date(2025, 1, 1), end_date=date(2025, 1, 2))
    assert result["records"] == [{"day": "2025-01-01", "views": 42}]
    assert client.query_obj.params["dimensions"] == "day"
    assert "filter_params" not in client.query_obj.__dict__


def test_private_channel_daily_summary_is_stored_in_separate_table():
    db = Database(":memory:")
    repo = PrivateAnalyticsRepository(db)
    inserted = repo.import_daily_rows(channel_id="UC_OWNER", rows=({"date": "2025-01-01", "views": 42},))
    assert inserted == 1
    assert repo.list_daily_for_channel("UC_OWNER")[0]["metrics"]["views"] == 42
    assert db.connection.execute("SELECT COUNT(*) FROM source_observations").fetchone()[0] == 0
    db.close()


def test_multiple_video_daily_report_adds_video_dimension_with_explicit_filter():
    client = FakeClient()
    result = YouTubeAnalyticsProvider(client).query_daily(
        channel_id="UC_OWNER", start_date=date(2025, 1, 1), end_date=date(2025, 1, 2),
        video_ids=("video-1", "video-2"))
    assert client.query_obj.params["dimensions"] == "day,video"
    assert client.query_obj.filter_params["filters"] == "video==video-1,video-2"


def test_country_economics_uses_owner_analytics_and_calculates_actual_channel_rpm():
    class CountryQuery(FakeQuery):
        def execute(self):
            return {"columnHeaders": [{"name": "country"}, {"name": "views"}, {"name": "estimatedRevenue"}],
                    "rows": [["US", 2000, 10.0], ["GB", 1000, 8.0]]}
    class CountryClient:
        def reports(self): return CountryQuery()
    result = YouTubeAnalyticsProvider(CountryClient()).query_country_economics(
        channel_id="UC_OWNER", start_date=date(2025, 1, 1), end_date=date(2025, 1, 31), currency="USD")
    assert result["records"][0]["rpm"] == 5
    assert result["records"][1]["rpm"] == 8
    assert result["records"][1]["country"] == "GB"
    assert result["private_data"] is True


def test_analytics_provider_rejects_unknown_metric_before_api_call():
    client = FakeClient()
    with pytest.raises(ValueError, match="unsupported Analytics metric"):
        YouTubeAnalyticsProvider(client).query_daily(
            channel_id="UC_OWNER", start_date=date(2025, 1, 1), end_date=date(2025, 1, 2),
            metrics="views,notARealMetric")
    assert client.query_obj.params is None


def test_analytics_provider_returns_metric_plan_and_raw_payload_provenance():
    client = FakeClient()
    result = YouTubeAnalyticsProvider(client).query_daily(
        channel_id="UC_OWNER", start_date=date(2025, 1, 1), end_date=date(2025, 1, 2))
    assert result["query_plan"]["registry_version"] == "youtube-analytics-v1"
    assert result["provenance"]["source_ref"] == "reports.query"
    assert len(result["provenance"]["raw_sha256"]) == 64
    assert "raw_payload" not in result["provenance"]


def test_private_analytics_repository_persists_provenance_separately_from_metrics():
    db = Database(":memory:")
    repo = PrivateAnalyticsRepository(db)
    provenance = {"source_ref": "reports.query", "raw_sha256": "a" * 64}
    repo.import_daily_rows(channel_id="UC_OWNER", rows=({"date": "2025-01-01", "views": 42},),
        provenance=provenance)
    saved = repo.list_daily_for_channel("UC_OWNER")[0]
    assert saved["provenance"] == provenance
    assert saved["metrics"] == {"views": 42}
    db.close()


def test_analytics_freshness_reports_partial_latest_day_without_calling_it_realtime():
    from datetime import date
    from v17_niche_intel.providers.youtube_analytics import classify_report_freshness
    result = classify_report_freshness(requested_end_date=date(2026, 11, 15),
        records=[{"day": "2026-11-12"}, {"day": "2026-11-13"}])
    assert result["status"] == "partial_or_processing_lag"
    assert result["latest_observed_report_date"] == "2026-11-13"
    assert result["lag_days"] == 2
    assert "not a real-time" in result["interpretation_limit"]
