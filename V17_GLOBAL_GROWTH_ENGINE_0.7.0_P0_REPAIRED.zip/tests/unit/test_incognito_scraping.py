import pytest

from v17_niche_intel.providers.incognito_scraper import (
    DirectHTTPSFetcher,
    FirecrawlHTTPClient,
    IncognitoScraper,
    ScrapePolicyError,
    parse_allowed_hosts,
    parse_allowed_paths,
)


def _safe_fetcher(monkeypatch, hosts="example.com", paths="example.com=/"):
    fetcher = DirectHTTPSFetcher(hosts, allowed_paths=paths)
    monkeypatch.setattr(fetcher, "scrape", lambda url: {
        "url": url, "markdown": "public page", "metadata": {"statusCode": 200}
    })
    return fetcher


def test_scraper_requires_exact_owner_allowlist_and_uses_pinned_fetcher(monkeypatch):
    client = _safe_fetcher(monkeypatch)
    result = IncognitoScraper(client, allowed_hosts={"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/public")
    assert result.markdown == "public page"


@pytest.mark.parametrize("url", [
    "file:///etc/passwd", "http://127.0.0.1/admin", "https://user:pass@example.com",
    "https://sub.example.com/path", "https://example.com.attacker.test/path",
    "https://example.com./path", "https://example.com:8443/path",
    "https://127.0.0.1/path", "https://[::1]/path", "https://example.com/path#fragment",
])
def test_scraper_rejects_targets_outside_exact_allowlist(url):
    client = DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/")
    with pytest.raises(ScrapePolicyError):
        IncognitoScraper(client, allowed_hosts={"example.com"}, allowed_paths="example.com=/").scrape(url)


def test_scraper_fails_closed_without_allowlist():
    with pytest.raises(ScrapePolicyError, match="allowlist"):
        IncognitoScraper(DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/"),
                         allowed_hosts=set(), allowed_paths="example.com=/")


def test_allowlist_normalizes_idna_and_rejects_wildcards():
    assert parse_allowed_hosts("BÜcher.example.org, example.com") == frozenset({"xn--bcher-kva.example.org", "example.com"})
    with pytest.raises(ScrapePolicyError):
        parse_allowed_hosts("*.example.com")


def test_direct_fetcher_rejects_private_dns_answers(monkeypatch):
    import socket
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443)),
        (socket.AF_INET, socket.SOCK_STREAM, 6, "", ("127.0.0.1", 443)),
    ])
    with pytest.raises(ScrapePolicyError, match="non-public"):
        DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")


def test_direct_fetcher_revalidates_dns_on_redirect_and_blocks_rebinding(monkeypatch):
    import socket
    calls = {"dns": 0, "connect": 0}
    class Response:
        status = 302
        headers = {"Location": "/next", "Content-Type": "text/html"}
        def read(self, limit=-1): return b""
    class Connection:
        def __init__(self, host, ip, timeout): calls["connect"] += 1
        def request(self, *a, **k): pass
        def getresponse(self): return Response()
        def close(self): pass
    def resolve(*args, **kwargs):
        calls["dns"] += 1
        address = "93.184.216.34" if calls["dns"] == 1 else "127.0.0.1"
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (address, 443))]
    monkeypatch.setattr(socket, "getaddrinfo", resolve)
    monkeypatch.setattr("v17_niche_intel.providers.incognito_scraper._PinnedHTTPSConnection", Connection)
    with pytest.raises(ScrapePolicyError, match="non-public"):
        DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")
    assert calls == {"dns": 2, "connect": 1}


def test_direct_fetcher_rejects_cross_origin_redirect_before_second_connection(monkeypatch):
    import socket
    calls = {"connect": 0}
    class Response:
        status = 302
        headers = {"Location": "https://attacker.example.net/steal", "Content-Type": "text/html"}
        def read(self, limit=-1): return b""
    class Connection:
        def __init__(self, host, ip, timeout): calls["connect"] += 1
        def request(self, *a, **k): pass
        def getresponse(self): return Response()
        def close(self): pass
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443))])
    monkeypatch.setattr("v17_niche_intel.providers.incognito_scraper._PinnedHTTPSConnection", Connection)
    with pytest.raises(ScrapePolicyError, match="allowlist"):
        DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")
    assert calls["connect"] == 1


def test_direct_fetcher_bounds_response_and_extracts_html(monkeypatch):
    import socket
    from v17_niche_intel.providers import incognito_scraper as module
    class Response:
        status = 200
        headers = {"Content-Type": "text/html; charset=utf-8", "Content-Length": "39"}
        def __init__(self): self.limit = None
        def read(self, limit=-1): self.limit = limit; return b"<html><script>bad()</script><p>Hello V17</p></html>"
    response = Response()
    class Connection:
        def __init__(self, host, ip, timeout): pass
        def request(self, *a, **k): pass
        def getresponse(self): return response
        def close(self): pass
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443))])
    monkeypatch.setattr(module, "_PinnedHTTPSConnection", Connection)
    monkeypatch.setattr(module, "_MAX_TARGET_RESPONSE_BYTES", 1024)
    result = DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")
    assert "Hello V17" in result["markdown"]
    assert "bad()" not in result["markdown"]
    assert response.limit == 1025


def test_direct_fetcher_rejects_oversized_content_length(monkeypatch):
    import socket
    from v17_niche_intel.providers import incognito_scraper as module
    class Response:
        status = 200
        headers = {"Content-Type": "text/plain", "Content-Length": "999999"}
        def read(self, limit=-1): raise AssertionError("body must not be read")
    class Connection:
        def __init__(self, host, ip, timeout): pass
        def request(self, *a, **k): pass
        def getresponse(self): return Response()
        def close(self): pass
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443))])
    monkeypatch.setattr(module, "_PinnedHTTPSConnection", Connection)
    monkeypatch.setattr(module, "_MAX_TARGET_RESPONSE_BYTES", 1024)
    with pytest.raises(RuntimeError, match="size limit"):
        DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")


def test_hosted_firecrawl_target_fetch_is_disabled():
    client = FirecrawlHTTPClient("fixture-secret")
    with pytest.raises(ScrapePolicyError, match="(?i)hosted target fetching is disabled"):
        client.scrape("https://example.com/")


def test_dns_rejects_nat64_and_special_purpose_ipv6(monkeypatch):
    import socket
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [
        (socket.AF_INET6, socket.SOCK_STREAM, 6, "", ("64:ff9b::7f00:1", 443, 0, 0))
    ])
    with pytest.raises(ScrapePolicyError, match="non-public or special-purpose"):
        DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")


def test_pinned_https_connection_connects_to_ip_and_keeps_hostname_for_tls(monkeypatch):
    import socket
    from v17_niche_intel.providers import incognito_scraper as module
    observed = {}
    class RawSocket:
        def close(self): observed["closed"] = True
    class Context:
        # http.client.HTTPSConnection validates these SSLContext attributes
        # during construction on Python 3.11 before our connect() override runs.
        check_hostname = True
        verify_mode = module.ssl.CERT_REQUIRED

        def wrap_socket(self, raw, server_hostname):
            observed["sni"] = server_hostname
            return "tls-socket"
    def fake_create_connection(address, timeout, source_address):
        observed["connect_address"] = address
        observed["timeout"] = timeout
        return RawSocket()
    monkeypatch.setattr(module.socket, "create_connection", fake_create_connection)
    monkeypatch.setattr(module.ssl, "create_default_context", lambda: Context())
    connection = module._PinnedHTTPSConnection("approved.example", "93.184.216.34", 9)
    connection.connect()
    assert observed["connect_address"] == ("93.184.216.34", 443)
    assert observed["sni"] == "approved.example"
    assert connection.sock == "tls-socket"


def test_direct_fetcher_rejects_redirect_to_private_ip_literal_before_dns(monkeypatch):
    import socket
    class Response:
        status = 302
        headers = {"Location": "https://127.0.0.1/admin"}
        def read(self, limit=-1): return b""
    class Connection:
        def __init__(self, host, ip, timeout): pass
        def request(self, *a, **k): pass
        def getresponse(self): return Response()
        def close(self): pass
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443))])
    monkeypatch.setattr("v17_niche_intel.providers.incognito_scraper._PinnedHTTPSConnection", Connection)
    with pytest.raises(ScrapePolicyError, match="IP-literal"):
        DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")


def test_dns_rejects_ipv6_special_purpose_orchid_range(monkeypatch):
    import socket
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [
        (socket.AF_INET6, socket.SOCK_STREAM, 6, "", ("2001:20::1", 443, 0, 0))
    ])
    with pytest.raises(ScrapePolicyError, match="non-public or special-purpose"):
        DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")


def test_path_policy_requires_every_host_and_uses_segment_boundary(monkeypatch):
    hosts = parse_allowed_hosts("example.com,docs.example.org")
    with pytest.raises(ScrapePolicyError, match="Every allowlisted hostname"):
        parse_allowed_paths("example.com=/public", hosts)
    policy = parse_allowed_paths("example.com=/public|/articles;docs.example.org=/guides", hosts)
    client = DirectHTTPSFetcher(hosts, allowed_paths="example.com=/public|/articles;docs.example.org=/guides")
    monkeypatch.setattr(client, "scrape", lambda url: {"url": url, "markdown": "public page", "metadata": {}})
    scraper = IncognitoScraper(client, allowed_hosts=hosts,
        allowed_paths="example.com=/public|/articles;docs.example.org=/guides")
    assert scraper.scrape("https://example.com/public/post").markdown == "public page"
    with pytest.raises(ScrapePolicyError, match="path"):
        scraper.scrape("https://example.com/publicity/post")
    with pytest.raises(ScrapePolicyError, match="path"):
        scraper.scrape("https://example.com/private")


@pytest.mark.parametrize("path", ["/public/../admin", "/public/%2e%2e/admin", "/public//admin", "/public\\admin"])
def test_path_policy_rejects_noncanonical_paths(path):
    scraper = IncognitoScraper(DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/public"),
                               allowed_hosts={"example.com"}, allowed_paths="example.com=/public")
    with pytest.raises(ScrapePolicyError):
        scraper.scrape("https://example.com" + path)


def test_direct_fetcher_sends_no_cookie_or_authorization_headers(monkeypatch):
    import socket
    from v17_niche_intel.providers import incognito_scraper as module
    observed = {}
    class Response:
        status = 200
        headers = {"Content-Type": "text/plain", "Content-Length": "2"}
        def read(self, limit=-1): return b"ok"
    class Connection:
        def __init__(self, host, ip, timeout): pass
        def request(self, method, path, headers): observed.update(headers)
        def getresponse(self): return Response()
        def close(self): pass
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443))])
    monkeypatch.setattr(module, "_PinnedHTTPSConnection", Connection)
    DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")
    names = {key.lower() for key in observed}
    assert "cookie" not in names
    assert "authorization" not in names
    assert observed["Host"] == "example.com"


def test_direct_fetcher_rejects_oversized_body_without_content_length(monkeypatch):
    import socket
    from v17_niche_intel.providers import incognito_scraper as module
    class Response:
        status = 200
        headers = {"Content-Type": "text/plain"}
        def __init__(self): self.read_limit = None
        def read(self, limit=-1): self.read_limit = limit; return b"x" * limit
    response = Response()
    class Connection:
        def __init__(self, host, ip, timeout): pass
        def request(self, *a, **k): pass
        def getresponse(self): return response
        def close(self): pass
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443))])
    monkeypatch.setattr(module, "_PinnedHTTPSConnection", Connection)
    monkeypatch.setattr(module, "_MAX_TARGET_RESPONSE_BYTES", 1024)
    with pytest.raises(RuntimeError, match="size limit"):
        DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")
    assert response.read_limit == 1025


def test_direct_fetcher_stops_after_three_redirects(monkeypatch):
    import socket
    from v17_niche_intel.providers import incognito_scraper as module
    calls = {"request": 0}
    class Response:
        status = 302
        headers = {"Location": "/next"}
        def read(self, limit=-1): return b""
    class Connection:
        def __init__(self, host, ip, timeout): pass
        def request(self, *a, **k): calls["request"] += 1
        def getresponse(self): return Response()
        def close(self): pass
    monkeypatch.setattr(socket, "getaddrinfo", lambda *a, **k: [(socket.AF_INET, socket.SOCK_STREAM, 6, "", ("93.184.216.34", 443))])
    monkeypatch.setattr(module, "_PinnedHTTPSConnection", Connection)
    with pytest.raises(RuntimeError, match="redirect limit"):
        DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/").scrape("https://example.com/")
    assert calls["request"] == 4


def test_incognito_scraper_rejects_untrusted_client_and_policy_mismatch(monkeypatch):
    class UntrustedClient:
        def scrape(self, url): return {"url": url, "markdown": "unsafe", "metadata": {}}
    with pytest.raises(TypeError, match="only the built-in DirectHTTPSFetcher"):
        IncognitoScraper(UntrustedClient(), allowed_hosts={"example.com"}, allowed_paths="example.com=/")
    client = DirectHTTPSFetcher({"example.com"}, allowed_paths="example.com=/public")
    with pytest.raises(ScrapePolicyError, match="policies must match"):
        IncognitoScraper(client, allowed_hosts={"example.com"}, allowed_paths="example.com=/private")


@pytest.mark.parametrize("host", ["service.local", "node.internal", "host.test", "localhost.localhost", "ptr.arpa"])
def test_allowlist_rejects_internal_and_special_use_dns_suffixes(host):
    with pytest.raises(ScrapePolicyError, match="special-use"):
        parse_allowed_hosts(host)
