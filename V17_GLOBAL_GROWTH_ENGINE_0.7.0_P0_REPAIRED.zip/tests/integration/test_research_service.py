from v17_niche_intel.storage.database import Database
from v17_niche_intel.services.research import ResearchService

class FakeYouTube:
    def search_videos(self, keyword, region, **kwargs):
        from types import SimpleNamespace
        return SimpleNamespace(status='no_data', videos=(), failed_orders=(), query_orders=('relevance',), detail_failures=0)


def test_market_research_persists_run_and_partial_provider_state():
    db=Database(':memory:')
    service=ResearchService(db, youtube_provider=FakeYouTube())
    result=service.research(topic='coffee roasting', country_code='ID', mode='market_entry')
    assert result['run']['topic']=='coffee roasting'
    assert result['providers']['youtube']['status']=='no_data'
    assert result['analysis']['coverage'] < 1
    db.close()


def test_research_result_is_persisted_and_retrievable():
    from v17_niche_intel.storage.repositories import ResultRepository
    db=Database(':memory:')
    result=ResearchService(db,youtube_provider=FakeYouTube()).research(topic='tea',country_code='ID')
    saved=ResultRepository(db).get(result['run']['id'])
    assert saved['analysis']['status']=='insufficient_evidence'
    db.close()


def test_research_exposes_market_intelligence_and_data_provenance():
    db = Database(':memory:')
    result = ResearchService(db, youtube_provider=FakeYouTube()).research(
        topic='how to roast coffee', country_code='ID', mode='market_entry')
    intel = result['market_intelligence']
    assert intel['search_intent'] == 'informational'
    assert intel['topic_clusters'][0]['topic'] == 'how to roast coffee'
    assert intel['serp_volatility']['status'] == 'insufficient_data'
    assert intel['thumbnail_benchmark']['status'] == 'not_configured'
    assert intel['data_provenance'][0]['source'] == 'youtube_data_api'
    assert intel['confidence']['independent_source_count'] == 0
    db.close()


def test_trends_observation_is_persisted_with_geo_language_and_relative_index_semantics():
    class FakeTrends:
        def interest_over_time(self, keyword, *, geo):
            return {"status": "ok", "geo": geo, "timeframe": "today 12-m",
                    "points": [{"date": "2025-01-01", "value": 20}, {"date": "2025-02-01", "value": 40}],
                    "features": {"mean_relative_interest": 30, "absolute_search_volume": None}}
    db = Database(":memory:")
    result = ResearchService(db, trends_provider=FakeTrends()).research(
        topic="kopi", country_code="ID", language_code="id")
    observations = result["market_intelligence"]["data_provenance"]
    stored = db.connection.execute("SELECT * FROM source_observations WHERE metric='trend_mean_relative_interest'").fetchone()
    assert stored is not None
    assert '"metric_semantics":"relative_index_not_search_volume"' in stored["metadata_json"]
    assert result["market_intelligence"]["confidence"]["independent_source_count"] == 1
    db.close()


def test_existing_channel_analytics_is_stored_separately_from_public_evidence():
    from datetime import date
    class FakeAnalytics:
        def query_daily(self, **kwargs):
            return {"records": [{"day": "2025-01-01", "views": 100, "estimatedMinutesWatched": 50}]}
    db = Database(":memory:")
    result = ResearchService(db, analytics_provider=FakeAnalytics()).research(
        topic="coffee", country_code="ID", mode="existing_channel", channel_id="UC_OWNER",
        analytics_start_date=date(2025, 1, 1), analytics_end_date=date(2025, 1, 7))
    assert result["private_channel_analytics"]["status"] == "ok"
    assert result["analysis"]["existing_channel_status"] == "ok"
    assert db.connection.execute("SELECT COUNT(*) FROM channel_analytics_daily_private").fetchone()[0] == 1
    assert db.connection.execute("SELECT COUNT(*) FROM source_observations").fetchone()[0] == 0
    db.close()


def test_research_analyzes_public_comment_pain_points_without_persisting_raw_text():
    class CommentYouTube(FakeYouTube):
        def search_videos(self, keyword, region, **kwargs):
            from datetime import datetime, timezone
            from v17_niche_intel.domain.video import VideoRecord, VideoSearchBatch
            video = VideoRecord(video_id="video-1", title="Coffee grinder", channel_id="channel-1",
                channel_title="Creator", published_at=datetime.now(timezone.utc), views=100,
                likes=5, comments=2, duration_seconds=120, live_broadcast_content="none",
                live_streaming_details={}, url="https://www.youtube.com/watch?v=video-1")
            return VideoSearchBatch((video,), "ok", ("relevance",), ())
        def fetch_public_comments(self, video_id, *, limit):
            return {"status": "ok", "comments": ("noisy grinder is hard to use", "noisy grinder makes recording difficult")}
    db = Database(":memory:")
    result = ResearchService(db, youtube_provider=CommentYouTube()).research(
        topic="coffee grinder", country_code="ID")
    pain = result["market_intelligence"]["audience_pain_points"]
    assert pain["status"] == "ok"
    assert "noisy" in pain["recurring_terms"]
    assert pain["raw_comments_persisted"] is False
    saved = db.connection.execute("SELECT result_json FROM research_results").fetchone()[0]
    assert "noisy grinder is hard to use" not in saved
    db.close()


def test_repeated_snapshot_updates_persisted_growth_history():
    from datetime import datetime, timezone
    from v17_niche_intel.domain.video import VideoRecord, VideoSearchBatch
    from v17_niche_intel.storage.repositories import ResultRepository
    class ChangingYouTube:
        def __init__(self): self.views = 100
        def search_videos(self, keyword, region, **kwargs):
            video = VideoRecord(video_id="same-video", title="Coffee", channel_id="UC1", channel_title="Creator",
                published_at=datetime(2025, 1, 1, tzinfo=timezone.utc), views=self.views, likes=5, comments=1,
                duration_seconds=60, live_broadcast_content="none", live_streaming_details={},
                url="https://www.youtube.com/watch?v=same-video")
            return VideoSearchBatch((video,), "ok", ("relevance",), ())
    db = Database(":memory:")
    provider = ChangingYouTube()
    service = ResearchService(db, youtube_provider=provider)
    first = service.research(topic="coffee", country_code="ID")
    provider.views = 200
    snapshot = service.snapshot(first["run"]["id"])
    saved = ResultRepository(db).get(first["run"]["id"])
    assert snapshot["historical_tracking"]["videos_with_growth_measurement"] == 1
    assert saved["market_intelligence"]["historical_tracking"]["growth_velocity_available"] is True
    assert saved["market_intelligence"]["historical_tracking"]["video_growth"][0]["view_delta"] == 100
    db.close()
