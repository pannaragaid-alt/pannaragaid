"""Deterministic, evidence-aware market intelligence primitives.

These functions analyze observed inputs only. They do not fabricate search volume,
CTR, thumbnail performance, audio measurements, or audience demographics.
"""
from __future__ import annotations

import re
from collections import Counter, defaultdict
from datetime import datetime, timezone
from math import sqrt, isfinite
from statistics import mean, pstdev
from typing import Any, Iterable, Mapping, Sequence

_WORD = re.compile(r"[^\W_]+", re.UNICODE | re.I)
_STOP = {"a", "an", "the", "to", "of", "for", "and", "or", "in", "on", "with", "is", "are", "how", "what", "why", "when", "where", "my", "your", "i", "it", "this", "that", "from", "by", "vs", "review", "tutorial", "dan", "yang", "untuk", "dengan", "dari", "ini", "itu", "cara", "saya", "anda"}
_INFO = {"how", "what", "why", "when", "where", "guide", "tutorial", "learn", "explained", "meaning", "ways", "cara", "bagaimana", "apa", "mengapa", "panduan", "belajar"}
_COMMERCIAL = {"best", "top", "review", "reviews", "compare", "comparison", "vs", "versus", "worth", "recommendation", "terbaik", "perbandingan", "rekomendasi"}
_TRANSACTIONAL = {"buy", "purchase", "order", "price", "coupon", "discount", "deal", "shop", "subscribe", "download", "beli", "harga", "diskon", "pesan", "langganan"}


def _tokens(value: str) -> set[str]:
    tokens = set()
    for word in _WORD.findall(value.lower()):
        if word in _STOP or len(word) < 2:
            continue
        if word.endswith("ing") and len(word) > 5:
            word = word[:-3]
        elif word.endswith("ies") and len(word) > 4:
            word = word[:-3] + "y"
        elif word.endswith("s") and len(word) > 4:
            word = word[:-1]
        tokens.add(word)
    return tokens


def classify_search_intent(query: str) -> str:
    if not isinstance(query, str) or not query.strip():
        raise ValueError("query must be non-empty")
    words = set(_WORD.findall(query.lower()))
    transactional = bool(words & _TRANSACTIONAL)
    commercial = bool(words & _COMMERCIAL)
    informational = bool(words & _INFO)
    if transactional:
        return "transactional"
    if commercial:
        return "commercial"
    if informational:
        return "informational"
    return "mixed_or_unknown"


def cluster_topics(topics: Sequence[str], *, similarity_threshold: float = 0.5) -> list[dict[str, Any]]:
    if not 0 < similarity_threshold <= 1:
        raise ValueError("similarity_threshold must be in (0, 1]")
    clusters: list[dict[str, Any]] = []
    centroids: list[set[str]] = []
    for topic in topics:
        if not isinstance(topic, str) or not topic.strip():
            raise ValueError("topics must contain non-empty strings")
        terms = _tokens(topic)
        if not terms:
            index = len(clusters)
            clusters.append({"cluster_id": f"topic-{index + 1:03d}", "topic": topic, "members": [topic]})
            centroids.append(set())
            continue
        best_index, best_score = None, 0.0
        for index, centroid in enumerate(centroids):
            union = terms | centroid
            score = len(terms & centroid) / len(union) if union else 1.0
            if score > best_score:
                best_index, best_score = index, score
        if best_index is None or best_score < similarity_threshold:
            best_index = len(clusters)
            clusters.append({"cluster_id": f"topic-{best_index + 1:03d}", "topic": topic, "members": [topic]})
            centroids.append(set(terms))
        else:
            clusters[best_index]["members"].append(topic)
            centroids[best_index].update(terms)
    return [{"cluster_id": item["cluster_id"], "topic": item["topic"], "members": item["members"]}
            for item in clusters for _ in item["members"]]


def competitor_overlap(keyword_channels: Mapping[str, Sequence[str]]) -> list[dict[str, Any]]:
    channel_keywords: dict[str, list[str]] = defaultdict(list)
    for keyword, channels in keyword_channels.items():
        if not keyword.strip():
            raise ValueError("keyword keys must be non-empty")
        for channel in set(channels):
            if channel:
                channel_keywords[str(channel)].append(keyword)
    return [{"channel_id": channel, "keyword_count": len(keywords), "keywords": sorted(keywords)}
            for channel, keywords in sorted(channel_keywords.items(), key=lambda item: (-len(item[1]), item[0]))]


def calculate_serp_volatility(snapshots: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if len(snapshots) < 2:
        return {"status": "insufficient_data", "snapshot_count": len(snapshots), "mean_absolute_rank_change": None}
    normalized = []
    for snapshot in snapshots:
        if not isinstance(snapshot, Mapping) or not snapshot.get("observed_at") or not isinstance(snapshot.get("results"), Sequence):
            return {"status": "insufficient_data", "snapshot_count": len(snapshots),
                    "mean_absolute_rank_change": None, "reason": "Each SERP snapshot requires observed_at and ordered results."}
        observed_at = datetime.fromisoformat(str(snapshot["observed_at"]).replace("Z", "+00:00"))
        if observed_at.tzinfo is None or observed_at.utcoffset() is None:
            raise ValueError("SERP snapshot timestamps must be timezone-aware")
        results = list(snapshot["results"])
        if any(not isinstance(item, str) or not item for item in results):
            raise ValueError("SERP result identifiers must be non-empty strings")
        if len(results) != len(set(results)):
            raise ValueError("each SERP snapshot must contain unique result identifiers")
        normalized.append((observed_at, results))
    normalized.sort(key=lambda item: item[0])
    changes = []
    for (previous_time, previous), (current_time, current) in zip(normalized, normalized[1:]):
        if current_time <= previous_time:
            raise ValueError("SERP snapshot timestamps must be strictly increasing")
        prev_rank = {item: index + 1 for index, item in enumerate(previous)}
        curr_rank = {item: index + 1 for index, item in enumerate(current)}
        common = set(prev_rank) & set(curr_rank)
        if common:
            changes.extend(abs(prev_rank[item] - curr_rank[item]) for item in common)
    if not changes:
        return {"status": "non_comparable", "snapshot_count": len(snapshots), "mean_absolute_rank_change": None}
    value = mean(changes)
    intervals = [(normalized[i + 1][0] - normalized[i][0]).total_seconds() / 86400
                 for i in range(len(normalized) - 1)]
    return {"status": "ok", "snapshot_count": len(snapshots),
            "mean_absolute_rank_change": round(value, 6),
            "volatility_index": round(value / max(1, max(map(len, [item[1] for item in normalized])) - 1), 4),
            "mean_snapshot_interval_days": round(mean(intervals), 3),
            "matched_rank_observations": len(changes), "time_aware": True}


def detect_cannibalization(video_assignments: Sequence[Mapping[str, str]]) -> list[dict[str, Any]]:
    by_intent: dict[str, list[str]] = defaultdict(list)
    for row in video_assignments:
        video_id, intent = row.get("video_id"), row.get("intent")
        if not video_id or not intent:
            raise ValueError("each assignment requires video_id and intent")
        by_intent[intent].append(video_id)
    return [{"intent": intent, "video_ids": sorted(set(ids))}
            for intent, ids in sorted(by_intent.items()) if len(set(ids)) > 1]


def analyze_seasonality(observations: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    monthly: dict[int, list[float]] = defaultdict(list)
    months_seen = set()
    for row in observations:
        date = datetime.fromisoformat(str(row["date"]).replace("Z", "+00:00"))
        value = float(row["value"])
        if not isfinite(value) or value < 0:
            raise ValueError("seasonality values must be finite and non-negative")
        monthly[date.month].append(value)
        months_seen.add((date.year, date.month))
    if len(months_seen) < 12:
        return {"status": "insufficient_data", "observed_months": len(months_seen), "monthly_profile": {}}
    profile = {month: round(mean(values), 4) for month, values in sorted(monthly.items())}
    peak = max(profile, key=profile.get)
    trough = min(profile, key=profile.get)
    overall = mean(profile.values())
    return {"status": "ok", "observed_months": len(months_seen), "monthly_profile": profile,
            "peak_month": peak, "trough_month": trough,
            "seasonal_amplitude_pct": round((profile[peak] - profile[trough]) / max(overall, 1e-12) * 100, 2),
            "recurrence_confirmed": len({year for year, _ in months_seen}) >= 2,
            "note": "One year describes monthly variation; recurring seasonality requires at least two years."}


def segment_market(observations: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    country: dict[str, float] = defaultdict(float)
    language: dict[str, float] = defaultdict(float)
    by_metric: dict[str, dict[str, dict[str, float]]] = defaultdict(lambda: {"country": defaultdict(float), "language": defaultdict(float)})
    for row in observations:
        value = float(row["value"])
        if not isfinite(value): raise ValueError("market values must be finite")
        if not (row.get("country") and row.get("language")):
            raise ValueError("each observation requires country and language")
        metric = str(row.get("metric", "value"))
        country_code, language_code = str(row["country"]).upper(), str(row["language"]).lower()
        by_metric[metric]["country"][country_code] += value
        by_metric[metric]["language"][language_code] += value
    for metric in by_metric:
        by_metric[metric] = {axis: dict(sorted(values.items())) for axis, values in by_metric[metric].items()}
    if len(by_metric) == 1:
        only = next(iter(by_metric.values()))
        country, language = only["country"], only["language"]
    else:
        country, language = {}, {}
    return {"by_country": country, "by_language": language, "by_metric": dict(sorted(by_metric.items())),
            "observation_count": len(observations), "cross_market_comparable": False,
            "note": "Metrics are never aggregated together; independently normalized indices are not cross-country comparable."}


def assess_freshness(observed_at: datetime, *, now: datetime | None = None, max_age_days: float = 30) -> dict[str, Any]:
    reference = now or datetime.now(timezone.utc)
    if observed_at.tzinfo is None or observed_at.utcoffset() is None or reference.tzinfo is None or reference.utcoffset() is None:
        raise ValueError("timestamps must be timezone-aware")
    if max_age_days < 0:
        raise ValueError("max_age_days cannot be negative")
    age = max(0.0, (reference - observed_at).total_seconds() / 86400)
    return {"status": "fresh" if age <= max_age_days else "stale", "age_days": round(age, 3),
            "max_age_days": max_age_days, "observed_at": observed_at.isoformat(),
            "checked_at": reference.isoformat()}


def _average(rows: Sequence[Mapping[str, Any]], key: str) -> float | None:
    values = [float(row[key]) for row in rows if row.get(key) is not None]
    return round(mean(values), 4) if values else None


def benchmark_thumbnail_metadata(samples: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if not samples:
        return {"status": "insufficient_data", "sample_size": 0}
    for row in samples:
        if int(row.get("width", 0)) <= 0 or int(row.get("height", 0)) <= 0:
            raise ValueError("thumbnail dimensions must be positive")
        if row.get("text_coverage") is not None and (not isfinite(float(row["text_coverage"])) or not 0 <= float(row["text_coverage"]) <= 1):
            raise ValueError("text_coverage must be finite and between 0 and 1")
        if row.get("contrast_score") is not None and (not isfinite(float(row["contrast_score"])) or not 0 <= float(row["contrast_score"]) <= 1):
            raise ValueError("contrast_score must be finite and between 0 and 1")
    return {"status": "ok", "sample_size": len(samples),
            "mean_aspect_ratio": round(mean(int(x["width"]) / int(x["height"]) for x in samples), 4),
            "face_presence_rate": round(mean(bool(x.get("has_face")) for x in samples), 4),
            "mean_text_coverage": _average(samples, "text_coverage"),
            "mean_contrast_score": _average(samples, "contrast_score"),
            "metric_semantics": "visual_metadata_descriptive_only; not CTR or performance"}


def benchmark_audio_metrics(samples: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    if not samples:
        return {"status": "insufficient_data", "sample_size": 0}
    bounded = {"clipping_ratio", "silence_ratio"}
    for row in samples:
        for key, raw in row.items():
            if raw is not None and isinstance(raw, (int, float)) and not isfinite(float(raw)):
                raise ValueError(f"{key} must be finite")
        for key in bounded:
            if row.get(key) is not None and not 0 <= float(row[key]) <= 1:
                raise ValueError(f"{key} must be between 0 and 1")
    return {"status": "ok", "sample_size": len(samples),
            "mean_integrated_lufs": _average(samples, "integrated_lufs"),
            "mean_true_peak_dbfs": _average(samples, "true_peak_dbfs"),
            "mean_clipping_ratio": _average(samples, "clipping_ratio"),
            "mean_silence_ratio": _average(samples, "silence_ratio"),
            "mean_snr_db": _average(samples, "snr_db"),
            "mean_sample_peak_dbfs": _average(samples, "sample_peak_dbfs"),
            "mean_rms_dbfs": _average(samples, "rms_dbfs"),
            "mean_sample_rate_hz": _average(samples, "sample_rate_hz"),
            "metric_semantics": "measured_audio_features; no subjective_quality_claim"}


def extract_audience_pain_points(texts: Sequence[str], *, minimum_frequency: int = 2) -> dict[str, Any]:
    if minimum_frequency < 1:
        raise ValueError("minimum_frequency must be positive")
    counts = Counter(word for text in texts for word in _tokens(text))
    recurring = [{"term": word, "mentions": count} for word, count in counts.most_common()
                 if count >= minimum_frequency]
    return {"status": "ok" if texts else "insufficient_data", "sample_size": len(texts),
            "recurring_terms": [row["term"] for row in recurring], "term_counts": recurring,
            "note": "Frequency-based discovery only; human review is required to validate pain points and context."}


def validate_experiment(baseline: Sequence[float], treatment: Sequence[float], *, metric: str,
                        minimum_sample_size: int = 5) -> dict[str, Any]:
    if not metric.strip() or minimum_sample_size < 2:
        raise ValueError("metric and a minimum sample size of at least two are required")
    before, after = [float(x) for x in baseline], [float(x) for x in treatment]
    if any(not isfinite(x) for x in before + after):
        raise ValueError("experiment metrics must be finite")
    if any(x < 0 for x in before + after):
        raise ValueError("experiment metrics cannot be negative")
    if len(before) < minimum_sample_size or len(after) < minimum_sample_size:
        return {"status": "insufficient_data", "metric": metric, "baseline_n": len(before),
                "treatment_n": len(after), "absolute_lift": None, "relative_lift_pct": None}
    base_mean, treatment_mean = mean(before), mean(after)
    delta = treatment_mean - base_mean
    base_var, treatment_var = pstdev(before) ** 2, pstdev(after) ** 2
    standard_error = sqrt(base_var / len(before) + treatment_var / len(after))
    ci = [delta - 1.96 * standard_error, delta + 1.96 * standard_error]
    return {"status": "evaluated", "metric": metric, "baseline_n": len(before), "treatment_n": len(after),
            "baseline_mean": round(base_mean, 6), "treatment_mean": round(treatment_mean, 6),
            "absolute_lift": round(delta, 6),
            "relative_lift_pct": round(delta / base_mean * 100, 4) if base_mean else None,
            "approx_95pct_ci_absolute_lift": [round(ci[0], 6), round(ci[1], 6)],
            "directional_result": "positive" if ci[0] > 0 else "negative" if ci[1] < 0 else "inconclusive",
            "method": "independent-group normal approximation; directional, not causal proof"}


def analyze_content_freshness(videos: Sequence[Mapping[str, Any]], *, now: datetime | None = None) -> dict[str, Any]:
    """Describe recency and lifetime-average performance of a public video sample."""
    reference = now or datetime.now(timezone.utc)
    if reference.tzinfo is None or reference.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    ages: list[float] = []
    recent_30: list[Mapping[str, Any]] = []
    older: list[Mapping[str, Any]] = []
    for video in videos:
        published = datetime.fromisoformat(str(video["published_at"]).replace("Z", "+00:00"))
        if published.tzinfo is None or published.utcoffset() is None:
            raise ValueError("published_at timestamps must be timezone-aware")
        age = max(0.0, (reference - published).total_seconds() / 86400)
        ages.append(age)
        (recent_30 if age <= 30 else older).append(video)
    if not ages:
        return {"status": "insufficient_data", "sample_size": 0}
    def lifetime_rate(rows: Sequence[Mapping[str, Any]]) -> float | None:
        rates = []
        for row in rows:
            views = row.get("views")
            if views is None:
                continue
            published = datetime.fromisoformat(str(row["published_at"]).replace("Z", "+00:00"))
            age_days = max(1.0, (reference - published).total_seconds() / 86400)
            rates.append(float(views) / age_days)
        return round(mean(rates), 3) if rates else None
    return {"status": "ok", "sample_size": len(ages),
            "videos_published_within_7_days": sum(age <= 7 for age in ages),
            "videos_published_within_30_days": len(recent_30),
            "videos_published_within_90_days": sum(age <= 90 for age in ages),
            "recent_30_day_share": round(len(recent_30) / len(ages), 4),
            "median_video_age_days": round(sorted(ages)[len(ages) // 2], 2),
            "recent_30d_lifetime_average_views_per_day": lifetime_rate(recent_30),
            "older_lifetime_average_views_per_day": lifetime_rate(older),
            "rate_semantics": "lifetime_average_not_real_time_velocity",
            "note": "A sample's recent-video share is not a causal freshness ranking signal."}
