from __future__ import annotations
import argparse, json, os, sys
from datetime import date, datetime
from pathlib import Path
from .storage.database import Database
from .ui.input_safety import load_bounded_json_file, parse_bounded_json
from .services.research import ResearchService
from .services.reporting import export_report
from .storage.repositories import ResearchRunRepository, ResultRepository, PrivateAnalyticsRepository, SERPSnapshotRepository, ExperimentRepository, DecisionLogRepository
from .credentials import CredentialManager, KeyringSecretStore, MemorySecretStore, CompositeSecretStore, EnvironmentSecretStore
from .credentials.providers import build_configured_youtube_data_api_provider
from .importers.analytics_csv import validate_analytics_csv
from .providers.incognito_scraper import IncognitoScraper, DirectHTTPSFetcher, parse_allowed_hosts
from .providers.firecrawl_search import FirecrawlSearchProvider
from .providers.youtube_analytics import YouTubeAnalyticsProvider, READONLY_SCOPE, MONETARY_READONLY_SCOPE
from .services.market_intelligence import MarketIntelligenceService
from .storage.secure_backup import create_encrypted_backup, restore_encrypted_backup, check_secret_store
from .services.retention import purge_expired_public_youtube_data
from .services.growth_intelligence import analyze_growth_bundle
from .providers.google_trends import GoogleTrendsProvider


def _service(db_path: str):
    db = Database(db_path)
    try:
        provider = build_configured_youtube_data_api_provider(db, use_case="market_research", environment="local")
    except Exception:
        db.close()
        raise
    return db, provider


def main(argv=None) -> int:
    parser=argparse.ArgumentParser(prog="v17",description="Evidence-aware YouTube niche intelligence")
    parser.add_argument("--database",default="v17_niche_intel.sqlite3")
    sub=parser.add_subparsers(dest="command",required=True)
    mc=sub.add_parser("metrics",help="List versioned YouTube Analytics metric definitions and required scopes")
    mc.add_argument("--json",action="store_true")
    r=sub.add_parser("research"); r.add_argument("topic"); r.add_argument("--country",default="US"); r.add_argument("--mode",choices=["market_entry","existing_channel","both"],default="market_entry"); r.add_argument("--limit",type=int,default=25); r.add_argument("--language",default=None); r.add_argument("--channel-id"); r.add_argument("--analytics-start-date"); r.add_argument("--analytics-end-date"); r.add_argument("--output")
    i=sub.add_parser("import-analytics"); i.add_argument("csv_path"); i.add_argument("--channel-id",required=True)
    ya=sub.add_parser("analytics",help="Fetch owner-authorized read-only YouTube Analytics")
    ya.add_argument("--channel-id",required=True); ya.add_argument("--start-date",required=True); ya.add_argument("--end-date",required=True)
    d=sub.add_parser("doctor"); d.add_argument("--json",action="store_true")
    rp=sub.add_parser("purge-expired",help="Purge expired public YouTube API-derived research data")
    rp.add_argument("--retention-days",type=int,default=30)
    b=sub.add_parser("backup",help="Create a password-encrypted database + secret backup")
    b.add_argument("--output",default="v17-backup.v17enc")
    rb=sub.add_parser("restore",help="Restore an encrypted backup into a new database and secret vault")
    rb.add_argument("backup_file"); rb.add_argument("--target-database",required=True)
    serp=sub.add_parser("serp-collect",help="Collect timestamped public web SERP snapshots for keyword tracking")
    serp.add_argument("--keyword",action="append",required=True); serp.add_argument("--country",default="ID")
    serp.add_argument("--language",default="id"); serp.add_argument("--location",default=None)
    serp.add_argument("--limit",type=int,default=5); serp.add_argument("--output")
    mi=sub.add_parser("intelligence",help="Analyze a JSON evidence bundle")
    mi.add_argument("input_json"); mi.add_argument("--output")
    ga=sub.add_parser("growth-audit",help="Run evidence-backed retention, localization, competitor, discovery and economics diagnostics")
    ga.add_argument("input_json"); ga.add_argument("--output")
    ga.add_argument("--persist-decisions",action="store_true",help="Persist explicit decision_records from the input JSON to the local decision log")
    ex=sub.add_parser("experiment",help="Manage the persistent experiment registry")
    ex_sub=ex.add_subparsers(dest="experiment_action",required=True)
    ex_create=ex_sub.add_parser("create"); ex_create.add_argument("experiment_id"); ex_create.add_argument("--idempotency-key",required=True)
    ex_create.add_argument("--objective",required=True); ex_create.add_argument("--primary-metric",required=True); ex_create.add_argument("--config-json",default="{}")
    ex_list=ex_sub.add_parser("list"); ex_list.add_argument("--status",action="append"); ex_list.add_argument("--limit",type=int,default=100)
    ex_transition=ex_sub.add_parser("transition"); ex_transition.add_argument("experiment_id"); ex_transition.add_argument("status",choices=["planned","running","paused","completed","failed","cancelled"])
    ex_result=ex_sub.add_parser("record-result"); ex_result.add_argument("experiment_id"); ex_result.add_argument("--result-json",required=True)
    dl=sub.add_parser("decision-log",help="List or transition evidence-linked strategic decisions")
    dl_sub=dl.add_subparsers(dest="decision_action")
    dl.add_argument("--topic"); dl.add_argument("--limit",type=int,default=100)
    dl_transition=dl_sub.add_parser("transition"); dl_transition.add_argument("decision_id")
    dl_transition.add_argument("status",choices=["proposed","accepted","rejected","implemented","validated"])
    dl_transition.add_argument("--outcome-json",default="{}")
    cs=sub.add_parser("strategy",help="Build an evidence-linked channel foundation and positioning blueprint")
    cs.add_argument("input_json"); cs.add_argument("--output")
    gg=sub.add_parser("global-growth",help="Run the integrated eight-priority global growth intelligence engine")
    gg.add_argument("input_json"); gg.add_argument("--output")
    gg.add_argument("--live-market-discovery",action="store_true",help="Query all YouTube-supported country/language market profiles using configured API credentials")
    gg.add_argument("--market-limit",type=int,default=25)
    gg.add_argument("--search-call-budget",type=int,default=80)
    gg.add_argument("--query-variant-limit",type=int,default=2,help="Sample up to N curated/localized query variants per market within the explicit quota budget")
    gg.add_argument("--machine-translate",action="store_true",help="Use machine translation for discovery only; native review remains mandatory")
    gg.add_argument("--google-trends",action="store_true",help="Collect market-local relative trend indices; requires trends extra")
    gg.add_argument("--trends-call-budget",type=int,default=40)
    gg.add_argument("--live-web-serp",action="store_true",help="Collect bounded public web SERPs for discovered markets; requires FIRECRAWL_API_KEY and input allowed_hosts")
    gg.add_argument("--serp-call-budget",type=int,default=40)
    gg.add_argument("--serp-limit",type=int,default=5)
    gg.add_argument("--channel-analytics",action="store_true",help="Fetch owner-authorized read-only channel KPIs and persist private daily rows")
    gg.add_argument("--channel-id")
    gg.add_argument("--analytics-start-date")
    gg.add_argument("--analytics-end-date")
    gg.add_argument("--analytics-currency",default="USD")
    sc=sub.add_parser("scrape",help="owner-allowlisted direct HTTPS scrape; DNS-pinned, no cookies or browser profile"); sc.add_argument("url"); sc.add_argument("--output")
    for name in ("snapshot","compare","report"):
        p=sub.add_parser(name); p.add_argument("run_id",nargs="?"); p.add_argument("--output")
    args=parser.parse_args(argv)
    if args.command == "metrics":
        from .services.metric_registry import METRIC_REGISTRY
        definitions = METRIC_REGISTRY.as_dicts()
        if args.json:
            print(json.dumps({"registry_version": METRIC_REGISTRY.version, "metrics": definitions}, indent=2))
        else:
            print(f"Registry: {METRIC_REGISTRY.version}")
            for item in definitions:
                print(f"{item['api_name']} | {item['unit']} | {', '.join(item['supported_endpoints'])}")
        return 0
    if args.command == "purge-expired":
        db = Database(args.database)
        try:
            result = purge_expired_public_youtube_data(db, retention_days=args.retention_days)
            print(json.dumps(result, indent=2)); return 0
        except Exception as exc:
            print(f"Retention purge failed: {type(exc).__name__}: {exc}", file=sys.stderr); return 5
        finally:
            db.close()
    if args.command == "serp-collect":
        db = Database(args.database)
        try:
            api_key = os.getenv("FIRECRAWL_API_KEY")
            if not api_key: raise ValueError("FIRECRAWL_API_KEY is not configured")
            provider = FirecrawlSearchProvider(api_key)
            repository = SERPSnapshotRepository(db)
            for keyword in dict.fromkeys(args.keyword):
                snapshot = provider.search(keyword, country=args.country, location=args.location, limit=args.limit)
                if snapshot["status"] == "ok":
                    repository.add(keyword=keyword, country=args.country, language=args.language,
                        observed_at=datetime.fromisoformat(snapshot["observed_at"]),
                        results=[{"url": item["url"]} for item in snapshot["results"]], source="firecrawl_search")
            snapshots = {keyword: repository.list_for_keyword(keyword, country=args.country) for keyword in dict.fromkeys(args.keyword)}
            latest = {keyword: rows[-1]["results"] for keyword, rows in snapshots.items() if rows}
            report = MarketIntelligenceService().analyze({"keywords": list(dict.fromkeys(args.keyword)),
                "serp_snapshots_by_keyword": snapshots, "serp_results_by_keyword": latest})
            report["collection"] = {"source": "firecrawl_search", "country": args.country.upper(),
                "language": args.language, "location": args.location, "keyword_count": len(snapshots),
                "snapshots_saved": sum(len(rows) for rows in snapshots.values()),
                "cache_policy": "provider_managed", "client_network_proxy": "disabled"}
            encoded = json.dumps(report, ensure_ascii=False, indent=2, default=str)
            if args.output: Path(args.output).write_text(encoded, encoding="utf-8")
            print(encoded); return 0
        except Exception as exc:
            print(f"SERP collection failed: {type(exc).__name__}: {exc}", file=sys.stderr); return 4
        finally:
            db.close()
    if args.command == "backup":
        from getpass import getpass
        db = Database(args.database)
        try:
            try: keyring_store = KeyringSecretStore()
            except RuntimeError: keyring_store = None
            source_store = CompositeSecretStore(keyring_store, EnvironmentSecretStore(prefix="", allowed_names={"YOUTUBE_API_KEY"}))
            first = getpass("Backup passphrase (12+ characters): ")
            second = getpass("Confirm backup passphrase: ")
            if first != second: raise ValueError("passphrases do not match")
            result = create_encrypted_backup(db, source_store, args.output, passphrase=first)
            print(json.dumps(result, indent=2)); return 0
        except Exception as exc:
            print(f"Backup failed: {type(exc).__name__}: {exc}", file=sys.stderr); return 6
        finally:
            db.close()
    if args.command == "restore":
        from getpass import getpass
        try:
            passphrase = getpass("Backup passphrase: ")
            result = restore_encrypted_backup(args.backup_file, args.target_database,
                KeyringSecretStore(), passphrase=passphrase)
            print(json.dumps(result, indent=2)); return 0
        except Exception as exc:
            print(f"Restore failed: {type(exc).__name__}: {exc}", file=sys.stderr); return 6
    if args.command == "global-growth":
        db = None
        try:
            from .services.global_growth_engine import (run_global_growth_engine,
                aggregate_channel_analytics_records, calculate_channel_kpis)
            payload = load_bounded_json_file(args.input_json)
            if (args.live_web_serp or args.machine_translate or args.google_trends) and not args.live_market_discovery:
                raise ValueError("--live-web-serp, --machine-translate and --google-trends require --live-market-discovery")
            if args.live_market_discovery and (not 1 <= args.market_limit <= 50 or args.search_call_budget < 0 or args.trends_call_budget < 0 or not 1 <= args.query_variant_limit <= 12):
                raise ValueError("market limit must be 1-50; query variant limit 1-12; search and trends budgets must be non-negative")
            if args.live_web_serp:
                if not os.getenv("FIRECRAWL_API_KEY"):
                    raise ValueError("FIRECRAWL_API_KEY is not configured")
                if not payload.get("allowed_hosts"):
                    raise ValueError("--live-web-serp requires an explicit non-empty allowed_hosts list in input JSON")
                if args.serp_call_budget < 1 or not 1 <= args.serp_limit <= 10:
                    raise ValueError("SERP call budget must be positive and SERP limit must be 1-10")
                from .services.global_growth_engine import collect_market_serps
                collect_market_serps([], provider=object(), allowed_hosts=payload["allowed_hosts"],
                    call_budget=args.serp_call_budget, limit=args.serp_limit)
            translator = None
            if args.machine_translate:
                try:
                    from deep_translator import GoogleTranslator
                except ImportError as exc:
                    raise RuntimeError("Install translation extra before using --machine-translate") from exc
                translator = lambda seed, target: GoogleTranslator(source="auto", target=target).translate(seed)
            trends_factory = None
            if args.google_trends:
                from .providers.google_trends import GoogleTrendsProvider
                trends_factory = lambda market: GoogleTrendsProvider(language_code=market.language_code, locale=market.locale)
            analytics_dates = None
            if args.channel_analytics:
                if not args.channel_id or not args.analytics_start_date or not args.analytics_end_date:
                    raise ValueError("--channel-analytics requires --channel-id, --analytics-start-date and --analytics-end-date")
                analytics_start = date.fromisoformat(args.analytics_start_date)
                analytics_end = date.fromisoformat(args.analytics_end_date)
                if analytics_start > analytics_end:
                    raise ValueError("analytics start date must not be after end date")
                analytics_dates = (analytics_start, analytics_end)
            preflight_payload = dict(payload)
            if args.channel_analytics:
                preflight_payload["analytics"] = None
                preflight_payload["country_rpm_evidence"] = []
            run_global_growth_engine(preflight_payload)

            if args.channel_analytics:
                db = Database(args.database)
                manager = CredentialManager(db, KeyringSecretStore())
                analytics_start, analytics_end = analytics_dates
                metrics = "views,engagedViews,estimatedMinutesWatched,averageViewDuration,averageViewPercentage,subscribersGained,estimatedRevenue"
                from .services.metric_registry import plan_daily_analytics_query
                analytics_plan = plan_daily_analytics_query(metrics)
                client = manager.build_youtube_analytics_client(args.channel_id,
                    required_scopes=set(analytics_plan.required_scopes))
                analytics_provider = YouTubeAnalyticsProvider(client)
                analytics_result = analytics_provider.query_daily(channel_id=args.channel_id,
                    start_date=analytics_start, end_date=analytics_end, metrics=metrics, currency=args.analytics_currency)
                daily_rows = tuple({"date": row["day"], **{key: value for key, value in row.items() if key != "day"}}
                                   for row in analytics_result["records"])
                repository = PrivateAnalyticsRepository(db)
                inserted = repository.import_daily_rows(channel_id=args.channel_id, rows=daily_rows, provenance=analytics_result.get("provenance")) if daily_rows else 0
                country_result = analytics_provider.query_country_economics(channel_id=args.channel_id,
                    start_date=analytics_start, end_date=analytics_end, currency=args.analytics_currency)
                country_inserted = repository.import_country_rows(channel_id=args.channel_id,
                    start_date=args.analytics_start_date, end_date=args.analytics_end_date,
                    currency=args.analytics_currency, rows=tuple(country_result["records"]),
                    provenance=country_result.get("provenance")) if country_result["records"] else 0
                aggregated = aggregate_channel_analytics_records(analytics_result["records"], currency=args.analytics_currency) if analytics_result["records"] else {"source": "owner_authorized_youtube_analytics", "views": 0, "currency": args.analytics_currency}
                payload["analytics"] = calculate_channel_kpis(aggregated)
                payload["country_rpm_evidence"] = country_result["records"]
                payload["country_rpm_period"] = [args.analytics_start_date, args.analytics_end_date]
                payload["analytics_collection"] = {"status": "ok" if daily_rows else "no_data", "date_range": [args.analytics_start_date, args.analytics_end_date],
                    "daily_rows_returned": len(daily_rows), "daily_rows_inserted": inserted,
                    "country_rows_returned": len(country_result["records"]), "country_rows_inserted": country_inserted,
                    "private_data": True, "revenue_adjustment_note": "YouTube estimated revenue may be adjusted at month-end.",
                    "oauth_scopes_required": [READONLY_SCOPE, MONETARY_READONLY_SCOPE]}

            discovery = None
            profiles = None
            web_serp_provider = None
            if args.live_market_discovery:
                from .services.global_market import GlobalMarketDiscoveryService, build_market_registry
                if db is None:
                    db, youtube = _service(args.database)
                else:
                    youtube = build_configured_youtube_data_api_provider(db, use_case="market_research", environment="local")
                supported_regions = youtube.list_supported_regions()
                profiles = build_market_registry(supported_regions)
                discovery = GlobalMarketDiscoveryService(youtube_provider=youtube,
                    trends_provider_factory=trends_factory, translator=translator)
                options = dict(payload.get("market_discovery_options") or {})
                options.update({"limit": args.market_limit, "search_call_budget": args.search_call_budget,
                    "query_variant_limit": args.query_variant_limit,
                    "trends_call_budget": args.trends_call_budget if args.google_trends else None,
                    "other_quota_preconsumed_units": 1, "market_registry_source": "youtube_i18nRegions_plus_CLDR"})
                payload["market_discovery_options"] = options
                if args.live_web_serp:
                    web_serp_provider = FirecrawlSearchProvider(os.getenv("FIRECRAWL_API_KEY"))
                    payload["serp_call_budget"] = args.serp_call_budget
                    payload["serp_limit"] = args.serp_limit
            result = run_global_growth_engine(payload, market_discovery_service=discovery,
                market_profiles=profiles, web_serp_provider=web_serp_provider,
                external_requests_made=bool(args.channel_analytics))
            if payload.get("analytics_collection"):
                result["capabilities"]["channel_analytics"]["collection"] = payload["analytics_collection"]
            encoded = json.dumps(result, ensure_ascii=False, indent=2, default=str)
            if args.output: Path(args.output).write_text(encoded, encoding="utf-8")
            print(encoded)
            return 0
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError, RuntimeError) as exc:
            print(f"Global growth engine failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
        finally:
            if db is not None:
                db.close()
    if args.command == "growth-audit":
        db = None
        try:
            payload = load_bounded_json_file(args.input_json)
            result = analyze_growth_bundle(payload)
            if args.persist_decisions:
                records = payload.get("decision_records", [])
                if not isinstance(records, list):
                    raise ValueError("decision_records must be a list")
                db = Database(args.database)
                repository = DecisionLogRepository(db)
                inserted = 0
                for record in records:
                    if not isinstance(record, dict):
                        raise ValueError("each decision record must be an object")
                    inserted += int(repository.add(**record))
                result["decision_log_inputs"] = {"status": "persisted", "submitted_count": len(records),
                    "inserted_count": inserted, "duplicate_or_existing_count": len(records) - inserted}
            encoded = json.dumps(result, ensure_ascii=False, indent=2)
            if args.output: Path(args.output).write_text(encoded, encoding="utf-8")
            print(encoded)
            return 0
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            print(f"Growth audit failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
        finally:
            if db is not None: db.close()
    if args.command == "decision-log":
        db = Database(args.database)
        try:
            repository = DecisionLogRepository(db)
            if args.decision_action == "transition":
                outcome = parse_bounded_json(args.outcome_json)
                changed = repository.transition(args.decision_id, args.status, outcome=outcome)
                print(json.dumps({"transitioned": changed, "decision": repository.get(args.decision_id)}, indent=2))
            else:
                print(json.dumps(repository.list(topic=args.topic, limit=args.limit), indent=2))
            return 0
        except (json.JSONDecodeError, ValueError) as exc:
            print(f"Decision log failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
        finally:
            db.close()
    if args.command == "experiment":
        db = Database(args.database)
        try:
            repository = ExperimentRepository(db)
            if args.experiment_action == "create":
                config = parse_bounded_json(args.config_json)
                created = repository.create(experiment_id=args.experiment_id,
                    idempotency_key=args.idempotency_key, objective=args.objective,
                    primary_metric=args.primary_metric, config=config)
                print(json.dumps({"created": created, "experiment": repository.get(args.experiment_id)}, indent=2))
            elif args.experiment_action == "list":
                print(json.dumps(repository.list(statuses=tuple(args.status) if args.status else None,
                    limit=args.limit), indent=2))
            elif args.experiment_action == "record-result":
                result = parse_bounded_json(args.result_json)
                changed = repository.record_result(args.experiment_id, result)
                print(json.dumps({"recorded": changed, "experiment": repository.get(args.experiment_id)}, indent=2))
            else:
                changed = repository.transition(args.experiment_id, args.status)
                print(json.dumps({"transitioned": changed, "experiment": repository.get(args.experiment_id)}, indent=2))
            return 0
        except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            print(f"Experiment command failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
        finally:
            db.close()
    if args.command == "strategy":
        try:
            from .services.channel_strategy import ChannelStrategyService
            payload = load_bounded_json_file(args.input_json)
            result = ChannelStrategyService().build(payload)
            encoded = json.dumps(result, ensure_ascii=False, indent=2)
            if args.output: Path(args.output).write_text(encoded, encoding="utf-8")
            print(encoded)
            return 0
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            print(f"Channel strategy failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
    if args.command == "intelligence":
        try:
            payload = load_bounded_json_file(args.input_json)
            result = MarketIntelligenceService().analyze(payload)
            encoded = json.dumps(result, ensure_ascii=False, indent=2, default=str)
            if args.output: Path(args.output).write_text(encoded, encoding="utf-8")
            print(encoded)
            return 0
        except (OSError, json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
            print(f"Intelligence analysis failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 2
    if args.command == "analytics":
        try:
            start_date, end_date = date.fromisoformat(args.start_date), date.fromisoformat(args.end_date)
            if start_date > end_date: raise ValueError("start-date must not be after end-date")
            db = Database(args.database)
            manager = CredentialManager(db, KeyringSecretStore())
            client = manager.build_youtube_analytics_client(args.channel_id, required_scopes={READONLY_SCOPE})
            result = YouTubeAnalyticsProvider(client).query_daily(channel_id=args.channel_id,
                start_date=start_date, end_date=end_date)
            rows = []
            aliases = {"day": "date", "video": "video_id", "estimatedMinutesWatched": "watch_time_minutes",
                       "averageViewDuration": "average_view_duration_seconds"}
            for record in result["records"]:
                rows.append({aliases.get(key, key): value for key, value in record.items()})
            repository = PrivateAnalyticsRepository(db)
            if rows and "video_id" in rows[0]:
                inserted = repository.import_rows(channel_id=args.channel_id, rows=tuple(rows), provenance=result.get("provenance"))
            else:
                inserted = repository.import_daily_rows(channel_id=args.channel_id, rows=tuple(rows), provenance=result.get("provenance"))
            print(json.dumps({"channel_id": args.channel_id, "private_data": True, "report_grain": "video_day" if rows and "video_id" in rows[0] else "channel_day",
                              "rows_returned": len(rows), "rows_inserted": inserted,
                              "start_date": args.start_date, "end_date": args.end_date}, indent=2))
            return 0
        except Exception as exc:
            print(f"Analytics query failed: {type(exc).__name__}: {exc}", file=sys.stderr)
            return 3
        finally:
            try: db.close()
            except Exception: pass
    if args.command=="import-analytics":
        result=validate_analytics_csv(args.csv_path)
        if result.valid:
            db=Database(args.database)
            try: inserted=PrivateAnalyticsRepository(db).import_rows(channel_id=args.channel_id,rows=result.rows)
            finally: db.close()
        else: inserted=0
        print(json.dumps({"valid":result.valid,"rows":result.row_count,"inserted":inserted,"errors":result.errors,"warnings":result.warnings})); return 0 if result.valid else 2
    if args.command=="scrape":
        try:
            allowed_hosts = parse_allowed_hosts(os.getenv("V17_SCRAPE_ALLOWED_HOSTS"))
            allowed_paths = os.getenv("V17_SCRAPE_ALLOWED_PATHS")
            fetcher = DirectHTTPSFetcher(allowed_hosts, allowed_paths=allowed_paths)
            result = IncognitoScraper(fetcher, allowed_hosts=allowed_hosts, allowed_paths=allowed_paths).scrape(args.url)
            output={"url":result.url,"status_code":result.status_code,"markdown":result.markdown,
                    "privacy_mode":"direct_https_dns_pinned_exact_allowlist_no_cookies_no_profile",
                    "metadata":result.metadata}
            if args.output: Path(args.output).write_text(result.markdown,encoding="utf-8")
            print(json.dumps(output,ensure_ascii=False,indent=2)); return 0
        except Exception as exc:
            print(f"Scrape failed: {type(exc).__name__}: {exc}",file=sys.stderr)
            return 5
    if args.command=="doctor":
        db = Database(args.database)
        try:
            manager = CredentialManager(db, MemorySecretStore())
            inventory = manager.credential_inventory()
            report={"database_path":args.database,"database_status":"ok",
                "youtube_api_key_configured":bool(os.getenv("YOUTUBE_API_KEY")),
                "youtube_project_id_configured":bool(os.getenv("YOUTUBE_API_PROJECT_ID")),
                "oauth_client_id_configured":bool(os.getenv("GOOGLE_OAUTH_CLIENT_ID")),
                "firecrawl_configured":bool(os.getenv("FIRECRAWL_API_KEY")),
                "credentials":inventory,"project_quota":manager.quota_inventory()}
            try: report["secret_vault"] = check_secret_store(KeyringSecretStore())
            except Exception as exc: report["secret_vault"] = {"status": "unavailable", "error_type": type(exc).__name__}
        finally:
            db.close()
        print(json.dumps(report,indent=2) if args.json else "\n".join(f"{k}: {v}" for k,v in report.items())); return 0
    if args.command in {"snapshot","compare","report"}:
        db=Database(args.database)
        try:
            if args.command=="snapshot":
                provider = build_configured_youtube_data_api_provider(db, use_case="market_research", environment="local")
                if not provider: print("No metered YouTube API credential route is configured",file=sys.stderr); return 3
                result=ResearchService(db,youtube_provider=provider).snapshot(args.run_id)
                print(json.dumps(result,indent=2)); return 0
            if args.command=="report":
                result=ResultRepository(db).get(args.run_id)
                if result is None: print("Research run not found",file=sys.stderr); return 4
                if args.output: export_report(result,args.output)
                print(json.dumps(result,ensure_ascii=False,indent=2,default=str)); return 0
            runs=ResearchRunRepository(db)
            with db.read() as conn: rows=conn.execute("SELECT id,topic,mode,country_code,algorithm_version,created_at FROM research_runs ORDER BY created_at DESC LIMIT 100").fetchall()
            payload=[dict(row) for row in rows]
            if args.output: Path(args.output).write_text(json.dumps(payload,indent=2),encoding="utf-8")
            print(json.dumps(payload,indent=2)); return 0
        finally: db.close()
    if args.command=="research":
        db,provider=_service(args.database)
        try:
            trends = None
            try: trends = GoogleTrendsProvider(language_code=args.language or "en")
            except Exception: pass
            analytics_provider = None
            analytics_start = date.fromisoformat(args.analytics_start_date) if args.analytics_start_date else None
            analytics_end = date.fromisoformat(args.analytics_end_date) if args.analytics_end_date else None
            if args.channel_id and args.mode in {"existing_channel", "both"}:
                manager = CredentialManager(db, KeyringSecretStore())
                analytics_client = manager.build_youtube_analytics_client(args.channel_id, required_scopes={READONLY_SCOPE})
                analytics_provider = YouTubeAnalyticsProvider(analytics_client)
            result=ResearchService(db,youtube_provider=provider,trends_provider=trends,
                analytics_provider=analytics_provider).research(
                topic=args.topic,country_code=args.country,mode=args.mode,limit=args.limit,language_code=args.language,
                channel_id=args.channel_id,analytics_start_date=analytics_start,analytics_end_date=analytics_end)
            if args.output: export_report(result,args.output)
            print(json.dumps(result,ensure_ascii=False,indent=2,default=str)); return 0
        finally: db.close()
    parser.error(f"unsupported command: {args.command}")
    return 2

if __name__=="__main__": raise SystemExit(main())
