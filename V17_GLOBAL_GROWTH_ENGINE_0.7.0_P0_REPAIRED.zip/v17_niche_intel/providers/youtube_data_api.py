from __future__ import annotations

import json
import re
from datetime import datetime, timezone
from typing import Any, Iterable

from ..domain.duration import parse_iso_duration
from ..domain.video import VideoRecord, VideoSearchBatch
from ..ui.input_safety import parse_bounded_json

_ALLOWED_ORDERS = {"date", "rating", "relevance", "title", "videoCount", "viewCount"}
_DEFAULT_ORDERS = ("relevance", "date")
_DETAIL_PARTS = "snippet,statistics,contentDetails,liveStreamingDetails"


def _optional_int(value: Any) -> int | None:
    if value is None:
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _parse_published_at(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=timezone.utc)


class APIKeyInvalidError(RuntimeError):
    """Raised only when Google's response identifies an invalid API key."""


def _api_error_details(error: Exception) -> tuple[set[str], str]:
    content = getattr(error, "content", b"")
    try:
        payload = parse_bounded_json(content.decode("utf-8") if isinstance(content, bytes) else str(content),
                                     max_bytes=64 * 1024, max_depth=16)
        errors = payload.get("error", {}).get("errors", [])
        reasons = {item.get("reason") for item in errors if isinstance(item, dict)}
        return reasons, str(payload.get("error", {}).get("message", ""))
    except (ValueError, AttributeError, TypeError):
        return set(), str(error)


def _is_invalid_api_key_error(error: Exception) -> bool:
    reasons, message = _api_error_details(error)
    return bool(reasons & {"keyInvalid", "keyExpired"}) or "api key not valid" in message.lower()


def _is_quota_exceeded_error(error: Exception) -> bool:
    reasons, message = _api_error_details(error)
    return bool(reasons & {"quotaExceeded", "dailyLimitExceeded"}) or any(
        phrase in message.lower() for phrase in ("quota exceeded", "daily limit exceeded")
    )


class YouTubeQuotaExceededError(RuntimeError):
    """Raised when Google reports that the project's YouTube API quota is exhausted."""


class YouTubeDataAPIProvider:
    """Read-only, quota-conscious adapter for public YouTube video research."""

    def __init__(self, api_key: str | None = None, *, client: Any | None = None,
                 timeout_seconds: int = 20, quota_callback=None) -> None:
        self.quota_callback = quota_callback
        if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, int) or not 1 <= timeout_seconds <= 120:
            raise ValueError("timeout_seconds must be between 1 and 120")
        if client is not None:
            self.client = client
            return
        if not isinstance(api_key, str) or not api_key.strip() or len(api_key.strip()) > 256 or any(ord(ch) < 0x21 or ord(ch) > 0x7e for ch in api_key.strip()):
            raise ValueError("YouTube API key must be a non-empty visible ASCII token")
        api_key = api_key.strip()
        try:
            from googleapiclient.discovery import build
            from .http_transport import build_no_redirect_httplib2
        except ImportError as exc:
            raise RuntimeError(
                "Install the YouTube provider extra: pip install -e '.[youtube]'"
            ) from exc
        http = build_no_redirect_httplib2(timeout_seconds)
        self.client = build(
            "youtube", "v3", developerKey=api_key, http=http,
            cache_discovery=False,
        )

    def search_videos(
        self,
        keyword: str,
        region: str,
        *,
        limit: int = 25,
        query_orders: Iterable[str] = _DEFAULT_ORDERS,
        relevance_language: str | None = None,
    ) -> VideoSearchBatch:
        if not isinstance(keyword, str) or not keyword.strip() or len(keyword) > 512:
            raise ValueError("keyword must be non-empty and at most 512 characters")
        if not isinstance(region, str) or not re.fullmatch(r"[A-Za-z]{2}", region):
            raise ValueError("region must be a two-letter country code")
        region = region.upper()
        if isinstance(limit, bool) or not isinstance(limit, int) or limit < 1:
            raise ValueError("limit must be a positive integer")
        if relevance_language is not None and (not relevance_language.strip() or len(relevance_language.strip()) > 8):
            raise ValueError("relevance_language must be a non-empty language code")
        limit = min(int(limit), 50)
        if isinstance(query_orders, str):
            raise ValueError("query_orders must be a collection of supported order names")
        orders = tuple(dict.fromkeys(query_orders))
        if not orders or len(orders) > len(_ALLOWED_ORDERS):
            raise ValueError("at least one query order is required")
        invalid = set(orders) - _ALLOWED_ORDERS
        if invalid:
            raise ValueError(f"Unsupported YouTube search order: {', '.join(sorted(invalid))}")

        ids_by_order: list[list[str]] = []
        failed_orders: list[str] = []
        successful_searches = 0
        for order in orders:
            if self.quota_callback: self.quota_callback("search.list", 1)
            try:
                params = {"q": keyword, "part": "snippet", "type": "video", "regionCode": region,
                          "maxResults": limit, "order": order}
                if relevance_language:
                    params["relevanceLanguage"] = relevance_language.strip()
                response = self.client.search().list(**params).execute()
                successful_searches += 1
            except Exception as exc:
                if _is_invalid_api_key_error(exc):
                    raise APIKeyInvalidError("Google rejected the configured YouTube API key") from exc
                if _is_quota_exceeded_error(exc):
                    raise YouTubeQuotaExceededError("Google reports that the YouTube Data API quota is exhausted") from exc
                failed_orders.append(order)
                continue
            order_ids: list[str] = []
            order_seen: set[str] = set()
            for item in response.get("items", []):
                video_id = item.get("id", {}).get("videoId")
                if video_id and video_id not in order_seen:
                    order_seen.add(video_id)
                    order_ids.append(video_id)
            ids_by_order.append(order_ids)

        # Interleave each ranking surface so relevance does not crowd out recency.
        ordered_ids: list[str] = []
        seen_ids: set[str] = set()
        max_depth = max((len(items) for items in ids_by_order), default=0)
        for index in range(max_depth):
            for items in ids_by_order:
                if index < len(items):
                    video_id = items[index]
                    if video_id not in seen_ids:
                        seen_ids.add(video_id)
                        ordered_ids.append(video_id)
                        if len(ordered_ids) >= limit:
                            break
            if len(ordered_ids) >= limit:
                break

        if not successful_searches:
            return VideoSearchBatch((), "error", orders, tuple(failed_orders))
        if not ordered_ids:
            status = "partial" if failed_orders else "no_data"
            return VideoSearchBatch((), status, orders, tuple(failed_orders))

        records_by_id: dict[str, VideoRecord] = {}
        detail_failures = 0
        for offset in range(0, len(ordered_ids), 50):
            batch_ids = ordered_ids[offset:offset + 50]
            if self.quota_callback: self.quota_callback("videos.list", 1)
            try:
                response = self.client.videos().list(
                    part=_DETAIL_PARTS, id=",".join(batch_ids),
                ).execute()
            except Exception as exc:
                if _is_invalid_api_key_error(exc):
                    raise APIKeyInvalidError("Google rejected the configured YouTube API key") from exc
                if _is_quota_exceeded_error(exc):
                    raise YouTubeQuotaExceededError("Google reports that the YouTube Data API quota is exhausted") from exc
                detail_failures += 1
                continue
            for item in response.get("items", []):
                snippet = item.get("snippet", {})
                stats = item.get("statistics", {})
                content = item.get("contentDetails", {})
                live = item.get("liveStreamingDetails", {})
                raw_duration = content.get("duration")
                try:
                    duration = parse_iso_duration(raw_duration) if raw_duration else None
                except ValueError:
                    duration = None
                try:
                    published = _parse_published_at(snippet["publishedAt"])
                except (KeyError, TypeError, ValueError):
                    continue
                video_id = item.get("id")
                if not video_id:
                    continue
                records_by_id[video_id] = VideoRecord(
                    video_id=video_id,
                    title=snippet.get("title", ""),
                    channel_id=snippet.get("channelId"),
                    channel_title=snippet.get("channelTitle", ""),
                    published_at=published,
                    views=_optional_int(stats.get("viewCount")),
                    likes=_optional_int(stats.get("likeCount")),
                    comments=_optional_int(stats.get("commentCount")),
                    duration_seconds=duration,
                    live_broadcast_content=snippet.get("liveBroadcastContent"),
                    live_streaming_details=dict(live),
                    url=f"https://www.youtube.com/watch?v={video_id}",
                )

        records = [records_by_id[video_id] for video_id in ordered_ids if video_id in records_by_id]
        if not records:
            status = "error" if detail_failures else ("partial" if failed_orders else "no_data")
        elif failed_orders or detail_failures:
            status = "partial"
        else:
            status = "ok"
        return VideoSearchBatch(
            tuple(records[:limit]), status, orders, tuple(failed_orders), detail_failures,
        )

    def list_supported_regions(self) -> tuple[dict[str, str], ...]:
        """Return YouTube-supported content regions (one quota unit)."""
        if self.quota_callback:
            self.quota_callback("i18nRegions.list", 1)
        try:
            response = self.client.i18nRegions().list(part="snippet").execute()
        except Exception as exc:
            if _is_invalid_api_key_error(exc):
                raise APIKeyInvalidError("Google rejected the configured YouTube API key") from exc
            if _is_quota_exceeded_error(exc):
                raise YouTubeQuotaExceededError("Google reports that the YouTube Data API quota is exhausted") from exc
            raise
        regions = []
        for item in response.get("items", []):
            snippet = item.get("snippet", {})
            code, name = snippet.get("gl"), snippet.get("name")
            if code and name:
                regions.append({"code": str(code).upper(), "name": str(name)})
        return tuple(regions)

    def fetch_public_comments(self, video_id: str, *, limit: int = 50) -> dict[str, Any]:
        """Fetch public top-level comment text only; author identity is never returned or stored."""
        import html
        import re
        if not isinstance(video_id, str) or not video_id.strip() or len(video_id) > 128:
            raise ValueError("video_id must be a non-empty identifier of at most 128 characters")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 100:
            raise ValueError("comment limit must be an integer between 1 and 100")
        comments: list[str] = []
        page_token = None
        seen_page_tokens: set[str] = set()
        pages = 0
        errors: list[str] = []
        while len(comments) < limit and pages < 5:
            if self.quota_callback: self.quota_callback("commentThreads.list", 1)
            params = {"part": "snippet", "videoId": video_id, "maxResults": min(100, limit-len(comments)),
                      "textFormat": "plainText", "order": "relevance"}
            if page_token: params["pageToken"] = page_token
            try:
                response = self.client.commentThreads().list(**params).execute()
            except Exception as exc:
                if _is_invalid_api_key_error(exc):
                    raise APIKeyInvalidError("Google rejected the configured YouTube API key") from exc
                errors.append(type(exc).__name__)
                break
            pages += 1
            for item in response.get("items", []):
                snippet = item.get("snippet", {}).get("topLevelComment", {}).get("snippet", {})
                raw = snippet.get("textDisplay") or snippet.get("textOriginal") or ""
                text = html.unescape(re.sub(r"<[^>]+>", " ", str(raw)))
                text = re.sub(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", "[EMAIL]", text, flags=re.I)
                text = re.sub(r"(?:\+?\d[\d\s().-]{7,}\d)", "[PHONE]", text)
                if text.strip(): comments.append(text.strip()[:5000])
                if len(comments) >= limit: break
            next_page_token = response.get("nextPageToken")
            if not isinstance(next_page_token, str) or not next_page_token or len(next_page_token) > 4096:
                break
            if next_page_token in seen_page_tokens or next_page_token == page_token:
                errors.append("RepeatedPageToken")
                break
            seen_page_tokens.add(next_page_token)
            page_token = next_page_token
        status = "ok" if comments and not errors else "partial" if comments else "error" if errors else "no_data"
        return {"status": status, "comments": tuple(comments[:limit]), "comment_count": min(len(comments), limit),
                "pages_fetched": pages, "error_types": errors, "author_metadata_returned": False,
                "raw_comments_should_be_persisted": False}
