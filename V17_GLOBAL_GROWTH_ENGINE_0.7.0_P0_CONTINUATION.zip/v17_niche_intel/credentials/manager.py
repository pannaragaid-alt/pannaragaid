from __future__ import annotations

import json
import re
import ssl
import urllib.request
from datetime import datetime, timezone
from zoneinfo import ZoneInfo
from typing import Iterable

from .models import APIKeyCredential, OAuthAccount
from .secrets import SecretStore
from .transport import harden_requests_session


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Sensitive token revocation requests must never forward bodies across redirects."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _open_google_revocation_request(request, timeout_seconds: int):
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        _NoRedirectHandler(),
        urllib.request.HTTPSHandler(context=ssl.create_default_context()),
    )
    return opener.open(request, timeout=timeout_seconds)


_ALLOWED_OAUTH_SCOPES = frozenset({
    "https://www.googleapis.com/auth/yt-analytics.readonly",
    "https://www.googleapis.com/auth/yt-analytics-monetary.readonly",
    "https://www.googleapis.com/auth/youtube.readonly",
})
_GOOGLE_CLIENT_ID = re.compile(r"^[A-Za-z0-9_-]+\.apps\.googleusercontent\.com$")
_SECRET_REFERENCE = re.compile(r"^(?:keyring|memory)://[a-f0-9]{32}$|^env://(?:YOUTUBE_API_KEY|V17_SECRET_[A-Za-z0-9_]{1,120})$")


def _validate_secret_reference(reference: str) -> str:
    if not isinstance(reference, str) or len(reference) > 256 or not _SECRET_REFERENCE.fullmatch(reference):
        raise ValueError("secret reference must use an approved keyring, memory, or environment reference format")
    return reference


class CredentialUnavailableError(RuntimeError):
    pass


class QuotaExhaustedError(CredentialUnavailableError):
    pass


class CredentialManager:
    """Policy-aware registry. API quota is tracked per project, never per key."""
    def __init__(self, database, secret_store: SecretStore) -> None:
        self.db = database
        self.secrets = secret_store

    @staticmethod
    def _quota_date() -> str:
        # YouTube's daily quota buckets reset at midnight Pacific Time.
        return datetime.now(ZoneInfo("America/Los_Angeles")).date().isoformat()

    @staticmethod
    def _now() -> str:
        return datetime.now(timezone.utc).isoformat()

    def add_api_key(self, credential_id: str, *, project_id: str, use_case: str,
                    environment: str, secret: str | None = None,
                    secret_ref: str | None = None, provider: str = "youtube_data_api") -> None:
        values = (credential_id, project_id, use_case, environment, provider)
        if (not all(isinstance(x, str) and x.strip() and len(x) <= 128 for x in values)
                or any(ord(ch) < 0x20 for value in values for ch in value)):
            raise ValueError("credential metadata must be bounded non-empty strings without controls")
        if provider != "youtube_data_api":
            raise ValueError("only the youtube_data_api key provider is supported")
        if bool(secret) == bool(secret_ref):
            raise ValueError("provide exactly one of secret or secret_ref")
        if secret is not None and (not isinstance(secret, str) or len(secret) > 8192
                or any(ord(ch) < 0x20 or ord(ch) > 0x7e for ch in secret)):
            raise ValueError("API key must be a bounded visible ASCII token")
        ref = self.secrets.put(secret) if secret is not None else _validate_secret_reference(secret_ref)
        _validate_secret_reference(ref)
        with self.db.transaction() as conn:
            conn.execute("INSERT INTO api_credentials VALUES (?,?,?,?,?,?,?,?)", (
                credential_id, provider, project_id, use_case, environment, ref, "active", self._now()
            ))

    def set_api_key_status(self, credential_id: str, status: str) -> None:
        if status not in {"active", "invalid", "disabled", "reauth_required"}:
            raise ValueError("invalid API credential status")
        with self.db.transaction() as conn:
            cur = conn.execute("UPDATE api_credentials SET status=? WHERE credential_id=?", (status, credential_id))
            if not cur.rowcount:
                raise KeyError(credential_id)

    def record_project_quota(self, project_id: str, *, used: int, limit: int, use_case: str) -> None:
        if used < 0 or limit <= 0:
            raise ValueError("used must be non-negative and limit must be positive")
        with self.db.transaction() as conn:
            conn.execute("""INSERT INTO project_quota_daily VALUES (?,?,?,?,?)
                ON CONFLICT(project_id,quota_date) DO UPDATE SET used=excluded.used,
                quota_limit=excluded.quota_limit, updated_at=excluded.updated_at""",
                (project_id, self._quota_date(), used, limit, self._now()))

    def select_api_key(self, *, use_case: str, environment: str, provider: str = "youtube_data_api",
                       quota_limit: int | None = None) -> APIKeyCredential:
        with self.db.read() as conn:
            rows = conn.execute("""SELECT * FROM api_credentials WHERE provider=? AND use_case=?
                AND environment=? ORDER BY created_at,credential_id""", (provider, use_case, environment)).fetchall()
            if not rows:
                raise CredentialUnavailableError("No API key is registered for this use case and environment")
            projects = {row["project_id"] for row in rows}
            if len(projects) != 1:
                raise CredentialUnavailableError("Ambiguous project route: configure a distinct use_case for each independent project")
            project_id = next(iter(projects))
            quota = conn.execute("SELECT used,quota_limit FROM project_quota_daily WHERE project_id=? AND quota_date=?",
                                 (project_id, self._quota_date())).fetchone()
            effective_limit = quota_limit if quota_limit is not None else (quota["quota_limit"] if quota else 10000)
            if effective_limit <= 0:
                raise ValueError("quota_limit must be positive")
            if quota and quota["used"] >= effective_limit:
                raise QuotaExhaustedError(f"Project general quota exhausted for project '{project_id}' and use case '{use_case}'")
            active = next((row for row in rows if row["status"] == "active"), None)
            if active is None:
                raise CredentialUnavailableError("All API keys for this project are inactive")
            secret_ref = _validate_secret_reference(active["secret_ref"])
            return APIKeyCredential(active["credential_id"], active["provider"], active["project_id"],
                                    active["use_case"], active["environment"], secret_ref)

    def add_oauth_account(self, account_id: str, *, account_label: str,
                          secret_access_token: str | None = None, secret_refresh_token: str | None = None,
                          access_token_ref: str | None = None, refresh_token_ref: str | None = None,
                          client_secret_ref: str | None = None, client_id: str | None = None,
                          scopes: Iterable[str], channel_ids: Iterable[str],
                          expires_at: str | None = None, provider: str = "youtube_analytics") -> None:
        if (not isinstance(account_id, str) or not account_id.strip() or len(account_id) > 128
                or not isinstance(account_label, str) or not account_label.strip() or len(account_label) > 128
                or any(ord(ch) < 0x20 for value in (account_id, account_label) for ch in value)):
            raise ValueError("account_id and account_label must be bounded non-empty strings without controls")
        if provider != "youtube_analytics":
            raise ValueError("only the youtube_analytics OAuth provider is supported")
        if bool(secret_access_token) == bool(access_token_ref) or bool(secret_refresh_token) == bool(refresh_token_ref):
            raise ValueError("provide exactly one access-token value/reference and one refresh-token value/reference")
        for token in (secret_access_token, secret_refresh_token):
            if token is not None and (not isinstance(token, str) or len(token) > 8192 or any(ord(ch) < 0x20 for ch in token)):
                raise ValueError("OAuth token is invalid or exceeds the 8 KiB limit")
        try:
            raw_scopes, raw_channels = list(scopes), list(channel_ids)
        except TypeError as exc:
            raise ValueError("OAuth scopes and channel IDs must be iterable strings") from exc
        if any(not isinstance(scope, str) for scope in raw_scopes):
            raise ValueError("OAuth scopes must be strings")
        if any(not isinstance(channel, str) for channel in raw_channels):
            raise ValueError("OAuth channel IDs must be strings")
        scope_set, channel_set = sorted(set(raw_scopes)), sorted(set(raw_channels))
        if not scope_set or len(scope_set) > len(_ALLOWED_OAUTH_SCOPES) or not set(scope_set).issubset(_ALLOWED_OAUTH_SCOPES):
            raise ValueError("OAuth grants must contain only approved read-only YouTube/Analytics scopes")
        if not channel_set or len(channel_set) > 100 or any(not channel.strip()
                or len(channel) > 128 or any(ord(ch) < 0x20 for ch in channel) for channel in channel_set):
            raise ValueError("OAuth account must have bounded explicit authorized channel IDs")
        if client_id is not None and (not isinstance(client_id, str) or not _GOOGLE_CLIENT_ID.fullmatch(client_id)):
            raise ValueError("Google OAuth client ID is invalid")
        for reference in (access_token_ref, refresh_token_ref, client_secret_ref):
            if reference is not None:
                _validate_secret_reference(reference)
        access_ref = self.secrets.put(secret_access_token) if secret_access_token is not None else access_token_ref
        refresh_ref = self.secrets.put(secret_refresh_token) if secret_refresh_token is not None else refresh_token_ref
        _validate_secret_reference(access_ref)
        _validate_secret_reference(refresh_ref)
        with self.db.transaction() as conn:
            conn.execute("INSERT INTO oauth_accounts (account_id,provider,account_label,access_token_ref,refresh_token_ref,client_secret_ref,scopes_json,channel_ids_json,client_id,status,expires_at,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)", (
                account_id, provider, account_label, access_ref, refresh_ref, client_secret_ref,
                json.dumps(scope_set), json.dumps(channel_set), client_id, "active", expires_at, self._now()
            ))

    def set_oauth_status(self, account_id: str, status: str) -> None:
        if status not in {"active", "invalid", "disabled", "revoked", "reauth_required"}:
            raise ValueError("invalid OAuth status")
        with self.db.transaction() as conn:
            row = conn.execute("SELECT status FROM oauth_accounts WHERE account_id=?", (account_id,)).fetchone()
            if row is None: raise KeyError(account_id)
            current = row["status"]
            if current == "revoked" and status != "revoked":
                raise ValueError("revoked OAuth accounts are terminal; complete a new consent flow")
            if current in {"invalid", "reauth_required"} and status == "active":
                raise ValueError("invalid or expired OAuth grants require a new consent flow")
            if current == "disabled" and status not in {"disabled", "active"}:
                raise ValueError("disabled OAuth accounts may only be re-enabled")
            conn.execute("UPDATE oauth_accounts SET status=? WHERE account_id=?", (status, account_id))

    def select_oauth_account(self, channel_id: str, *, required_scopes: Iterable[str],
                             provider: str = "youtube_analytics") -> OAuthAccount:
        try:
            needed = set(required_scopes)
        except TypeError as exc:
            raise ValueError("requested OAuth scopes must be iterable strings") from exc
        if any(not isinstance(scope, str) for scope in needed) or not needed or not needed.issubset(_ALLOWED_OAUTH_SCOPES):
            raise ValueError("requested OAuth scopes must be approved read-only scopes")
        if provider != "youtube_analytics":
            raise ValueError("only the youtube_analytics OAuth provider is supported")
        with self.db.read() as conn:
            rows = conn.execute("SELECT * FROM oauth_accounts WHERE provider=? AND status='active' ORDER BY created_at,account_id",
                                (provider,)).fetchall()
            for row in rows:
                try:
                    scopes, channels = set(json.loads(row["scopes_json"])), set(json.loads(row["channel_ids_json"]))
                    _validate_secret_reference(row["access_token_ref"])
                    _validate_secret_reference(row["refresh_token_ref"])
                    if row["client_secret_ref"] is not None:
                        _validate_secret_reference(row["client_secret_ref"])
                except (TypeError, ValueError, json.JSONDecodeError):
                    continue
                if scopes.issubset(_ALLOWED_OAUTH_SCOPES) and channel_id in channels and needed.issubset(scopes):
                    # Expired access tokens remain selectable: the refresh token may still be valid.
                    # Refresh failures such as invalid_grant transition the account to reauth_required.
                    return OAuthAccount(row["account_id"], row["account_label"], row["access_token_ref"],
                                        row["refresh_token_ref"], frozenset(scopes), frozenset(channels), row["expires_at"])
        raise CredentialUnavailableError(f"No active OAuth account is authorized for channel '{channel_id}' and required scopes")

    def build_google_oauth_credentials(self, account_id: str, *, client_id: str | None = None,
                                       client_secret_ref: str | None = None, token_uri: str = "https://oauth2.googleapis.com/token"):
        """Load/refresh an authorized Google OAuth account without exposing tokens to SQLite."""
        if token_uri != "https://oauth2.googleapis.com/token":
            raise ValueError("Google OAuth token endpoint must be the official HTTPS endpoint")
        with self.db.read() as conn:
            row = conn.execute("SELECT * FROM oauth_accounts WHERE account_id=?", (account_id,)).fetchone()
        if row is None or row["status"] != "active" or row["provider"] != "youtube_analytics":
            raise CredentialUnavailableError("OAuth account is missing, inactive, or has an unsupported provider")
        try:
            stored_scopes = set(json.loads(row["scopes_json"]))
        except (TypeError, ValueError, json.JSONDecodeError) as exc:
            raise CredentialUnavailableError("OAuth account scope metadata is invalid") from exc
        if not stored_scopes or not stored_scopes.issubset(_ALLOWED_OAUTH_SCOPES):
            raise CredentialUnavailableError("OAuth account contains a non-read-only or unsupported scope")
        try:
            from google.auth.transport.requests import Request
            from google.oauth2.credentials import Credentials
        except ImportError as exc:
            raise RuntimeError("Install the YouTube provider extra: pip install -e '.[youtube]'") from exc
        _validate_secret_reference(row["refresh_token_ref"])
        if row["access_token_ref"] is not None:
            _validate_secret_reference(row["access_token_ref"])
        refresh_token = self.secrets.get(row["refresh_token_ref"])
        secret_ref = client_secret_ref or row["client_secret_ref"]
        import os
        resolved_client_id = client_id or row["client_id"] or os.getenv("GOOGLE_OAUTH_CLIENT_ID")
        if not secret_ref: raise CredentialUnavailableError("OAuth client secret reference is missing")
        if not resolved_client_id or not _GOOGLE_CLIENT_ID.fullmatch(resolved_client_id):
            raise CredentialUnavailableError("Google OAuth client ID is missing or invalid")
        _validate_secret_reference(secret_ref)
        client_secret = self.secrets.get(secret_ref)
        if not isinstance(refresh_token, str) or not refresh_token or len(refresh_token) > 8192 or any(ord(ch) < 0x20 for ch in refresh_token):
            raise CredentialUnavailableError("OAuth refresh token is invalid or exceeds the 8 KiB limit")
        if not isinstance(client_secret, str) or not client_secret or len(client_secret) > 1024 or any(ord(ch) < 0x20 for ch in client_secret):
            raise CredentialUnavailableError("Google OAuth client secret is invalid")
        credentials = Credentials(
            token=None, refresh_token=refresh_token, token_uri=token_uri,
            client_id=resolved_client_id, client_secret=client_secret,
            scopes=json.loads(row["scopes_json"]),
        )
        import requests
        session = harden_requests_session(requests.Session())
        try:
            credentials.refresh(Request(session=session))
        except Exception as exc:
            # A revoked/invalid_grant token requires explicit user re-authorization.
            message = str(exc).lower()
            if "invalid_grant" in message or "revoked" in message:
                self.set_oauth_status(account_id, "reauth_required")
                raise CredentialUnavailableError("Google OAuth refresh was rejected; re-authorization is required") from exc
            raise
        finally:
            session.close()
        if credentials.token:
            if not isinstance(credentials.token, str) or len(credentials.token) > 8192 or any(ord(ch) < 0x20 for ch in credentials.token):
                raise CredentialUnavailableError("Google OAuth access token is invalid or exceeds the 8 KiB limit")
            new_ref = self.secrets.put(credentials.token)
            _validate_secret_reference(new_ref)
            with self.db.transaction() as conn:
                conn.execute("UPDATE oauth_accounts SET access_token_ref=?, expires_at=? WHERE account_id=?",
                             (new_ref, credentials.expiry.isoformat() if credentials.expiry else None, account_id))
            self.secrets.delete(row["access_token_ref"])
        return credentials

    def build_youtube_analytics_client(self, channel_id: str, *, required_scopes: Iterable[str],
                                       client_id: str | None = None, client_secret_ref: str | None = None):
        account = self.select_oauth_account(channel_id, required_scopes=required_scopes)
        credentials = self.build_google_oauth_credentials(
            account.account_id, client_id=client_id, client_secret_ref=client_secret_ref
        )
        try:
            from googleapiclient.discovery import build
            from google_auth_httplib2 import AuthorizedHttp
            from ..providers.http_transport import build_no_redirect_httplib2
        except ImportError as exc:
            raise RuntimeError("Install the YouTube provider extra: pip install -e '.[youtube]'") from exc
        authorized_http = AuthorizedHttp(credentials, http=build_no_redirect_httplib2(30))
        return build("youtubeAnalytics", "v2", http=authorized_http, cache_discovery=False)


    def consume_project_quota(self, project_id: str, *, units: int, limit: int, use_case: str,
                              bucket: str = "default") -> int:
        """Atomically meter a project-wide daily quota bucket.

        `search.list` has a separate call bucket; all other read methods share
        the general daily-units bucket. The caller supplies the configured
        bucket limit so an approved quota increase can be applied consistently.
        """
        if units <= 0 or limit <= 0:
            raise ValueError("units and limit must be positive")
        if bucket not in {"default", "search.list"}:
            raise ValueError("bucket must be default or search.list")
        table = "project_search_quota_daily" if bucket == "search.list" else "project_quota_daily"
        with self.db.transaction() as conn:
            row = conn.execute(f"SELECT used FROM {table} WHERE project_id=? AND quota_date=?",
                               (project_id, self._quota_date())).fetchone()
            current = row["used"] if row else 0
            if current + units > limit:
                raise QuotaExhaustedError(
                    f"Project '{project_id}' exhausted the {bucket} quota bucket for use case '{use_case}'")
            updated = current + units
            conn.execute(f"""INSERT INTO {table} VALUES (?,?,?,?,?)
                ON CONFLICT(project_id,quota_date) DO UPDATE SET used=excluded.used,
                quota_limit=excluded.quota_limit, updated_at=excluded.updated_at""",
                (project_id, self._quota_date(), updated, limit, self._now()))
            return updated

    def list_api_credentials(self) -> list[dict]:
        with self.db.read() as conn:
            rows=conn.execute("SELECT credential_id,provider,project_id,use_case,environment,status,created_at FROM api_credentials ORDER BY created_at").fetchall()
        return [dict(row) for row in rows]

    def list_oauth_accounts(self) -> list[dict]:
        with self.db.read() as conn:
            rows=conn.execute("SELECT account_id,provider,account_label,scopes_json,channel_ids_json,status,expires_at,created_at FROM oauth_accounts ORDER BY created_at").fetchall()
        return [{"account_id":r["account_id"],"provider":r["provider"],"account_label":r["account_label"],
                 "scopes":json.loads(r["scopes_json"]),"channel_ids":json.loads(r["channel_ids_json"]),
                 "status":r["status"],"expires_at":r["expires_at"],"created_at":r["created_at"]} for r in rows]

    def revoke_oauth_account(self, account_id: str) -> None:
        """Revoke the Google refresh token remotely, then disable and erase local token material."""
        import urllib.parse
        with self.db.read() as conn:
            row=conn.execute("SELECT refresh_token_ref,access_token_ref,client_secret_ref,status FROM oauth_accounts WHERE account_id=?",(account_id,)).fetchone()
        if row is None: raise KeyError(account_id)
        if row["status"] == "revoked": raise ValueError("OAuth account is already revoked")
        token=self.secrets.get(row["refresh_token_ref"])
        if not isinstance(token, str) or not token or len(token) > 8192 or any(ord(ch) < 0x20 for ch in token):
            raise CredentialUnavailableError("OAuth refresh token is invalid or exceeds the revocation request limit")
        request=urllib.request.Request("https://oauth2.googleapis.com/revoke",
            data=urllib.parse.urlencode({"token":token}).encode(),
            headers={"Content-Type":"application/x-www-form-urlencoded"},method="POST")
        with _open_google_revocation_request(request, timeout_seconds=15) as response:
            if response.status not in (200,204): raise RuntimeError("Google token revocation was not confirmed")
        with self.db.transaction() as conn:
            conn.execute("UPDATE oauth_accounts SET status='revoked' WHERE account_id=?",(account_id,))
        self.secrets.delete(row["refresh_token_ref"]); self.secrets.delete(row["access_token_ref"])
        if row["client_secret_ref"]: self.secrets.delete(row["client_secret_ref"])

    def credential_inventory(self) -> dict[str, int]:
        """Return counts only; never return secret values, token refs, or account labels."""
        with self.db.read() as conn:
            api = conn.execute("SELECT COUNT(*) AS n FROM api_credentials").fetchone()["n"]
            oauth = conn.execute("SELECT COUNT(*) AS n FROM oauth_accounts").fetchone()["n"]
            active_api = conn.execute("SELECT COUNT(*) AS n FROM api_credentials WHERE status='active'").fetchone()["n"]
            active_oauth = conn.execute("SELECT COUNT(*) AS n FROM oauth_accounts WHERE status='active'").fetchone()["n"]
        return {"api_keys_total": api, "api_keys_active": active_api,
                "oauth_accounts_total": oauth, "oauth_accounts_active": active_oauth}

    def quota_inventory(self) -> list[dict]:
        """Return both YouTube quota buckets without exposing credentials."""
        with self.db.read() as conn:
            general = conn.execute("SELECT project_id,quota_date,used,quota_limit,updated_at FROM project_quota_daily").fetchall()
            search = conn.execute("SELECT project_id,quota_date,used,quota_limit,updated_at FROM project_search_quota_daily").fetchall()
        rows = [{**dict(row), "bucket": "general"} for row in general]
        rows.extend({**dict(row), "bucket": "search.list"} for row in search)
        return sorted(rows, key=lambda row: (row["quota_date"], row["project_id"], row["bucket"]), reverse=True)
