"""Loopback-only OAuth callback listener for locally hosted Streamlit/CLI sessions."""
from __future__ import annotations

from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from queue import Empty, Queue
from threading import Thread
from urllib.parse import urlparse


class OAuthCallbackListener:
    def __init__(self, flow, *, host: str = "127.0.0.1", port: int = 8765):
        if host != "127.0.0.1":
            raise ValueError("OAuth callback listener must bind to loopback only")
        if not 0 <= port <= 65535:
            raise ValueError("invalid callback port")
        self.flow = flow
        self.host = host
        self.port = port
        self.redirect_uri: str | None = None
        self._queue: Queue = Queue(maxsize=1)
        self._server: ThreadingHTTPServer | None = None
        self._thread: Thread | None = None

    def start(self) -> str:
        if self._server is not None:
            return self.redirect_uri or ""
        listener = self
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                parsed = urlparse(self.path)
                if len(self.path) > 8192:
                    self.send_error(414); return
                if parsed.path != "/oauth2/callback":
                    self.send_error(404); return
                callback_url = f"{listener.redirect_uri}?{parsed.query}"
                try:
                    from urllib.parse import parse_qs
                    params = parse_qs(parsed.query)
                    state = params.get("state", [None])[0]
                    if not state: raise ValueError("OAuth callback is missing state")
                    credentials = listener.flow.complete(state=state, authorization_response=callback_url)
                    listener._queue.put_nowait({"status": "ok", "credentials": credentials})
                    status, message = 200, "Google authorization completed. You can return to the V17 app."
                except Exception as exc:
                    try: listener._queue.put_nowait({"status": "error", "error_type": type(exc).__name__})
                    except Exception: pass
                    status, message = 400, "Google authorization could not be completed. Return to the V17 app and restart consent."
                body = ("<!doctype html><html><head><meta charset='utf-8'><title>V17 OAuth</title></head>"
                        f"<body><h2>V17 OAuth</h2><p>{message}</p></body></html>").encode("utf-8")
                self.send_response(status)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(body)))
                self.send_header("Cache-Control", "no-store")
                self.send_header("Referrer-Policy", "no-referrer")
                self.send_header("X-Content-Type-Options", "nosniff")
                self.send_header("X-Frame-Options", "DENY")
                self.send_header("Content-Security-Policy", "default-src 'none'; frame-ancestors 'none'; base-uri 'none'")
                self.end_headers()
                self.wfile.write(body)
            def log_message(self, format, *args):
                # Never log callback URLs, authorization codes, or state values.
                return
        self._server = ThreadingHTTPServer((self.host, self.port), Handler)
        actual_host, actual_port = self._server.server_address[:2]
        display_host = "127.0.0.1" if actual_host in {"0.0.0.0", "::"} else actual_host
        self.redirect_uri = f"http://{display_host}:{actual_port}/oauth2/callback"
        self.flow.redirect_uri = self.redirect_uri
        self._thread = Thread(target=self._server.serve_forever, name="v17-oauth-loopback", daemon=True)
        self._thread.start()
        return self.redirect_uri

    def poll(self) -> dict | None:
        try: return self._queue.get_nowait()
        except Empty: return None

    def stop(self) -> None:
        if self._server is not None:
            self._server.shutdown()
            self._server.server_close()
            self._server = None
        if self._thread is not None:
            self._thread.join(timeout=2)
            self._thread = None
