# V17 P1 Dependency and Translation Security Remediation

Date: 2026-11-24
Scope: V17 Global Growth Engine 0.7.0 — P1 remediation increment
Status: **IMPLEMENTED LOCALLY — HOSTED REVALIDATION PENDING FOR P1.3 ARTIFACT**

## Findings from hosted dependency audit

The first meaningful `pip-audit --strict --local` run installed the application and scanner extras in the same interpreter. It found 58 advisory records across six packages. Inspection of the install log showed that Semgrep's own dependency chain introduced `mcp`, `opentelemetry`, and `wcmatch`; those are scanner-tool dependencies, not V17 runtime dependencies. The same environment also contained application dependencies that were genuinely vulnerable or unsafe to retain:

- `Pillow 12.3.0` was below the fixed `13.0.0` release.
- `cryptography 46.0.7` was constrained below the available fix versions.
- `deep-translator 1.11.4` was listed in PYSEC-2022-252, an advisory describing a compromised package release that exfiltrated environment variables and downloaded/executed malware at install time.

## Changes implemented

1. Raised media extra to `Pillow>=13,<14`.
2. Raised backup crypto extra to `cryptography>=50,<51`.
3. Removed `deep-translator` from all dependency sets and removed its runtime imports.
4. Replaced the unofficial translation package with a first-party adapter for authenticated Google Cloud Translation API v3:
   - Google Application Default Credentials only;
   - explicit `GOOGLE_CLOUD_PROJECT` / `GCLOUD_PROJECT`;
   - fixed HTTPS origin and fixed v3 resource path;
   - TLS verification enabled, ambient proxies disabled, redirects refused;
   - strict project/language/text validation;
   - bounded 15-second read timeout and 1 MiB streaming response ceiling;
   - strict bounded JSON parsing and response-shape validation;
   - no response body, user text, or credentials in raised error messages.
5. Dashboard translation is disabled when no Google Cloud project is configured; CLI `--machine-translate` fails early with a configuration error.
6. Added 17 security-focused translation tests covering validation, endpoint pinning, redirects, streaming bounds, malformed payloads, and environment configuration.
7. CI dependency audit now runs in an isolated scanner/runtime split and audits the full V17 runtime extras without including Semgrep or Bandit transitive dependencies.

## Local verification

- `pytest -q`: **512 passed**.
- Translation adapter tests: **17 passed**; source-archive hygiene tests: **17 passed**.
- `compileall` for application, tests, and tools: passed.
- P1.2 wheel build passed using locally installed build tools with `--no-build-isolation`; P1.3 raises the isolated build backend floor to setuptools>=84.1.0, and the P1.3 wheel build remains pending hosted CI verification.
- CLI help and `doctor --json`: passed; database integrity/config checks were healthy. The local container has no configured secret-store backend, so the doctor correctly reported `secret_vault=unavailable`.
- Uploaded artifact SHA-256 `469b8825ccd9d507045b4f5135fac59efec4003b48d65334e948bb7d27779634` passed hosted Run #27: all six jobs green, 510 tests on Python 3.11 and 3.12, Ruff/Bandit/Semgrep pass, and Python 3.12 runtime pip-audit reported no known vulnerabilities.
- Expanded dual-version dependency audit Run #29 exposed `setuptools 79.0.1` in the Python 3.11 audit venv. Run #31 passed all seven jobs after upgrading audit venv setuptools to 84.2.1; both Python 3.11 and 3.12 runtime audits reported no known vulnerabilities.
- P1.3 additionally raises the PEP 517 build-system floor to setuptools>=84.1.0 and adds a regression test. Updated P1.3 ZIP SHA-256: `3ecfeac4dcc3b87e438091e86fbcfd0c644c67e10bc45c9afb877c7f91aa62ae`. This P1.3 artifact has 512 local tests passing and requires a fresh hosted CI run after upload.
- Live Google Cloud Translation request: not run; no Google Cloud project, API enablement, or ADC credentials were supplied.

## Remaining external acceptance gates

This remediation does not complete the P1 operational acceptance runbook. Backup/restore drills, RPO/RTO evidence, system supervision/recovery drills, centralized observability/alerting, OIDC/RBAC and session security, staging load/soak/security tests, and rollback drills still require the target infrastructure, identity provider, storage, monitoring destination, provider credentials, and authorized reviewers. Public deployment remains blocked until those gates pass.
