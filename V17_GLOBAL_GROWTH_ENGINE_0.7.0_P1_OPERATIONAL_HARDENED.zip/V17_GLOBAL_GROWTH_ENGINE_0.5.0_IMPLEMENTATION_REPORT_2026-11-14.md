# V17 Global Growth Engine 0.5.0 — P0/P1/P2 implementation report

**Date:** 2026-11-14  
**Base:** V17 0.4.1 P0-P8 archive  
**Release:** 0.5.0  
**Compatibility:** Existing 0.4.1 service interfaces and persisted data retained; additive analytics output fields, SQLite tables and CLI commands.

## Executive status

V17 0.5.0 adds evidence coverage, localization query provenance, repeated-snapshot competitor velocity, originality review signals, audience cohort summaries, expanded first-party KPIs, robust proportion-experiment diagnostics, multiple-testing correction, forecast interval evaluation, model comparison gates, risk-adjusted expected contribution, persistent experiment registry and strategic decision logs, plus CLI/dashboard integration.

This is a locally testable engineering release. It is not a guarantee of YouTube rankings, recommendations, views, revenue or exhaustive country coverage. No live provider credentials or native reviewers were supplied, so live integrations and language quality remain external validation gates.

## P0 — Fundamental accuracy and evidence

| Item | Implementation | Status |
|---|---|---|
| Country coverage audit | Explicit expected market universe; attempted, successful, partial, failed, unsupported, not-attempted states; rankability requires successful sample | Implemented + tested |
| Localized query plan | Per-market seed, curated and supplied/machine-translated variants; deduplication, origin labels, bounded variants | Implemented + tested |
| Native localization gate | Fresh timestamp, HTTPS review reference, dialect, accent and cultural gates are required for recorded readiness; evidence remains unverified by the engine | Implemented; human QA pending |
| Source quality/freshness | Missing provenance and stale source labeling; HTTPS provenance refs and timezone-aware observations | Implemented + tested |
| Competitor velocity | Interval views/day and acceleration from repeated snapshots of the same video | Implemented + tested |
| Originality screening | Lexical similarity flags for human review; explicitly not a copyright determination | Implemented + tested |
| First-party KPI expansion | Watch time per impression, views per unique viewer, returning-viewer share, end-screen click rate, Shorts stayed-to-watch rate, revenue per watch hour | Implemented + tested; requires owner Analytics inputs |
| Data lineage | Source refs and interpretation limitations retained in diagnostics; existing private Analytics separation preserved | Implemented; full provider lineage remains dependent on ingestion |

## P1 — Intelligence and predictive advantage

| Item | Implementation | Status |
|---|---|---|
| Audience cohorts | Aggregated views, watch time, AVD, returning viewers and completeness; missing fields remain null | Implemented + tested |
| Risk-adjusted economics | Probability-weighted gross revenue less costs and reserve | Implemented + tested; probabilities are supplied assumptions |
| Forecast interval evaluation | Holdout coverage and mean interval width | Implemented + tested; requires actual holdout series |
| Forecast champion/challenger | Same-holdout MAE/WAPE comparison; minimum sample gate; no auto-promotion | Implemented + tested |
| Forecast drift | Baseline-vs-recent WAPE deterioration alert; no auto-retrain | Implemented + tested |
| Topic saturation | Demand-index-per-competitor-upload ratio with aligned-window warning; no absolute search-volume claim | Implemented + tested |
| Satisfaction survey | Explicit 0-10 survey summary, top-box shares and NPS; no proxy substitution | Implemented + tested |
| Experiment statistics | Wilson arm intervals, Newcombe difference interval, approximate two-proportion p-value, SRM and small-cell gates | Implemented + tested |
| Multiple testing | Benjamini-Hochberg false-discovery-rate adjustment | Implemented + tested |
| Experiment integrity | Existing pre-registration/SRM/guardrail checks retained | Implemented; production experiment design still required |

## P2 — Continuous optimization

| Item | Implementation | Status |
|---|---|---|
| Persistent experiment registry | SQLite lifecycle, idempotent create, list, guarded transitions and result recording | Implemented + tested |
| Strategic decision log | Idempotent records with evidence refs, expected metric, outcome and proposed/accepted/implemented/validated lifecycle | Implemented + tested |
| CLI | `growth-audit --persist-decisions`, `experiment create/list/transition/record-result`, `decision-log list/transition` | Implemented + tested |
| Dashboard | Growth evidence audit input/output and experiment/decision registry views | Source implemented; Streamlit runtime QA pending |
| Bounded worker batch | `PersistentJobRunner.run_batch` processes up to a bounded count and exits idle | Implemented + tested |
| Recurring scheduler | No host scheduler service deployed; CLI/host scheduler must invoke worker batch | Not deployed |
| Model auto-learning | Candidate comparison and evaluation only; no automatic weight promotion | Deliberately disabled |

## Formulas and techniques added

1. **Market coverage**: `attempted_markets / expected_markets × 100`; separate successful coverage uses successful markets with usable samples. It measures registry coverage, not the world-wide YouTube census.
2. **Competitor interval velocity**: `(views_t − views_(t−1)) / elapsed_days`; requires at least two snapshots per video.
3. **Competitor velocity acceleration**: `(latest_interval_views_per_day − previous_interval_views_per_day) / elapsed_days_between_interval_endpoints`; requires at least three snapshots.
4. **Originality lexical similarity**: `|tokens_A ∩ tokens_B| / |tokens_A ∪ tokens_B| × 100`; screening signal only, not copyright or plagiarism proof.
5. **Expected gross revenue**: `Σ(probability_i × gross_revenue_i)`; scenario probabilities must sum to 1.
6. **Risk-adjusted expected contribution**: `Σ(p_i × gross_revenue_i) − costs − risk_reserve`.
7. **Forecast interval coverage**: `covered_actuals / holdout_observations × 100`.
8. **Mean interval width**: `mean(upper_bound − lower_bound)`.
9. **Benjamini-Hochberg FDR**: `adjusted_p_i = min_{j≥i}(m × p_(j) / j)`, capped at 1, then mapped to original test order.
10. **Wilson score interval** for each proportion arm and **Newcombe difference interval**: `[lower_treatment − upper_control, upper_treatment − lower_control]`.
11. **Pooled two-proportion z-test** with inference withheld for observational data, sample-ratio mismatch or expected cells below 5.
12. **First-party extended KPIs**: watch time/impression; views/unique viewers; returning viewers/unique viewers; end-screen clicks/element impressions; Shorts stayed-to-watch/shown-in-feed; revenue/watch hour.
13. **Forecast champion/challenger**: same-holdout MAE/WAPE and relative WAPE improvement; promotion is never automatic.
14. **Topic saturation diagnostic**: `demand_index / competitor_uploads`; this is a relative ratio only when topic, market and observation window align.
15. **Satisfaction survey**: `NPS = (promoters − detractors) / responses × 100`; promoters are scores 9-10, detractors 0-6, passives 7-8 on an explicit 0-10 survey.
16. **Forecast drift**: `relative_WAPE_change = (recent_WAPE − baseline_WAPE) / baseline_WAPE × 100`; zero-baseline deterioration is flagged separately without an infinite percentage.
17. **Model challenger improvement**: `(baseline_WAPE − challenger_WAPE) / baseline_WAPE × 100`; holdout-only and no auto-promotion.

Existing 0.4.1 formulas remain unchanged unless explicitly extended. Opportunity weights, four-layer decision weights, and surface diagnostic weights remain internal decision heuristics, not disclosed YouTube ranking weights.

## Skills used

Skills loaded and applied from the user-listed plugins:

- **Superpowers:** `using-superpowers`, `brainstorming` (user explicitly delegated design decisions), `writing-plans`, `test-driven-development`, `systematic-debugging`, `executing-plans`, `verification-before-completion`.
- **Caveman Development:** `cavecrew` (delegation boundaries; no subagents were available).
- **Agency Agents:** `agency-academic` applied to evidence and statistical review; no separate Agency agent instances were launched.
- **Matt Pocock Engineering Studio:** `ask-matt` routing and repository-first, narrow-change, verification contract.
- **ECC Agent Harness:** `ecc-agent-harness-architecture` applied to state transitions, idempotency, resumability and human approval boundaries.
- **Marketing Growth Studio:** `ab-testing` applied to experiment assumptions, SRM, multiple testing, guardrails and decision logging.
- **Spec Kit:** `agent-context-sync` applied to repository conventions, package metadata, CLI and schema consistency.
- **Scrapling:** `scrapling-browser-mcp` applied to runtime boundary and public-only collection constraints; Scrapling MCP server is not connected and was not invoked.
- **UI/UX Pro Max:** `charts-data-visualization` applied to table-first diagnostic presentation and missing-data semantics.
- **Ponytail:** `ponytail` applied to inspect-first, additive migration, smallest complete changes and verification.
- **Anti Slop:** `antislop` quality/evidence gates applied to dashboard additions; runtime delivery gate remains not verified.
- **I Have ADHD:** bounded work packages, visible progress, concise status reporting.

No subagents, Scrapling MCP runtime, Streamlit browser, live external provider, or production deployment was available or claimed.

## Verification record

Baseline on the extracted 0.4.1 source: `pytest -q` → 298 passed.

New targeted tests cover market coverage, query provenance and review gates, velocity/acceleration, originality flags, risk-adjusted contribution, forecast interval coverage, Benjamini-Hochberg, cohort completeness, source freshness, robust experiment analysis, forecast model comparison/drift, topic saturation, satisfaction surveys, KPI extensions, experiment/decision persistence and lifecycle, CLI commands and bounded worker batches.

Final verification:
- `pytest -q` → **325 passed** (baseline 298, 27 additional tests).
- `python -m compileall -q v17_niche_intel tests` → passed.
- `python -m py_compile v17_niche_intel/dashboard.py v17_niche_intel/cli.py` → passed.
- CLI help for root, experiment and decision-log → passed.
- Offline `growth-audit` smoke → passed; output schema version `v17-growth-audit-1.2` and advanced sections present.
- Offline `global-growth` smoke → passed; all 8 existing capability blocks present.
- JSON Schema Draft 2020-12 + format validation: growth-audit input template, global-growth input template and generated global-growth output → passed.
- Wheel build `v17_niche_intelligence-0.5.0-py3-none-any.whl` → passed.
- Isolated wheel install/import + `advanced_intelligence.audit_market_coverage` smoke → passed.
- Wheel SHA-256: `0072e4af2521fb29d454db605209be366e05e72e388fbd253aabf7bdb04d43a1`.
- Ruff → not run; executable not installed.
- Streamlit runtime/browser/responsive/keyboard/accessibility QA → not run; Streamlit not installed.
- Live YouTube Data API, Google Trends, Firecrawl, OAuth, machine translation provider and native-speaker review → not run; credentials/provider runtime/human reviewer were not supplied.
- Recurring scheduler, production worker service and deployment → not performed.

## Boundaries

- YouTube does not publish a complete ranking formula; V17 diagnostics do not claim to reproduce it.
- All-country research is bounded by the live supported-region registry, configured query variants, API quotas and returned samples.
- Machine translation and curated query strings do not prove local fluency, accent or cultural fit.
- Competitor private RPM and Analytics are unavailable; actual RPM is first-party owner-authorized only.
- Similarity scores do not determine copyright infringement or monetization eligibility.
- Forecast calibration requires a representative holdout dataset; a single local smoke test is not predictive validation.
- Scheduler invocation, live providers and deployment remain host-owned operations.

## Preserved 0.4.1 formula families and decision strategies

The following 0.4.1 formula families remain in the 0.5.0 release. Their meanings and caveats are unchanged:

- **Four-layer market decision**: each layer uses explicit evidence and its configured component weights; missing required evidence withholds the layer score. The four layers are audience demand, competitive opening, monetization economics and creator execution fit.
- **Market opportunity**: `0.25 × demand + 0.20 × relative monetization + 0.20 × competitive gap + 0.20 × creator fit + 0.15 × confidence`.
- **Confidence adjustment**: `opportunity score × confidence`.
- **Scenario gross revenue**: `reachable monthly views / 1,000 × RPM scenario`.
- **Net contribution**: `gross revenue − production cost − localization cost − risk reserve`.
- **Sample HHI**: `10,000 × Σ(sampled channel share²)`; only a sampled-result-set statistic.
- **Top-channel sample share**: `max(channel sampled views) / total sampled views × 100`.
- **Thumbnail CTR**: registered thumbnail-impression CTR, or registered impression clicks / registered impressions × 100 only with explicit click semantics.
- **AVD**: `watch time seconds / views`.
- **APV**: `watch time seconds / (views × video duration seconds) × 100`, when consistent denominator data is available.
- **Subscriber conversion**: `subscribers gained / views × 1,000`.
- **Revenue per 1,000 views**: `estimated revenue / views × 1,000`.
- **Surface-specific diagnostics**: Search, Browse, Suggested and Shorts use the configured internal weights from 0.4.1. They are diagnostic scores, not YouTube's proprietary weights.
- **Portfolio concentration**: `HHI = 10,000 × Σ(allocation share²)` and effective market count `1 / Σ(share²)`.
- **Forecast error**: MAE, WAPE, MAPE (non-zero actuals) and signed aggregate bias.
- **Experiment planning**: two-proportion sample-size approximation using alpha, power, baseline rate and minimum detectable effect.
- **Experiment integrity**: two-arm SRM chi-square approximation, preregistered primary metric and guardrail requirements.
- **Learning policy**: holdout/backtest and minimum-observation gates; no automatic score-weight application.

## Remaining external or deployment gates

The source implementation is complete for the deterministic/offline features listed above. The following work cannot be certified or fully activated from this workspace alone:

- Actual all-country live scans require the user's YouTube Data API project, current supported-region results, quota and provider access. The market registry is bounded to YouTube-supported regions and CLDR's official/major language segments, not every dialect or every speaker group.
- Native translation, dialect, accent, pronunciation and cultural validation require qualified human reviewers. The engine records review gates but cannot certify natural speech.
- Multi-language audio production, dubbing, metadata publication and channel uploads remain human/YouTube Studio or separately authorized workflow operations; no channel mutation was performed.
- Competitor RPM, private Analytics, satisfaction survey responses and detailed audience cohorts are unavailable unless supplied from authorized first-party or explicit research inputs.
- Originality screening currently uses supplied title/script lexical similarity. It does not compare full audio/video embeddings, determine copyright infringement or certify monetization eligibility.
- The dashboard source is updated, but Streamlit is absent, so runtime, mobile layout, keyboard, screen-reader, WCAG contrast and browser interaction remain NOT VERIFIED.
- Recurring scheduler, worker service supervision, provider failover under live quota conditions, production observability, deployment, and operational backup/restore drills remain host deployment tasks.
- No live YouTube, Google Trends, Firecrawl, OAuth, translation API or native-review calls were executed.
