from __future__ import annotations
import csv
import math
from dataclasses import dataclass
from datetime import date
from pathlib import Path
from typing import Any

REQUIRED = {"date", "video_id"}
NUMERIC = {"views", "watch_time_minutes", "average_view_duration_seconds", "impressions", "impressions_ctr", "likes", "comments", "subscribers_gained", "subscribers_lost", "estimated_revenue"}
MAX_BYTES = 25 * 1024 * 1024
MAX_ROWS = 250_000

@dataclass(frozen=True, slots=True)
class AnalyticsCSVResult:
    valid: bool
    rows: tuple[dict[str, Any], ...]
    errors: tuple[str, ...]
    warnings: tuple[str, ...]
    row_count: int


def validate_analytics_csv(path: str | Path) -> AnalyticsCSVResult:
    p = Path(path)
    errors: list[str] = []; warnings: list[str] = []; rows: list[dict[str, Any]] = []; seen=set()
    if not p.is_file(): return AnalyticsCSVResult(False, (), ("CSV file does not exist",), (), 0)
    if p.stat().st_size > MAX_BYTES: return AnalyticsCSVResult(False, (), ("CSV exceeds 25 MiB limit",), (), 0)
    try:
        with p.open("r", encoding="utf-8-sig", newline="") as f:
            reader=csv.DictReader(f)
            normalized_fields = [x.strip() for x in (reader.fieldnames or [])]
            if not normalized_fields or any(not field for field in normalized_fields):
                return AnalyticsCSVResult(False, (), ("CSV header contains an empty column name",), (), 0)
            if len(set(normalized_fields)) != len(normalized_fields):
                return AnalyticsCSVResult(False, (), ("CSV contains duplicate header names after normalization",), (), 0)
            fields=set(normalized_fields)
            missing=REQUIRED-fields
            if missing: return AnalyticsCSVResult(False, (), (f"Missing required columns: {', '.join(sorted(missing))}",), (), 0)
            unknown=fields-REQUIRED-NUMERIC
            if unknown: warnings.append(f"Unrecognized columns preserved as text: {', '.join(sorted(unknown))}")
            physical_rows = 0
            for line,row in enumerate(reader, start=2):
                physical_rows += 1
                if physical_rows > MAX_ROWS: errors.append("CSV exceeds 250,000 row limit"); break
                if None in row:
                    errors.append(f"Row {line}: extra cells beyond the header")
                    continue
                item={k.strip(): (v.strip() if isinstance(v,str) else v) for k,v in row.items() if k}
                try: parsed_date=date.fromisoformat(item["date"])
                except (ValueError, TypeError): errors.append(f"Row {line}: date must use YYYY-MM-DD"); continue
                video_id=item.get("video_id", "")
                if not video_id: errors.append(f"Row {line}: video_id is required"); continue
                key=(parsed_date.isoformat(), video_id)
                if key in seen: errors.append(f"Row {line}: duplicate date/video_id row"); continue
                seen.add(key); item["date"]=parsed_date.isoformat()
                for col in NUMERIC & item.keys():
                    raw=item[col]
                    if raw in (None, ""): item[col]=None; continue
                    try: value=float(raw)
                    except (TypeError, ValueError): errors.append(f"Row {line}: {col} must be numeric"); continue
                    if not math.isfinite(value): errors.append(f"Row {line}: {col} must be finite"); continue
                    if value < 0: errors.append(f"Row {line}: {col} cannot be negative"); continue
                    item[col]=int(value) if value.is_integer() else value
                rows.append(item)
    except (UnicodeDecodeError, csv.Error, OSError) as exc:
        errors.append(f"Unable to read CSV: {type(exc).__name__}")
    if not rows and not errors: errors.append("CSV contains no data rows")
    return AnalyticsCSVResult(not errors, tuple(rows), tuple(errors), tuple(warnings), len(rows))
