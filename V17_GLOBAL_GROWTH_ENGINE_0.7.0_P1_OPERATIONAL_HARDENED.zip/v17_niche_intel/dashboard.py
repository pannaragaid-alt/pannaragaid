from __future__ import annotations
import json
import os
import uuid
from datetime import date, datetime, timedelta
import streamlit as st
from .storage.database import Database
from .config import youtube_quota_limits
from .services.research import ResearchService
from .services.global_market import GlobalMarketDiscoveryService, DEFAULT_MARKETS, build_market_registry
from .credentials.manager import CredentialManager
from .credentials.secrets import KeyringSecretStore
from .credentials.providers import build_configured_youtube_data_api_provider
from .credentials.oauth_flow import GoogleOAuthConsentFlow, ANALYTICS_READONLY_SCOPE, ANALYTICS_MONETARY_READONLY_SCOPE
from .credentials.oauth_callback import OAuthCallbackListener
from .services.market_intelligence import MarketIntelligenceService
from .services.growth_intelligence import analyze_growth_bundle
from .providers.youtube_analytics import YouTubeAnalyticsProvider, READONLY_SCOPE
from .storage.repositories import PrivateAnalyticsRepository, JobCheckpointRepository, ExperimentRepository, DecisionLogRepository
from .providers.incognito_scraper import IncognitoScraper, DirectHTTPSFetcher, parse_allowed_hosts, parse_allowed_paths, ScrapePolicyError
from .providers.firecrawl_search import FirecrawlSearchProvider
from .storage.repositories import SERPSnapshotRepository
from .ui.theme import build_theme_css
from .ui.input_safety import parse_bounded_json

st.set_page_config(page_title="V17 Niche Intelligence", page_icon="◈", layout="wide", initial_sidebar_state="expanded")
try:
    other_daily_limit, search_daily_limit = youtube_quota_limits()
except ValueError as exc:
    st.error(f"Invalid runtime configuration: {exc}")
    st.stop()
db_path=os.getenv("V17_DATABASE","v17_niche_intel.sqlite3")
db=Database(db_path)

# User-selectable appearance; System follows the operating-system preference.
theme_choice = st.sidebar.selectbox("Appearance", ["System", "Light", "Dark"], index=0, key="v17_theme_choice")
st.markdown(build_theme_css(theme_choice.lower()), unsafe_allow_html=True)

st.markdown("""<section class="v17-hero">
  <div class="v17-eyebrow">V17 / SIGNAL ATELIER · NICHE INTELLIGENCE</div>
  <h1>Find the signal.<br>Build with evidence.</h1>
  <p>Research demand, map competitors, and validate channel opportunities in one focused workspace. Public market evidence stays separate from your private channel analytics.</p>
</section>""", unsafe_allow_html=True)

tab_overview, tab_strategy, tab_connections, tab_public, tab_advanced = st.tabs(["Overview", "Channel Strategy", "Connections", "Public Intelligence", "Advanced Lab"])

with st.sidebar:
    st.markdown("**RESEARCH WORKSPACE**")
    st.caption("Define the market and run an evidence-led scan.")
    topic=st.text_input("Niche / topic",placeholder="e.g. home coffee roasting",help="Use a specific audience, problem, or content category.")
    global_discovery = st.checkbox("Global discovery · scan supported country-language markets", value=True,
        help="Discovers YouTube-supported regions when connected and runs one localized research pass per market-language profile. Each profile uses one search.list call plus a possible videos.list detail call.")
    if global_discovery:
        st.caption(f"{len(DEFAULT_MARKETS)} curated profiles before live YouTube region expansion · country/language localization · up to 2 query variants per market by default")
        st.caption(f"search.list: 1 call in a separate {search_daily_limit:,}-calls/day bucket. videos.list and i18nRegions.list: 1 unit each in the general {other_daily_limit:,}-units/day bucket.")
        global_search_call_budget = st.number_input("Global search.list call budget", min_value=0, max_value=search_daily_limit,
            value=min(90, search_daily_limit), step=1, help="A partial scan is not ranked. Increase only if your project has an approved search quota increase.")
        global_query_variant_limit = st.number_input("Localized query variants per market", min_value=1, max_value=12, value=2, step=1,
            help="Samples up to two curated/native query variants per market by default; each variant consumes its own API search budget.")
        global_other_quota_budget = st.number_input("Global general API quota budget (units)", min_value=0, max_value=other_daily_limit,
            value=min(9000, other_daily_limit), step=100, help="Reserves video-detail and region-registry calls from the separate general API quota bucket.")
        decision_evidence_file = st.file_uploader("Optional decision, eligibility + localized-query evidence JSON", type=["json"], key="v17_global_evidence")
        country, language = "ID", "id"
    else:
        global_search_call_budget = None
        global_query_variant_limit = 1
        global_other_quota_budget = None
        decision_evidence_file = None
        country=st.text_input("Market country code",value="ID",max_chars=2).upper()
        language=st.text_input("Language code",value="id",max_chars=8)
    mode=st.selectbox("Research mode", ["market_entry", "existing_channel", "both"],
        format_func=lambda value: {"market_entry": "Market entry", "existing_channel": "Existing channel", "both": "Market + channel"}[value],
        disabled=global_discovery)
    if global_discovery:
        st.caption("Global discovery currently scans public market evidence. Disable it to run private channel Analytics for one market.")
    research_channel_id = ""
    research_analytics_start = date.today() - timedelta(days=28)
    research_analytics_end = date.today()
    if mode in {"existing_channel", "both"}:
        st.markdown("<div class=\"v17-section-kicker\">CHANNEL CONTEXT</div>", unsafe_allow_html=True)
        research_channel_id=st.text_input("Your channel ID",help="Only used with owner-authorized read-only Analytics.")
        research_analytics_start=st.date_input("Analytics start",value=research_analytics_start)
        research_analytics_end=st.date_input("Analytics end",value=research_analytics_end)
    else:
        st.caption("Market entry mode does not require OAuth or private channel access.")
    st.markdown("<div class=\"v17-section-kicker\">COLLECTION DEPTH</div>", unsafe_allow_html=True)
    limit=st.slider("Video sample size",5,50,25)
    run=st.button("Run research",type="primary",disabled=not topic.strip(),use_container_width=True)

if run:
    provider=None
    try:
        provider=build_configured_youtube_data_api_provider(db,use_case="market_research",environment="local")
    except Exception as exc:
        provider=None
        st.warning(f"YouTube provider unavailable: {type(exc).__name__}")
    with st.spinner("Collecting public evidence..."):
        trends_provider = None
        if not global_discovery:
            try:
                from .providers.google_trends import GoogleTrendsProvider
                trends_provider = GoogleTrendsProvider(language_code=language or "en")
            except Exception:
                pass
        analytics_provider = None
        if not global_discovery and mode in {"existing_channel", "both"} and research_channel_id.strip():
            try:
                analytics_manager = CredentialManager(db, KeyringSecretStore())
                analytics_client = analytics_manager.build_youtube_analytics_client(research_channel_id.strip(), required_scopes={READONLY_SCOPE})
                analytics_provider = YouTubeAnalyticsProvider(analytics_client)
            except Exception as exc:
                st.warning(f"Private Analytics not connected: {type(exc).__name__}")
        if global_discovery:
            decision_evidence = {}
            market_eligibility = {}
            localized_query_variants = {}
            if decision_evidence_file is not None:
                try:
                    evidence_bytes = decision_evidence_file.getvalue()
                    if len(evidence_bytes) > 5 * 1024 * 1024:
                        raise ValueError("Evidence JSON exceeds the 5 MiB upload limit")
                    evidence_payload = parse_bounded_json(evidence_bytes.decode("utf-8"), max_bytes=5 * 1024 * 1024)
                    if not isinstance(evidence_payload, dict):
                        raise ValueError("Evidence file root must be a JSON object")
                    unexpected = set(evidence_payload) - {"decision_evidence", "market_eligibility", "localized_query_variants"}
                    if unexpected:
                        raise ValueError(f"Unexpected top-level fields: {', '.join(sorted(unexpected))}")
                    decision_evidence = evidence_payload.get("decision_evidence", {})
                    market_eligibility = evidence_payload.get("market_eligibility", {})
                    localized_query_variants = evidence_payload.get("localized_query_variants", {})
                    if (not isinstance(decision_evidence, dict) or not isinstance(market_eligibility, dict)
                            or not isinstance(localized_query_variants, dict)):
                        raise ValueError("decision_evidence, market_eligibility, and localized_query_variants must be JSON objects")
                except (UnicodeDecodeError, json.JSONDecodeError, ValueError) as exc:
                    st.error(f"Evidence JSON rejected; no global scan was run: {exc}")
                    st.stop()
            def trends_factory(market):
                from .providers.google_trends import GoogleTrendsProvider
                return GoogleTrendsProvider(language_code=market.language_code, locale=market.locale)
            def translate_query(seed, language_code):
                from deep_translator import GoogleTranslator
                return GoogleTranslator(source="auto", target=language_code).translate(seed)
            try:
                translator = translate_query
                import deep_translator  # noqa: F401
            except ImportError:
                translator = None
            markets = DEFAULT_MARKETS
            registry_source = "curated_default_fallback"
            region_lookup_units = 0
            if provider is not None and hasattr(provider, "list_supported_regions"):
                region_lookup_units = 1
                try:
                    markets = build_market_registry(list(provider.list_supported_regions()))
                    registry_source = "live_youtube_i18nRegions.list_plus_cldr_metadata"
                except Exception as exc:
                    st.warning(f"Dynamic YouTube region discovery unavailable; using {len(DEFAULT_MARKETS)} curated market profiles: {type(exc).__name__}")
            result = GlobalMarketDiscoveryService(youtube_provider=provider,
                trends_provider_factory=trends_factory, translator=translator).discover(
                    topic=topic, markets=markets, limit=limit,
                    decision_evidence=decision_evidence, market_eligibility=market_eligibility,
                    localized_query_variants=localized_query_variants,
                    query_variant_limit=int(global_query_variant_limit),
                    search_call_budget=int(global_search_call_budget),
                    other_quota_budget_units=int(global_other_quota_budget),
                    other_quota_preconsumed_units=region_lookup_units,
                    search_quota_limit=search_daily_limit, other_quota_limit=other_daily_limit,
                    market_registry_source=registry_source)
        else:
            result=ResearchService(db,youtube_provider=provider,trends_provider=trends_provider,
                analytics_provider=analytics_provider).research(
                topic=topic,country_code=country,mode=mode,limit=limit,language_code=language or None,
                channel_id=research_channel_id.strip() or None,analytics_start_date=research_analytics_start,
                analytics_end_date=research_analytics_end)
    st.session_state["last_result"]=result
with tab_overview:
    st.markdown('<div class="v17-section-kicker">LATEST RESEARCH SNAPSHOT</div>', unsafe_allow_html=True)
    result = st.session_state.get("last_result")
    if result:
        if "markets" in result:
            a, b, c = st.columns(3)
            a.metric("Market profiles", result["registry"]["market_profile_count"])
            c.metric("Usable YouTube samples", sum(1 for item in result["markets"] if item["youtube"]["status"] in {"ok", "partial"}))
            b.metric("Rankable markets", sum(1 for item in result["markets"] if item.get("ranking_eligible")))
            market_rows = []
            for item in result["markets"]:
                market_rows.append({"Market segment": item["country_name"], "Code": item["country_code"],
                    "Language": item["locale"], "YouTube": item["youtube"]["status"],
                    "Videos": item["youtube"].get("sample_size", 0),
                    "Trends": item["google_trends"].get("status", "not_configured"),
                    "Demand": item["decision_layers"].get("audience_demand", {}).get("score"),
                    "Competition": item["decision_layers"].get("competitive_opening", {}).get("score"),
                    "Monetization": item["decision_layers"].get("monetization_economics", {}).get("score"),
                    "Execution": item["decision_layers"].get("creator_execution_fit", {}).get("score"),
                    "Decision": item["decision"]["status"],
                    "Eligibility": item["eligibility"]["status"],
                    "Ranking eligible": item.get("ranking_eligible", False),
                    "Coverage": f"{item['decision']['coverage']:.0%}"})
            st.subheader("Global market comparison")
            st.dataframe(market_rows, use_container_width=True, hide_index=True)
            if result.get("ranked_markets"):
                st.subheader("Evidence-qualified market ranking")
                st.dataframe([{"Rank": index + 1, "Market": item["market_id"],
                    "Decision score": item["decision"]["score"], "Confidence": item.get("confidence"),
                    "Independent sources": item.get("independent_source_count", 0)}
                    for index, item in enumerate(result["ranked_markets"])], use_container_width=True, hide_index=True)
            elif result.get("status") == "partial_quota_limited":
                st.warning("Global scan berhenti pada batas kuota. Hasil parsial tetap ditampilkan untuk inspeksi, tetapi ranking sengaja dinonaktifkan agar pasar yang belum dipindai tidak dirugikan.")
            else:
                st.info("Belum ada pasar yang memenuhi seluruh gerbang keputusan: empat lapisan berbukti, bahasa ditinjau penutur asli, hak/kebijakan lolos, dan kelayakan pasar terverifikasi. RPM/CPM atau satu sinyal tren tidak cukup.")
            st.caption("Markets are not ranked by RPM/CPM. Four decision layers: audience demand, competitive opening, monetization economics, and creator execution fit. Missing, stale, or unprovenanced evidence is not neutral-filled. A quota-limited scan is never ranked.")
            from .services.global_growth_engine import analyze_competitor_sample
            competitor_rows = []
            for item in result["markets"]:
                profile = analyze_competitor_sample(item.get("youtube", {}).get("videos", []))
                competitor_rows.append({"Market": item["market_id"], "Sample videos": profile["sample_size"],
                    "Channels": profile["channel_count"], "Median views": profile["median_video_views"],
                    "Sample HHI": profile["channel_view_share_hhi"],
                    "Lifetime avg views/day": profile["mean_lifetime_average_views_per_day"]})
            st.subheader("Public competitor sample diagnostics")
            st.dataframe(competitor_rows, use_container_width=True, hide_index=True)
            st.caption("HHI and views/day describe only the sampled public results. Views/day is lifetime-average, not growth velocity; repeated timestamped snapshots are required for interval velocity.")
            st.caption(f"Registry: {result['registry']['country_count']} countries / {result['registry']['market_profile_count']} language markets · {result['registry']['source']}")
            search_quota = result["quota"]["search_bucket"]
            other_quota = result["quota"]["general_bucket"]
            st.caption(f"Quota estimate — search.list: {search_quota['estimated_calls']}/{search_quota['daily_limit_calls']} calls; general endpoints: {other_quota['estimated_units']}/{other_quota['daily_limit_units']} units.")
            st.caption(f"Reserved/attempted — search.list: {search_quota['attempted_calls']} calls; general: {other_quota['attempted_or_reserved_units']} units. Partial scans are never ranked.")
            with st.expander("Market evidence and localization details"):
                st.json(result["markets"])
            with st.expander("Decision model and global limitations"):
                st.json({"model": result["decision_model"], "limitations": result["global_limitations"]})
        else:
            a, b, c = st.columns(3)
            a.metric("Score status", result["analysis"]["status"])
            b.metric("Evidence coverage", f"{result['analysis']['coverage']:.0%}")
            c.metric("Sampled videos", len(result["videos"]))

        if "markets" not in result:
            st.subheader("Provider readiness")
            provider_rows = [
                {"Provider": name.replace("_", " ").title(), "Status": value.get("status", "unknown") if isinstance(value, dict) else str(value)}
                for name, value in result.get("providers", {}).items()
            ]
            if provider_rows:
                st.dataframe(provider_rows, use_container_width=True, hide_index=True)
            else:
                st.info("Belum ada status provider yang tersedia untuk riset ini.")

        if "markets" not in result:
            st.subheader("Video evidence sample")
            st.dataframe(result["videos"], use_container_width=True, hide_index=True)

        if "markets" not in result and result.get("private_channel_analytics", {}).get("status") == "ok":
            st.subheader("Private channel analytics")
            st.caption("Data ini berasal dari channel yang Anda otorisasi dan tetap terpisah dari bukti kompetitor publik.")
            st.json(result["private_channel_analytics"])
        if "markets" not in result:
            with st.expander("Market intelligence · detailed evidence"):
                st.json(result.get("market_intelligence", {}))
        if result.get("limitations"):
            with st.expander(f"Research limitations · {len(result['limitations'])}"):
                for limitation in result["limitations"]:
                    st.warning(limitation)
    else:
        st.markdown("""<div class="v17-note"><strong>Workspace ready.</strong> Masukkan niche di panel kiri, lalu jalankan pemindaian global untuk semua wilayah YouTube yang didukung (jika API terhubung). Tanpa kredensial, aplikasi menggunakan registry kurasi dan menandai provider sebagai <code>not_configured</code>; tidak ada metrik yang direkayasa.</div>""", unsafe_allow_html=True)
        st.write("### Your research workflow")
        step_a, step_b, step_c = st.columns(3)
        step_a.markdown("**01 · Define**  \nPilih niche, negara, bahasa, dan tipe channel.")
        step_b.markdown("**02 · Collect**  \nKumpulkan sinyal publik dan data milik channel yang diotorisasi.")
        step_c.markdown("**03 · Decide**  \nBaca coverage, confidence, risiko, dan peluang sebelum bertindak.")

with tab_strategy:
    st.markdown('<div class="v17-section-kicker">CHANNEL FOUNDATION · POSITIONING · CONTENT ADVANTAGE</div>', unsafe_allow_html=True)
    st.caption("Bangun positioning dari audience problem, keunggulan kreator, dan kelemahan kompetitor yang memiliki referensi bukti.")
    with st.form("channel_strategy_builder"):
        strategy_niche = st.text_input("Niche / category", placeholder="home coffee brewing")
        strategy_audience = st.text_input("Target audience", placeholder="beginner home baristas in Indonesia")
        strategy_problem = st.text_area("Core audience problem", placeholder="Masalah spesifik yang ingin diselesaikan channel", height=75)
        strategy_outcome = st.text_area("Desired audience outcome", placeholder="Perubahan nyata yang ingin dicapai penonton", height=75)
        strategy_method = st.text_area("Differentiated method", placeholder="Metode, sudut pandang, akses, atau proses khas channel", height=75)
        strategy_advantages = st.text_input("Creator advantages (comma-separated)", placeholder="hands-on testing, local expertise")
        strategy_competitor_gaps = st.text_area("Competitor gaps JSON", value="[]", height=130, max_chars=1_048_576, help="Each item needs competitor_id, gap, audience_impact, source_family, and real evidence_refs.")
        strategy_audience_signals = st.text_area("Audience signals JSON", value="[]", height=110, max_chars=1_048_576, help="Each item needs problem, source_family, real evidence_refs, and optional frequency.")
        build_strategy = st.form_submit_button("Build channel strategy", type="primary", use_container_width=True)
    if build_strategy:
        try:
            from .services.channel_strategy import ChannelStrategyService
            brief = {
                "niche": strategy_niche,
                "target_audience": strategy_audience,
                "audience_problem": strategy_problem,
                "desired_outcome": strategy_outcome,
                "unique_method": strategy_method,
                "creator_advantages": [item.strip() for item in strategy_advantages.split(",") if item.strip()],
                "competitor_gaps": parse_bounded_json(strategy_competitor_gaps),
                "audience_signals": parse_bounded_json(strategy_audience_signals),
            }
            st.session_state["channel_strategy_result"] = ChannelStrategyService().build(brief)
        except (json.JSONDecodeError, TypeError, ValueError) as exc:
            st.error(f"Channel strategy input is invalid: {type(exc).__name__}: {exc}")
    strategy_result = st.session_state.get("channel_strategy_result")
    if strategy_result:
        st.markdown("### Positioning and strategic opportunities")
        st.caption(f"Status: {strategy_result['status']} · excluded unsupported claims: {strategy_result.get('excluded_claims', 0)}")
        if strategy_result.get("positioning"):
            st.info(strategy_result["positioning"]["statement"])
            st.write("**Creator advantages**")
            st.write(strategy_result["positioning"].get("creator_advantages") or ["Not supplied"])
        if strategy_result.get("opportunity_map"):
            st.write("**Evidence-linked competitor gaps**")
            st.dataframe(strategy_result["opportunity_map"], use_container_width=True, hide_index=True)
        if strategy_result.get("content_pillars"):
            st.write("**Audience-led content pillars**")
            st.dataframe(strategy_result["content_pillars"], use_container_width=True, hide_index=True)
        with st.expander("Launch sequence and measurement contract"):
            st.json({"launch_sequence": strategy_result.get("launch_sequence", []),
                     "measurement_contract": strategy_result.get("measurement_contract", {}),
                     "evidence_quality": strategy_result.get("evidence_quality", {}),
                     "limitations": strategy_result.get("limitations", [])})
        st.download_button("Export channel strategy JSON", data=json.dumps(strategy_result, ensure_ascii=False, indent=2),
                           file_name="v17-channel-strategy.json", mime="application/json")

with tab_connections:
    st.markdown('<div class="v17-section-kicker">ACCOUNTS · PROVIDERS · PRIVACY</div>', unsafe_allow_html=True)
    st.caption("Kelola koneksi riset di satu tempat. Secret tetap berada di OS keyring; dashboard hanya menampilkan metadata dan status.")
    with st.expander("Credential management — local, private", expanded=True):
        st.caption("Secrets are stored in the operating-system keyring. SQLite stores references and metadata only.")
        try:
            secret_store = KeyringSecretStore()
            manager = CredentialManager(db, secret_store)
            with st.form("add_api_key"):
                st.markdown("**Register YouTube Data API key**")
                api_key = st.text_input("API key", type="password")
                project_id = st.text_input("Google Cloud project ID")
                use_case = st.text_input("Independent use case", value="market_research")
                environment = st.text_input("Environment", value="local")
                if st.form_submit_button("Save API key"):
                    manager.add_api_key(uuid.uuid4().hex, project_id=project_id, use_case=use_case,
                                        environment=environment, secret=api_key)
                    st.success("API key saved in OS keyring; value is not stored in SQLite.")
            api_credentials = manager.list_api_credentials()
            st.markdown("**API key inventory · secret values hidden**")
            if api_credentials:
                st.dataframe(api_credentials, use_container_width=True, hide_index=True)
                api_ids = [item["credential_id"] for item in api_credentials]
                selected_api = st.selectbox("API key to manage", api_ids)
                api_status = next(item["status"] for item in api_credentials if item["credential_id"] == selected_api)
                new_api_status = "disabled" if api_status == "active" else "active"
                if st.button(f"Set API key status: {new_api_status}"):
                    manager.set_api_key_status(selected_api, new_api_status)
                    st.success(f"API key status updated: {new_api_status}")
            else:
                st.info("No API key registered.")
            st.caption("Quota is shared by every key and use case inside the same Google Cloud project.")
            quota_rows = manager.quota_inventory()
            if quota_rows:
                st.dataframe(quota_rows, use_container_width=True, hide_index=True)
            st.markdown("**Registered OAuth accounts**")
            accounts = manager.list_oauth_accounts()
            if accounts:
                st.dataframe(accounts, use_container_width=True, hide_index=True)
                account_ids = [item["account_id"] for item in accounts]
                selected_account = st.selectbox("Account to disable / re-enable", account_ids)
                current_status = next(item["status"] for item in accounts if item["account_id"] == selected_account)
                target_status = "disabled" if current_status == "active" else "active" if current_status == "disabled" else None
                if target_status and st.button(f"Set OAuth status: {target_status}"):
                    manager.set_oauth_status(selected_account, target_status)
                    st.success(f"OAuth account status updated: {target_status}")
                elif target_status is None:
                    st.info("This account requires a fresh OAuth consent flow; status cannot be manually reactivated.")
                confirm_revoke = st.checkbox("I confirm remote Google token revocation")
                if st.button("Revoke Google OAuth grant and erase local token material", disabled=(not confirm_revoke or current_status == "revoked")):
                    try:
                        manager.revoke_oauth_account(selected_account)
                        st.success("Google OAuth grant revoked and local token material erased.")
                    except Exception as exc:
                        st.error(f"Google revocation failed: {type(exc).__name__}")
            else:
                st.info("No OAuth account registered.")
            st.markdown("**Fetch your private channel Analytics · read-only**")
            with st.form("fetch_private_analytics"):
                analytics_channel = st.text_input("Authorized channel ID", key="analytics_channel_query")
                private_analytics_start = st.date_input("Start date", value=date.today() - timedelta(days=28), key="private_analytics_start")
                private_analytics_end = st.date_input("End date", value=date.today(), key="private_analytics_end")
                fetch_analytics = st.form_submit_button("Fetch and store private Analytics")
            if fetch_analytics:
                try:
                    client = manager.build_youtube_analytics_client(analytics_channel, required_scopes={READONLY_SCOPE})
                    analytics_result = YouTubeAnalyticsProvider(client).query_daily(
                        channel_id=analytics_channel, start_date=private_analytics_start, end_date=private_analytics_end)
                    aliases = {"day": "date", "video": "video_id", "estimatedMinutesWatched": "watch_time_minutes",
                               "averageViewDuration": "average_view_duration_seconds"}
                    private_rows = tuple({aliases.get(key, key): value for key, value in row.items()}
                                         for row in analytics_result["records"])
                    repository = PrivateAnalyticsRepository(db)
                    if private_rows and "video_id" in private_rows[0]:
                        inserted = repository.import_rows(channel_id=analytics_channel, rows=private_rows, provenance=analytics_result.get("provenance"))
                    else:
                        inserted = repository.import_daily_rows(channel_id=analytics_channel, rows=private_rows, provenance=analytics_result.get("provenance"))
                    st.success(f"Fetched {len(private_rows)} daily channel rows; stored {inserted} private rows separately from public evidence.")
                except Exception as exc:
                    st.error(f"Analytics request failed: {type(exc).__name__}")
        except Exception as exc:
            st.warning(f"OS keyring unavailable: {type(exc).__name__}. Install/configure a supported OS keyring before saving credentials.")

    with st.expander("Connect YouTube Analytics · read-only OAuth"):
        client_json = st.text_area("Google OAuth Desktop/Web client JSON", height=120, max_chars=16384)
        oauth_channel_id = st.text_input("Authorized channel ID", key="oauth_channel")
        account_label = st.text_input("Account label", key="oauth_label")
        redirect_uri = st.text_input("OAuth redirect URI", value="http://127.0.0.1:8765/oauth2/callback")
        include_revenue_scope = st.checkbox("Include estimated revenue and country RPM (additional read-only permission)",
            value=False, help="Required only if you want V17 to calculate your own channel revenue and country-level RPM. This does not grant publishing or channel-management access.")

        def persist_oauth_credentials(credentials):
            if not credentials.refresh_token:
                raise RuntimeError("Google did not return a refresh token; revoke prior grant and retry consent")
            store = KeyringSecretStore()
            client = st.session_state["v17_oauth_client_config"]
            client_block = client.get("installed") or client.get("web")
            secret_ref = store.put(client_block["client_secret"])
            CredentialManager(db, store).add_oauth_account(uuid.uuid4().hex,
                account_label=st.session_state["v17_oauth_label"], secret_access_token=credentials.token,
                secret_refresh_token=credentials.refresh_token, client_secret_ref=secret_ref,
                scopes=credentials.scopes or st.session_state.get("v17_oauth_scopes", [ANALYTICS_READONLY_SCOPE]),
                channel_ids=[st.session_state["v17_oauth_channel"]], client_id=client_block["client_id"],
                expires_at=credentials.expiry.isoformat() if credentials.expiry else None)
            listener = st.session_state.pop("v17_oauth_listener", None)
            if listener:
                listener.stop()
            for key in ("v17_oauth_flow", "v17_oauth_state", "v17_oauth_url", "v17_oauth_scopes"):
                st.session_state.pop(key, None)
            revenue_scope_granted = ANALYTICS_MONETARY_READONLY_SCOPE in (credentials.scopes or st.session_state.get("v17_oauth_scopes", []))
            st.success("OAuth account registered with read-only scope and explicit channel binding. Estimated-revenue access: " + ("enabled" if revenue_scope_granted else "not enabled"))

        if st.button("Generate Google consent link"):
            try:
                if len(client_json.encode("utf-8")) > 16 * 1024:
                    raise ValueError("Google OAuth client JSON exceeds the 16 KiB limit")
                config = parse_bounded_json(client_json, max_bytes=16 * 1024, max_depth=16)
                flow = GoogleOAuthConsentFlow(config, redirect_uri=redirect_uri)
                parsed_redirect = __import__("urllib.parse", fromlist=["urlparse"]).urlparse(redirect_uri)
                listener = None
                if parsed_redirect.scheme == "http" and parsed_redirect.hostname in {"127.0.0.1", "localhost"}:
                    listener = OAuthCallbackListener(flow, host="127.0.0.1", port=parsed_redirect.port or 8765)
                    try:
                        listener.start()
                    except OSError:
                        listener = None
                if listener is None:
                    st.warning("Automatic callback is available only for a local loopback redirect; use manual callback fallback.")
                st.session_state["v17_oauth_listener"] = listener
                requested_scopes = [ANALYTICS_READONLY_SCOPE]
                if include_revenue_scope:
                    requested_scopes.append(ANALYTICS_MONETARY_READONLY_SCOPE)
                auth = flow.begin(scopes=tuple(requested_scopes))
                st.session_state["v17_oauth_scopes"] = requested_scopes
                st.session_state["v17_oauth_flow"] = flow
                st.session_state["v17_oauth_state"] = auth.state
                st.session_state["v17_oauth_client_config"] = config
                st.session_state["v17_oauth_channel"] = oauth_channel_id
                st.session_state["v17_oauth_label"] = account_label or oauth_channel_id
                st.session_state["v17_oauth_url"] = auth.authorization_url
            except Exception as exc:
                st.error(f"OAuth setup failed: {type(exc).__name__}")
        if st.session_state.get("v17_oauth_url"):
            st.link_button("Open Google consent", st.session_state["v17_oauth_url"])
            listener = st.session_state.get("v17_oauth_listener")
            if listener and st.button("Check automatic loopback callback"):
                callback_result = listener.poll()
                if callback_result is None:
                    st.info("Callback belum diterima. Selesaikan consent di browser, lalu cek kembali.")
                elif callback_result["status"] == "ok":
                    try:
                        persist_oauth_credentials(callback_result["credentials"])
                    except Exception as exc:
                        st.error(f"OAuth account storage failed: {type(exc).__name__}")
                else:
                    listener.stop()
                    st.session_state.pop("v17_oauth_listener", None)
                    st.error(f"OAuth callback rejected: {callback_result.get('error_type', 'unknown')}")
            callback = st.text_input("Manual fallback: paste full callback URL after consent", max_chars=4096)
            if st.button("Complete OAuth authorization manually"):
                try:
                    credentials = st.session_state["v17_oauth_flow"].complete(
                        state=st.session_state["v17_oauth_state"], authorization_response=callback)
                    persist_oauth_credentials(credentials)
                except Exception as exc:
                    st.error(f"OAuth callback rejected: {type(exc).__name__}")

with tab_public:
    st.markdown('<div class="v17-section-kicker">PUBLIC WEB SIGNALS · SNAPSHOTS · COMPETITOR SOURCES</div>', unsafe_allow_html=True)
    with st.expander("Public SERP history and competitor overlap", expanded=True):
        st.caption("Collect timestamped public web results by keyword. Search results are not private account data.")
        serp_keywords_text = st.text_input("Keywords (comma-separated)", placeholder="coffee roasting, espresso grinder", max_chars=5120)
        serp_country = st.text_input("SERP country", value=country, max_chars=2).upper()
        serp_location = st.text_input("SERP location (optional)", placeholder="Surabaya", max_chars=256)
        if st.button("Collect SERP snapshots", disabled=not serp_keywords_text.strip()):
            firecrawl_key = os.getenv("FIRECRAWL_API_KEY")
            if not firecrawl_key:
                st.error("FIRECRAWL_API_KEY is not configured in the local environment.")
            else:
                try:
                    serp_provider = FirecrawlSearchProvider(firecrawl_key)
                    serp_repo = SERPSnapshotRepository(db)
                    serp_keywords = list(dict.fromkeys(item.strip() for item in serp_keywords_text.split(",") if item.strip()))[:10]
                    for keyword in serp_keywords:
                        snapshot = serp_provider.search(keyword, country=serp_country,
                            location=serp_location or None, limit=5)
                        if snapshot["status"] == "ok":
                            serp_repo.add(keyword=keyword, country=serp_country, language=language or None,
                                observed_at=datetime.fromisoformat(snapshot["observed_at"]),
                                results=[{"url": item["url"]} for item in snapshot["results"]])
                    histories = {keyword: serp_repo.list_for_keyword(keyword, country=serp_country) for keyword in serp_keywords}
                    latest = {keyword: rows[-1]["results"] for keyword, rows in histories.items() if rows}
                    serp_report = MarketIntelligenceService().analyze({"keywords": serp_keywords,
                        "serp_snapshots_by_keyword": histories, "serp_results_by_keyword": latest})
                    st.session_state["serp_intelligence_report"] = serp_report
                except Exception as exc:
                    st.error(f"SERP collection failed: {type(exc).__name__}")
        if st.session_state.get("serp_intelligence_report"):
            with st.expander("SERP intelligence report"):
                st.json(st.session_state["serp_intelligence_report"])

    with st.expander("Incognito public-page research"):
        st.caption("Owner-approved exact hostnames only · HTTPS · DNS-pinned egress · redirects revalidated · no cookies/profile")
        scrape_url = st.text_input("Public competitor/reference URL", placeholder="https://approved.example/article", max_chars=4096)
        try:
            scrape_allowlist = parse_allowed_hosts(os.getenv("V17_SCRAPE_ALLOWED_HOSTS"))
            parse_allowed_paths(os.getenv("V17_SCRAPE_ALLOWED_PATHS"), scrape_allowlist)
            scrape_configured = True
        except ScrapePolicyError:
            scrape_allowlist = frozenset()
            scrape_path_policy = {}
            scrape_configured = False
            st.warning("Set V17_SCRAPE_ALLOWED_HOSTS and V17_SCRAPE_ALLOWED_PATHS before enabling public-page fetches.")
        if st.button("Scrape public page", disabled=(not scrape_url.strip() or not scrape_configured)):
            try:
                fetcher = DirectHTTPSFetcher(scrape_allowlist, allowed_paths=os.getenv("V17_SCRAPE_ALLOWED_PATHS"))
                scrape_result = IncognitoScraper(fetcher, allowed_hosts=scrape_allowlist,
                    allowed_paths=os.getenv("V17_SCRAPE_ALLOWED_PATHS")).scrape(scrape_url.strip())
                st.session_state["incognito_scrape_result"] = {
                    "url": scrape_result.url, "status_code": scrape_result.status_code,
                    "privacy_mode": "direct_https_dns_pinned_exact_allowlist_no_cookies_no_profile",
                    "metadata": scrape_result.metadata}
                st.session_state["incognito_scrape_markdown"] = scrape_result.markdown
            except Exception as exc:
                st.error(f"Public scrape failed: {type(exc).__name__}: {exc}")
        if st.session_state.get("incognito_scrape_result"):
            st.json(st.session_state["incognito_scrape_result"])
            st.text_area("Scraped text (untrusted source)", st.session_state.get("incognito_scrape_markdown", ""), height=240)

with tab_advanced:
    st.markdown('<div class="v17-section-kicker">POWER USER WORKSPACE · STRUCTURED EVIDENCE</div>', unsafe_allow_html=True)
    st.caption("Advanced controls are separated from the main research flow to keep the workspace focused.")
    with st.expander("Persistent research job checkpoints", expanded=False):
        st.caption("V17 stores resumable job metadata and checkpoints. This view does not start workers or schedule background jobs.")
        try:
            job_rows = JobCheckpointRepository(db).list(limit=100)
            if job_rows:
                st.dataframe([{"Job": row["job_id"], "Type": row["job_type"], "Status": row["status"],
                    "Attempts": row["attempt_count"], "Updated": row["updated_at"],
                    "Checkpoint keys": ", ".join(sorted(row["checkpoint"].keys()))} for row in job_rows],
                    use_container_width=True, hide_index=True)
            else:
                st.info("No persistent job checkpoints have been created.")
        except Exception as exc:
            st.warning(f"Job checkpoint storage unavailable: {type(exc).__name__}")
    with st.expander("Persistent experiments and strategic decisions", expanded=False):
        try:
            experiment_rows = ExperimentRepository(db).list(limit=100)
            decision_rows = DecisionLogRepository(db).list(limit=100)
            st.caption("Experiment lifecycle and decision evidence are stored locally. No experiment is run or published by this view.")
            if experiment_rows:
                st.dataframe([{"Experiment": row["experiment_id"], "Status": row["status"],
                    "Objective": row["objective"], "Primary metric": row["primary_metric"],
                    "Updated": row["updated_at"]} for row in experiment_rows], use_container_width=True, hide_index=True)
            else:
                st.info("No experiments registered yet.")
            if decision_rows:
                st.dataframe([{"Decision": row["decision_id"], "Topic": row["topic"],
                    "Recommendation": row["recommendation"], "Metric": row["expected_metric"],
                    "Status": row["status"]} for row in decision_rows], use_container_width=True, hide_index=True)
            else:
                st.info("No strategic decisions logged yet.")
        except Exception as exc:
            st.warning(f"Experiment/decision registry unavailable: {type(exc).__name__}")

    with st.expander("V17 0.7.0 · Global growth evidence audit", expanded=True):
        st.caption("P0-P2 diagnostics: coverage, localization query provenance, competitor velocity, audience cohorts, originality review, forecast calibration and experimentation.")
        growth_payload_text = st.text_area("Growth evidence JSON", value="{}", height=220, max_chars=1_048_576, key="v17_growth_evidence_json")
        if st.button("Run global growth evidence audit", key="v17_growth_audit_run"):
            try:
                growth_result = analyze_growth_bundle(parse_bounded_json(growth_payload_text))
                st.session_state["v17_growth_audit_result"] = growth_result
                st.success("Growth evidence audit completed.")
            except Exception as exc:
                st.error(f"Growth audit failed: {type(exc).__name__}")
        if st.session_state.get("v17_growth_audit_result"):
            with st.expander("Growth evidence audit output"):
                st.json(st.session_state["v17_growth_audit_result"])

    with st.expander("Advanced intelligence — analyze imported evidence", expanded=True):
        st.caption("Paste measured evidence as JSON. Missing fields remain explicitly unconfigured; no metrics are fabricated.")
        sample = '{"keywords":["how to brew coffee","best espresso grinder"],"keyword_channels":{"coffee":["UC1","UC2"],"espresso":["UC1"]},"serp_snapshots":[{"observed_at":"2025-01-01T00:00:00+00:00","results":["UC1","UC2"]},{"observed_at":"2025-01-02T00:00:00+00:00","results":["UC2","UC1"]}],"content_plan":[{"video_id":"v1","intent":"informational"},{"video_id":"v2","intent":"informational"}]} '
        evidence_json = st.text_area("Evidence JSON", value=sample, height=200, max_chars=1_048_576)
        if st.button("Analyze evidence bundle"):
            try:
                advanced = MarketIntelligenceService().analyze(parse_bounded_json(evidence_json))
                st.session_state["advanced_intelligence"] = advanced
                st.success("Evidence bundle analyzed.")
            except Exception as exc:
                st.error(f"Evidence analysis failed: {type(exc).__name__}")
        if st.session_state.get("advanced_intelligence"):
            with st.expander("Structured intelligence output"):
                st.json(st.session_state["advanced_intelligence"])

db.close()
