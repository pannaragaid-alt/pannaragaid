from __future__ import annotations

import html
import json
import os
import tempfile
from pathlib import Path
from typing import Any, Callable, TextIO


def _safe_spreadsheet_cell(value: Any) -> Any:
    """Prefix untrusted text that spreadsheet applications may interpret as a formula."""
    if not isinstance(value, str):
        return value
    probe = value.lstrip("\ufeff \t\r\n")
    if value[:1] in {"\t", "\r", "\n"} or probe[:1] in {"=", "+", "-", "@"}:
        return "'" + value
    return value


def _safe_markdown_text(value: Any) -> str:
    text = str(value).replace("\r\n", " ").replace("\r", " ").replace("\n", " ")
    text = html.escape(text, quote=False)
    for character in "\\`*_{}[]()#+-.!>|":
        text = text.replace(character, "\\" + character)
    return text


def _atomic_private_write(target: Path, writer: Callable[[TextIO], None]) -> None:
    """Write reports atomically with owner-only permissions; never follow target symlinks."""
    descriptor, temporary_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=target.parent)
    try:
        if os.name == "posix":
            os.fchmod(descriptor, 0o600)
        with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as stream:
            writer(stream)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary_name, target)
        if os.name == "posix":
            os.chmod(target, 0o600)
    except BaseException:
        try:
            os.close(descriptor)
        except OSError:
            pass
        try:
            os.unlink(temporary_name)
        except FileNotFoundError:
            pass
        raise


def export_report(result: dict[str, Any], path: str | Path, *, format: str | None = None) -> Path:
    target = Path(path)
    kind = (format or target.suffix.lstrip(".") or "json").lower()
    if kind == "json":
        content = json.dumps(result, ensure_ascii=False, indent=2, default=str)
        _atomic_private_write(target, lambda stream: stream.write(content))
    elif kind == "md":
        lines = [
            f"# V17 Research: {_safe_markdown_text(result['run']['topic'])}",
            "",
            f"- Run: `{_safe_markdown_text(result['run']['id'])}`",
            f"- Mode: {_safe_markdown_text(result['run']['mode'])}",
            f"- Country: {_safe_markdown_text(result['run']['country_code'])}",
            f"- Score status: {_safe_markdown_text(result['analysis']['status'])}",
            f"- Coverage: {result['analysis']['coverage']:.0%}",
            "",
            "## Provider status",
        ]
        lines += [f"- **{_safe_markdown_text(name)}:** {_safe_markdown_text(value.get('status', 'unknown'))}"
                  for name, value in result["providers"].items()]
        lines += ["", "## Videos"] + [
            f"- {_safe_markdown_text(video['title'])} — {_safe_markdown_text(video['format']['label'])} — views: {video['views']}"
            for video in result["videos"]
        ]
        lines += ["", "## Limitations"] + [f"- {_safe_markdown_text(item)}" for item in result["limitations"]]
        _atomic_private_write(target, lambda stream: stream.write("\n".join(lines) + "\n"))
    elif kind == "csv":
        import csv

        def write_csv(stream: TextIO) -> None:
            writer = csv.DictWriter(stream, fieldnames=["video_id", "title", "channel_id", "views", "published_at", "format"])
            writer.writeheader()
            for video in result["videos"]:
                row = {
                    **{key: video.get(key) for key in ("video_id", "title", "channel_id", "views", "published_at")},
                    "format": video["format"]["label"],
                }
                writer.writerow({key: _safe_spreadsheet_cell(value) for key, value in row.items()})

        _atomic_private_write(target, write_csv)
    else:
        raise ValueError("format must be json, md, or csv")
    return target
