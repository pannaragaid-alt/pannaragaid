"""Advanced, evidence-aware diagnostics for V17 0.5.0.

All scores are decision-support diagnostics. They are not YouTube ranking formulas,
market censuses, native-language certification, or copyright determinations.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from itertools import combinations
from math import isfinite
import re
from statistics import mean
from typing import Any, Callable, Mapping, Sequence
from urllib.parse import urlparse


def _number(value: Any, name: str, minimum: float | None = None,
            maximum: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)):
        raise ValueError(f"{name} must be a finite number")
    number = float(value)
    if minimum is not None and number < minimum:
        raise ValueError(f"{name} must be >= {minimum}")
    if maximum is not None and number > maximum:
        raise ValueError(f"{name} must be <= {maximum}")
    return number


def _aware(value: Any, name: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be an ISO-8601 datetime") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{name} must include a timezone")
    return parsed.astimezone(timezone.utc)


def audit_market_coverage(expected_market_ids: Sequence[str],
                          attempts: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Expose exact attempted/covered markets; partial or failed markets are not rankable."""
    if isinstance(expected_market_ids, (str, bytes)) or not isinstance(expected_market_ids, Sequence) or not expected_market_ids:
        raise ValueError("expected_market_ids must be a non-empty list")
    expected = [str(item).strip() for item in expected_market_ids]
    if any(not item for item in expected) or len(expected) != len(set(expected)):
        raise ValueError("expected market IDs must be non-empty and unique")
    if isinstance(attempts, (str, bytes)) or not isinstance(attempts, Sequence):
        raise ValueError("attempts must be a list")
    by_id: dict[str, dict[str, Any]] = {}
    allowed = {"ok", "partial", "failed", "unsupported", "not_attempted"}
    for row in attempts:
        if not isinstance(row, Mapping):
            raise ValueError("each market attempt must be an object")
        market_id = str(row.get("market_id") or "").strip()
        status = str(row.get("status") or "").strip().lower()
        if market_id not in expected:
            raise ValueError(f"unexpected market attempt: {market_id}")
        if market_id in by_id:
            raise ValueError(f"duplicate market attempt: {market_id}")
        if status not in allowed:
            raise ValueError(f"invalid attempt status for {market_id}")
        count = row.get("sample_count", 0)
        if isinstance(count, bool) or not isinstance(count, int) or count < 0:
            raise ValueError("sample_count must be a non-negative integer")
        by_id[market_id] = {"status": status, "sample_count": count,
                            "error_code": str(row.get("error_code") or "") or None,
                            "rankable": status == "ok" and count > 0}
    for market_id in expected:
        by_id.setdefault(market_id, {"status": "not_attempted", "sample_count": 0,
                                      "error_code": None, "rankable": False})
    attempted = sum(row["status"] != "not_attempted" for row in by_id.values())
    successful = sum(row["status"] == "ok" and row["sample_count"] > 0 for row in by_id.values())
    counts = {status: sum(row["status"] == status for row in by_id.values()) for status in
              ("ok", "partial", "failed", "unsupported", "not_attempted")}
    return {"status": "audited", "expected_market_count": len(expected),
            "attempted_market_count": attempted, "successful_market_count": successful,
            "coverage_pct": round(attempted / len(expected) * 100, 2),
            "successful_coverage_pct": round(successful / len(expected) * 100, 2),
            "status_counts": counts, "markets": by_id,
            "interpretation_limit": "Coverage describes only the supplied registry and attempts; it does not prove exhaustive country or language coverage."}


def generate_localized_query_plan(seed: str, markets: Sequence[Mapping[str, Any]], *,
                                  translator: Callable[[str, str], str] | None = None,
                                  curated_variants: Mapping[str, Sequence[str]] | None = None,
                                  translated_queries: Mapping[str, str] | None = None,
                                  max_variants: int = 5) -> dict[str, Any]:
    """Build traceable query candidates; machine translation never passes native QA."""
    seed_text = " ".join(str(seed).split())
    if not seed_text:
        raise ValueError("seed must be non-empty")
    if isinstance(max_variants, bool) or not isinstance(max_variants, int) or not 1 <= max_variants <= 20:
        raise ValueError("max_variants must be an integer from 1 to 20")
    if isinstance(markets, (str, bytes)) or not isinstance(markets, Sequence):
        raise ValueError("markets must be a list")
    curated_variants = curated_variants or {}
    translated_queries = translated_queries or {}
    output, seen = [], set()
    for market in markets:
        if not isinstance(market, Mapping):
            raise ValueError("each market must be an object")
        market_id = str(market.get("market_id") or "").strip()
        language = str(market.get("language") or "").strip()
        locale = str(market.get("locale") or "").strip()
        if not market_id or not language or not locale or market_id in seen:
            raise ValueError("each market requires unique market_id, language and locale")
        seen.add(market_id)
        candidates: list[dict[str, str]] = []
        curated = curated_variants.get(market_id, [])
        if isinstance(curated, (str, bytes)) or not isinstance(curated, Sequence):
            raise ValueError(f"curated variants for {market_id} must be a list")
        for value in curated:
            text = " ".join(str(value).split())
            if text:
                candidates.append({"query": text, "origin": "human_curated"})
        translation_status = "not_configured"
        supplied_translation = " ".join(str(translated_queries.get(market_id) or "").split())
        if supplied_translation:
            candidates.append({"query": supplied_translation, "origin": "machine_translation"})
            translation_status = "supplied_machine_translation_unreviewed"
        if translator is not None and not supplied_translation:
            try:
                translated = " ".join(str(translator(seed_text, language) or "").split())
                if translated:
                    candidates.append({"query": translated, "origin": "machine_translation"})
                    translation_status = "generated_unreviewed"
                else:
                    translation_status = "empty_translation"
            except Exception as exc:  # Provider failures become explicit, not silent successes.
                translation_status = f"provider_error:{type(exc).__name__}"
        candidates.append({"query": seed_text, "origin": "seed_fallback"})
        deduped, query_seen = [], set()
        for item in candidates:
            key = item["query"].casefold()
            if key not in query_seen:
                query_seen.add(key)
                deduped.append(item)
            if len(deduped) >= max_variants:
                break
        native_ok = False
        review_source = str(market.get("review_source_ref") or "").strip()
        try:
            reviewed_at = _aware(market.get("reviewed_at"), "reviewed_at")
            source_url = urlparse(review_source)
            review_fresh = (datetime.now(timezone.utc) - timedelta(days=180) <= reviewed_at
                            <= datetime.now(timezone.utc) + timedelta(days=1))
            native_ok = (market.get("native_reviewed") is True and source_url.scheme == "https"
                         and bool(source_url.netloc) and review_fresh
                         and all(market.get(key) is True for key in
                             ("dialect_reviewed", "accent_reviewed", "cultural_reviewed")))
        except ValueError:
            native_ok = False
        output.append({"market_id": market_id, "locale": locale, "language": language,
                       "variants": deduped, "variant_count": len(deduped),
                       "translation_status": translation_status,
                       "native_review_status": "recorded_native_review_gates_passed_unverified" if native_ok else "required_or_stale",
                       "native_review_verified": False,
                       "interpretation_limit": "Query candidates are discovery inputs, not proof of native fluency, search demand, dialect or accent quality."})
    return {"status": "generated", "seed": seed_text, "market_count": len(output),
            "markets": output, "max_variants_per_market": max_variants,
            "interpretation_limit": "Machine translation and human-curated strings are not independently authenticated; native review remains a separate gate."}


def analyze_competitor_velocity(snapshots: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Calculate interval views/day from repeated snapshots of the same public video."""
    if isinstance(snapshots, (str, bytes)) or not isinstance(snapshots, Sequence):
        raise ValueError("snapshots must be a list")
    grouped: dict[str, dict[datetime, float]] = defaultdict(dict)
    for row in snapshots:
        if not isinstance(row, Mapping):
            raise ValueError("each snapshot must be an object")
        video_id = str(row.get("video_id") or "").strip()
        if not video_id:
            raise ValueError("video_id is required")
        observed = _aware(row.get("observed_at"), "observed_at")
        views = _number(row.get("views"), "views", 0)
        if observed in grouped[video_id] and grouped[video_id][observed] != views:
            raise ValueError("conflicting views for same video and observation time")
        grouped[video_id][observed] = views
    videos = {}
    for video_id, points in grouped.items():
        ordered = sorted(points.items())
        intervals = []
        for (start, start_views), (end, end_views) in zip(ordered, ordered[1:]):
            elapsed_days = (end - start).total_seconds() / 86400
            if elapsed_days <= 0 or end_views < start_views:
                raise ValueError(f"invalid snapshot progression for {video_id}")
            intervals.append({"start": start.isoformat(), "end": end.isoformat(),
                              "elapsed_days": round(elapsed_days, 6),
                              "views_delta": round(end_views - start_views, 3),
                              "views_per_day": round((end_views - start_views) / elapsed_days, 4)})
        rates = [item["views_per_day"] for item in intervals]
        videos[video_id] = {"snapshot_count": len(ordered), "interval_count": len(intervals),
                            "intervals": intervals,
                            "latest_views_per_day": rates[-1] if rates else None,
                            "acceleration_views_per_day2": round((rates[-1] - rates[-2]) /
                                ((ordered[-1][0] - ordered[-2][0]).total_seconds() / 86400), 4)
                                if len(rates) >= 2 else None,
                            "status": "velocity_observed" if intervals else "insufficient_snapshots"}
    return {"status": "analyzed" if videos else "insufficient_data", "video_count": len(videos),
            "videos": videos,
            "interpretation_limit": "Velocity is based only on supplied public snapshots; collection intervals, sampling bias and public view-count delays affect estimates."}


def analyze_originality_risk(items: Sequence[Mapping[str, Any]], *, review_threshold_pct: float = 70) -> dict[str, Any]:
    """Flag near-duplicate supplied text for human review; not a copyright classifier."""
    threshold = _number(review_threshold_pct, "review_threshold_pct", 0, 100)
    if isinstance(items, (str, bytes)) or not isinstance(items, Sequence):
        raise ValueError("items must be a list")
    normalized = {}
    for row in items:
        if not isinstance(row, Mapping):
            raise ValueError("each content item must be an object")
        content_id = str(row.get("content_id") or "").strip()
        if not content_id or content_id in normalized:
            raise ValueError("content_id must be non-empty and unique")
        text = f"{row.get('title') or ''} {row.get('script') or ''}".casefold()
        tokens = set(re.findall(r"[\w']+", text, flags=re.UNICODE))
        normalized[content_id] = tokens
    pairs = []
    for left, right in combinations(sorted(normalized), 2):
        a, b = normalized[left], normalized[right]
        union = a | b
        similarity = len(a & b) / len(union) * 100 if union else 0.0
        if similarity >= threshold:
            pairs.append({"left_content_id": left, "right_content_id": right,
                          "similarity_pct": round(similarity, 2), "review_required": True})
    return {"status": "screened", "content_count": len(normalized), "flagged_pair_count": len(pairs),
            "pairs": pairs,
            "interpretation_limit": "not_a_copyright_determination; lexical similarity is only a human-review signal and cannot establish copying, rights ownership or transformative value."}


def calculate_risk_adjusted_contribution(*, scenarios: Sequence[Mapping[str, Any]],
                                         costs: float, risk_reserve: float = 0) -> dict[str, Any]:
    """Probability-weight revenue scenarios and deduct explicit costs/reserve."""
    if isinstance(scenarios, (str, bytes)) or not isinstance(scenarios, Sequence) or not scenarios:
        raise ValueError("scenarios must be a non-empty list")
    cost = _number(costs, "costs", 0)
    reserve = _number(risk_reserve, "risk_reserve", 0)
    normalized, total_probability = [], 0.0
    for row in scenarios:
        if not isinstance(row, Mapping):
            raise ValueError("each scenario must be an object")
        probability = _number(row.get("probability"), "probability", 0, 1)
        revenue = _number(row.get("gross_revenue"), "gross_revenue", 0)
        total_probability += probability
        normalized.append({"probability": probability, "gross_revenue": revenue})
    if abs(total_probability - 1.0) > 1e-6:
        raise ValueError("scenario probabilities must sum to 1")
    expected = sum(row["probability"] * row["gross_revenue"] for row in normalized)
    net = expected - cost - reserve
    return {"status": "calculated", "expected_gross_revenue": round(expected, 4),
            "costs": cost, "risk_reserve": reserve,
            "expected_net_contribution": round(net, 4),
            "scenario_count": len(normalized),
            "formula": "sum(probability_i * gross_revenue_i) - costs - risk_reserve",
            "interpretation_limit": "Expected value depends on operator-supplied scenario probabilities and revenue assumptions; it is not a guaranteed forecast."}


def analyze_forecast_intervals(actuals: Sequence[float], lower_bounds: Sequence[float],
                               upper_bounds: Sequence[float]) -> dict[str, Any]:
    """Evaluate empirical interval coverage and width on supplied holdout observations."""
    if any(isinstance(values, (str, bytes)) or not isinstance(values, Sequence) for values in
           (actuals, lower_bounds, upper_bounds)):
        raise ValueError("actuals and bounds must be numeric lists")
    if not actuals or len(actuals) != len(lower_bounds) or len(actuals) != len(upper_bounds):
        raise ValueError("actuals and bounds must have the same non-zero length")
    rows = []
    for index, (actual, low, high) in enumerate(zip(actuals, lower_bounds, upper_bounds)):
        a = _number(actual, f"actuals[{index}]")
        lo = _number(low, f"lower_bounds[{index}]")
        hi = _number(high, f"upper_bounds[{index}]")
        if lo > hi:
            raise ValueError("lower bound cannot exceed upper bound")
        rows.append({"covered": lo <= a <= hi, "width": hi - lo})
    return {"status": "evaluated", "n": len(rows),
            "coverage_pct": round(mean([row["covered"] for row in rows]) * 100, 4),
            "mean_interval_width": round(mean([row["width"] for row in rows]), 6),
            "covered_count": sum(row["covered"] for row in rows),
            "nominal_coverage_pct": None,
            "interpretation_limit": "Empirical coverage is meaningful only on a representative holdout set; provide nominal coverage to assess calibration against the intended interval level."}


def correct_multiple_testing(p_values: Sequence[float]) -> dict[str, Any]:
    """Benjamini-Hochberg false-discovery-rate adjustment, preserving input order."""
    if isinstance(p_values, (str, bytes)) or not isinstance(p_values, Sequence) or not p_values:
        raise ValueError("p_values must be a non-empty list")
    values = [_number(value, f"p_values[{index}]", 0, 1) for index, value in enumerate(p_values)]
    order = sorted(range(len(values)), key=lambda index: values[index])
    adjusted = [1.0] * len(values)
    running = 1.0
    total = len(values)
    for rank_index in range(total - 1, -1, -1):
        original_index = order[rank_index]
        rank = rank_index + 1
        running = min(running, values[original_index] * total / rank)
        adjusted[original_index] = min(1.0, running)
    return {"status": "adjusted", "method": "benjamini_hochberg_fdr",
            "family_size": total,
            "results": [{"p_value": value, "adjusted_p_value": round(adjusted[index], 10),
                         "reject_at_0_05": adjusted[index] < .05}
                        for index, value in enumerate(values)],
            "interpretation_limit": "FDR adjustment does not fix invalid randomization, dependence, selective reporting or underpowered study design."}


def summarize_audience_cohorts(rows: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Aggregate only supplied cohort-level first-party metrics; preserve unknowns."""
    if isinstance(rows, (str, bytes)) or not isinstance(rows, Sequence):
        raise ValueError("cohort rows must be a list")
    groups: dict[str, list[Mapping[str, Any]]] = defaultdict(list)
    for row in rows:
        if not isinstance(row, Mapping):
            raise ValueError("each cohort row must be an object")
        cohort = str(row.get("cohort") or "").strip()
        if not cohort:
            raise ValueError("cohort is required")
        groups[cohort].append(row)
    output = {}
    for cohort, values in groups.items():
        views = [_number(row["views"], "views", 0) for row in values if row.get("views") is not None]
        watch = [_number(row["watch_time_seconds"], "watch_time_seconds", 0) for row in values if row.get("watch_time_seconds") is not None]
        complete_watch = len(watch) == len(values)
        complete_views = len(views) == len(values)
        returning = [ _number(row["returning_viewers"], "returning_viewers", 0)
                      for row in values if row.get("returning_viewers") is not None ]
        output[cohort] = {
            "record_count": len(values), "views": round(sum(views), 4) if complete_views else None,
            "watch_time_seconds": round(sum(watch), 4) if complete_watch else None,
            "average_view_duration_seconds": round(sum(watch) / sum(views), 4)
                if complete_watch and complete_views and sum(views) > 0 else None,
            "returning_viewers": round(sum(returning), 4) if len(returning) == len(values) else None,
            "data_completeness_pct": round(sum(row.get("views") is not None and row.get("watch_time_seconds") is not None
                for row in values) / len(values) * 100, 2),
        }
    return {"status": "summarized" if output else "insufficient_data", "cohort_count": len(output),
            "cohorts": output,
            "interpretation_limit": "Cohort comparisons require consistent date ranges, audience definitions, traffic surfaces and metric semantics."}


def audit_source_quality(records: Sequence[Mapping[str, Any]], *, now: datetime | None = None,
                         freshness_days: int = 90) -> dict[str, Any]:
    """Label provenance and freshness; never silently score incomplete records."""
    if isinstance(records, (str, bytes)) or not isinstance(records, Sequence):
        raise ValueError("records must be a list")
    if isinstance(freshness_days, bool) or not isinstance(freshness_days, int) or freshness_days < 1:
        raise ValueError("freshness_days must be a positive integer")
    reference = now or datetime.now(timezone.utc)
    if reference.tzinfo is None or reference.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    output, seen = [], set()
    counts = {"fresh": 0, "stale": 0, "missing_provenance": 0}
    for index, row in enumerate(records):
        if not isinstance(row, Mapping):
            raise ValueError("each source record must be an object")
        source_id = str(row.get("source_id") or f"row-{index}").strip()
        if not source_id or source_id in seen:
            raise ValueError("source_id must be non-empty and unique")
        seen.add(source_id)
        source_ref = str(row.get("source_ref") or "").strip()
        observed_raw = row.get("observed_at")
        quality_raw = row.get("quality")
        if quality_raw is not None:
            _number(quality_raw, "quality", 0, 1)
        if not source_ref or not observed_raw or quality_raw is None:
            status = "missing_provenance"
        else:
            parsed = urlparse(source_ref)
            if parsed.scheme != "https" or not parsed.netloc:
                status = "missing_provenance"
            else:
                observed = _aware(observed_raw, "observed_at")
                if observed > reference + timedelta(minutes=5):
                    raise ValueError("source observation cannot be future-dated")
                _number(quality_raw, "quality", 0, 1)
                status = "stale" if observed < reference - timedelta(days=freshness_days) else "fresh"
        counts[status] += 1
        output.append({"source_id": source_id, "status": status,
                       "source_ref_present": bool(source_ref),
                       "observed_at": str(observed_raw) if observed_raw else None,
                       "quality": quality_raw if status != "missing_provenance" else None})
    return {"status": "audited", "record_count": len(output), "status_counts": counts,
            "records": output, "freshness_days": freshness_days,
            "interpretation_limit": "A syntactically valid reference is not independent authentication of the source or its claim."}


def analyze_proportion_experiment(control_trials: int, control_successes: int,
                                  treatment_trials: int, treatment_successes: int, *,
                                  randomized: bool, allocation_control: float = 0.5,
                                  alpha: float = 0.05) -> dict[str, Any]:
    """Two-arm proportion analysis with Wilson intervals, Newcombe difference CI and SRM gate."""
    for value, name in ((control_trials, "control_trials"), (treatment_trials, "treatment_trials"),
                        (control_successes, "control_successes"), (treatment_successes, "treatment_successes")):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{name} must be a non-negative integer")
    if control_trials < 1 or treatment_trials < 1:
        raise ValueError("both experiment arms require at least one trial")
    if control_successes > control_trials or treatment_successes > treatment_trials:
        raise ValueError("successes cannot exceed trials")
    allocation = _number(allocation_control, "allocation_control", 0.000001, 0.999999)
    alpha_value = _number(alpha, "alpha", 0.0001, 0.2)
    total = control_trials + treatment_trials
    expected_control = total * allocation
    expected_treatment = total * (1 - allocation)
    chi_square = ((control_trials - expected_control) ** 2 / expected_control
                  + (treatment_trials - expected_treatment) ** 2 / expected_treatment)
    from math import erfc, sqrt
    srm_p = erfc(sqrt(chi_square / 2))
    srm = randomized and srm_p < min(alpha_value, .001)

    def wilson(successes: int, trials: int) -> tuple[float, float]:
        from statistics import NormalDist
        z = NormalDist().inv_cdf(1 - alpha_value / 2)
        p = successes / trials
        denominator = 1 + z * z / trials
        center = (p + z * z / (2 * trials)) / denominator
        half = z * sqrt((p * (1 - p) / trials) + z * z / (4 * trials * trials)) / denominator
        return max(0.0, center - half), min(1.0, center + half)

    p_control = control_successes / control_trials
    p_treatment = treatment_successes / treatment_trials
    control_ci = wilson(control_successes, control_trials)
    treatment_ci = wilson(treatment_successes, treatment_trials)
    difference = p_treatment - p_control
    difference_ci = [treatment_ci[0] - control_ci[1], treatment_ci[1] - control_ci[0]]
    expected_cells = [control_trials * p_control, control_trials * (1 - p_control),
                      treatment_trials * p_treatment, treatment_trials * (1 - p_treatment)]
    small_cells = min(expected_cells) < 5
    p_value = None
    if randomized and not srm and not small_cells:
        from statistics import NormalDist
        pooled = (control_successes + treatment_successes) / total
        se = sqrt(pooled * (1 - pooled) * (1 / control_trials + 1 / treatment_trials))
        z_stat = difference / se if se else 0.0
        p_value = min(1.0, 2 * (1 - NormalDist().cdf(abs(z_stat))))
    if not randomized:
        status = "observational_only"
    elif srm:
        status = "invalid_sample_ratio_mismatch"
    elif small_cells:
        status = "small_cells_inferential_test_withheld"
    elif p_value is not None and p_value < alpha_value:
        status = "statistically_detectable_review_guardrails"
    else:
        status = "no_statistically_detectable_difference"
    return {"status": status, "randomized": randomized, "sample_ratio_mismatch": srm,
            "srm_p_value_approx": round(srm_p, 10),
            "control_rate_pct": round(p_control * 100, 4),
            "treatment_rate_pct": round(p_treatment * 100, 4),
            "absolute_lift_percentage_points": round(difference * 100, 4),
            "relative_lift_pct": round(difference / p_control * 100, 4) if p_control else None,
            "control_wilson_ci_pct": [round(value * 100, 4) for value in control_ci],
            "treatment_wilson_ci_pct": [round(value * 100, 4) for value in treatment_ci],
            "newcombe_difference_ci_pct_points": [round(value * 100, 4) for value in difference_ci],
            "p_value_two_sided": round(p_value, 10) if p_value is not None else None,
            "alpha": alpha_value, "sample_sizes": {"control": control_trials, "treatment": treatment_trials},
            "guardrails_required": True,
            "interpretation_limit": "Approximate two-proportion test with Wilson arm intervals and Newcombe difference interval; valid inference still requires pre-registration, correct randomization unit, independence, adequate power, multiple-testing control and guardrail review."}


def compare_forecast_models(actuals: Sequence[float], baseline_predictions: Sequence[float],
                            challenger_predictions: Sequence[float], *,
                            minimum_observations: int = 30) -> dict[str, Any]:
    """Compare model errors on the same holdout set; never auto-promote a challenger."""
    from .kpi_calculations import forecast_error_metrics
    if isinstance(minimum_observations, bool) or not isinstance(minimum_observations, int) or minimum_observations < 2:
        raise ValueError("minimum_observations must be an integer >= 2")
    baseline = forecast_error_metrics(actuals, baseline_predictions)
    challenger = forecast_error_metrics(actuals, challenger_predictions)
    if len(actuals) != len(baseline_predictions) or len(actuals) != len(challenger_predictions):
        raise ValueError("all model series must have equal length")
    baseline_wape, challenger_wape = baseline["wape_pct"], challenger["wape_pct"]
    if len(actuals) < minimum_observations:
        status = "insufficient_holdout_observations"
        improvement = None
    elif baseline_wape is None or challenger_wape is None:
        status = "insufficient_nonzero_actuals"
        improvement = None
    else:
        improvement = (baseline_wape - challenger_wape) / baseline_wape * 100 if baseline_wape else None
        status = "challenger_lower_wape_on_holdout" if improvement is not None and improvement > 0 else "baseline_not_beaten"
    return {"status": status, "n": len(actuals), "minimum_observations": minimum_observations,
            "baseline": baseline, "challenger": challenger,
            "challenger_wape_improvement_pct": round(improvement, 4) if improvement is not None else None,
            "promotion_allowed": False,
            "required_next_steps": ["rolling_origin_backtest", "segment_calibration", "prediction_interval_validation", "human_approval"],
            "interpretation_limit": "A single holdout comparison is not proof of future superiority; do not automatically replace the champion model."}


def analyze_topic_saturation(*, demand_index: float, competitor_uploads: int,
                             competitor_median_views: float | None = None,
                             audience_pain_evidence_count: int = 0,
                             observation_days: int = 30) -> dict[str, Any]:
    """Expose demand/supply ratios without pretending relative indices are search volume."""
    demand = _number(demand_index, "demand_index", 0)
    if isinstance(competitor_uploads, bool) or not isinstance(competitor_uploads, int) or competitor_uploads < 0:
        raise ValueError("competitor_uploads must be a non-negative integer")
    if isinstance(audience_pain_evidence_count, bool) or not isinstance(audience_pain_evidence_count, int) or audience_pain_evidence_count < 0:
        raise ValueError("audience_pain_evidence_count must be a non-negative integer")
    if isinstance(observation_days, bool) or not isinstance(observation_days, int) or observation_days < 1:
        raise ValueError("observation_days must be a positive integer")
    median_views = _number(competitor_median_views, "competitor_median_views", 0) if competitor_median_views is not None else None
    return {"status": "analyzed" if competitor_uploads > 0 else "insufficient_supply_data",
            "demand_index": demand, "demand_metric_semantics": "provider_relative_index_not_absolute_search_volume",
            "competitor_uploads": competitor_uploads, "competitor_uploads_per_30d": round(competitor_uploads / observation_days * 30, 4),
            "demand_index_per_competitor_upload": round(demand / competitor_uploads, 4) if competitor_uploads else None,
            "competitor_median_views": median_views,
            "audience_pain_evidence_count": audience_pain_evidence_count,
            "interpretation_limit": "Demand index and competitor uploads must refer to the same market, topic definition and observation window; ratio is a diagnostic, not absolute keyword difficulty or guaranteed opportunity."}


def analyze_satisfaction_survey(responses: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Summarize explicit 0-10 satisfaction/NPS responses; no proxy is silently substituted."""
    if isinstance(responses, (str, bytes)) or not isinstance(responses, Sequence) or not responses:
        raise ValueError("responses must be a non-empty list")
    scores = []
    for index, row in enumerate(responses):
        if not isinstance(row, Mapping):
            raise ValueError("each satisfaction response must be an object")
        scores.append(_number(row.get("score"), f"responses[{index}].score", 0, 10))
    promoters = sum(score >= 9 for score in scores)
    detractors = sum(score <= 6 for score in scores)
    passives = len(scores) - promoters - detractors
    return {"status": "summarized", "response_count": len(scores),
            "mean_score_0_10": round(mean(scores), 4),
            "promoter_pct": round(promoters / len(scores) * 100, 4),
            "passive_pct": round(passives / len(scores) * 100, 4),
            "detractor_pct": round(detractors / len(scores) * 100, 4),
            "net_promoter_score": round((promoters - detractors) / len(scores) * 100, 2),
            "interpretation_limit": "Voluntary survey response is subject to response and selection bias; NPS is not a YouTube ranking signal and does not replace platform feedback."}


def analyze_forecast_drift(baseline_actuals: Sequence[float], baseline_predictions: Sequence[float],
                           recent_actuals: Sequence[float], recent_predictions: Sequence[float], *,
                           degradation_threshold_pct: float = 20,
                           minimum_observations: int = 10) -> dict[str, Any]:
    """Detect deterioration in recent WAPE relative to a comparable baseline window."""
    from .kpi_calculations import forecast_error_metrics
    threshold = _number(degradation_threshold_pct, "degradation_threshold_pct", 0)
    if isinstance(minimum_observations, bool) or not isinstance(minimum_observations, int) or minimum_observations < 2:
        raise ValueError("minimum_observations must be >= 2")
    baseline = forecast_error_metrics(baseline_actuals, baseline_predictions)
    recent = forecast_error_metrics(recent_actuals, recent_predictions)
    if len(baseline_actuals) < minimum_observations or len(recent_actuals) < minimum_observations:
        status = "insufficient_observations"
        change = None
    elif baseline["wape_pct"] is None or recent["wape_pct"] is None:
        status = "insufficient_nonzero_actuals"
        change = None
    else:
        change = recent["wape_pct"] - baseline["wape_pct"]
        relative = change / baseline["wape_pct"] * 100 if baseline["wape_pct"] else None
        status = ("degradation_alert" if recent["wape_pct"] > 0 else "no_degradation_alert") if baseline["wape_pct"] == 0 else ("degradation_alert" if relative is not None and relative >= threshold else "no_degradation_alert")
    relative = (change / baseline["wape_pct"] * 100
                if change is not None and baseline["wape_pct"] else None)
    return {"status": status, "baseline_wape_pct": baseline["wape_pct"],
            "recent_wape_pct": recent["wape_pct"],
            "absolute_wape_change_pct_points": round(change, 4) if change is not None else None,
            "relative_wape_change_pct": round(relative, 4) if relative is not None else None,
            "degradation_threshold_pct": threshold, "minimum_observations": minimum_observations,
            "auto_retrain_or_promote": False,
            "interpretation_limit": "Windows must be comparable by horizon, market, format and data source; drift alert triggers investigation, not automatic retraining or policy changes."}
