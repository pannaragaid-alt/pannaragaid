"""Evidence-led operating workflows for the V17 growth intelligence system.

All outputs are deterministic decision support. They do not imply live collection,
causal effects, native-speaker validation, scheduled execution, or publishing.
"""
from __future__ import annotations

from collections import defaultdict
from datetime import datetime, timedelta, timezone
from math import erfc, isfinite, sqrt
import re
from typing import Any, Mapping, Sequence
from urllib.parse import urlparse


def _number(value: Any, name: str, low: float = 0, high: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)):
        raise ValueError(f"{name} must be a finite number")
    value = float(value)
    if value < low or (high is not None and value > high):
        raise ValueError(f"{name} must be between {low} and {high if high is not None else 'infinity'}")
    return value


def _aware_datetime(value: Any, name: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be an ISO-8601 datetime") from exc
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError(f"{name} must include a timezone")
    return parsed


def build_competitor_evidence_graph(observations: Sequence[Mapping[str, Any]], *,
                                    now: datetime | None = None,
                                    freshness_days: int = 90) -> dict[str, Any]:
    """Validate, deduplicate and freshness-label dated public competitor observations."""
    if isinstance(observations, (str, bytes)) or not isinstance(observations, Sequence):
        raise ValueError("observations must be a list")
    reference = now or datetime.now(timezone.utc)
    if reference.tzinfo is None or reference.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    if isinstance(freshness_days, bool) or not isinstance(freshness_days, int) or freshness_days < 1:
        raise ValueError("freshness_days must be a positive integer")
    seen: dict[str, tuple[str, str, str, str]] = {}
    accepted, rejected, duplicates, stale, conflicts = [], 0, 0, 0, 0
    for row in observations:
        if not isinstance(row, Mapping):
            raise ValueError("each observation must be an object")
        competitor = str(row.get("competitor_id") or "").strip()
        gap = str(row.get("gap") or "").strip()
        source_ref = str(row.get("source_ref") or "").strip()
        observation_id = str(row.get("observation_id") or "").strip()
        if not competitor or not gap or not source_ref:
            rejected += 1
            continue
        parsed_url = urlparse(source_ref)
        if parsed_url.scheme != "https" or not parsed_url.netloc:
            rejected += 1
            continue
        observed_at = _aware_datetime(row.get("observed_at"), "observed_at")
        if observed_at > reference + timedelta(days=1):
            rejected += 1
            continue
        dedupe_key = observation_id or f"{competitor}|{gap.casefold()}|{source_ref}|{observed_at.isoformat()}"
        signature = (competitor, gap, source_ref, observed_at.isoformat())
        if dedupe_key in seen:
            if seen[dedupe_key] != signature:
                conflicts += 1
            else:
                duplicates += 1
            continue
        seen[dedupe_key] = signature
        is_stale = observed_at < reference - timedelta(days=freshness_days)
        stale += int(is_stale)
        accepted.append({"observation_id": observation_id or None, "competitor_id": competitor,
                         "gap": gap, "source_ref": source_ref, "observed_at": observed_at.isoformat(),
                         "freshness_status": "stale_review_required" if is_stale else "fresh"})
    by_competitor: dict[str, list[dict[str, Any]]] = defaultdict(list)
    by_gap: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for item in accepted:
        by_competitor[item["competitor_id"]].append(item)
        by_gap[item["gap"]].append(item)
    return {"status": "built", "accepted_count": len(accepted), "rejected_count": rejected,
            "duplicate_count": duplicates, "conflicting_id_count": conflicts, "stale_count": stale,
            "competitors": {key: rows for key, rows in sorted(by_competitor.items())},
            "gap_evidence": {key: rows for key, rows in sorted(by_gap.items())},
            "observations": accepted,
            "interpretation_limit": "Public observations only; no private CTR, retention, impressions, audience demographics or competitor revenue are inferred."}


def analyze_audience_voice(samples: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    """Aggregate operator-labelled audience pain themes with sampling provenance."""
    if isinstance(samples, (str, bytes)) or not isinstance(samples, Sequence):
        raise ValueError("audience_samples must be a list")
    clusters: dict[tuple[str, str], list[dict[str, str]]] = defaultdict(list)
    rejected = 0
    for sample in samples:
        if not isinstance(sample, Mapping):
            raise ValueError("each audience sample must be an object")
        text = str(sample.get("text") or "").strip()
        theme = " ".join(str(sample.get("theme") or "").casefold().split())
        language = str(sample.get("language") or "und").strip().lower()
        source_ref = str(sample.get("source_ref") or "").strip()
        if not text or not theme or not source_ref:
            rejected += 1
            continue
        clusters[(language, theme)].append({"source_ref": source_ref,
                                            "sample_window": str(sample.get("sample_window") or "unspecified")})
    rows = []
    for (language, theme), members in sorted(clusters.items()):
        rows.append({"language": language, "theme": theme, "sample_count": len(members),
                     "source_refs": sorted({m["source_ref"] for m in members}),
                     "sample_windows": sorted({m["sample_window"] for m in members})})
    return {"status": "analyzed", "sample_count": sum(len(v) for v in clusters.values()),
            "rejected_count": rejected, "cluster_count": len(rows), "clusters": rows,
            "interpretation_limit": "Counts describe only the supplied sample, not_population_prevalence; theme labels are operator-supplied and require human multilingual review."}


def build_editorial_backlog(topics: Sequence[Mapping[str, Any]], *, capacity_hours: float) -> dict[str, Any]:
    """Rank evidence-linked topics using explicit operator scores and a hard capacity cap."""
    capacity = _number(capacity_hours, "capacity_hours")
    if isinstance(topics, (str, bytes)) or not isinstance(topics, Sequence):
        raise ValueError("topics must be a list")
    prepared = []
    seen = set()
    weights = {"demand_signal": .25, "audience_pain": .25, "competitive_gap": .20,
               "creator_fit": .20, "freshness": .10}
    for topic in topics:
        if not isinstance(topic, Mapping):
            raise ValueError("each topic must be an object")
        topic_id = str(topic.get("topic_id") or "").strip()
        title = str(topic.get("title") or "").strip()
        refs = topic.get("evidence_refs")
        if not topic_id or topic_id in seen or not title:
            raise ValueError("topic_id must be unique and title must be non-empty")
        if not isinstance(refs, Sequence) or isinstance(refs, (str, bytes)) or not any(str(x).strip() for x in refs):
            raise ValueError(f"topic {topic_id} requires evidence_refs")
        seen.add(topic_id)
        effort = _number(topic.get("effort_hours"), f"{topic_id}.effort_hours", low=.01)
        values = {key: _number(topic.get(key), f"{topic_id}.{key}", 0, 100) for key in weights}
        score = sum(values[key] * weight for key, weight in weights.items())
        prepared.append({"topic_id": topic_id, "title": title, "evidence_refs": sorted({str(x).strip() for x in refs if str(x).strip()}),
                         "effort_hours": effort, "priority_score": round(score, 2),
                         "score_method": "operator_inputs_weighted_25_25_20_20_10", "_density": score / effort})
    prepared.sort(key=lambda row: (-row["_density"], -row["priority_score"], row["topic_id"]))
    remaining = capacity
    for row in prepared:
        allocated = min(row["effort_hours"], remaining) if row["effort_hours"] <= remaining else 0
        row["allocated_hours"] = allocated
        row["allocation_status"] = "within_capacity" if allocated else "capacity_deferred"
        remaining -= allocated
        row.pop("_density")
    return {"status": "prioritized", "capacity_hours": capacity,
            "allocated_hours": round(capacity - remaining, 2), "remaining_capacity_hours": round(remaining, 2),
            "items": prepared,
            "interpretation_limit": "Scores are transparent operator inputs, not measured demand or predicted views; capacity uses a greedy score-per-hour heuristic."}


def build_video_brief(topic: Mapping[str, Any]) -> dict[str, Any]:
    """Create a structured draft brief; all claims remain tied to supplied evidence."""
    if not isinstance(topic, Mapping):
        raise ValueError("topic must be an object")
    required = ("topic_id", "title", "audience_problem", "promise", "evidence_refs")
    missing = [key for key in required if not topic.get(key)]
    if missing:
        raise ValueError("video brief missing required fields: " + ", ".join(missing))
    refs = topic["evidence_refs"]
    if not isinstance(refs, Sequence) or isinstance(refs, (str, bytes)) or not refs:
        raise ValueError("evidence_refs must be a non-empty list")
    return {"topic_id": str(topic["topic_id"]), "working_title": str(topic["title"]),
            "audience_problem": str(topic["audience_problem"]), "viewer_promise": str(topic["promise"]),
            "evidence_refs": sorted({str(ref).strip() for ref in refs if str(ref).strip()}),
            "narrative_beats": ["Hook: name the specific audience problem", "Context: establish the viewer's starting point",
                                "Proof: demonstrate each important claim", "Payoff: deliver the promised outcome",
                                "Next step: one relevant call to action"],
            "packaging_hypotheses": {"title": "State audience, problem and outcome without overpromising",
                                     "thumbnail": "Show one visual proof or tension point that matches the video"},
            "claim_policy": "claims_must_be_supported_by_brief_evidence",
            "human_review_required": ["factual_accuracy", "rights_and_assets", "native_localization", "title_thumbnail_promise_match"]}


def calculate_first_party_kpi_tree(metrics: Mapping[str, Any]) -> dict[str, Any]:
    """Calculate common channel KPIs only from explicitly owner-authorized Analytics input."""
    if not isinstance(metrics, Mapping):
        raise ValueError("metrics must be an object")
    if metrics.get("source") != "owner_authorized_youtube_analytics" or not str(metrics.get("source_ref") or "").strip():
        raise ValueError("first-party KPI tree requires owner-authorized Analytics source and source_ref")
    def optional_count(key: str) -> float | None:
        if key not in metrics or metrics[key] is None:
            return None
        return _number(metrics[key], key)
    impressions, clicks = optional_count("impressions"), optional_count("clicks")
    supplied_ctr = (_number(metrics["impressions_ctr_pct"], "impressions_ctr_pct", 0, 100)
                    if metrics.get("impressions_ctr_pct") is not None else None)
    views, watch = optional_count("views"), optional_count("watch_time_seconds")
    duration, subs, revenue = (optional_count(k) for k in ("video_duration_seconds", "subscribers_gained", "estimated_revenue"))
    unique_viewers, returning_viewers = optional_count("unique_viewers"), optional_count("returning_viewers")
    end_screen_clicks, end_screen_impressions = optional_count("end_screen_clicks"), optional_count("end_screen_element_impressions")
    shorts_stayed, shorts_shown = optional_count("shorts_stayed_to_watch"), optional_count("shorts_shown_in_feed")
    def ratio(numerator: float | None, denominator: float | None, scale: float = 1) -> float | None:
        return round(numerator / denominator * scale, 4) if numerator is not None and denominator is not None and denominator > 0 else None
    result = {
        "impressions_ctr_pct": (supplied_ctr if supplied_ctr is not None else
                                (ratio(clicks, impressions, 100) if clicks is not None and metrics.get("clicks_semantics") == "views_from_registered_impressions" else None)),
        "average_view_duration_seconds": ratio(watch, views),
        "average_percentage_viewed_pct": ratio(watch, views * duration, 100) if duration is not None and views is not None else None,
        "watch_time_per_impression_seconds": ratio(watch, impressions),
        "views_per_unique_viewer": ratio(views, unique_viewers),
        "returning_viewer_share_pct": ratio(returning_viewers, unique_viewers, 100),
        "end_screen_click_rate_pct": ratio(end_screen_clicks, end_screen_impressions, 100),
        "shorts_stayed_to_watch_pct": ratio(shorts_stayed, shorts_shown, 100),
        "subscribers_gained_per_1000_views": ratio(subs, views, 1000),
        "revenue_per_1000_views": ratio(revenue, views, 1000),
        "revenue_per_watch_hour": ratio(revenue, watch / 3600 if watch is not None else None),
        "watch_time_hours": ratio(watch, 3600),
    }
    definitions = {
        "impressions_ctr_pct": ("registered_impression_clicks / impressions * 100", "percent"),
        "average_view_duration_seconds": ("watch_time_seconds / views", "seconds per view"),
        "average_percentage_viewed_pct": ("watch_time_seconds / (views * video_duration_seconds) * 100", "percent"),
        "watch_time_per_impression_seconds": ("watch_time_seconds / impressions", "seconds per registered impression"),
        "views_per_unique_viewer": ("views / unique_viewers", "views per unique viewer"),
        "returning_viewer_share_pct": ("returning_viewers / unique_viewers * 100", "percent"),
        "end_screen_click_rate_pct": ("end_screen_clicks / end_screen_element_impressions * 100", "percent"),
        "shorts_stayed_to_watch_pct": ("shorts_stayed_to_watch / shorts_shown_in_feed * 100", "percent"),
        "subscribers_gained_per_1000_views": ("subscribers_gained / views * 1000", "subscribers per 1,000 views"),
        "revenue_per_1000_views": ("estimated_revenue / views * 1000", "currency per 1,000 views"),
        "revenue_per_watch_hour": ("estimated_revenue / (watch_time_seconds / 3600)", "currency per watch hour"),
        "watch_time_hours": ("watch_time_seconds / 3600", "hours"),
    }
    return {"status": "calculated", "source": metrics["source"], "source_ref": metrics["source_ref"],
            "source_verification": "declared_not_independently_authenticated",
            "metrics": {key: {"value": result[key], "formula": definitions[key][0], "unit": definitions[key][1],
                              "status": "calculated" if result[key] is not None else "insufficient_data"}
                        for key in definitions},
            "interpretation_limit": "Use matching date ranges, traffic surfaces, formats and cohorts. CTR is impression-based only where the supplied clicks field represents views from registered thumbnail impressions."}


def assess_experiment_integrity(experiment: Mapping[str, Any]) -> dict[str, Any]:
    """Check allocation sample-ratio mismatch and basic pre-registration safeguards."""
    if not isinstance(experiment, Mapping):
        raise ValueError("experiment must be an object")
    randomized = experiment.get("randomized") is True
    control = experiment.get("control_impressions", 0)
    treatment = experiment.get("treatment_impressions", 0)
    for value, key in ((control, "control_impressions"), (treatment, "treatment_impressions")):
        if isinstance(value, bool) or not isinstance(value, int) or value < 0:
            raise ValueError(f"{key} must be a non-negative integer")
    if control + treatment == 0:
        raise ValueError("experiment requires at least one impression")
    alpha = _number(experiment.get("sample_ratio_mismatch_alpha", .001), "sample_ratio_mismatch_alpha", .000001, .2)
    allocation = _number(experiment.get("allocation_control", .5), "allocation_control", .000001, .999999)
    total = control + treatment
    expected_control, expected_treatment = total * allocation, total * (1 - allocation)
    chi_square = ((control - expected_control) ** 2 / expected_control
                  + (treatment - expected_treatment) ** 2 / expected_treatment)
    p_value = erfc(sqrt(chi_square / 2))
    srm = randomized and p_value < alpha
    if not randomized:
        status = "observational_only"
    elif srm:
        status = "invalid_srm_review_required"
    elif experiment.get("predeclared_primary_metric") is not True:
        status = "randomized_but_preregistration_missing"
    else:
        status = "integrity_checks_passed_pending_power_and_guardrails"
    return {"status": "audited", "decision_status": status, "randomized": randomized,
            "sample_ratio_mismatch": srm, "srm_p_value_approx": round(p_value, 8),
            "srm_alpha": alpha, "observed_allocation_control": round(control / total, 6),
            "expected_allocation_control": allocation, "predeclared_primary_metric": experiment.get("predeclared_primary_metric") is True,
            "checks": {"randomization_declared": randomized, "srm_pass": not srm,
                       "primary_metric_predeclared": experiment.get("predeclared_primary_metric") is True,
                       "guardrails_declared": bool(experiment.get("guardrails"))},
            "interpretation_limit": "A two-arm chi-square SRM screen is not proof of valid randomization, sufficient power, independence, or causal validity."}


def evaluate_portfolio_allocation(markets: Sequence[Mapping[str, Any]], *, capacity_hours: float) -> dict[str, Any]:
    """Allocate limited operator hours to highest risk-adjusted score density."""
    capacity = _number(capacity_hours, "capacity_hours")
    if isinstance(markets, (str, bytes)) or not isinstance(markets, Sequence):
        raise ValueError("markets must be a list")
    rows, seen = [], set()
    for market in markets:
        if not isinstance(market, Mapping):
            raise ValueError("each market must be an object")
        market_id = str(market.get("market_id") or "").strip()
        if not market_id or market_id in seen:
            raise ValueError("market_id must be non-empty and unique")
        seen.add(market_id)
        score = _number(market.get("opportunity_score"), f"{market_id}.opportunity_score", 0, 100)
        confidence = _number(market.get("confidence"), f"{market_id}.confidence", 0, 1)
        risk = _number(market.get("risk"), f"{market_id}.risk", 0, 100)
        effort = _number(market.get("effort_hours"), f"{market_id}.effort_hours", .01)
        adjusted = score * confidence * (1 - risk / 100)
        rows.append({"market_id": market_id, "risk_adjusted_score": round(adjusted, 4),
                     "effort_hours": effort, "_density": adjusted / effort})
    rows.sort(key=lambda x: (-x["_density"], x["market_id"]))
    remaining, allocated = capacity, 0.0
    for row in rows:
        hours = row["effort_hours"] if row["effort_hours"] <= remaining else 0.0
        row["allocated_hours"] = hours
        row["allocation_status"] = "allocated" if hours else "deferred_capacity"
        allocated += hours
        remaining -= hours
        row.pop("_density")
    shares = [row["allocated_hours"] / allocated for row in rows if allocated and row["allocated_hours"]]
    allocation_hhi = round(sum(share * share for share in shares) * 10000, 2) if shares else None
    return {"status": "allocated", "capacity_hours": capacity, "allocated_hours": round(allocated, 2),
            "remaining_capacity_hours": round(remaining, 2), "allocation": rows,
            "allocation_hhi": allocation_hhi, "allocation_hhi_scale": "0-10000 concentration of allocated operator hours",
            "interpretation_limit": "Allocation is a deterministic heuristic over operator-supplied scores; validate opportunity and risk with comparable evidence before committing resources."}


def validate_automation_job(job: Mapping[str, Any]) -> dict[str, Any]:
    """Validate a bounded automation contract; does not create or schedule a job."""
    if not isinstance(job, Mapping):
        raise ValueError("job must be an object")
    required = ("job_id", "operation", "idempotency_key", "max_attempts", "timeout_seconds",
                "max_items", "budget_units", "kill_switch_enabled")
    missing = [key for key in required if key not in job]
    if missing:
        raise ValueError("job missing required fields: " + ", ".join(missing))
    job_id, key = str(job["job_id"]).strip(), str(job["idempotency_key"]).strip()
    if not job_id or not key:
        raise ValueError("job_id and idempotency_key must be non-empty")
    limits = {"max_attempts": (1, 5), "timeout_seconds": (1, 300), "max_items": (1, 1000), "budget_units": (1, 10000)}
    violations = []
    for name, (minimum, maximum) in limits.items():
        value = job[name]
        if isinstance(value, bool) or not isinstance(value, int) or not minimum <= value <= maximum:
            violations.append(f"{name}_outside_safe_bounds")
    if job.get("kill_switch_enabled") is not True:
        violations.append("kill_switch_required")
    domains = job.get("target_domains", [])
    if (not isinstance(domains, Sequence) or isinstance(domains, (str, bytes))
            or not domains or any(not str(x).strip() for x in domains)):
        violations.append("target_domains_must_be_explicit_non_empty_allowlist")
    elif any(not re.fullmatch(r"[a-zA-Z0-9](?:[a-zA-Z0-9.-]*[a-zA-Z0-9])?", str(x).strip())
             or ".." in str(x) or "." not in str(x) for x in domains):
        violations.append("target_domains_must_be_hostnames_not_urls")
    operation = str(job["operation"]).strip().lower()
    if operation != "read_only":
        violations.append("human_approval_required_for_mutating_operation")
    if violations:
        status = "blocked_human_approval_required" if operation != "read_only" else "blocked_policy_validation"
    else:
        status = "ready_for_operator_scheduling"
    return {"status": status, "job_id": job_id, "operation": operation,
            "idempotency_key_present": bool(key), "limits": {name: job[name] for name in limits},
            "kill_switch_enabled": job.get("kill_switch_enabled") is True,
            "target_domains": sorted({str(x).strip().lower() for x in domains}) if isinstance(domains, Sequence) and not isinstance(domains, (str, bytes)) else [],
            "violations": violations,
            "execution_status": "not_scheduled_or_executed",
            "interpretation_limit": "This validates a proposed job contract only; no scheduler, provider, browser session, credential, or external side effect is invoked."}
