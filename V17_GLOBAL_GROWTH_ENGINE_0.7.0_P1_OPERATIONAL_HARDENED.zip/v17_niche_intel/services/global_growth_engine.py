"""Integrated eight-priority global YouTube growth decision engine.

This module composes supplied evidence into auditable decision support. It does
not fetch data, authenticate third-party provenance, change channel settings,
or execute/schedule automation.
"""
from __future__ import annotations

from datetime import datetime, timedelta, timezone
from hashlib import sha256
from ipaddress import ip_address
import json
import re
from math import isfinite, sqrt
from statistics import NormalDist, median
from typing import Any, Mapping, Sequence
from urllib.parse import urlparse

from .growth_operations import validate_automation_job
from .kpi_calculations import forecast_error_metrics


MARKET_WEIGHTS = {
    "demand_score": 0.25,
    "monetization_score": 0.20,
    "competitive_gap": 0.20,
    "creator_fit": 0.20,
    "confidence": 0.15,
}
SURFACE_WEIGHTS = {
    "search": {"intent_match": .35, "topic_relevance": .30, "metadata_alignment": .15, "satisfaction": .20},
    "browse": {"audience_fit": .25, "packaging": .25, "early_retention": .25, "satisfaction": .25},
    "suggested": {"topic_adjacency": .30, "viewer_overlap": .25, "session_continuity": .20, "satisfaction": .25},
    "shorts": {"swipe_stop": .25, "viewed_vs_swiped": .25, "retention": .25, "satisfaction": .25},
}


def _num(value: Any, name: str, low: float = 0.0, high: float | None = None) -> float:
    if isinstance(value, bool) or not isinstance(value, (int, float)) or not isfinite(float(value)):
        raise ValueError(f"{name} must be a finite number")
    result = float(value)
    if result < low or (high is not None and result > high):
        raise ValueError(f"{name} must be between {low} and {high if high is not None else 'infinity'}")
    return result


def _aware(value: Any, name: str) -> datetime:
    try:
        result = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be an ISO-8601 datetime") from exc
    if result.tzinfo is None or result.utcoffset() is None:
        raise ValueError(f"{name} must include a timezone")
    return result.astimezone(timezone.utc)


def _https_host(url: Any, name: str) -> str:
    parsed = urlparse(str(url or "").strip())
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password or parsed.port not in (None, 443):
        raise ValueError(f"{name} must be a public HTTPS URL on the standard port without embedded credentials")
    host = parsed.hostname.lower().rstrip(".")
    if host in {"localhost", "localhost.localdomain"} or host.endswith((".localhost", ".local", ".internal")):
        raise ValueError(f"{name} cannot target local or internal hosts")
    try:
        address = ip_address(host)
    except ValueError:
        address = None
    if address is not None and not address.is_global:
        raise ValueError(f"{name} cannot target non-public IP addresses")
    if address is None and ("." not in host or ".." in host or
            not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?", host)):
        raise ValueError(f"{name} must use a valid public hostname")
    return host



def _normalize_allowed_hosts(allowed_hosts: Sequence[str]) -> set[str]:
    if isinstance(allowed_hosts, (str, bytes)) or not isinstance(allowed_hosts, Sequence):
        raise ValueError("allowed_hosts must be a sequence of hostnames")
    hosts = set()
    for raw in allowed_hosts:
        value = str(raw).strip()
        if not value or value != raw or "/" in value or "@" in value or "?" in value or "#" in value:
            raise ValueError("allowed_hosts entries must be bare public hostnames, not URLs or paths")
        host = _https_host("https://" + value, "allowed_hosts entry")
        hosts.add(host)
    if not hosts:
        raise ValueError("allowed_hosts must contain at least one hostname")
    return hosts


def analyze_competitor_sample(videos: Sequence[Mapping[str, Any]], *,
                              observed_at: datetime | None = None) -> dict[str, Any]:
    """Summarize a public video sample without implying market census or velocity."""
    if isinstance(videos, (str, bytes)) or not isinstance(videos, Sequence):
        raise ValueError("videos must be a sequence")
    reference = observed_at or datetime.now(timezone.utc)
    if reference.tzinfo is None or reference.utcoffset() is None:
        raise ValueError("observed_at must be timezone-aware")
    seen: set[str] = set()
    channel_views: dict[str, float] = {}
    view_values: list[float] = []
    views_per_day: list[float] = []
    excluded = 0
    for index, row in enumerate(videos):
        if not isinstance(row, Mapping):
            raise ValueError("each video sample row must be an object")
        video_id = str(row.get("video_id") or "").strip()
        channel_id = str(row.get("channel_id") or "").strip()
        if not video_id or not channel_id:
            excluded += 1
            continue
        if video_id in seen:
            continue
        if row.get("views") is None:
            excluded += 1
            continue
        views = _num(row.get("views"), f"videos[{index}].views")
        try:
            published = _aware(row.get("published_at"), f"videos[{index}].published_at")
        except ValueError:
            excluded += 1
            continue
        age_days = (reference.astimezone(timezone.utc) - published).total_seconds() / 86400
        if age_days < 0:
            excluded += 1
            continue
        seen.add(video_id)
        view_values.append(views)
        channel_views[channel_id] = channel_views.get(channel_id, 0.0) + views
        views_per_day.append(views / max(age_days, 1.0))
    total_views = sum(view_values)
    shares = [value / total_views for value in channel_views.values()] if total_views else []
    hhi = sum(share * share for share in shares) * 10000 if shares else None
    return {
        "status": "scored" if view_values else "insufficient_evidence",
        "observed_at": reference.astimezone(timezone.utc).isoformat(),
        "sample_size": len(view_values), "excluded_or_invalid_count": excluded,
        "channel_count": len(channel_views), "sampled_views": int(total_views),
        "median_video_views": median(view_values) if view_values else None,
        "channel_view_share_hhi": round(hhi, 2) if hhi is not None else None,
        "top_channel_sampled_view_share_pct": round(max(shares) * 100, 2) if shares else None,
        "mean_lifetime_average_views_per_day": round(sum(views_per_day) / len(views_per_day), 2) if views_per_day else None,
        "views_per_day_semantics": "lifetime_average_not_velocity",
        "interpretation_scope": "sample_only_not_market_census",
        "limitations": [
            "Public search results are a bounded sample, not a complete competitor census.",
            "Lifetime-average views per day is not interval growth velocity; velocity requires repeated timestamped snapshots.",
            "Channel view-share concentration describes only this sampled result set.",
        ],
    }


def score_market_economics(markets: Sequence[Mapping[str, Any]], *,
                           reporting_currency: str | None = None) -> list[dict[str, Any]]:
    """Score markets; normalize currencies only with dated, sourced FX evidence."""
    if isinstance(markets, (str, bytes)) or not isinstance(markets, Sequence) or not markets:
        raise ValueError("markets must be a non-empty sequence")
    prepared = []
    incomplete = []
    market_ids = [str(row.get("market_id") or "").strip() for row in markets if isinstance(row, Mapping)]
    if len(market_ids) != len(set(market_ids)):
        raise ValueError("market_id values must be unique")
    target_currency = (reporting_currency or "").upper().strip() or None
    if target_currency is not None and (len(target_currency) != 3 or not target_currency.isalpha()):
        raise ValueError("reporting_currency must be a three-letter currency code")
    currencies = {str(row.get("rpm_currency") or "").upper().strip() for row in markets if isinstance(row, Mapping)}
    if target_currency is None and len(currencies) > 1:
        target_currency = sorted(currencies)[0]
    for index, row in enumerate(markets):
        if not isinstance(row, Mapping):
            raise ValueError("each market must be an object")
        market_id = str(row.get("market_id") or "").strip()
        if row.get("rpm_source") == "owner_analytics_actual" or row.get("source_family") == "youtube_analytics_api":
            raise ValueError("YouTube API Data must remain isolated from external market-opportunity scoring")
        currency = str(row.get("rpm_currency") or "").upper().strip()
        if not market_id or len(currency) != 3 or not currency.isalpha():
            raise ValueError(f"markets[{index}] requires market_id and ISO-like 3-letter rpm_currency")
        if target_currency is None:
            target_currency = currency
        country_code = str(row.get("country_code") or "").upper().strip()
        if country_code and (len(country_code) != 2 or not country_code.isalpha()):
            raise ValueError(f"{market_id}.country_code must be a two-letter code")
        required_inputs = ("rpm_base", "reachable_monthly_views", "demand_score", "competitive_gap", "creator_fit", "confidence")
        missing_inputs = [key for key in required_inputs if row.get(key) is None]
        if missing_inputs:
            incomplete.append({"market_id": market_id, "country_code": country_code or None,
                "currency": currency, "status": "insufficient_evidence", "score": None,
                "missing_inputs": missing_inputs})
            continue
        if currency != target_currency:
            fx = row.get("fx_conversion")
            if not isinstance(fx, Mapping) or str(fx.get("to_currency", "")).upper() != target_currency:
                raise ValueError("mixed currencies require explicit fx_conversion to the same reporting currency")
        rate = 1.0
        if currency != target_currency:
            fx = row["fx_conversion"]
            rate = _num(fx.get("rate_to_reporting"), f"{market_id}.fx_conversion.rate_to_reporting", .0000001)
            _https_host(fx.get("source_ref"), f"{market_id}.fx_conversion.source_ref")
            observed = _aware(fx.get("observed_at"), f"{market_id}.fx_conversion.observed_at")
            if observed > datetime.now(timezone.utc) + timedelta(days=1):
                raise ValueError("FX evidence cannot be future-dated")
            if observed < datetime.now(timezone.utc) - timedelta(days=7):
                raise ValueError("FX evidence is older than the seven-day freshness window")
        low = _num(row.get("rpm_low", row.get("rpm_base", 0)), f"{market_id}.rpm_low") * rate
        base = _num(row.get("rpm_base"), f"{market_id}.rpm_base") * rate
        high = _num(row.get("rpm_high", row.get("rpm_base", 0)), f"{market_id}.rpm_high") * rate
        if not low <= base <= high:
            raise ValueError(f"{market_id} RPM range must satisfy low <= base <= high")
        views = _num(row.get("reachable_monthly_views"), f"{market_id}.reachable_monthly_views")
        costs = {key: _num(row.get(key, 0), f"{market_id}.{key}") for key in
                 ("production_cost", "localization_cost", "risk_reserve")}
        components = {key: _num(row.get(key), f"{market_id}.{key}", 0, 100) for key in
                      ("demand_score", "competitive_gap", "creator_fit")}
        confidence = _num(row.get("confidence"), f"{market_id}.confidence", 0, 1)
        prepared.append({"market_id": market_id, "country_code": country_code or None, "currency": target_currency,
                         "rpm_low": low, "rpm_base": base, "rpm_high": high,
                         "views": views, "costs": costs, "components": components,
                         "confidence": confidence, "fx_rate": rate,
                         "rpm_source": str(row.get("rpm_source") or "scenario_assumption"),
                         "rpm_observed_period": row.get("rpm_observed_period"),
                         "fx_source_ref": (row.get("fx_conversion") or {}).get("source_ref") if isinstance(row.get("fx_conversion"), Mapping) else None})
    max_rpm = max((row["rpm_base"] for row in prepared), default=0.0)
    output = list(incomplete)
    for row in prepared:
        monetization = row["rpm_base"] / max_rpm * 100 if max_rpm > 0 else 0.0
        values = {**row["components"], "monetization_score": monetization,
                  "confidence": row["confidence"] * 100}
        opportunity = sum(values[key] * weight for key, weight in MARKET_WEIGHTS.items())
        revenue = {label: row["views"] / 1000 * row[f"rpm_{label}"] for label in ("low", "base", "high")}
        total_cost = sum(row["costs"].values())
        output.append({"market_id": row["market_id"], "country_code": row["country_code"], "currency": row["currency"],
            "rpm_low": round(row["rpm_low"], 6), "rpm_base": round(row["rpm_base"], 6),
            "rpm_high": round(row["rpm_high"], 6), "reachable_monthly_views": row["views"],
            "gross_revenue_low": round(revenue["low"], 2),
            "gross_revenue_base": round(revenue["base"], 2),
            "gross_revenue_high": round(revenue["high"], 2),
            "total_monthly_cost": round(total_cost, 2),
            "net_contribution_base": round(revenue["base"] - total_cost, 2),
            "opportunity_score": round(opportunity, 2),
            "confidence_adjusted_score": round(opportunity * row["confidence"], 2),
            "score_components": {key: round(value, 2) for key, value in values.items()},
            "score_formula": "0.25*demand + 0.20*relative_monetization + 0.20*competitive_gap + 0.20*creator_fit + 0.15*confidence",
            "fx_rate": row["fx_rate"], "fx_source_ref": row["fx_source_ref"],
            "rpm_evidence_source": row["rpm_source"], "rpm_observed_period": row["rpm_observed_period"],
            "status": "scenario_revenue_forecast_not_actual_future_revenue"})
    return sorted(output, key=lambda item: (item.get("status") != "insufficient_evidence",
        -item.get("confidence_adjusted_score", 0), -item.get("net_contribution_base", 0), item["market_id"]))


def build_localization_matrix(markets: Sequence[Mapping[str, Any]], *,
                              now: datetime | None = None, review_max_age_days: int = 180) -> dict[str, Any]:
    if isinstance(markets, (str, bytes)) or not isinstance(markets, Sequence):
        raise ValueError("localization markets must be a sequence")
    reference = now or datetime.now(timezone.utc)
    if reference.tzinfo is None or reference.utcoffset() is None or review_max_age_days < 1:
        raise ValueError("now must be timezone-aware and review_max_age_days positive")
    output = []
    seen = set()
    for row in markets:
        if not isinstance(row, Mapping):
            raise ValueError("each localization market must be an object")
        market_id = str(row.get("market_id") or "").strip()
        locale = str(row.get("locale") or "").strip()
        language = str(row.get("language") or "").strip()
        variants = row.get("query_variants")
        if not market_id or not locale or not language or not isinstance(variants, Sequence) or isinstance(variants, (str, bytes)) or not variants:
            raise ValueError("each localization market requires market_id, locale, language and query_variants")
        if market_id in seen:
            raise ValueError(f"duplicate localization market_id: {market_id}")
        seen.add(market_id)
        clean_variants = list(dict.fromkeys(" ".join(str(item).split()) for item in variants if str(item).strip()))
        if not clean_variants:
            raise ValueError(f"{market_id} must contain at least one non-empty query variant")
        review_ok = row.get("native_reviewed") is True
        source_ref = row.get("review_source_ref")
        reviewed_at = row.get("reviewed_at")
        freshness = "not_reviewed"
        if review_ok and source_ref and reviewed_at:
            _https_host(source_ref, f"{market_id}.review_source_ref")
            observed = _aware(reviewed_at, f"{market_id}.reviewed_at")
            age = (reference.astimezone(timezone.utc) - observed).total_seconds() / 86400
            freshness = "future_dated" if age < -(5 / 1440) else "stale" if age > review_max_age_days else "current"
        complete = all(row.get(key) is True for key in ("dialect_reviewed", "accent_reviewed", "cultural_reviewed"))
        ready = review_ok and freshness == "current" and complete
        missing = [key for key in ("native_reviewed", "dialect_reviewed", "accent_reviewed", "cultural_reviewed") if row.get(key) is not True]
        if not source_ref:
            missing.append("review_source_ref")
        if not reviewed_at:
            missing.append("reviewed_at")
        if reviewed_at and freshness in {"stale", "future_dated"}:
            missing.append("reviewed_at_not_current")
        output.append({"market_id": market_id, "locale": locale, "language": language,
            "query_variants": clean_variants, "translation_origin": str(row.get("translation_origin", "unknown")),
            "status": "native_reviewed" if ready else "native_review_required",
            "native_review_freshness": freshness, "missing_review_gates": missing,
            "dialect_notes": str(row.get("dialect_notes") or ""),
            "accent_notes": str(row.get("accent_notes") or ""),
            "cultural_notes": str(row.get("cultural_notes") or ""),
            "review_source_ref": source_ref if ready else None,
            "review_source_verification": "declared_not_independently_authenticated" if ready else None,
            "native_review_required": not ready})
    return {"status": "built", "market_count": len(output),
            "ready_market_count": sum(row["status"] == "native_reviewed" for row in output),
            "markets": output,
            "interpretation_limit": "Machine translation and locale metadata are not proof of natural speech; human native-speaker review is required."}


def build_research_pipeline(records: Sequence[Mapping[str, Any]], *, allowed_hosts: Sequence[str],
                            now: datetime | None = None, max_age_days: int = 90,
                            max_records: int = 10000) -> dict[str, Any]:
    if isinstance(records, (str, bytes)) or not isinstance(records, Sequence):
        raise ValueError("research_records must be a sequence")
    if isinstance(allowed_hosts, (str, bytes)) or not isinstance(allowed_hosts, Sequence):
        raise ValueError("allowed_hosts must be a sequence")
    if max_age_days < 1 or max_records < 1 or len(records) > max_records:
        raise ValueError("invalid freshness or record limit")
    hosts = _normalize_allowed_hosts(allowed_hosts) if records else set()
    reference = now or datetime.now(timezone.utc)
    if reference.tzinfo is None or reference.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    output, fingerprints = [], set()
    duplicates = stale = 0
    for row in records:
        if not isinstance(row, Mapping):
            raise ValueError("each research record must be an object")
        market_id = str(row.get("market_id") or "").strip()
        source_family = str(row.get("source_family") or "").strip()
        metric = str(row.get("metric") or "").strip()
        if not market_id or not source_family or not metric:
            raise ValueError("research records require market_id, source_family and metric")
        host = _https_host(row.get("source_ref"), "source_ref")
        if not hosts or not any(host == allowed or host.endswith("." + allowed) for allowed in hosts):
            raise ValueError(f"source host is not in the explicit allowlist: {host}")
        observed = _aware(row.get("observed_at"), "observed_at")
        if observed > reference + timedelta(minutes=5):
            raise ValueError("research observation cannot be future-dated")
        metadata = row.get("metadata") or {}
        if not isinstance(metadata, Mapping):
            raise ValueError("research record metadata must be an object")
        stable = {"market_id": market_id, "source_family": source_family, "metric": metric,
                  "source_ref": str(row["source_ref"]), "observed_at": observed.isoformat(),
                  "value": row.get("value"), "metadata": dict(metadata)}
        fingerprint = sha256(json.dumps(stable, sort_keys=True, ensure_ascii=False, default=str).encode()).hexdigest()
        if fingerprint in fingerprints:
            duplicates += 1
            continue
        fingerprints.add(fingerprint)
        is_stale = observed < reference.astimezone(timezone.utc) - timedelta(days=max_age_days)
        stale += int(is_stale)
        output.append({**stable, "freshness": "stale" if is_stale else "fresh",
                       "evidence_status": "review_required" if is_stale else "eligible_for_review",
                       "record_fingerprint": fingerprint})
    return {"status": "normalized", "accepted_count": len(output), "duplicate_count": duplicates,
            "stale_count": stale, "rejected_count": 0, "records": output,
            "source_policy": {"https_only": True, "allowed_hosts": sorted(hosts), "max_age_days": max_age_days},
            "execution_status": "normalization_only_no_network_requests"}




def collect_market_serps(market_results: Sequence[Mapping[str, Any]], *, provider: Any,
                         allowed_hosts: Sequence[str], call_budget: int = 40, limit: int = 5) -> dict[str, Any]:
    """Collect bounded public web SERP samples for discovered country-language markets."""
    if provider is None:
        return {"status": "not_configured", "records": [], "attempted_calls": 0}
    if isinstance(allowed_hosts, (str, bytes)) or not isinstance(allowed_hosts, Sequence) or not allowed_hosts:
        raise ValueError("live web SERP collection requires an explicit non-empty allowed_hosts list")
    if isinstance(call_budget, bool) or not isinstance(call_budget, int) or call_budget < 1:
        raise ValueError("serp call_budget must be a positive integer")
    if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 10:
        raise ValueError("SERP limit must be between 1 and 10")
    hosts = _normalize_allowed_hosts(allowed_hosts)
    records, failures, attempted, skipped = [], [], 0, 0
    for market in market_results:
        if attempted >= call_budget:
            skipped += 1
            continue
        if not isinstance(market, Mapping):
            raise ValueError("market results must be objects")
        market_id = str(market.get("market_id") or "").strip()
        country = str(market.get("country_code") or "").upper()
        localization = market.get("localization") or {}
        query = str(localization.get("selected_query") or "").strip() if isinstance(localization, Mapping) else ""
        if not market_id or len(country) != 2 or not query:
            failures.append({"market_id": market_id or None, "status": "missing_market_query_or_country"})
            continue
        attempted += 1
        try:
            result = provider.search(query, country=country, limit=limit)
            if result.get("status") not in {"ok", "partial"}:
                failures.append({"market_id": market_id, "status": result.get("status", "no_data")})
                continue
            observed_at = _aware(result.get("observed_at"), "SERP observed_at")
            accepted = 0
            for rank, item in enumerate(result.get("results", []), start=1):
                if not isinstance(item, Mapping):
                    continue
                source_ref = str(item.get("url") or "")
                host = _https_host(source_ref, "SERP result URL")
                if not any(host == allowed or host.endswith("." + allowed) for allowed in hosts):
                    continue
                records.append({"market_id": market_id, "source_ref": source_ref,
                    "source_family": "firecrawl_web_serp", "observed_at": observed_at.isoformat(),
                    "metric": "web_serp_rank", "value": rank,
                    "metadata": {"query": query, "country_code": country,
                        "title": str(item.get("title") or ""),
                        "description": str(item.get("description") or ""),
                        "localization_query_source": localization.get("selected_query_source")}})
                accepted += 1
            if not accepted:
                failures.append({"market_id": market_id, "status": "no_allowlisted_results"})
        except Exception as exc:
            failures.append({"market_id": market_id, "status": "error", "error_type": type(exc).__name__})
    return {"status": "partial" if skipped or failures else "ok", "records": records,
        "attempted_calls": attempted, "call_budget": call_budget, "skipped_market_count": skipped,
        "failure_count": len(failures), "failures": failures,
        "allowlisted_result_count": len(records),
        "execution_status": "live_public_search_completed_with_bounded_calls",
        "interpretation_limit": "SERP is a sampled public web search result, not YouTube SERP or a census; only explicitly allowlisted result hosts are retained."}


def aggregate_channel_analytics_records(records: Sequence[Mapping[str, Any]], *, currency: str = "USD") -> dict[str, Any]:
    """Aggregate daily owner Analytics rows with denominator-aware weighted rates."""
    if isinstance(records, (str, bytes)) or not isinstance(records, Sequence) or not records:
        raise ValueError("Analytics records must be a non-empty sequence")
    totals = {key: 0.0 for key in ("views", "engaged_views", "watch_time_minutes", "subscribers_gained", "estimated_revenue")}
    view_weighted_apv = 0.0
    apv_weight = 0.0
    for row in records:
        if not isinstance(row, Mapping):
            raise ValueError("each Analytics record must be an object")
        aliases = {"estimatedMinutesWatched": "watch_time_minutes", "subscribersGained": "subscribers_gained",
                   "estimatedRevenue": "estimated_revenue", "engagedViews": "engaged_views",
                   "averageViewPercentage": "average_view_percentage_pct"}
        normalized = {aliases.get(key, key): value for key, value in row.items()}
        for key in totals:
            if normalized.get(key) is not None:
                totals[key] += _num(normalized[key], key)
        engaged_views = _num(normalized.get("engaged_views", 0), "engaged_views")
        if normalized.get("average_view_percentage_pct") is not None and engaged_views:
            view_weighted_apv += _num(normalized["average_view_percentage_pct"], "average_view_percentage_pct", 0, 100) * engaged_views
            apv_weight += engaged_views
    return {"source": "owner_authorized_youtube_analytics", "views": totals["views"],
        "watch_time_minutes": totals["watch_time_minutes"],
        "engaged_views": totals["engaged_views"],
        "average_view_duration_seconds": totals["watch_time_minutes"] * 60 / totals["engaged_views"] if totals["engaged_views"] else None,
        "average_view_percentage_pct": view_weighted_apv / apv_weight if apv_weight else None,
        "subscribers_gained": totals["subscribers_gained"], "estimated_revenue": totals["estimated_revenue"],
        "impressions": None,
        "impressions_ctr_pct": None,
        "ctr_source_semantics": "reporting_api_reach_report_required",
        "currency": currency.upper(), "daily_record_count": len(records),
        "aggregation_method": "sum_public_views_and_engaged_views_separately; sum_watch_time_and_revenue; engaged_view_weighted_average_view_percentage; thumbnail_reach_requires_reporting_api"}


def calculate_channel_kpis(metrics: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(metrics, Mapping):
        raise ValueError("analytics metrics must be an object")
    if metrics.get("source") != "owner_authorized_youtube_analytics":
        raise ValueError("channel KPI calculation requires declared owner-authorized Analytics source")
    values = {}
    for key in ("views", "engaged_views", "impressions", "impressions_clicks", "watch_time_minutes", "average_view_duration_seconds",
                "video_duration_seconds", "average_view_percentage_pct", "subscribers_gained", "estimated_revenue"):
        values[key] = _num(metrics[key], key) if key in metrics and metrics[key] is not None else None
    views, impressions = values["views"], values["impressions"]
    clicks = values["impressions_clicks"]
    ctr = None
    if metrics.get("impressions_ctr_pct") is not None and metrics.get("ctr_source_semantics") in {
            "youtube_analytics_impression_click_through_rate",
            "youtube_analytics_video_thumbnail_impressions_click_rate_percentage"}:
        ctr = _num(metrics["impressions_ctr_pct"], "impressions_ctr_pct", 0, 100)
    elif impressions and clicks is not None and metrics.get("clicks_semantics") == "views_from_registered_impressions":
        if clicks > impressions:
            raise ValueError("impressions_clicks cannot exceed impressions")
        ctr = clicks / impressions * 100
    avd = values["average_view_duration_seconds"]
    duration = values["video_duration_seconds"]
    apv = values["average_view_percentage_pct"] if values["average_view_percentage_pct"] is not None else (avd / duration * 100 if avd is not None and duration and duration > 0 else None)
    revenue = values["estimated_revenue"]
    result = {"impressions_ctr_pct": round(ctr, 6) if ctr is not None else None,
        "average_view_duration_seconds": avd,
        "average_percentage_viewed_pct": round(apv, 6) if apv is not None else None,
        "watch_time_hours": round(values["watch_time_minutes"] / 60, 6) if values["watch_time_minutes"] is not None else None,
        "subscriber_conversion_per_1000_engaged_views": round(values["subscribers_gained"] / values["engaged_views"] * 1000, 6) if values["engaged_views"] and values["subscribers_gained"] is not None else None,
        "revenue_per_1000_views": round(revenue / views * 1000, 6) if views and revenue is not None else None,
        "estimated_revenue": revenue, "currency": str(metrics.get("currency") or "unspecified"),
        "denominators": {"ctr": "Reporting API registered thumbnail clicks / eligible thumbnail impressions", "subscriber_conversion": "subscribers_gained / engagedViews", "revenue_per_1000_views": "estimated_revenue / public views"},
        "source_verification": "declared_not_independently_authenticated",
        "data_boundary": "owner_channel_analytics_private_not_competitor_public_data"}
    result["metric_availability"] = {
        "thumbnail_ctr": result["impressions_ctr_pct"] is not None,
        "average_view_duration": avd is not None,
        "average_percentage_viewed": result["average_percentage_viewed_pct"] is not None,
        "watch_time": result["watch_time_hours"] is not None,
        "subscriber_conversion": result["subscriber_conversion_per_1000_engaged_views"] is not None,
        "revenue_per_1000_views": result["revenue_per_1000_views"] is not None,
    }
    result["funnel_diagnostics"] = {
        "packaging": {"supporting_metric": "thumbnail_ctr", "value": result["impressions_ctr_pct"],
            "status": "available" if result["impressions_ctr_pct"] is not None else "insufficient_evidence"},
        "consumption": {"supporting_metrics": ["average_view_duration", "average_percentage_viewed", "watch_time"],
            "values": {"average_view_duration_seconds": avd, "average_percentage_viewed_pct": result["average_percentage_viewed_pct"],
                "watch_time_hours": result["watch_time_hours"]},
            "status": "available" if avd is not None or result["average_percentage_viewed_pct"] is not None else "insufficient_evidence"},
        "audience_response": {"supporting_metric": "subscriber_conversion_per_1000_engaged_views",
            "value": result["subscriber_conversion_per_1000_engaged_views"],
            "status": "available" if result["subscriber_conversion_per_1000_engaged_views"] is not None else "insufficient_evidence"},
        "satisfaction": {"status": "not_measured_by_these_kpis",
            "note": "CTR, watch time and subscriber conversion do not independently measure viewer satisfaction."},
    }
    return result


def evaluate_distribution_surfaces(surface_inputs: Mapping[str, Mapping[str, Any]]) -> dict[str, Any]:
    if not isinstance(surface_inputs, Mapping):
        raise ValueError("distribution inputs must be an object")
    unknown = set(surface_inputs) - set(SURFACE_WEIGHTS)
    if unknown:
        raise ValueError("unknown distribution surfaces: " + ", ".join(sorted(unknown)))
    output = {}
    for surface, weights in SURFACE_WEIGHTS.items():
        row = surface_inputs.get(surface)
        if row is None:
            output[surface] = {"status": "insufficient_evidence", "score": None,
                               "missing_metrics": list(weights), "diagnostic_only": True}
            continue
        if not isinstance(row, Mapping):
            raise ValueError(f"{surface} metrics must be an object")
        unknown_metrics = set(row) - set(weights)
        if unknown_metrics:
            raise ValueError(f"unknown {surface} metrics: {', '.join(sorted(unknown_metrics))}")
        missing = sorted(set(weights) - set(row))
        if missing:
            output[surface] = {"status": "insufficient_evidence", "score": None,
                               "missing_metrics": missing, "diagnostic_only": True}
            continue
        values = {key: _num(row[key], f"{surface}.{key}", 0, 100) for key in weights}
        score = sum(values[key] * weight for key, weight in weights.items())
        output[surface] = {"status": "scored", "score": round(score, 2),
            "components": values, "weights": weights, "missing_metrics": [], "diagnostic_only": True,
            "interpretation_limit": "Heuristic diagnostic score, not a YouTube ranking factor or distribution prediction."}
    return {"status": "analyzed", "surfaces": output}


def plan_proportion_experiment(*, baseline_rate: float, minimum_detectable_effect: float,
                               alpha: float = .05, power: float = .8,
                               baseline_successes: int | None = None, baseline_trials: int | None = None,
                               treatment_successes: int | None = None, treatment_trials: int | None = None,
                               expected_treatment_share: float = .5) -> dict[str, Any]:
    p1 = _num(baseline_rate, "baseline_rate", 0.000001, .999999)
    delta = _num(minimum_detectable_effect, "minimum_detectable_effect", .000001, .999999)
    if p1 + delta >= 1:
        raise ValueError("baseline_rate + minimum_detectable_effect must be below 1")
    alpha = _num(alpha, "alpha", .000001, .2)
    power = _num(power, "power", .5, .999)
    share = _num(expected_treatment_share, "expected_treatment_share", .01, .99)
    p2 = p1 + delta
    normal = NormalDist()
    z_alpha = normal.inv_cdf(1 - alpha / 2)
    z_power = normal.inv_cdf(power)
    pooled = (p1 + p2) / 2
    n = ((z_alpha * sqrt(2 * pooled * (1 - pooled)) + z_power *
          sqrt(p1 * (1 - p1) + p2 * (1 - p2))) ** 2 / (delta ** 2))
    required_per_arm = int(n + .999999)
    required_total = int(max(required_per_arm / (1 - share), required_per_arm / share) + .999999)
    required_baseline = int(required_total * (1 - share) + .999999)
    required_treatment = int(required_total * share + .999999)
    result: dict[str, Any] = {"required_sample_per_arm": required_per_arm,
        "required_total_sample": required_total, "required_baseline_sample": required_baseline,
        "required_treatment_sample": required_treatment,
        "baseline_rate": p1, "minimum_detectable_effect": delta,
        "target_treatment_rate": p2, "alpha": alpha, "power": power,
        "confidence_level_pct": round((1 - alpha) * 100, 4),
        "expected_treatment_share": share,
        "method": "normal_approximation_two_independent_proportions_equal_variance_planning",
        "status": "planning_only", "srm_status": "not_assessed",
        "interpretation_limit": "Planning approximation; adjust for clustering, repeated exposure, attrition, multiple tests and platform experiment constraints."}
    observed_fields = (baseline_successes, baseline_trials, treatment_successes, treatment_trials)
    if any(value is not None for value in observed_fields) and not all(value is not None for value in observed_fields):
        raise ValueError("all four observed experiment counts must be supplied together")
    if all(value is not None for value in observed_fields):
        b_s, b_n, t_s, t_n = observed_fields
        for value, name in ((b_s, "baseline_successes"), (b_n, "baseline_trials"),
                            (t_s, "treatment_successes"), (t_n, "treatment_trials")):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ValueError(f"{name} must be a non-negative integer")
        if b_n < 1 or t_n < 1 or b_s > b_n or t_s > t_n:
            raise ValueError("experiment successes/trials are invalid")
        total = b_n + t_n
        expected_t = total * share
        expected_b = total * (1 - share)
        chi2 = (t_n - expected_t) ** 2 / expected_t + (b_n - expected_b) ** 2 / expected_b
        srm = "fail" if chi2 > 3.841458820694124 else "pass"
        r1, r2 = b_s / b_n, t_s / t_n
        diff = r2 - r1
        se = sqrt(r1 * (1 - r1) / b_n + r2 * (1 - r2) / t_n)
        z = diff / se if se else 0.0
        p_value = 2 * (1 - normal.cdf(abs(z)))
        ci_z = z_alpha
        ci = (diff - ci_z * se, diff + ci_z * se)
        underpowered = b_n < result["required_baseline_sample"] or t_n < result["required_treatment_sample"]
        if srm == "fail": status = "invalid_sample_ratio_mismatch"
        elif underpowered: status = "inconclusive"
        elif p_value < alpha and ci[0] > 0: status = "significant_review_guardrails"
        elif p_value < alpha and ci[1] < 0: status = "significant_negative_lift_review"
        elif diff > 0: status = "promising_not_significant"
        else: status = "no_positive_lift_observed"
        result.update({"baseline_n": b_n, "treatment_n": t_n,
            "baseline_rate_observed": round(r1, 8), "treatment_rate_observed": round(r2, 8),
            "observed_lift_percentage_points": round(diff * 100, 6),
            "relative_lift_pct": round(diff / r1 * 100, 6) if r1 else None,
            "confidence_interval_percentage_points": [round(ci[0] * 100, 6), round(ci[1] * 100, 6)],
            "p_value_normal_approximation": round(p_value, 8), "srm_chi_square": round(chi2, 6),
            "srm_status": srm, "underpowered": underpowered, "status": status,
            "ship_gate": "human_guardrail_review_required" if srm == "pass" and not underpowered and status == "significant_review_guardrails" else "blocked",
            "guardrails_required": ["randomization integrity", "novelty and seasonality", "multiple-comparison control",
                "repeated exposure and clustering", "practical effect size", "audience harm and downstream quality"],
            "interpretation_limit": "Normal-approximation inference assumes independent observations; do not use for sequential peeking or clustered/repeated exposure without an adjusted design."})
    return result


def update_learning_proposal(*, predictions: Sequence[float], actuals: Sequence[float],
                             current_policy_version: str, proposed_weights: Mapping[str, float],
                             minimum_observations: int = 20) -> dict[str, Any]:
    if isinstance(predictions, (str, bytes)) or isinstance(actuals, (str, bytes)):
        raise ValueError("predictions and actuals must be sequences")
    if not isinstance(current_policy_version, str) or not current_policy_version.strip():
        raise ValueError("current_policy_version must be non-empty")
    if isinstance(minimum_observations, bool) or not isinstance(minimum_observations, int) or minimum_observations < 2:
        raise ValueError("minimum_observations must be an integer >= 2")
    if not isinstance(proposed_weights, Mapping) or not proposed_weights:
        raise ValueError("proposed_weights must be a non-empty mapping")
    weights = {str(key): _num(value, f"weight.{key}", 0, 1) for key, value in proposed_weights.items()}
    if abs(sum(weights.values()) - 1) > .0001:
        raise ValueError("proposed weights must sum to 1")
    errors = forecast_error_metrics(predictions, actuals)
    sufficient = errors["n"] >= minimum_observations
    return {"status": "human_review_required" if sufficient else "insufficient_observations",
        "current_policy_version": current_policy_version,
        "proposed_policy_version": current_policy_version + "+proposal",
        "observation_count": errors["n"], "minimum_observations": minimum_observations,
        "forecast_error": errors, "proposed_weights": weights,
        "calibration_status": "insufficient_observations" if not sufficient else "backtest_required",
        "out_of_sample_validation_required": True, "holdout_required": True,
        "apply_allowed": False, "approval_required": True,
        "recommendation": "review_proposal_with_out_of_sample_backtest" if sufficient else "collect_more_observations",
        "interpretation_limit": "No scoring policy is modified automatically; proposal is not evidence of causal improvement."}


def run_global_growth_engine(payload: Mapping[str, Any], *, market_discovery_service: Any = None,
                             market_profiles: Sequence[Any] | None = None,
                             web_serp_provider: Any = None,
                             external_requests_made: bool = False) -> dict[str, Any]:
    """Run all eight capability stages from one versioned, auditable payload."""
    if not isinstance(payload, Mapping):
        raise ValueError("payload must be an object")
    if not isinstance(external_requests_made, bool):
        raise ValueError("external_requests_made must be a boolean")
    topic = str(payload.get("topic") or "").strip()
    if not topic:
        raise ValueError("topic must be non-empty")

    markets = payload.get("markets") or []
    localization = payload.get("localization") or []
    research_records = payload.get("research_records") or []
    allowed_hosts = payload.get("allowed_hosts") or []
    for name, value in (("markets", markets), ("localization", localization), ("research_records", research_records)):
        if isinstance(value, (str, bytes)) or not isinstance(value, Sequence):
            raise ValueError(f"{name} must be a sequence")

    # Validate all user-supplied evidence and configuration before any live provider call.
    localization_result = build_localization_matrix(localization) if localization else {
        "status": "not_configured", "markets": [], "ready_market_count": 0}
    base_research_result = build_research_pipeline(research_records, allowed_hosts=allowed_hosts,
        max_age_days=payload.get("research_max_age_days", 90),
        max_records=payload.get("research_max_records", 10000)) if research_records else {
        "status": "not_configured", "records": [], "accepted_count": 0, "duplicate_count": 0, "stale_count": 0}

    country_rpm_rows = payload.get("country_rpm_evidence") or []
    if isinstance(country_rpm_rows, (str, bytes)) or not isinstance(country_rpm_rows, Sequence):
        raise ValueError("country_rpm_evidence must be a sequence")
    country_rpm_by_code = {}
    for row in country_rpm_rows:
        if not isinstance(row, Mapping):
            raise ValueError("each country RPM evidence row must be an object")
        code = str(row.get("country") or row.get("country_code") or "").upper()
        if len(code) != 2 or not code.isalpha() or code in country_rpm_by_code:
            raise ValueError("country RPM evidence requires unique two-letter country codes")
        currency = str(row.get("currency") or "").upper()
        if len(currency) != 3 or not currency.isalpha():
            raise ValueError("country RPM evidence requires a three-letter currency code")
        views = _num(row.get("views"), f"{code}.views")
        revenue = _num(row.get("estimatedRevenue", row.get("estimated_revenue")), f"{code}.estimatedRevenue")
        actual_rpm = revenue / views * 1000 if views > 0 else None
        country_rpm_by_code[code] = {**dict(row), "views": views, "estimatedRevenue": revenue,
            "rpm": actual_rpm, "currency": currency,
            "source_verification": "declared_not_independently_authenticated"}

    market_inputs = []
    for market in markets:
        if not isinstance(market, Mapping):
            raise ValueError("each market economics input must be an object")
        normalized_market = dict(market)
        country_code = str(normalized_market.get("country_code") or "").upper()
        actual = country_rpm_by_code.get(country_code)
        # YouTube API Data is kept separate from external market-opportunity inputs.
        # First-party RPM is attached below as a distinct owner-only evidence panel.
        if normalized_market.get("rpm_source") == "owner_analytics_actual":
            raise ValueError("owner-authorized YouTube RPM cannot be blended into external market-opportunity scoring")
        market_inputs.append(normalized_market)
    market_economics = score_market_economics(market_inputs) if market_inputs else []
    for item in market_economics:
        actual = country_rpm_by_code.get(item.get("country_code"))
        if actual:
            item["first_party_channel_rpm_evidence"] = {"rpm": actual.get("rpm"),
                "views": actual.get("views"), "estimated_revenue": actual.get("estimatedRevenue", actual.get("estimated_revenue")),
                "currency": actual.get("currency"), "source": actual.get("source", "unknown_declared_source"),
                "currency_comparable": str(actual.get("currency") or "").upper() == str(item.get("currency") or "").upper(),
                "source_verification": actual.get("source_verification", "declared_not_independently_authenticated"),
                "used_in_opportunity_score": False,
                "interpretation_limit": "Observed for this channel and reporting period; not competitor RPM or a market-wide forecast."}
            item["used_first_party_rpm_in_opportunity_score"] = False
    scored_market_count = sum(item.get("status") != "insufficient_evidence" for item in market_economics)

    analytics_input = payload.get("analytics")
    analytics_result = calculate_channel_kpis(analytics_input) if analytics_input else {"status": "not_configured"}
    distribution_result = evaluate_distribution_surfaces(payload.get("distribution") or {})
    experiment_input = payload.get("experiment")
    if experiment_input is not None and not isinstance(experiment_input, Mapping):
        raise ValueError("experiment must be an object")
    experiment_result = plan_proportion_experiment(**experiment_input) if experiment_input else {"status": "not_configured"}
    learning_input = payload.get("learning")
    if learning_input is not None and not isinstance(learning_input, Mapping):
        raise ValueError("learning must be an object")
    learning_result = update_learning_proposal(**learning_input) if learning_input else {
        "status": "not_configured", "apply_allowed": False}
    automation_jobs = payload.get("automation_jobs", [])
    if isinstance(automation_jobs, (str, bytes)) or not isinstance(automation_jobs, Sequence):
        raise ValueError("automation_jobs must be a sequence")
    automation_results = [validate_automation_job(job) for job in automation_jobs]
    discovery_options = payload.get("market_discovery_options") or {}
    if not isinstance(discovery_options, Mapping):
        raise ValueError("market_discovery_options must be an object")

    web_serp_collection = {"status": "not_configured", "records": [], "attempted_calls": 0}
    if web_serp_provider is not None:
        if market_discovery_service is None:
            raise ValueError("web_serp_provider requires market_discovery_service")
        # Empty collection validates host allowlist and bounds before YouTube calls begin.
        collect_market_serps([], provider=web_serp_provider, allowed_hosts=allowed_hosts,
            call_budget=payload.get("serp_call_budget", 40), limit=payload.get("serp_limit", 5))

    market_discovery = {"status": "not_configured", "reason": "Live provider not configured; pass an authorized discovery service to run multi-market collection."}
    if market_discovery_service is not None:
        if not market_profiles:
            raise ValueError("market_profiles are required when market_discovery_service is supplied")
        options = dict(discovery_options)
        localized_reviews = {}
        for item in localization_result["markets"]:
            localized_reviews[item["market_id"]] = {
                "queries": item["query_variants"],
                "review_status": "native_reviewed" if item["status"] == "native_reviewed" else "pending",
                "source_ref": item.get("review_source_ref"),
                "reviewed_at": next((source.get("reviewed_at") for source in localization if source.get("market_id") == item["market_id"]), None),
                "dialect_reviewed": item["status"] == "native_reviewed",
                "accent_reviewed": item["status"] == "native_reviewed",
                "cultural_reviewed": item["status"] == "native_reviewed"}
        supplied_reviews = options.get("localized_query_variants")
        if supplied_reviews is not None:
            if not isinstance(supplied_reviews, Mapping):
                raise ValueError("localized_query_variants must be a mapping")
            for market_id, review in supplied_reviews.items():
                if not isinstance(review, Mapping):
                    raise ValueError("localized query review entries must be objects")
                validated = localized_reviews.get(str(market_id))
                if review.get("review_status") == "native_reviewed":
                    if (not validated or validated.get("review_status") != "native_reviewed" or
                        review.get("source_ref") != validated.get("source_ref") or
                        review.get("reviewed_at") != validated.get("reviewed_at")):
                        review = {**dict(review), "review_status": "pending"}
                localized_reviews[str(market_id)] = {**dict(review),
                    "dialect_reviewed": bool((validated or {}).get("dialect_reviewed", False)),
                    "accent_reviewed": bool((validated or {}).get("accent_reviewed", False)),
                    "cultural_reviewed": bool((validated or {}).get("cultural_reviewed", False)),
                    "reviewer_ref": (validated or {}).get("reviewer_ref", review.get("reviewer_ref"))}
        options["localized_query_variants"] = localized_reviews
        market_discovery = market_discovery_service.discover(topic=topic, markets=tuple(market_profiles), **options)

    if web_serp_provider is not None:
        web_serp_collection = collect_market_serps(market_discovery.get("markets", []),
            provider=web_serp_provider, allowed_hosts=allowed_hosts,
            call_budget=payload.get("serp_call_budget", 40), limit=payload.get("serp_limit", 5))
    combined_records = list(research_records) + list(web_serp_collection.get("records", []))
    research_result = build_research_pipeline(combined_records, allowed_hosts=allowed_hosts,
        max_age_days=payload.get("research_max_age_days", 90),
        max_records=payload.get("research_max_records", 10000)) if combined_records else base_research_result
    research_result["web_serp_collection"] = {key: value for key, value in web_serp_collection.items() if key != "records"}

    discovery_rows = market_discovery.get("markets", []) if isinstance(market_discovery, Mapping) else []
    discovery_by_id = {str(row.get("market_id")): row for row in discovery_rows
                       if isinstance(row, Mapping) and row.get("market_id")}
    discovery_economics_bridge = []
    for economics in market_economics:
        discovered = discovery_by_id.get(str(economics.get("market_id")))
        decision = (discovered or {}).get("decision") or {}
        discovery_economics_bridge.append({
            "market_id": economics.get("market_id"),
            "status": "matched" if discovered else "discovery_not_matched",
            "discovery_decision_status": decision.get("status"),
            "discovery_decision_score": decision.get("score"),
            "discovery_coverage": decision.get("coverage"),
            "discovery_ranking_eligible": bool((discovered or {}).get("ranking_eligible", False)),
            "economics_opportunity_score": economics.get("opportunity_score"),
            "economics_confidence_adjusted_score": economics.get("confidence_adjusted_score"),
            "scores_blended": False,
            "interpretation_limit": "Four-layer evidence decision and market-economics score remain separate decision lenses; neither is substituted for the other.",
        })
    competitor_profiles = {str(row.get("market_id")): analyze_competitor_sample(row.get("youtube", {}).get("videos", []))
        for row in discovery_rows if isinstance(row, Mapping) and row.get("market_id") and isinstance(row.get("youtube"), Mapping)}

    capabilities: dict[str, Any] = {
        "global_market": {"status": ("scored" if scored_market_count else "insufficient_evidence"), "markets": market_economics,
            "discovery_economics_bridge": {"status": "joined" if discovery_economics_bridge else "not_joined",
                "matched_count": sum(row["status"] == "matched" for row in discovery_economics_bridge),
                "unmatched_count": sum(row["status"] != "matched" for row in discovery_economics_bridge),
                "scores_blended": False, "markets": discovery_economics_bridge},
            "competitor_intelligence": competitor_profiles,
            "first_party_country_rpm_evidence_count": len(country_rpm_by_code), "discovery": market_discovery}
            if markets else {"status": "discovered" if market_discovery.get("status") in {"ok", "partial_quota_limited"} else "not_configured",
                "markets": [], "discovery_economics_bridge": {"status": "not_joined", "matched_count": 0, "unmatched_count": 0, "scores_blended": False, "markets": []},
                "competitor_intelligence": competitor_profiles,
                "first_party_country_rpm_evidence": list(country_rpm_by_code.values()),
                "first_party_country_rpm_evidence_count": len(country_rpm_by_code), "discovery": market_discovery},
        "localization": localization_result,
        "research_pipeline": research_result,
        "channel_analytics": analytics_result,
        "distribution": distribution_result,
        "experimentation": experiment_result,
        "continuous_learning": learning_result,
        "automation": {"status": "validated", "jobs": automation_results,
                       "execution_status": "not_scheduled_or_executed"},
    }
    hard_gates = []
    if not markets and market_discovery.get("status") not in {"ok", "partial_quota_limited"}:
        hard_gates.append("global_market_inputs_missing")
    if markets and scored_market_count < len(markets):
        hard_gates.append("market_economics_insufficient_evidence_for_some_markets")
    if not markets and market_discovery.get("status") in {"ok", "partial_quota_limited"}:
        hard_gates.append("market_economics_inputs_missing")
    if not localization:
        hard_gates.append("localization_inputs_missing")
    if market_discovery.get("status") == "not_configured":
        hard_gates.append("live_global_market_collection_not_run")
    if market_discovery.get("status") == "partial_quota_limited":
        hard_gates.append("global_market_scan_incomplete_no_final_ranking")
    if market_discovery.get("status") == "insufficient_evidence":
        hard_gates.append("global_market_discovery_insufficient_evidence")
    if localization_result.get("ready_market_count", 0) < len(localization):
        hard_gates.append("native_localization_review_incomplete")
    if research_result.get("accepted_count", 0) == 0:
        hard_gates.append("research_evidence_not_supplied")
    if web_serp_collection.get("status") == "partial":
        hard_gates.append("web_serp_collection_partial")
    if analytics_result.get("status") == "not_configured":
        hard_gates.append("owner_analytics_not_supplied")
    if any(item.get("status") != "scored" for item in distribution_result["surfaces"].values()):
        hard_gates.append("distribution_surface_evidence_incomplete")
    if experiment_result.get("status") != "significant_review_guardrails":
        hard_gates.append("experiment_not_validated")
    else:
        hard_gates.append("experiment_guardrail_review_required")
    if learning_result.get("status") != "human_review_required":
        hard_gates.append("learning_evidence_below_review_threshold")
    else:
        hard_gates.append("learning_policy_human_approval_required")
    if not automation_results:
        hard_gates.append("automation_contracts_not_supplied")
    elif any(job.get("status") != "ready_for_operator_scheduling" for job in automation_results):
        hard_gates.append("automation_contract_blocked")
    else:
        hard_gates.append("automation_requires_operator_scheduling_approval")

    external_requests_made = bool(external_requests_made or market_discovery_service is not None or web_serp_provider is not None)
    return {"engine_version": "v17-global-growth-engine-1.0.0", "topic": topic,
        "status": "decision_support_ready_with_gates" if hard_gates else "decision_support_ready_pending_human_approval",
        "capabilities": capabilities, "hard_gates": hard_gates,
        "execution_boundary": {"external_requests_made": external_requests_made,
            "youtube_account_mutations": False, "automation_scheduled": False, "policy_auto_updated": False},
        "decision_policy": "evidence_first_missing_is_not_zero; all forecasts are scenarios; human approval required for production changes"}
