"""Versioned YouTube metric definitions and conservative Analytics query planning."""
from __future__ import annotations

from dataclasses import asdict, dataclass
from types import MappingProxyType
from typing import Mapping


@dataclass(frozen=True, slots=True)
class MetricDefinition:
    canonical_name: str
    api_name: str
    definition: str
    unit: str
    numerator: str | None
    denominator: str | None
    source: str
    privacy: str
    required_scopes: tuple[str, ...]
    supported_endpoints: tuple[str, ...]
    compatible_dimensions: tuple[str, ...]
    freshness_target_hours: int
    interpretation_limit: str


@dataclass(frozen=True, slots=True)
class AnalyticsQueryPlan:
    endpoint: str
    metrics: tuple[str, ...]
    dimensions: tuple[str, ...]
    required_scopes: tuple[str, ...]
    registry_version: str


_READONLY = "https://www.googleapis.com/auth/yt-analytics.readonly"
_MONETARY = "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"
_DAILY = "reports.query.daily"
_COUNTRY = "reports.query.country"
_REPORTING_REACH = "reporting.jobs"


def _metric(name: str, definition: str, unit: str, *, numerator: str | None = None,
            denominator: str | None = None, scopes: tuple[str, ...] = (_READONLY,),
            endpoints: tuple[str, ...] = (_DAILY,),
            dimensions: tuple[str, ...] = ("day", "day,video"),
            privacy: str = "owner_private", limit: str = "First-party channel metric; not available for public competitor inference.") -> MetricDefinition:
    return MetricDefinition(name, name, definition, unit, numerator, denominator,
        "youtube_analytics_api", privacy, scopes, endpoints, dimensions, 24, limit)


_DEFINITIONS = (
    _metric("views", "Public view count under the active YouTube definition; do not treat as engaged viewing.", "views", endpoints=(_DAILY, _COUNTRY), dimensions=("day", "day,video", "country"), privacy="owner_private"),
    _metric("engagedViews", "Views that passed YouTube's engaged-view definition; separate from public views.", "views", endpoints=(_DAILY,), dimensions=("day", "day,video"), privacy="owner_private", limit="Use as the consumption denominator where YouTube Analytics defines engaged views; not interchangeable with public views."),
    _metric("estimatedMinutesWatched", "Estimated minutes watched.", "minutes", privacy="owner_private"),
    _metric("averageViewDuration", "Average view duration.", "seconds", numerator="watch_time_seconds", denominator="engagedViews", privacy="owner_private"),
    _metric("likes", "Count of likes.", "likes", privacy="owner_private"),
    _metric("comments", "Count of comments.", "comments", privacy="owner_private"),
    _metric("subscribersGained", "Subscribers gained during the report period.", "subscribers", privacy="owner_private"),
    _metric("averageViewPercentage", "Average percentage of the video watched.", "percent",
        numerator="watch_time_seconds", denominator="engagedViews_times_video_duration_seconds", privacy="owner_private"),
    _metric("estimatedRevenue", "Estimated revenue reported for the authorized channel.", "currency",
        scopes=(_READONLY, _MONETARY), endpoints=(_DAILY, _COUNTRY),
        dimensions=("day", "day,video", "country"),
        limit="Private channel-period estimate in the requested currency; never infer competitor RPM or future revenue."),
)


@dataclass(frozen=True, slots=True, init=False)
class MetricRegistry:
    """Immutable metric catalog with explicit version and conservative lookups."""

    version: str
    _definitions: Mapping[str, MetricDefinition]

    def __init__(self, definitions: tuple[MetricDefinition, ...] = _DEFINITIONS,
                 version: str = "youtube-analytics-v1") -> None:
        if not isinstance(version, str) or not version.strip():
            raise ValueError("registry version must be non-empty")
        by_name = {item.canonical_name: item for item in definitions}
        if len(by_name) != len(definitions):
            raise ValueError("metric canonical names must be unique")
        object.__setattr__(self, "version", version)
        object.__setattr__(self, "_definitions", MappingProxyType(by_name))

    def get(self, name: str) -> MetricDefinition:
        try:
            return self._definitions[name]
        except KeyError as exc:
            raise ValueError(f"unsupported Analytics metric: {name}") from exc

    def list(self) -> tuple[MetricDefinition, ...]:
        return tuple(self._definitions.values())

    def as_dicts(self) -> list[dict[str, object]]:
        return [asdict(item) for item in self.list()]


@dataclass(frozen=True, slots=True)
class ReportingReportPlan:
    """Bulk Reporting API report contract; not valid for Analytics reports.query."""

    endpoint: str
    report_family: str
    metrics: tuple[str, ...]
    registry_version: str


def plan_reporting_reach_report() -> ReportingReportPlan:
    """Describe the Reach bulk report fields without pretending to run a job."""
    return ReportingReportPlan(
        endpoint=_REPORTING_REACH,
        report_family="reach",
        metrics=("video_thumbnail_impressions", "video_thumbnail_impressions_ctr"),
        registry_version="youtube-reporting-reach-v1",
    )


METRIC_REGISTRY = MetricRegistry()


def _parse_metrics(metrics: str | tuple[str, ...] | list[str]) -> tuple[str, ...]:
    values = tuple(part.strip() for part in metrics.split(",")) if isinstance(metrics, str) else tuple(metrics)
    if not values or any(not isinstance(item, str) or not item for item in values):
        raise ValueError("at least one non-empty Analytics metric is required")
    if len(set(values)) != len(values):
        raise ValueError("duplicate Analytics metrics are not allowed")
    return values


def plan_daily_analytics_query(metrics: str | tuple[str, ...] | list[str], *,
                               video_ids: tuple[str, ...] = (),
                               dimensions: str | None = None,
                               allow_video_dimension: bool = True) -> AnalyticsQueryPlan:
    names = _parse_metrics(metrics)
    if len(set(video_ids)) != len(video_ids) or any(not isinstance(item, str) or not item.strip() for item in video_ids):
        raise ValueError("video_ids must be unique non-empty identifiers")
    selected_dimensions = dimensions or ("day,video" if len(video_ids) > 1 else "day")
    if selected_dimensions not in {"day", "day,video"}:
        raise ValueError("daily Analytics dimensions must be 'day' or 'day,video'")
    if selected_dimensions == "day,video" and (not video_ids or not allow_video_dimension):
        raise ValueError("video dimension requires video IDs and explicit video-dimension support")
    definitions = tuple(METRIC_REGISTRY.get(name) for name in names)
    scopes: set[str] = set()
    for definition in definitions:
        if _DAILY not in definition.supported_endpoints or selected_dimensions not in definition.compatible_dimensions:
            raise ValueError(f"unsupported Analytics metric/dimension combination: {definition.api_name}/{selected_dimensions}")
        scopes.update(definition.required_scopes)
    return AnalyticsQueryPlan(_DAILY, names, tuple(selected_dimensions.split(",")),
        tuple(sorted(scopes)), METRIC_REGISTRY.version)


def plan_country_analytics_query(metrics: str | tuple[str, ...] | list[str]) -> AnalyticsQueryPlan:
    names = _parse_metrics(metrics)
    definitions = tuple(METRIC_REGISTRY.get(name) for name in names)
    scopes: set[str] = set()
    for definition in definitions:
        if _COUNTRY not in definition.supported_endpoints or "country" not in definition.compatible_dimensions:
            raise ValueError(f"unsupported country Analytics metric: {definition.api_name}")
        scopes.update(definition.required_scopes)
    return AnalyticsQueryPlan(_COUNTRY, names, ("country",), tuple(sorted(scopes)), METRIC_REGISTRY.version)
