"""Conservative retention enforcement for public YouTube API-derived records."""
from __future__ import annotations
from datetime import datetime, timedelta, timezone


def purge_expired_public_youtube_data(database, *, now: datetime | None = None,
                                      retention_days: int = 30) -> dict:
    if not 1 <= retention_days <= 30:
        raise ValueError("public YouTube API data retention must be between 1 and 30 days")
    reference = now or datetime.now(timezone.utc)
    if reference.tzinfo is None or reference.utcoffset() is None:
        raise ValueError("now must be timezone-aware")
    cutoff = (reference - timedelta(days=retention_days)).isoformat()
    with database.transaction() as connection:
        before = connection.execute("SELECT COUNT(*) FROM research_runs WHERE created_at < ?", (cutoff,)).fetchone()[0]
        connection.execute("DELETE FROM research_runs WHERE created_at < ?", (cutoff,))
        expired_serp = connection.execute("SELECT COUNT(*) FROM serp_snapshots WHERE observed_at < ?", (cutoff,)).fetchone()[0]
        connection.execute("DELETE FROM serp_snapshots WHERE observed_at < ?", (cutoff,))
    return {"status": "ok", "retention_days": retention_days, "cutoff": cutoff,
            "expired_research_runs_deleted": before,
            "expired_serp_snapshots_deleted": expired_serp,
            "scope": "public_research_runs_evidence_results_and_video_snapshots",
            "private_channel_analytics_preserved": True,
            "serp_snapshots_preserved": False}
