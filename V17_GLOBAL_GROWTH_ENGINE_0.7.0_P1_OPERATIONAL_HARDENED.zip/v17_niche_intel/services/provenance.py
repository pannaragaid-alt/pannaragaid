"""Deterministic source provenance records for normalized evidence."""
from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone
from typing import Any, Mapping


def _timestamp(value: datetime, field: str) -> str:
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError(f"{field} must be timezone-aware")
    return value.astimezone(timezone.utc).isoformat()


def _canonical_json(value: Any) -> str:
    try:
        return json.dumps(value, sort_keys=True, separators=(",", ":"),
            ensure_ascii=False, allow_nan=False)
    except (TypeError, ValueError) as exc:
        raise ValueError("raw payload and request parameters must be finite JSON-serializable values") from exc


def build_provenance_record(*, source_family: str, source_ref: str, raw_payload: Any,
                            observed_at: datetime, transform_version: str,
                            fetched_at: datetime | None = None,
                            request_params: Mapping[str, Any] | None = None,
                            timezone_name: str | None = None, region: str | None = None,
                            locale: str | None = None,
                            sample_window: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Build a metadata record; raw payload is hashed, not copied into the record."""
    if not isinstance(source_family, str) or not source_family.strip():
        raise ValueError("source_family must be non-empty")
    if not isinstance(source_ref, str) or not source_ref.strip():
        raise ValueError("source_ref must be non-empty")
    if not isinstance(transform_version, str) or not transform_version.strip():
        raise ValueError("transform_version must be non-empty")
    observed = _timestamp(observed_at, "observed_at")
    fetched = _timestamp(fetched_at or datetime.now(timezone.utc), "fetched_at")
    raw_canonical = _canonical_json(raw_payload)
    request_canonical = _canonical_json(dict(request_params or {}))
    sample_canonical = _canonical_json(dict(sample_window or {}))
    return {
        "provenance_version": "v1",
        "source_family": source_family.strip(),
        "source_ref": source_ref.strip(),
        "observed_at": observed,
        "fetched_at": fetched,
        "request_params": json.loads(request_canonical),
        "timezone": timezone_name,
        "region": region,
        "locale": locale,
        "sample_window": json.loads(sample_canonical),
        "transform_version": transform_version.strip(),
        "raw_sha256": hashlib.sha256(raw_canonical.encode("utf-8")).hexdigest(),
    }
