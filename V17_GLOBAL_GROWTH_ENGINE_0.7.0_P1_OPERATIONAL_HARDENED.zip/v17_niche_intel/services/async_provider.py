"""Bounded async facade for existing synchronous provider adapters."""
from __future__ import annotations

import asyncio
from collections.abc import Callable
from typing import Any, TypeVar

T = TypeVar("T")


class BoundedAsyncExecutor:
    """Offload blocking provider calls without exceeding a configured in-flight bound.

    The wrapped provider must configure its own finite network timeout. Python cannot
    forcibly stop a worker thread; cancellation therefore waits for that call to exit
    before releasing the semaphore slot, preventing hidden concurrency oversubscription.
    """

    def __init__(self, *, max_concurrency: int = 4) -> None:
        if isinstance(max_concurrency, bool) or not isinstance(max_concurrency, int) or max_concurrency < 1:
            raise ValueError("max_concurrency must be a positive integer")
        self.max_concurrency = max_concurrency
        self._semaphore = asyncio.Semaphore(max_concurrency)

    async def run(self, function: Callable[..., T], /, *args: Any, **kwargs: Any) -> T:
        if not callable(function):
            raise TypeError("function must be callable")
        async with self._semaphore:
            worker = asyncio.create_task(asyncio.to_thread(function, *args, **kwargs))
            try:
                return await asyncio.shield(worker)
            except asyncio.CancelledError:
                while True:
                    try:
                        await asyncio.shield(worker)
                        break
                    except asyncio.CancelledError:
                        continue
                    except Exception:
                        break
                raise
