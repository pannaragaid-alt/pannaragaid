from __future__ import annotations

import json
from pathlib import Path

_DEFAULT_FILE_MAX_JSON_BYTES = 10 * 1024 * 1024


_DEFAULT_MAX_JSON_BYTES = 1024 * 1024
_DEFAULT_MAX_JSON_DEPTH = 64


def _reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"JSON contains a duplicate object key: {key}")
        result[key] = value
    return result


def _reject_non_finite(value):
    raise ValueError(f"JSON contains a non-finite numeric constant: {value}")


def parse_bounded_json(
    payload: str,
    *,
    max_bytes: int = _DEFAULT_MAX_JSON_BYTES,
    max_depth: int = _DEFAULT_MAX_JSON_DEPTH,
):
    """Decode user-supplied JSON only after enforcing byte and structural-depth bounds."""
    if not isinstance(payload, str):
        raise ValueError("JSON input must be text")
    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int) or max_bytes < 1:
        raise ValueError("max_bytes must be a positive integer")
    if isinstance(max_depth, bool) or not isinstance(max_depth, int) or max_depth < 1:
        raise ValueError("max_depth must be a positive integer")
    try:
        encoded_size = len(payload.encode("utf-8"))
    except UnicodeEncodeError as exc:
        raise ValueError("JSON input contains invalid Unicode") from exc
    if encoded_size > max_bytes:
        raise ValueError(f"JSON input exceeds the {max_bytes}-byte limit")

    depth = 0
    in_string = False
    escaped = False
    for char in payload:
        if in_string:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char in "[{":
            depth += 1
            if depth > max_depth:
                raise ValueError(f"JSON input exceeds the nesting limit of {max_depth}")
        elif char in "]}":
            depth -= 1

    try:
        return json.loads(payload, object_pairs_hook=_reject_duplicate_keys, parse_constant=_reject_non_finite)
    except RecursionError as exc:
        raise ValueError("JSON input exceeds the parser recursion limit") from exc


def load_bounded_json_file(
    path: str | Path,
    *,
    max_bytes: int = _DEFAULT_FILE_MAX_JSON_BYTES,
    max_depth: int = _DEFAULT_MAX_JSON_DEPTH,
):
    """Read at most max_bytes + 1 bytes from an untrusted JSON file and parse it."""
    if isinstance(max_bytes, bool) or not isinstance(max_bytes, int) or max_bytes < 1:
        raise ValueError("max_bytes must be a positive integer")
    try:
        with Path(path).open("rb") as stream:
            raw = stream.read(max_bytes + 1)
    except OSError:
        raise
    if len(raw) > max_bytes:
        raise ValueError(f"JSON input exceeds the {max_bytes}-byte limit")
    try:
        payload = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        raise ValueError("JSON input is not valid UTF-8") from exc
    return parse_bounded_json(payload, max_bytes=max_bytes, max_depth=max_depth)
