"""Validated runtime configuration helpers."""
from __future__ import annotations

import os
import re
from collections.abc import Mapping

_INTEGER = re.compile(r"[0-9]{1,10}\Z")


def positive_int_setting(name: str, default: int, *, maximum: int = 1_000_000_000,
                         environ: Mapping[str, str] | None = None) -> int:
    """Read a bounded positive integer setting; reject malformed values explicitly."""
    if not isinstance(name, str) or not name or not isinstance(default, int) or isinstance(default, bool):
        raise ValueError("setting name and integer default are required")
    if isinstance(maximum, bool) or not isinstance(maximum, int) or maximum < 1:
        raise ValueError("setting maximum must be a positive integer")
    source = os.environ if environ is None else environ
    raw = source.get(name)
    if raw is None or not str(raw).strip():
        value = default
    else:
        normalized = str(raw).strip()
        if not _INTEGER.fullmatch(normalized):
            raise ValueError(f"{name} must contain only decimal digits")
        value = int(normalized)
    if not 1 <= value <= maximum:
        raise ValueError(f"{name} must be between 1 and {maximum}")
    return value


def youtube_quota_limits(*, quota_limit: int | None = None,
                         search_quota_limit: int | None = None,
                         environ: Mapping[str, str] | None = None) -> tuple[int, int]:
    """Return validated general-unit and search-call daily quota ceilings."""
    source = os.environ if environ is None else environ
    default_quota = 10_000 if quota_limit is None else quota_limit
    default_search = 100 if search_quota_limit is None else search_quota_limit
    general = positive_int_setting("YOUTUBE_DAILY_QUOTA_LIMIT", default_quota,
                                   maximum=1_000_000_000, environ=source)
    search = positive_int_setting("YOUTUBE_SEARCH_DAILY_LIMIT", default_search,
                                  maximum=1_000_000, environ=source)
    return general, search
