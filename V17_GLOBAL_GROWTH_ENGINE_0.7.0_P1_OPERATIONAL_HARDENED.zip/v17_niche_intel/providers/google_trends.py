from __future__ import annotations
from typing import Any
from ..domain.demand import extract_trend_features

class GoogleTrendsProvider:
    """Optional pytrends adapter; values remain geo/timeframe-local relative indices."""
    def __init__(self, client: Any | None = None, *, language_code: str = "en",
                 locale: str | None = None, property: str = "youtube_search", timeout: tuple[int,int]=(5,20)):
        if not language_code.strip(): raise ValueError("language_code must be non-empty")
        if locale is not None and not locale.strip(): raise ValueError("locale must be non-empty when provided")
        if property not in {"youtube_search", "google_web_search"}: raise ValueError("property must be youtube_search or google_web_search")
        locales = {"id": "id-ID", "en": "en-US", "es": "es-ES", "pt": "pt-BR",
                   "fr": "fr-FR", "de": "de-DE", "ja": "ja-JP", "ko": "ko-KR", "zh": "zh-CN"}
        locale = locale or locales.get(language_code.lower(), language_code if "-" in language_code else f"{language_code}-{language_code.upper()}")
        if client is None:
            try: from pytrends.request import TrendReq
            except ImportError as exc: raise RuntimeError("Install trends extra: pip install -e '.[trends]'") from exc
            client=TrendReq(hl=locale, tz=0, timeout=timeout, retries=1, backoff_factor=0.2)
        self.client=client
        self.language_code=language_code
        self.locale=locale
        self.property=property

    def interest_over_time(self, keyword: str, *, geo: str, timeframe: str="today 12-m") -> dict:
        if not keyword.strip() or not timeframe.strip(): raise ValueError("keyword and timeframe are required")
        self.client.build_payload([keyword], cat=0, timeframe=timeframe, geo=geo,
            gprop="youtube" if self.property == "youtube_search" else "")
        frame=self.client.interest_over_time()
        if frame is None or frame.empty: return {"status":"no_data","geo":geo,"timeframe":timeframe,"property":self.property,"points":[]}
        values=[int(x) for x in frame[keyword].tolist()]
        points=[{"date":idx.isoformat(),"value":value} for idx,value in zip(frame.index,values)]
        return {"status":"ok","geo":geo,"timeframe":timeframe,"property":self.property,"points":points,"features":extract_trend_features(values)}
