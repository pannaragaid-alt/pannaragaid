from __future__ import annotations


def build_no_redirect_httplib2(timeout_seconds: int = 20):
    """Create direct TLS-verified httplib2 transport that refuses HTTP redirects."""
    if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, int) or not 1 <= timeout_seconds <= 120:
        raise ValueError("HTTP transport timeout must be between 1 and 120 seconds")
    try:
        import httplib2
    except ImportError as exc:
        raise RuntimeError("Install the YouTube provider extra: pip install -e '.[youtube]'") from exc

    class NoRedirectHttp(httplib2.Http):
        def request(self, uri, method="GET", body=None, headers=None, redirections=0, connection_type=None):
            return super().request(uri, method=method, body=body, headers=headers,
                                   redirections=0, connection_type=connection_type)

    return NoRedirectHttp(timeout=timeout_seconds, proxy_info=None,
                          disable_ssl_certificate_validation=False)
