"""Authenticated Google Cloud Translation adapter with strict egress bounds.

Uses Application Default Credentials and the fixed Google Translation v3 endpoint.
No anonymous scraping or third-party translation package is used.
"""
from __future__ import annotations

import os
import re
from typing import Any

from ..credentials.transport import harden_requests_session
from ..ui.input_safety import parse_bounded_json

_TRANSLATE_SCOPE = "https://www.googleapis.com/auth/cloud-platform"
_TRANSLATE_URL = "https://translation.googleapis.com/v3/projects/{project}/locations/global:translateText"
_MAX_TEXT_CHARS = 5000
_MAX_RESPONSE_BYTES = 1024 * 1024
_LANGUAGE_RE = re.compile(r"[A-Za-z]{2,3}(?:-[A-Za-z0-9]{2,8})*\Z")
_PROJECT_RE = re.compile(r"[a-z][a-z0-9-]{4,28}[a-z0-9]\Z")


class GoogleCloudTranslator:
    """Translate text using Google Cloud Translation API v3 and ADC."""

    def __init__(self, project_id: str, *, session: Any | None = None) -> None:
        if not isinstance(project_id, str) or not _PROJECT_RE.fullmatch(project_id):
            raise ValueError("GOOGLE_CLOUD_PROJECT must be a valid Google Cloud project ID")
        self.project_id = project_id
        if session is None:
            try:
                import google.auth
                from google.auth.transport.requests import AuthorizedSession
            except ImportError as exc:
                raise RuntimeError("Install translation support: pip install -e '.[translation]'") from exc
            credentials, _ = google.auth.default(scopes=[_TRANSLATE_SCOPE])
            session = AuthorizedSession(credentials)
        self.session = harden_requests_session(session)

    @classmethod
    def from_environment(cls, *, session: Any | None = None) -> "GoogleCloudTranslator":
        project_id = os.getenv("GOOGLE_CLOUD_PROJECT") or os.getenv("GCLOUD_PROJECT")
        if not project_id:
            raise RuntimeError("Set GOOGLE_CLOUD_PROJECT and configure Google Application Default Credentials")
        return cls(project_id, session=session)

    def translate(self, text: str, target_language: str) -> str:
        if not isinstance(text, str) or not text.strip() or len(text) > _MAX_TEXT_CHARS:
            raise ValueError("translation text must contain 1-5000 characters")
        if not isinstance(target_language, str) or not _LANGUAGE_RE.fullmatch(target_language):
            raise ValueError("target language must be a valid BCP-47 language code")

        url = _TRANSLATE_URL.format(project=self.project_id)
        try:
            response = self.session.post(
                url,
                json={
                    "contents": [text],
                    "mimeType": "text/plain",
                    "targetLanguageCode": target_language,
                },
                timeout=(3, 15),
                allow_redirects=False,
                stream=True,
            )
        except Exception:
            raise RuntimeError("Google Cloud Translation request failed") from None

        try:
            status = getattr(response, "status_code", None)
            if isinstance(status, bool) or not isinstance(status, int):
                raise RuntimeError("Google Cloud Translation returned an invalid response")
            if 300 <= status < 400:
                raise RuntimeError("Google Cloud Translation redirect refused")
            if status < 200 or status >= 300:
                raise RuntimeError(f"Google Cloud Translation returned HTTP {status}")

            headers = getattr(response, "headers", {})
            content_type = str(headers.get("Content-Type", "")).lower()
            if "application/json" not in content_type:
                raise RuntimeError("Google Cloud Translation returned an unexpected content type")
            raw = bytearray()
            try:
                for chunk in response.iter_content(chunk_size=65536):
                    if not isinstance(chunk, bytes):
                        raise ValueError("non-byte response chunk")
                    raw.extend(chunk)
                    if len(raw) > _MAX_RESPONSE_BYTES:
                        raise RuntimeError("Google Cloud Translation response exceeded the size limit")
                if not raw:
                    raise RuntimeError("Google Cloud Translation response was empty")
                payload = parse_bounded_json(bytes(raw).decode("utf-8", errors="strict"),
                                             max_bytes=_MAX_RESPONSE_BYTES, max_depth=16)
                translations = payload.get("translations")
                translated = translations[0].get("translatedText") if isinstance(translations, list) and translations else None
            except RuntimeError:
                raise
            except (UnicodeDecodeError, ValueError, AttributeError, TypeError, IndexError) as exc:
                raise RuntimeError("Google Cloud Translation returned an invalid response") from exc
            if not isinstance(translated, str) or not translated.strip() or len(translated) > _MAX_TEXT_CHARS * 8:
                raise RuntimeError("Google Cloud Translation returned an invalid response")
            return translated
        finally:
            close = getattr(response, "close", None)
            if callable(close):
                close()


def translate_text(text: str, target_language: str) -> str:
    """Convenience entry point used by CLI and dashboard integrations."""
    return GoogleCloudTranslator.from_environment().translate(text, target_language)
