"""Local-file-only thumbnail and audio measurement helpers.

No video/audio is downloaded from YouTube. Supply files you own or are authorized
 to analyze. Metrics are descriptive and are not proxies for CTR or audience retention.
"""
from __future__ import annotations

from pathlib import Path

MAX_MEDIA_BYTES = 100 * 1024 * 1024
MAX_AUDIO_SECONDS = 600
MAX_IMAGE_PIXELS = 40_000_000
MAX_AUDIO_SAMPLES = 40_000_000
_ALLOWED_IMAGE_FORMATS = {"JPEG", "PNG", "WEBP"}


def measure_thumbnail_file(path: str | Path) -> dict:
    try:
        from PIL import Image, ImageStat
    except ImportError as exc:
        raise RuntimeError("Install media extras: pip install -e '.[media]'") from exc
    target = Path(path)
    if not target.is_file() or target.stat().st_size > MAX_MEDIA_BYTES:
        raise ValueError("thumbnail file is missing or exceeds 100 MiB")
    with Image.open(target) as image:
        width, height = image.size
        if image.format not in _ALLOWED_IMAGE_FORMATS:
            raise ValueError("thumbnail image format is not supported")
        if width <= 0 or height <= 0 or width * height > MAX_IMAGE_PIXELS:
            raise ValueError("thumbnail exceeds the configured pixel limit")
        image.verify()
    with Image.open(target) as image:
        width, height = image.size
        if width <= 0 or height <= 0 or width * height > MAX_IMAGE_PIXELS:
            raise ValueError("thumbnail exceeds the configured pixel limit")
        rgb = image.convert("RGB")
        stats = ImageStat.Stat(rgb)
        width, height = rgb.size
        if width <= 0 or height <= 0:
            raise ValueError("invalid image dimensions")
        return {"width": width, "height": height, "aspect_ratio": round(width / height, 4),
                "mean_rgb": [round(value, 3) for value in stats.mean],
                "channel_stddev": [round(value, 3) for value in stats.stddev],
                "mean_brightness": round(sum(stats.mean) / 3, 3),
                "contrast_proxy": round(sum(stats.stddev) / 3, 3),
                "file_bytes": target.stat().st_size,
                "measurement": "Pillow RGB channel statistics; no face, OCR, or CTR inference"}


def measure_audio_file(path: str | Path) -> dict:
    try:
        import numpy as np
        import soundfile as sf
    except ImportError as exc:
        raise RuntimeError("Install media extras: pip install -e '.[media]'") from exc
    target = Path(path)
    if not target.is_file() or target.stat().st_size > MAX_MEDIA_BYTES:
        raise ValueError("audio file is missing or exceeds 100 MiB")
    info = sf.info(str(target))
    if info.channels > 8 or info.samplerate > 192000 or info.duration > MAX_AUDIO_SECONDS:
        raise ValueError("audio exceeds supported channel, sample-rate, or duration limits")
    if info.frames < 0 or info.frames * info.channels > MAX_AUDIO_SAMPLES:
        raise ValueError("audio exceeds the configured decoded sample-count limit")
    samples, sample_rate = sf.read(str(target), dtype="float32", always_2d=True)
    if samples.size == 0 or not np.isfinite(samples).all():
        raise ValueError("audio contains no samples or non-finite values")
    peak = float(np.max(np.abs(samples)))
    rms = float(np.sqrt(np.mean(np.square(samples))))
    silence_threshold = 10 ** (-60 / 20)
    return {"sample_rate_hz": int(sample_rate), "channels": int(samples.shape[1]),
            "duration_seconds": round(len(samples) / sample_rate, 4),
            "sample_peak_dbfs": round(20 * np.log10(max(peak, 1e-12)), 3),
            "rms_dbfs": round(20 * np.log10(max(rms, 1e-12)), 3),
            "clipping_ratio": round(float(np.mean(np.abs(samples) >= 0.999)), 6),
            "silence_ratio": round(float(np.mean(np.abs(samples) < silence_threshold)), 6),
            "measurement": "sample peak/RMS/clipping/silence; not LUFS, true peak, or SNR"}
