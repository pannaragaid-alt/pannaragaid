"""Public web SERP sampling through Firecrawl Search API (no browser/session state)."""
from __future__ import annotations

import json
import re
import ssl
from datetime import datetime, timezone
from ipaddress import ip_address
from typing import Any
from urllib.parse import urlsplit
import urllib.error
import urllib.request

from .text_safety import redact_basic_pii
from ..ui.input_safety import parse_bounded_json

_MAX_PROVIDER_RESPONSE_BYTES = 10 * 1024 * 1024
_MAX_QUERY_CHARS = 512
_MAX_LOCATION_CHARS = 256
_HOST_LABEL = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")


def _safe_result_url(value: Any) -> str | None:
    if not isinstance(value, str) or not value or len(value) > 4096:
        return None
    if any(ord(char) < 0x20 or char.isspace() for char in value) or "\\" in value or "#" in value:
        return None
    try:
        parsed = urlsplit(value)
        port = parsed.port
        host = parsed.hostname
    except ValueError:
        return None
    if parsed.scheme.lower() != "https" or not host or "@" in parsed.netloc or port not in (None, 443):
        return None
    if host.endswith(".") or host.endswith((".localhost", ".local", ".internal", ".test", ".invalid", ".example", ".onion", ".arpa")):
        return None
    try:
        ip_address(host)
        return None
    except ValueError:
        pass
    try:
        ascii_host = host.encode("idna").decode("ascii").lower()
    except UnicodeError:
        return None
    labels = ascii_host.split(".")
    if len(labels) < 2 or len(ascii_host) > 253 or any(not _HOST_LABEL.fullmatch(label) for label in labels):
        return None
    return value


class _NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    """Credentialed API calls must never forward Authorization across redirects."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _open_firecrawl_request(request: urllib.request.Request, timeout_seconds: int):
    # Ignore HTTP(S)_PROXY environment variables for requests carrying the API key.
    opener = urllib.request.build_opener(
        urllib.request.ProxyHandler({}),
        _NoRedirectHandler(),
        urllib.request.HTTPSHandler(context=ssl.create_default_context()),
    )
    return opener.open(request, timeout=timeout_seconds)


class FirecrawlSearchProvider:
    def __init__(self, api_key: str, *, timeout_seconds: int = 30):
        if not isinstance(api_key, str):
            raise ValueError("Firecrawl API key must be a non-empty visible ASCII token")
        normalized_key = api_key.strip()
        if not normalized_key or len(normalized_key) > 512 or any(ord(char) < 0x21 or ord(char) > 0x7e for char in normalized_key):
            raise ValueError("Firecrawl API key must be a non-empty visible ASCII token")
        if isinstance(timeout_seconds, bool) or not isinstance(timeout_seconds, int) or not 1 <= timeout_seconds <= 120:
            raise ValueError("timeout_seconds must be between 1 and 120")
        self.api_key = normalized_key
        self.timeout_seconds = timeout_seconds

    def search(self, keyword: str, *, country: str = "US", location: str | None = None,
               limit: int = 5) -> dict[str, Any]:
        if not isinstance(keyword, str) or not keyword.strip() or any(ord(char) < 0x20 for char in keyword):
            raise ValueError("keyword must be non-empty and contain no control characters")
        if len(keyword) > _MAX_QUERY_CHARS:
            raise ValueError("keyword exceeds the configured length limit")
        if location is not None:
            if not isinstance(location, str) or any(ord(char) < 0x20 for char in location):
                raise ValueError("location must contain no control characters")
            if len(location) > _MAX_LOCATION_CHARS:
                raise ValueError("location exceeds the configured length limit")
        if not isinstance(country, str) or not re.fullmatch(r"[A-Za-z]{2}", country):
            raise ValueError("country must be a two-letter ISO code")
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 10:
            raise ValueError("SERP sample limit must be an integer between 1 and 10")
        # SERP-only: deliberately omit scrapeOptions so Firecrawl never fetches result URLs
        # on V17's behalf outside the locally enforced egress policy.
        payload = {"query": keyword, "limit": limit, "sources": [{"type": "web"}],
            "country": country.upper(), "safe": True, "timeout": self.timeout_seconds * 1000}
        if location: payload["location"] = location
        request = urllib.request.Request("https://api.firecrawl.dev/v2/search",
            data=json.dumps(payload).encode("utf-8"),
            headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
            method="POST")
        try:
            with _open_firecrawl_request(request, self.timeout_seconds) as response:
                raw = response.read(_MAX_PROVIDER_RESPONSE_BYTES + 1)
                if len(raw) > _MAX_PROVIDER_RESPONSE_BYTES:
                    raise RuntimeError("Firecrawl Search response exceeds the configured size limit")
                result = parse_bounded_json(raw.decode("utf-8"), max_bytes=_MAX_PROVIDER_RESPONSE_BYTES, max_depth=64)
        except urllib.error.HTTPError as exc:
            # Includes redirects: never follow a redirect from a credentialed API request.
            raise RuntimeError(f"Firecrawl Search returned HTTP {exc.code}") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            raise RuntimeError("Firecrawl Search request failed") from exc
        data = result.get("data", result) if isinstance(result, dict) else {}
        items = data.get("web", data.get("results", [])) if isinstance(data, dict) else []
        normalized = []
        if not isinstance(items, list):
            items = []
        for item in items[:limit]:
            if not isinstance(item, dict):
                continue
            url = _safe_result_url(item.get("url"))
            if not url:
                continue
            normalized.append({"url": url, "title": redact_basic_pii(str(item.get("title") or "")[:500]),
                "description": redact_basic_pii(str(item.get("description") or item.get("snippet") or "")[:2000])})
        return {"status": "ok" if normalized else "no_data", "keyword": keyword,
            "country": country.upper(), "location": location, "results": normalized,
            "observed_at": datetime.now(timezone.utc).isoformat(),
            "source": "firecrawl_search", "cache_policy": "provider_managed",
            "client_network_proxy": "disabled", "pii_redaction": "email_phone_heuristic"}
