from __future__ import annotations

import re

_EMAIL = re.compile(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", re.I)
_PHONE = re.compile(r"(?<![A-Z0-9])(?:\+?\d[\d\s().-]{7,}\d)(?!\d)", re.I)


def redact_basic_pii(text: str) -> str:
    """Heuristically mask email and phone-like strings; this is not comprehensive PII detection."""
    if not isinstance(text, str):
        return ""
    return _PHONE.sub("[PHONE]", _EMAIL.sub("[EMAIL]", text))
