from __future__ import annotations

import http.client
import re
import socket
import ssl
from dataclasses import dataclass
from html.parser import HTMLParser
from ipaddress import ip_address, ip_network
from typing import Any, Iterable
from urllib.parse import urljoin, urlsplit

from .text_safety import redact_basic_pii


class ScrapePolicyError(ValueError):
    """Raised when a target violates the explicit public-source egress policy."""


_MAX_TARGET_RESPONSE_BYTES = 5 * 1024 * 1024
_MAX_REDIRECTS = 3
_DEFAULT_TIMEOUT_SECONDS = 15
_ALLOWED_CONTENT_TYPES = {"text/html", "application/xhtml+xml", "text/plain"}
_HOST_LABEL = re.compile(r"^[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$")


@dataclass(frozen=True, slots=True)
class ScrapeResult:
    url: str
    markdown: str
    status_code: int | None
    metadata: dict[str, Any]


def _normalize_hostname(host: str) -> str:
    if not isinstance(host, str) or not host or host.endswith(".") or "%" in host:
        raise ScrapePolicyError("Hostname is not a canonical DNS name")
    try:
        ip_address(host)
    except ValueError:
        pass
    else:
        raise ScrapePolicyError("IP-literal targets are not allowed")
    try:
        ascii_host = host.encode("idna").decode("ascii").lower()
    except UnicodeError as exc:
        raise ScrapePolicyError("Hostname IDNA normalization failed") from exc
    if len(ascii_host) > 253:
        raise ScrapePolicyError("Hostname exceeds DNS length limits")
    labels = ascii_host.split(".")
    if len(labels) < 2 or any(not _HOST_LABEL.fullmatch(label) for label in labels):
        raise ScrapePolicyError("A fully-qualified canonical hostname is required")
    if ascii_host.endswith((".localhost", ".local", ".internal", ".test", ".invalid", ".example", ".onion", ".home.arpa", ".arpa")):
        raise ScrapePolicyError("Internal, special-use, and non-public DNS suffixes are not allowed")
    return ascii_host


def parse_allowed_hosts(value: str | Iterable[str] | None) -> frozenset[str]:
    """Parse an exact-host allowlist. Wildcards and suffix matching are intentionally unsupported."""
    if value is None:
        raw_hosts: list[str] = []
    elif isinstance(value, str):
        raw_hosts = [part.strip() for part in value.split(",") if part.strip()]
    else:
        raw_hosts = [str(part).strip() for part in value if str(part).strip()]
    if not raw_hosts:
        raise ScrapePolicyError("An explicit owner-approved hostname allowlist is required")
    normalized: set[str] = set()
    for host in raw_hosts:
        if "*" in host or "/" in host or ":" in host or "@" in host:
            raise ScrapePolicyError("Allowlist entries must be exact hostnames; wildcards are not supported")
        normalized.add(_normalize_hostname(host))
    return frozenset(normalized)


def parse_allowed_paths(value: str | None, allowed_hosts: frozenset[str]) -> dict[str, tuple[str, ...]]:
    """Parse host-bound path prefixes: host=/path|/other;other.example=/docs."""
    if not isinstance(value, str) or not value.strip():
        raise ScrapePolicyError("An explicit owner-approved path-prefix policy is required")
    policies: dict[str, tuple[str, ...]] = {}
    for entry in value.split(";"):
        if not entry.strip() or "=" not in entry:
            raise ScrapePolicyError("Path policy entries must use hostname=/path-prefix syntax")
        raw_host, raw_prefixes = entry.split("=", 1)
        host = _normalize_hostname(raw_host.strip())
        if host not in allowed_hosts or host in policies:
            raise ScrapePolicyError("Path policy host must appear once in the hostname allowlist")
        prefixes = []
        for raw_prefix in raw_prefixes.split("|"):
            prefix = raw_prefix.strip()
            if (not prefix.startswith("/") or not prefix.isascii() or "%" in prefix
                    or "\\" in prefix or "?" in prefix or "#" in prefix
                    or "*" in prefix or "//" in prefix or any(ord(ch) < 0x21 for ch in prefix)):
                raise ScrapePolicyError("Path prefixes must be canonical absolute paths without encoding or wildcards")
            segments = prefix.split("/")
            if any(segment in {".", ".."} for segment in segments):
                raise ScrapePolicyError("Dot-segment path prefixes are not allowed")
            normalized = prefix.rstrip("/") or "/"
            if normalized not in prefixes:
                prefixes.append(normalized)
        if not prefixes:
            raise ScrapePolicyError("Each allowlisted hostname requires at least one path prefix")
        policies[host] = tuple(prefixes)
    if set(policies) != set(allowed_hosts):
        raise ScrapePolicyError("Every allowlisted hostname must have an explicit path-prefix policy")
    return policies


def _validate_target_url(url: str, allowed_hosts: frozenset[str],
                         allowed_paths: dict[str, tuple[str, ...]]) -> tuple[Any, str]:
    if not isinstance(url, str) or not url or len(url) > 4096:
        raise ScrapePolicyError("Target URL is empty or exceeds the maximum length")
    if any(ord(char) < 0x20 or char.isspace() for char in url) or "\\" in url or "#" in url:
        raise ScrapePolicyError("Target URL contains invalid characters")
    try:
        parsed = urlsplit(url)
        port = parsed.port
        host = parsed.hostname
    except ValueError as exc:
        raise ScrapePolicyError("Target URL is malformed") from exc
    if parsed.scheme.lower() != "https" or not host or "@" in parsed.netloc:
        raise ScrapePolicyError("Only credential-free public HTTPS URLs are allowed")
    if port not in (None, 443):
        raise ScrapePolicyError("Only the standard HTTPS port is allowed")
    if parsed.fragment:
        raise ScrapePolicyError("URL fragments are not accepted")
    canonical_host = _normalize_hostname(host)
    if canonical_host not in allowed_hosts:
        raise ScrapePolicyError("Target hostname is not present in the owner-approved allowlist")
    path = parsed.path or "/"
    if not path.isascii() or "%" in path or "\\" in path or "//" in path:
        raise ScrapePolicyError("Target path is not canonical or contains encoded separators")
    if any(segment in {".", ".."} for segment in path.split("/")):
        raise ScrapePolicyError("Dot-segment target paths are not allowed")
    allowed_prefixes = allowed_paths.get(canonical_host, ())
    if not any(prefix == "/" or path == prefix or path.startswith(prefix + "/") for prefix in allowed_prefixes):
        raise ScrapePolicyError("Target path is not present in the owner-approved path policy")
    return parsed, canonical_host


def _is_public_routable_address(address: Any) -> bool:
    # Reject special-purpose ranges even where a Python release marks an anycast/special
    # address as is_global. IPv6 transition/translation forms are excluded to prevent
    # embedding a non-public IPv4 destination inside an apparently global IPv6 address.
    if not address.is_global or address.is_reserved or address.is_multicast or address.is_unspecified:
        return False
    if address.version == 4:
        return address not in ip_network("192.0.0.0/24")
    if address.version == 6:
        if address not in ip_network("2000::/3"):
            return False
        if address in ip_network("2001::/23"):
            return False
        if address.ipv4_mapped is not None or address.sixtofour is not None or address.teredo is not None:
            return False
        return True
    return False


def _resolve_public_addresses(host: str) -> tuple[str, ...]:
    try:
        records = socket.getaddrinfo(host, 443, family=socket.AF_UNSPEC, type=socket.SOCK_STREAM)
    except OSError as exc:
        raise ScrapePolicyError("Target DNS resolution failed") from exc
    if not records:
        raise ScrapePolicyError("Target DNS returned no addresses")
    addresses: set[str] = set()
    for record in records:
        raw_address = record[4][0]
        try:
            parsed_ip = ip_address(raw_address.split("%", 1)[0])
        except ValueError as exc:
            raise ScrapePolicyError("DNS returned an invalid IP address") from exc
        if not _is_public_routable_address(parsed_ip):
            raise ScrapePolicyError("DNS resolved to a non-public or special-purpose address")
        addresses.add(str(parsed_ip))
    return tuple(sorted(addresses))


class _PinnedHTTPSConnection(http.client.HTTPSConnection):
    """HTTPS connection that pins TCP to a previously validated IP while preserving TLS SNI."""

    def __init__(self, host: str, pinned_ip: str, timeout: int):
        super().__init__(host, port=443, timeout=timeout, context=ssl.create_default_context())
        self._pinned_ip = pinned_ip

    def connect(self) -> None:
        raw_socket = socket.create_connection((self._pinned_ip, self.port), self.timeout, self.source_address)
        try:
            self.sock = self._context.wrap_socket(raw_socket, server_hostname=self.host)
        except BaseException:
            raw_socket.close()
            raise


class _VisibleTextExtractor(HTMLParser):
    _IGNORED = {"script", "style", "svg", "noscript", "template"}

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self._ignored_depth = 0
        self.parts: list[str] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self._IGNORED:
            self._ignored_depth += 1
        elif not self._ignored_depth and tag in {"p", "div", "br", "li", "h1", "h2", "h3", "h4", "tr"}:
            self.parts.append("\n")

    def handle_endtag(self, tag: str) -> None:
        if tag in self._IGNORED and self._ignored_depth:
            self._ignored_depth -= 1
        elif not self._ignored_depth and tag in {"p", "div", "li", "h1", "h2", "h3", "h4", "tr"}:
            self.parts.append("\n")

    def handle_data(self, data: str) -> None:
        if not self._ignored_depth and data.strip():
            self.parts.append(data.strip())

    def text(self) -> str:
        lines = [" ".join(part.split()) for part in self.parts]
        return "\n".join(line for line in lines if line).strip()


class DirectHTTPSFetcher:
    """Small public-page fetcher with exact allowlist, DNS pinning, redirect checks and hard limits."""

    def __init__(self, allowed_hosts: str | Iterable[str], *, allowed_paths: str | None,
                 timeout_seconds: int = _DEFAULT_TIMEOUT_SECONDS):
        if timeout_seconds <= 0 or timeout_seconds > 60:
            raise ValueError("timeout_seconds must be between 1 and 60")
        self.allowed_hosts = parse_allowed_hosts(allowed_hosts)
        self.allowed_paths = parse_allowed_paths(allowed_paths, self.allowed_hosts)
        self.timeout_seconds = timeout_seconds

    def _request_once(self, host: str, pinned_ip: str, path: str) -> tuple[int, Any, bytes]:
        connection = _PinnedHTTPSConnection(host, pinned_ip, self.timeout_seconds)
        try:
            connection.request("GET", path, headers={
                "Host": host,
                "User-Agent": "V17-PublicResearch/1.0 (+owner-authorized-public-page-fetch)",
                "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9",
                "Accept-Encoding": "identity",
                "Connection": "close",
            })
            response = connection.getresponse()
            status = response.status
            headers = response.headers
            if status in {301, 302, 303, 307, 308}:
                return status, headers, b""
            if status != 200:
                raise RuntimeError(f"Target returned HTTP {status}")
            content_type = (headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
            if content_type not in _ALLOWED_CONTENT_TYPES:
                raise RuntimeError("Target content type is not allowed")
            encoding = (headers.get("Content-Encoding") or "identity").strip().lower()
            if encoding not in {"", "identity"}:
                raise RuntimeError("Compressed target responses are not accepted")
            raw_length = headers.get("Content-Length")
            if raw_length is not None:
                try:
                    if int(raw_length) < 0 or int(raw_length) > _MAX_TARGET_RESPONSE_BYTES:
                        raise RuntimeError("Target response exceeds the configured size limit")
                except ValueError as exc:
                    raise RuntimeError("Target returned an invalid Content-Length") from exc
            body = response.read(_MAX_TARGET_RESPONSE_BYTES + 1)
            if len(body) > _MAX_TARGET_RESPONSE_BYTES:
                raise RuntimeError("Target response exceeds the configured size limit")
            return status, headers, body
        finally:
            connection.close()

    def scrape(self, url: str) -> dict[str, Any]:
        current_url = url
        redirects = 0
        resolved_ip = ""
        while True:
            parsed, host = _validate_target_url(current_url, self.allowed_hosts, self.allowed_paths)
            addresses = _resolve_public_addresses(host)
            # One selected, validated address is pinned for this request; no second DNS lookup occurs in connect().
            resolved_ip = addresses[0]
            path = parsed.path or "/"
            if parsed.query:
                path += "?" + parsed.query
            status, headers, body = self._request_once(host, resolved_ip, path)
            if status in {301, 302, 303, 307, 308}:
                if redirects >= _MAX_REDIRECTS:
                    raise RuntimeError("Target exceeded the redirect limit")
                location = headers.get("Location")
                if not location:
                    raise RuntimeError("Target redirect omitted Location")
                current_url = urljoin(current_url, location)
                redirects += 1
                continue
            content_type = (headers.get("Content-Type") or "").split(";", 1)[0].strip().lower()
            if content_type == "text/html" or content_type == "application/xhtml+xml":
                charset = "utf-8"
                content_type_header = headers.get("Content-Type") or ""
                match = re.search(r"charset\s*=\s*['\"]?([a-zA-Z0-9._-]+)", content_type_header, re.I)
                if match:
                    charset = match.group(1)
                decoded = body.decode(charset, errors="replace")
                parser = _VisibleTextExtractor()
                parser.feed(decoded)
                markdown = parser.text()
            else:
                markdown = body.decode("utf-8", errors="replace")
            markdown = redact_basic_pii(markdown)
            return {
                "url": current_url,
                "markdown": markdown,
                "metadata": {
                    "statusCode": 200,
                    "fetcher": "v17_direct_https_pinned",
                    "resolvedPublicIp": resolved_ip,
                    "redirectCount": redirects,
                    "responseBytes": len(body),
                    "contentType": content_type,
                    "cookiesUsed": False,
                    "browserProfileUsed": False,
                    "cacheUsed": False,
                    "piiRedaction": "email_phone_heuristic",
                },
            }


class IncognitoScraper:
    """Owner-allowlisted public fetch; no cookies, browser profile, or authenticated session."""

    def __init__(self, client: DirectHTTPSFetcher, *, allowed_hosts: str | Iterable[str], allowed_paths: str | None):
        if type(client) is not DirectHTTPSFetcher:
            raise TypeError("IncognitoScraper accepts only the built-in DirectHTTPSFetcher")
        self.client = client
        self.allowed_hosts = parse_allowed_hosts(allowed_hosts)
        self.allowed_paths = parse_allowed_paths(allowed_paths, self.allowed_hosts)
        if client.allowed_hosts != self.allowed_hosts or client.allowed_paths != self.allowed_paths:
            raise ScrapePolicyError("IncognitoScraper and fetcher egress policies must match exactly")

    def scrape(self, url: str) -> ScrapeResult:
        _validate_target_url(url, self.allowed_hosts, self.allowed_paths)
        payload = self.client.scrape(url)
        if not isinstance(payload, dict):
            raise RuntimeError("Scraper returned an unsupported response")
        metadata = payload.get("metadata") or {}
        return ScrapeResult(payload.get("url", url), payload.get("markdown") or "",
                            metadata.get("statusCode"), metadata)


class FirecrawlHTTPClient:
    """Retained for explicit compatibility; hosted target fetching is fail-closed by design."""

    def __init__(self, api_key: str, *, timeout_seconds: int = 45, base_url: str = "https://api.firecrawl.dev"):
        normalized_key = api_key.strip()
        if not normalized_key or any(ord(char) < 0x21 or ord(char) > 0x7e for char in normalized_key):
            raise ValueError("Firecrawl API key must be a non-empty visible ASCII token")
        if timeout_seconds <= 0 or timeout_seconds > 120:
            raise ValueError("timeout_seconds must be between 1 and 120")
        try:
            parsed = urlsplit(base_url)
            valid_origin = (
                parsed.scheme == "https" and parsed.hostname is not None
                and parsed.hostname.lower() == "api.firecrawl.dev" and parsed.port in (None, 443)
                and parsed.username is None and parsed.password is None
                and parsed.path in ("", "/") and not parsed.query and not parsed.fragment
            )
        except ValueError:
            valid_origin = False
        if not valid_origin:
            raise ValueError("base_url must be the official HTTPS API origin")
        # Validate caller configuration, but do not retain the secret: this compatibility
        # adapter intentionally performs no hosted target-fetch request.
        self.timeout_seconds = timeout_seconds

    def scrape(self, url: str, **privacy_options: Any) -> dict[str, Any]:
        raise ScrapePolicyError(
            "Hosted target fetching is disabled: fetch-time DNS and redirect enforcement cannot be proven client-side; "
            "use DirectHTTPSFetcher with an owner-approved hostname allowlist"
        )
