from __future__ import annotations
import json
import re
import secrets
import time
from dataclasses import dataclass
from .transport import harden_requests_session
from urllib.parse import urlparse, parse_qs

ANALYTICS_READONLY_SCOPE = "https://www.googleapis.com/auth/yt-analytics.readonly"
ANALYTICS_MONETARY_READONLY_SCOPE = "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"
YOUTUBE_READONLY_SCOPE = "https://www.googleapis.com/auth/youtube.readonly"
_ALLOWED_AUTH_URIS = {"https://accounts.google.com/o/oauth2/auth", "https://accounts.google.com/o/oauth2/v2/auth"}
_ALLOWED_TOKEN_URI = "https://oauth2.googleapis.com/token"
_ALLOWED_CERT_URI = "https://www.googleapis.com/oauth2/v1/certs"
_CLIENT_ID = re.compile(r"^[A-Za-z0-9_-]+\.apps\.googleusercontent\.com$")


def _validate_google_client_config(client_config: dict) -> tuple[str, dict]:
    if not isinstance(client_config, dict) or len(client_config) > 8:
        raise ValueError("Google OAuth client config must be a bounded JSON object")
    try:
        encoded = json.dumps(client_config, separators=(",", ":"), ensure_ascii=True)
    except (TypeError, ValueError) as exc:
        raise ValueError("Google OAuth client config must be JSON-serializable") from exc
    if len(encoded.encode("utf-8")) > 16 * 1024:
        raise ValueError("Google OAuth client config exceeds 16 KiB")
    if len(client_config) != 1 or not set(client_config).issubset({"installed", "web"}):
        raise ValueError("Google OAuth client config must contain exactly one installed or web client")
    client_type = next(iter(client_config))
    block = client_config[client_type]
    if not isinstance(block, dict):
        raise ValueError("Google OAuth client config block must be an object")
    client_id = block.get("client_id")
    client_secret = block.get("client_secret")
    if not isinstance(client_id, str) or not _CLIENT_ID.fullmatch(client_id):
        raise ValueError("Google OAuth client_id is invalid")
    if (not isinstance(client_secret, str) or not client_secret or len(client_secret) > 1024
            or any(ord(ch) < 0x20 for ch in client_secret)):
        raise ValueError("Google OAuth client_secret is invalid")
    if block.get("auth_uri") not in _ALLOWED_AUTH_URIS or block.get("token_uri") != _ALLOWED_TOKEN_URI:
        raise ValueError("Google OAuth endpoint must use the official Google authorization and token endpoints")
    if block.get("auth_provider_x509_cert_url", _ALLOWED_CERT_URI) != _ALLOWED_CERT_URI:
        raise ValueError("Google OAuth certificate endpoint must use the official Google endpoint")
    redirect_uris = block.get("redirect_uris")
    if not isinstance(redirect_uris, list) or not 1 <= len(redirect_uris) <= 10:
        raise ValueError("Google OAuth redirect_uris must be a bounded non-empty list")
    for uri in redirect_uris:
        if not isinstance(uri, str) or len(uri) > 2048:
            raise ValueError("Google OAuth registered redirect URI is invalid")
        try:
            parsed = urlparse(uri)
            _ = parsed.port
        except ValueError as exc:
            raise ValueError("Google OAuth registered redirect URI is malformed") from exc
        if (not parsed.hostname or "@" in parsed.netloc or parsed.username is not None or parsed.password is not None
                or parsed.query or parsed.fragment or "#" in uri
                or any(ord(ch) < 0x20 or ch.isspace() for ch in uri)):
            raise ValueError("Google OAuth registered redirect URI contains forbidden components")
        if client_type == "installed":
            if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost"}:
                raise ValueError("Installed Google OAuth registered redirect URIs must be loopback HTTP")
        elif parsed.scheme != "https":
            raise ValueError("Web Google OAuth registered redirect URIs must use HTTPS")
    return client_type, json.loads(encoded)


@dataclass(frozen=True, slots=True)
class OAuthAuthorization:
    authorization_url: str
    state: str
    redirect_uri: str


class GoogleOAuthConsentFlow:
    """Single-use state + PKCE OAuth flow; caller must bind callback to the same local session."""
    def __init__(self, client_config: dict, *, redirect_uri: str="http://127.0.0.1:8765/oauth2/callback"):
        client_type, safe_client_config = _validate_google_client_config(client_config)
        if not isinstance(redirect_uri, str) or not redirect_uri or len(redirect_uri) > 2048:
            raise ValueError("OAuth redirect URI must be a bounded absolute URL")
        try:
            parsed = urlparse(redirect_uri)
            _ = parsed.port
        except ValueError as exc:
            raise ValueError("OAuth redirect URI is malformed") from exc
        if (not parsed.hostname or not parsed.path.startswith("/") or "@" in parsed.netloc
                or parsed.username is not None or parsed.password is not None
                or parsed.query or "#" in redirect_uri or any(ord(ch) < 0x20 or ch.isspace() for ch in redirect_uri)):
            raise ValueError("OAuth redirect URI contains a forbidden component")
        if client_type == "installed":
            registered_hosts = {urlparse(uri).hostname for uri in safe_client_config["installed"]["redirect_uris"]}
            if parsed.scheme != "http" or parsed.hostname not in {"127.0.0.1", "localhost"} or parsed.hostname not in registered_hosts:
                raise ValueError("Installed Google OAuth redirect URI must use a registered loopback host")
        elif parsed.scheme != "https" or redirect_uri not in safe_client_config["web"]["redirect_uris"]:
            raise ValueError("Web Google OAuth redirect URI must exactly match a registered HTTPS redirect")
        self.client_config=safe_client_config; self.redirect_uri=redirect_uri; self._pending={}

    def begin(self, *, scopes: tuple[str,...]=(ANALYTICS_READONLY_SCOPE,)) -> OAuthAuthorization:
        allowed = {ANALYTICS_READONLY_SCOPE, ANALYTICS_MONETARY_READONLY_SCOPE, YOUTUBE_READONLY_SCOPE}
        if not scopes or not set(scopes).issubset(allowed):
            raise ValueError("Only approved read-only YouTube and Analytics OAuth scopes are allowed")
        now = time.monotonic()
        self._pending = {key: value for key, value in self._pending.items() if value[3] > now}
        if len(self._pending) >= 10:
            raise RuntimeError("Too many pending OAuth consent attempts; complete or restart an existing flow")
        try: from google_auth_oauthlib.flow import Flow
        except ImportError as exc: raise RuntimeError("Install OAuth extra: pip install -e '.[oauth]'") from exc
        verifier=secrets.token_urlsafe(64); state=secrets.token_urlsafe(32)
        flow=Flow.from_client_config(self.client_config, scopes=list(scopes), state=state,
                                     redirect_uri=self.redirect_uri, code_verifier=verifier)
        oauth_session = getattr(flow, "oauth2session", None)
        if oauth_session is None:
            raise RuntimeError("Google OAuth library did not expose its transport session; refusing an unbounded token exchange")
        harden_requests_session(oauth_session)
        url,_=flow.authorization_url(access_type="offline", prompt="consent", include_granted_scopes="false")
        self._pending[state]=(flow,verifier,frozenset(scopes),time.monotonic()+600)
        return OAuthAuthorization(url,state,self.redirect_uri)

    def complete(self, *, state: str, authorization_response: str):
        pending=self._pending.pop(state,None)
        if pending is None: raise ValueError("OAuth state is missing, expired, or already used")
        flow,_,scopes,expires_at=pending
        if time.monotonic() > expires_at:
            raise ValueError("OAuth state has expired; start a new consent flow")
        if (not isinstance(authorization_response, str) or len(authorization_response) > 4096
                or "#" in authorization_response or any(ord(ch) < 0x20 or ch.isspace() for ch in authorization_response)):
            raise ValueError("OAuth callback URL is invalid or exceeds the length limit")
        try:
            callback = urlparse(authorization_response)
            callback_port = callback.port
        except ValueError as exc:
            raise ValueError("OAuth callback URL is malformed") from exc
        expected = urlparse(self.redirect_uri)
        if (callback.scheme, callback.hostname, callback_port, callback.path) != (expected.scheme, expected.hostname, expected.port, expected.path):
            raise ValueError("OAuth callback redirect URI does not match the registered redirect URI")
        if "@" in callback.netloc or callback.username is not None or callback.password is not None or callback.fragment:
            raise ValueError("OAuth callback URL contains forbidden components")
        params = parse_qs(callback.query, keep_blank_values=True)
        if len(params.get("state", [])) != 1:
            raise ValueError("OAuth callback must contain exactly one state parameter")
        callback_state=params["state"][0]
        if callback_state != state: raise ValueError("OAuth callback state mismatch")
        if params.get("error"):
            raise PermissionError("Google OAuth consent was denied or cancelled")
        if len(params.get("code", [])) != 1 or not params["code"][0]:
            raise ValueError("OAuth callback is missing the authorization code")
        flow.fetch_token(authorization_response=authorization_response)
        credentials=flow.credentials
        granted=frozenset(credentials.scopes or ())
        if not scopes.issubset(granted): raise PermissionError("Google did not grant all requested read-only scopes")
        return credentials
