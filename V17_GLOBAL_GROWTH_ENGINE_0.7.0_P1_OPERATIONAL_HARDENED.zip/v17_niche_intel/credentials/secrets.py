from __future__ import annotations

import re
from typing import Protocol, Iterable
from uuid import uuid4


class SecretStore(Protocol):
    def put(self, value: str) -> str: ...
    def get(self, reference: str) -> str: ...
    def delete(self, reference: str) -> None: ...


class MemorySecretStore:
    """Process-local secret store for tests and ephemeral sessions only."""
    def __init__(self) -> None:
        self._values: dict[str, str] = {}

    def put(self, value: str) -> str:
        if not value:
            raise ValueError("secret must be non-empty")
        reference = f"memory://{uuid4().hex}"
        self._values[reference] = value
        return reference

    def get(self, reference: str) -> str:
        try:
            return self._values[reference]
        except KeyError as exc:
            raise KeyError("secret reference not found") from exc

    def delete(self, reference: str) -> None:
        self._values.pop(reference, None)


class EnvironmentSecretStore:
    """Resolve only namespaced or explicitly allowlisted environment secrets."""
    _NAME = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")

    def __init__(self, prefix: str = "V17_SECRET_", *, allowed_names: Iterable[str] | None = None) -> None:
        import os
        if not isinstance(prefix, str):
            raise ValueError("environment secret prefix must be a string")
        names = frozenset(allowed_names) if allowed_names is not None else None
        if names is not None and (not names or any(not isinstance(name, str) or not self._NAME.fullmatch(name) for name in names)):
            raise ValueError("environment secret allowlist must contain valid exact variable names")
        if not prefix and names is None:
            raise ValueError("an empty environment prefix requires an exact variable-name allowlist")
        if prefix and (not self._NAME.fullmatch(prefix.rstrip("_")) or not prefix.endswith("_")):
            raise ValueError("environment secret prefix must be a valid namespace ending in underscore")
        self._os = os
        self._prefix = prefix
        self._allowed_names = names

    def put(self, value: str) -> str:
        raise RuntimeError("EnvironmentSecretStore is read-only; configure secret references in the environment")

    def get(self, reference: str) -> str:
        if not isinstance(reference, str) or not reference.startswith("env://"):
            raise KeyError("unsupported environment secret reference")
        name = reference.removeprefix("env://")
        if (not self._NAME.fullmatch(name)
                or (self._allowed_names is not None and name not in self._allowed_names)
                or (self._allowed_names is None and not name.startswith(self._prefix))):
            raise KeyError("unsupported environment secret reference")
        value = self._os.environ.get(name)
        if not value:
            raise KeyError("environment secret is missing")
        return value

    def delete(self, reference: str) -> None:
        raise RuntimeError("EnvironmentSecretStore does not delete environment variables")


class KeyringSecretStore:
    """Persist secrets in the operating-system credential vault via optional keyring."""
    def __init__(self, service_name: str = "v17-niche-intelligence") -> None:
        try:
            import keyring
        except ImportError as exc:
            raise RuntimeError("Install secure credential storage: pip install -e '.[secrets]'") from exc
        self._keyring = keyring
        self._service_name = service_name

    def put(self, value: str) -> str:
        if not value:
            raise ValueError("secret must be non-empty")
        reference = f"keyring://{uuid4().hex}"
        self._keyring.set_password(self._service_name, reference, value)
        return reference

    def get(self, reference: str) -> str:
        value = self._keyring.get_password(self._service_name, reference)
        if value is None:
            raise KeyError("secret reference not found in OS keyring")
        return value

    def delete(self, reference: str) -> None:
        try:
            self._keyring.delete_password(self._service_name, reference)
        except self._keyring.errors.PasswordDeleteError:
            pass


class CompositeSecretStore:
    """Resolve keyring and environment references without mixing their write paths."""
    def __init__(self, keyring_store: SecretStore | None = None,
                 environment_store: EnvironmentSecretStore | None = None) -> None:
        self.keyring_store = keyring_store
        self.environment_store = environment_store or EnvironmentSecretStore(prefix="V17_SECRET_")

    def put(self, value: str) -> str:
        if self.keyring_store is None:
            raise RuntimeError("A writable OS keyring is required for persistent secrets")
        return self.keyring_store.put(value)

    def get(self, reference: str) -> str:
        if reference.startswith("env://"):
            return self.environment_store.get(reference)
        if reference.startswith("keyring://") and self.keyring_store is not None:
            return self.keyring_store.get(reference)
        raise KeyError("unsupported or unavailable secret reference backend")

    def delete(self, reference: str) -> None:
        if reference.startswith("env://"):
            raise RuntimeError("Environment-backed secrets are managed by the environment")
        if reference.startswith("keyring://") and self.keyring_store is not None:
            self.keyring_store.delete(reference)
            return
        raise KeyError("unsupported or unavailable secret reference backend")
