from __future__ import annotations

from types import MethodType
from typing import Any


def harden_requests_session(session: Any) -> Any:
    """Disable ambient proxy/cookie/auth state and refuse all HTTP redirects."""
    session.trust_env = False
    session.proxies = {}
    session.verify = True
    session.cert = None
    session.auth = None
    cookies = getattr(session, "cookies", None)
    if cookies is not None and hasattr(cookies, "clear"):
        cookies.clear()
    headers = getattr(session, "headers", None)
    if headers is not None:
        headers.pop("Authorization", None)
        headers.pop("Cookie", None)

    def refuse_redirects(self, response, request, **kwargs):
        if getattr(response, "is_redirect", False) or getattr(response, "is_permanent_redirect", False):
            raise RuntimeError("Sensitive Google OAuth request redirect refused")
        return iter(())

    session.resolve_redirects = MethodType(refuse_redirects, session)
    return session
