"""Password-encrypted SQLite + secret-reference backup/restore.

Secrets are exported only into the authenticated encrypted payload and are remapped
into the destination secret store during restore. Never log passphrases or values.
"""
from __future__ import annotations

import hashlib
import io
import json
import os
import secrets
import sqlite3
import tempfile
import zipfile
from pathlib import Path

from ..ui.input_safety import parse_bounded_json

_MAGIC = b"V17BKP1\0"
_MAX_BACKUP_BYTES = 500 * 1024 * 1024
_MAX_SECRET_MAP_BYTES = 10 * 1024 * 1024


def _derive_key(passphrase: str, salt: bytes) -> bytes:
    if not isinstance(passphrase, str) or len(passphrase) < 12:
        raise ValueError("backup passphrase must contain at least 12 characters")
    return hashlib.scrypt(passphrase.encode("utf-8"), salt=salt, n=2**15, r=8, p=1, dklen=32, maxmem=64 * 1024 * 1024)


def _secret_references(database) -> list[str]:
    with database.read() as conn:
        rows = conn.execute("""SELECT secret_ref AS ref FROM api_credentials
            UNION SELECT access_token_ref FROM oauth_accounts
            UNION SELECT refresh_token_ref FROM oauth_accounts
            UNION SELECT client_secret_ref FROM oauth_accounts WHERE client_secret_ref IS NOT NULL""").fetchall()
    return sorted({row["ref"] for row in rows if row["ref"]})


def create_encrypted_backup(database, source_store, output_path: str | Path, *, passphrase: str) -> dict:
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError as exc:
        raise RuntimeError("Install backup crypto support: pip install -e '.[backup]'") from exc
    output = Path(output_path).expanduser()
    if database.path != ":memory:" and output.resolve() == Path(database.path).expanduser().resolve():
        raise ValueError("backup output must not overwrite the active SQLite database")
    if output.exists():
        raise FileExistsError("backup output already exists; choose a new backup filename")
    output.parent.mkdir(parents=True, exist_ok=True)
    integrity = database.connection.execute("PRAGMA integrity_check").fetchone()[0]
    if integrity != "ok": raise ValueError("source database integrity check failed")
    refs = _secret_references(database)
    secret_values = {ref: source_store.get(ref) for ref in refs}
    with tempfile.TemporaryDirectory(prefix="v17-backup-") as directory:
        sqlite_path = Path(directory) / "database.sqlite3"
        target = sqlite3.connect(sqlite_path)
        try:
            database.connection.backup(target)
            target.commit()
        finally:
            target.close()
        bundle = io.BytesIO()
        with zipfile.ZipFile(bundle, "w", compression=zipfile.ZIP_DEFLATED) as archive:
            archive.writestr("database.sqlite3", sqlite_path.read_bytes())
            archive.writestr("secrets.json", json.dumps(secret_values, separators=(",", ":")).encode("utf-8"))
    salt, nonce = secrets.token_bytes(16), secrets.token_bytes(12)
    key = _derive_key(passphrase, salt)
    encrypted = AESGCM(key).encrypt(nonce, bundle.getvalue(), _MAGIC)
    envelope = _MAGIC + salt + nonce + encrypted
    if len(envelope) > _MAX_BACKUP_BYTES:
        raise ValueError("encrypted backup exceeds 500 MiB limit")
    fd, temporary = tempfile.mkstemp(prefix=f".{output.name}.", dir=output.parent)
    try:
        if hasattr(os, "fchmod"): os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as stream:
            stream.write(envelope)
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, output)
        try: os.chmod(output, 0o600)
        except OSError: pass
    except Exception:
        try: os.unlink(temporary)
        except OSError: pass
        raise
    return {"status": "created", "path": str(output), "bytes": len(envelope),
            "secret_reference_count": len(refs), "encrypted": True}


def restore_encrypted_backup(backup_path: str | Path, target_path: str | Path,
                             target_store, *, passphrase: str) -> dict:
    try:
        from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    except ImportError as exc:
        raise RuntimeError("Install backup crypto support: pip install -e '.[backup]'") from exc
    backup = Path(backup_path).expanduser()
    target = Path(target_path).expanduser()
    if not backup.is_file() or backup.stat().st_size > _MAX_BACKUP_BYTES:
        raise ValueError("backup file is missing or exceeds 500 MiB")
    if target.exists():
        raise FileExistsError("restore target already exists; choose a new database path")
    raw = backup.read_bytes()
    if len(raw) < len(_MAGIC) + 16 + 12 + 16 or not raw.startswith(_MAGIC):
        raise ValueError("backup format is invalid")
    salt = raw[len(_MAGIC):len(_MAGIC) + 16]
    nonce = raw[len(_MAGIC) + 16:len(_MAGIC) + 28]
    key = _derive_key(passphrase, salt)
    try:
        plaintext = AESGCM(key).decrypt(nonce, raw[len(_MAGIC) + 28:], _MAGIC)
    except Exception as exc:
        raise ValueError("backup authentication failed; check the passphrase or file integrity") from exc
    try:
        with zipfile.ZipFile(io.BytesIO(plaintext), "r") as archive:
            members = archive.infolist()
            names = [info.filename for info in members]
            if (len(members) != 2 or len(set(names)) != len(names)
                    or set(names) != {"database.sqlite3", "secrets.json"}
                    or any(info.is_dir() for info in members)):
                raise ValueError("backup contains duplicate or unexpected members")
            if sum(info.file_size for info in members) > _MAX_BACKUP_BYTES:
                raise ValueError("decompressed backup exceeds 500 MiB limit")
            database_info = next(info for info in members if info.filename == "database.sqlite3")
            secrets_info = next(info for info in members if info.filename == "secrets.json")
            if secrets_info.file_size > _MAX_SECRET_MAP_BYTES:
                raise ValueError("backup secret map exceeds the 10 MiB limit")
            db_bytes = archive.read(database_info)
            secrets_payload = archive.read(secrets_info).decode("utf-8", errors="strict")
            secrets_map = parse_bounded_json(secrets_payload, max_bytes=_MAX_SECRET_MAP_BYTES, max_depth=16)
    except (zipfile.BadZipFile, json.JSONDecodeError, KeyError) as exc:
        raise ValueError("backup payload is invalid") from exc
    if not isinstance(secrets_map, dict) or any(not isinstance(k, str) or not isinstance(v, str) for k, v in secrets_map.items()):
        raise ValueError("backup secret map is invalid")
    target.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix=f".{target.name}.", dir=target.parent)
    new_refs: dict[str, str] = {}
    db = None
    try:
        if hasattr(os, "fchmod"): os.fchmod(fd, 0o600)
        with os.fdopen(fd, "wb") as stream:
            stream.write(db_bytes)
            stream.flush()
            os.fsync(stream.fileno())
        # Hard-link creation is atomic and fails rather than overwriting a target
        # that appeared after the initial existence check.
        os.link(temporary, target)
        os.unlink(temporary)
        from .database import Database
        db = Database(target)
        refs = _secret_references(db)
        if set(refs) != set(secrets_map):
            raise ValueError("backup secret references do not match database metadata")
        for old_ref, value in secrets_map.items():
            new_refs[old_ref] = target_store.put(value)
        with db.transaction() as conn:
            for old_ref, new_ref in new_refs.items():
                conn.execute("UPDATE api_credentials SET secret_ref=? WHERE secret_ref=?", (new_ref, old_ref))
                conn.execute("UPDATE oauth_accounts SET access_token_ref=? WHERE access_token_ref=?", (new_ref, old_ref))
                conn.execute("UPDATE oauth_accounts SET refresh_token_ref=? WHERE refresh_token_ref=?", (new_ref, old_ref))
                conn.execute("UPDATE oauth_accounts SET client_secret_ref=? WHERE client_secret_ref=?", (new_ref, old_ref))
        integrity = db.connection.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok": raise ValueError("restored database integrity check failed")
        db.close(); db = None
        try: os.chmod(target, 0o600)
        except OSError: pass
        return {"status": "restored", "path": str(target), "secret_reference_count": len(new_refs),
                "encrypted_source": True, "integrity": integrity}
    except Exception:
        if db is not None: db.close()
        for reference in new_refs.values():
            try: target_store.delete(reference)
            except Exception: pass
        try: target.unlink()
        except OSError: pass
        try: os.unlink(temporary)
        except OSError: pass
        raise


def check_secret_store(secret_store) -> dict:
    """Perform a write/read/delete health probe without exposing its value."""
    probe = secrets.token_urlsafe(32)
    reference = secret_store.put(probe)
    try:
        if secret_store.get(reference) != probe:
            raise RuntimeError("secret store read-back did not match")
        return {"status": "ok", "backend": type(secret_store).__name__}
    finally:
        secret_store.delete(reference)
