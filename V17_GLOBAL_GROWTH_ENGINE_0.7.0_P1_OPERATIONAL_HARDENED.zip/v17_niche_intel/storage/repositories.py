from __future__ import annotations
import hashlib
import json
import re
from math import isfinite
import uuid
from datetime import date, datetime, timedelta, timezone
from typing import Any
from ..domain.models import Evidence
from .database import Database

def _json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


_MAX_JOB_PAYLOAD_BYTES = 1024 * 1024
_JOB_ERROR_CODE = re.compile(r"^[A-Za-z0-9_.:-]{1,128}$")


def _validate_worker_id(worker_id: str) -> str:
    if not isinstance(worker_id, str) or not worker_id.strip() or len(worker_id) > 128 or any(ord(ch) < 0x20 for ch in worker_id):
        raise ValueError("worker_id must be a non-empty string of at most 128 characters without controls")
    return worker_id.strip()

class ResearchRunRepository:
    def __init__(self, database: Database) -> None:
        self.database = database

    def create(self, *, topic: str, mode: str, country_code: str | None,
               algorithm_version: str, config: dict[str, Any], created_at: datetime | None = None) -> str:
        if not topic.strip():
            raise ValueError("topic must be non-empty")
        if mode not in {"market_entry", "existing_channel", "both"}:
            raise ValueError("unsupported research mode")
        if not algorithm_version.strip():
            raise ValueError("algorithm_version must be non-empty")
        run_id = str(uuid.uuid4())
        timestamp = (created_at or datetime.now(timezone.utc)).isoformat()
        with self.database.transaction() as connection:
            connection.execute(
                "INSERT INTO research_runs (id, topic, mode, country_code, algorithm_version, config_json, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (run_id, topic.strip(), mode, country_code, algorithm_version, _json(config), timestamp),
            )
        return run_id

    def get(self, run_id: str) -> dict[str, Any] | None:
        with self.database.read() as connection:
            row = connection.execute("SELECT * FROM research_runs WHERE id = ?", (run_id,)).fetchone()
        if row is None:
            return None
        result = dict(row)
        result["config"] = json.loads(result.pop("config_json"))
        return result

class EvidenceRepository:
    def __init__(self, database: Database) -> None:
        self.database = database

    @staticmethod
    def _observation_key(run_id: str, evidence: Evidence) -> str:
        payload = {"run_id": run_id, "metric": evidence.metric, "value": evidence.value,
                   "source_family": evidence.source_family, "observed_at": evidence.observed_at.isoformat(),
                   "status": str(evidence.status), "quality": evidence.quality,
                   "source_ref": evidence.source_ref, "metadata": evidence.metadata}
        return hashlib.sha256(_json(payload).encode("utf-8")).hexdigest()

    def add(self, run_id: str, evidence: Evidence) -> bool:
        key = self._observation_key(run_id, evidence)
        with self.database.transaction() as connection:
            cursor = connection.execute(
                "INSERT OR IGNORE INTO source_observations "
                "(run_id, observation_key, metric, value_json, source_family, observed_at, status, quality, source_ref, metadata_json) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                (run_id, key, evidence.metric, None if evidence.value is None else _json(evidence.value),
                 evidence.source_family, evidence.observed_at.isoformat(), str(evidence.status),
                 float(evidence.quality), evidence.source_ref, _json(evidence.metadata)),
            )
        return cursor.rowcount == 1

    def list_for_run(self, run_id: str) -> list[dict[str, Any]]:
        with self.database.read() as connection:
            rows = connection.execute(
                "SELECT * FROM source_observations WHERE run_id = ? ORDER BY observed_at, id", (run_id,)
            ).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["value"] = None if item["value_json"] is None else json.loads(item["value_json"])
            item.pop("value_json", None)
            item["metadata"] = json.loads(item.pop("metadata_json"))
            result.append(item)
        return result

class ResultRepository:
    """Stores reproducible report payloads; callers must keep private analytics out of public reports."""
    def __init__(self, database: Database) -> None: self.database=database
    def save(self, run_id: str, result: dict[str,Any]) -> None:
        with self.database.transaction() as connection:
            connection.execute("INSERT INTO research_results(run_id,result_json,saved_at) VALUES(?,?,?) ON CONFLICT(run_id) DO UPDATE SET result_json=excluded.result_json,saved_at=excluded.saved_at",
                (run_id,_json(result),datetime.now(timezone.utc).isoformat()))
    def get(self, run_id: str) -> dict[str,Any] | None:
        with self.database.read() as connection: row=connection.execute("SELECT result_json FROM research_results WHERE run_id=?",(run_id,)).fetchone()
        return json.loads(row["result_json"]) if row else None

class SnapshotRepository:
    def __init__(self, database: Database) -> None: self.database=database
    def add(self, run_id: str, *, video_id: str, observed_at: datetime, views: int|None, likes: int|None, comments: int|None) -> bool:
        if observed_at.tzinfo is None or observed_at.utcoffset() is None: raise ValueError("observed_at must be timezone-aware")
        with self.database.transaction() as connection:
            cur=connection.execute("INSERT OR IGNORE INTO video_snapshots(run_id,video_id,observed_at,views,likes,comments) VALUES(?,?,?,?,?,?)",
                (run_id,video_id,observed_at.isoformat(),views,likes,comments))
        return cur.rowcount==1
    def list_for_video(self, video_id: str) -> list[dict[str,Any]]:
        with self.database.read() as connection: rows=connection.execute("SELECT * FROM video_snapshots WHERE video_id=? ORDER BY observed_at",(video_id,)).fetchall()
        return [dict(row) for row in rows]

class PrivateAnalyticsRepository:
    """First-party owner data is isolated from public source_observations."""
    def __init__(self, database: Database) -> None: self.database=database
    def import_rows(self, *, channel_id: str, rows: tuple[dict[str,Any],...], run_id: str|None=None,
                    provenance: dict[str, Any] | None = None) -> int:
        if not channel_id.strip(): raise ValueError("channel_id is required")
        provenance_json = _json(provenance or {})
        inserted=0
        with self.database.transaction() as connection:
            for row in rows:
                metrics={k:v for k,v in row.items() if k not in {"date","video_id"}}
                cur=connection.execute("INSERT OR IGNORE INTO channel_analytics_private(run_id,channel_id,video_id,report_date,metrics_json,imported_at,provenance_json) VALUES(?,?,?,?,?,?,?)",
                    (run_id,channel_id,row["video_id"],row["date"],_json(metrics),datetime.now(timezone.utc).isoformat(),provenance_json))
                inserted += cur.rowcount
        return inserted
    def list_for_channel(self, channel_id: str) -> list[dict[str,Any]]:
        with self.database.read() as connection: rows=connection.execute("SELECT * FROM channel_analytics_private WHERE channel_id=? ORDER BY report_date",(channel_id,)).fetchall()
        result=[]
        for row in rows:
            item=dict(row); item["metrics"]=json.loads(item.pop("metrics_json")); item["provenance"]=json.loads(item.pop("provenance_json")); result.append(item)
        return result

    def import_daily_rows(self, *, channel_id: str, rows: tuple[dict[str,Any],...],
                          provenance: dict[str, Any] | None = None) -> int:
        if not channel_id.strip(): raise ValueError("channel_id is required")
        provenance_json = _json(provenance or {})
        inserted = 0
        with self.database.transaction() as connection:
            for row in rows:
                report_date = row.get("date") or row.get("day")
                if not report_date: raise ValueError("daily Analytics row requires date")
                metrics = {key: value for key, value in row.items() if key not in {"date", "day"}}
                cursor = connection.execute("INSERT OR IGNORE INTO channel_analytics_daily_private(channel_id,report_date,metrics_json,imported_at,provenance_json) VALUES(?,?,?,?,?)",
                    (channel_id, report_date, _json(metrics), datetime.now(timezone.utc).isoformat(), provenance_json))
                inserted += cursor.rowcount
        return inserted

    def list_daily_for_channel(self, channel_id: str) -> list[dict[str,Any]]:
        with self.database.read() as connection:
            rows = connection.execute("SELECT * FROM channel_analytics_daily_private WHERE channel_id=? ORDER BY report_date", (channel_id,)).fetchall()
        result = []
        for row in rows:
            item = dict(row); item["metrics"] = json.loads(item.pop("metrics_json")); item["provenance"] = json.loads(item.pop("provenance_json")); result.append(item)
        return result

    def import_country_rows(self, *, channel_id: str, start_date: str, end_date: str,
                            currency: str, rows: tuple[dict[str,Any],...],
                            provenance: dict[str, Any] | None = None) -> int:
        if not isinstance(channel_id, str) or not channel_id.strip() or not isinstance(currency, str) or len(currency) != 3 or not currency.isalpha():
            raise ValueError("valid channel and three-letter currency are required")
        try:
            parsed_start, parsed_end = date.fromisoformat(start_date), date.fromisoformat(end_date)
        except (TypeError, ValueError) as exc:
            raise ValueError("country Analytics dates must use YYYY-MM-DD") from exc
        if parsed_start > parsed_end:
            raise ValueError("country Analytics start date must not be after end date")
        provenance_json = _json(provenance or {})
        inserted = 0
        with self.database.transaction() as connection:
            for row in rows:
                country = str(row.get("country") or "").upper()
                if len(country) != 2 or not country.isalpha():
                    raise ValueError("country Analytics rows require a two-letter country code")
                views = row.get("views")
                revenue = row.get("estimatedRevenue")
                rpm = row.get("rpm")
                if any(isinstance(value, bool) or not isinstance(value, (int,float)) or not isfinite(float(value)) or value < 0 for value in (views,revenue)):
                    raise ValueError("country views and estimated revenue must be non-negative numbers")
                if rpm is not None and (isinstance(rpm, bool) or not isinstance(rpm, (int,float)) or not isfinite(float(rpm)) or rpm < 0):
                    raise ValueError("country RPM must be a non-negative number")
                cursor = connection.execute("""INSERT OR IGNORE INTO channel_analytics_country_private
                    (channel_id,country_code,start_date,end_date,currency,views,estimated_revenue,rpm,imported_at,provenance_json)
                    VALUES(?,?,?,?,?,?,?,?,?,?)""", (channel_id,country,start_date,end_date,currency.upper(),
                    float(views),float(revenue),float(rpm) if rpm is not None else None,datetime.now(timezone.utc).isoformat(),provenance_json))
                inserted += cursor.rowcount
        return inserted

    def list_country_for_channel(self, channel_id: str) -> list[dict[str,Any]]:
        with self.database.read() as connection:
            rows = connection.execute("SELECT * FROM channel_analytics_country_private WHERE channel_id=? ORDER BY start_date,country_code", (channel_id,)).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["provenance"] = json.loads(item.pop("provenance_json"))
            result.append(item)
        return result


class SERPSnapshotRepository:
    def __init__(self, database: Database) -> None: self.database = database

    def add(self, *, keyword: str, country: str, language: str | None,
            observed_at: datetime, results: list[dict[str, Any]], source: str = "firecrawl_search") -> bool:
        if not keyword.strip() or not country.strip(): raise ValueError("keyword and country are required")
        if observed_at.tzinfo is None or observed_at.utcoffset() is None: raise ValueError("observed_at must be timezone-aware")
        with self.database.transaction() as connection:
            cursor = connection.execute("INSERT OR IGNORE INTO serp_snapshots(keyword,country,language,observed_at,results_json,source) VALUES(?,?,?,?,?,?)",
                (keyword.strip(), country.upper(), language, observed_at.isoformat(), _json(results), source))
        return cursor.rowcount == 1

    def list_for_keyword(self, keyword: str, *, country: str | None = None) -> list[dict[str, Any]]:
        query = "SELECT * FROM serp_snapshots WHERE keyword=?"
        params: tuple[Any, ...] = (keyword,)
        if country:
            query += " AND country=?"; params += (country.upper(),)
        query += " ORDER BY observed_at"
        with self.database.read() as connection: rows = connection.execute(query, params).fetchall()
        result = []
        for row in rows:
            item = dict(row); item["results"] = json.loads(item.pop("results_json")); result.append(item)
        return result

    def list_keywords(self, *, country: str | None = None) -> list[str]:
        with self.database.read() as connection:
            if country:
                rows = connection.execute("SELECT DISTINCT keyword FROM serp_snapshots WHERE country=? ORDER BY keyword", (country.upper(),)).fetchall()
            else:
                rows = connection.execute("SELECT DISTINCT keyword FROM serp_snapshots ORDER BY keyword").fetchall()
        return [row["keyword"] for row in rows]


class JobCheckpointRepository:
    """Persist idempotent, resumable job state; this repository does not run jobs."""
    _TRANSITIONS = {
        "pending": {"failed"},  # running is reachable only through claim_next(), which assigns the lease
        "running": {"paused", "completed", "failed"},
        "paused": {"pending", "failed"},  # resume by returning to the claimable queue
        "failed": {"pending"},
        "completed": set(),
    }

    def __init__(self, database: Database) -> None:
        self.database = database

    def create(self, *, job_id: str, idempotency_key: str, job_type: str,
               config: dict[str, Any]) -> bool:
        if not all(isinstance(value, str) and value.strip() for value in (job_id, idempotency_key, job_type)):
            raise ValueError("job_id, idempotency_key and job_type must be non-empty strings")
        if len(job_id) > 128 or len(idempotency_key) > 256 or len(job_type) > 64:
            raise ValueError("job identifiers exceed their configured length limits")
        if any(ord(ch) < 0x20 for value in (job_id, idempotency_key, job_type) for ch in value):
            raise ValueError("job identifiers must not contain control characters")
        if not isinstance(config, dict):
            raise ValueError("job config must be an object")
        config_json = _json(config)
        if len(config_json.encode("utf-8")) > _MAX_JOB_PAYLOAD_BYTES:
            raise ValueError("job config exceeds the 1 MiB payload limit")
        now = datetime.now(timezone.utc).isoformat()
        with self.database.transaction() as connection:
            cursor = connection.execute("""INSERT OR IGNORE INTO job_checkpoints
                (job_id,idempotency_key,job_type,status,config_json,checkpoint_json,attempt_count,created_at,updated_at)
                VALUES(?,?,?,'pending',?,'{}',0,?,?)""",
                (job_id.strip(), idempotency_key.strip(), job_type.strip(), config_json, now, now))
        return cursor.rowcount == 1

    def get(self, job_id: str) -> dict[str, Any] | None:
        with self.database.read() as connection:
            row = connection.execute("SELECT * FROM job_checkpoints WHERE job_id=?", (job_id,)).fetchone()
        if row is None:
            return None
        result = dict(row)
        for column, public_key in (("config_json", "config"), ("checkpoint_json", "checkpoint")):
            try:
                result[public_key] = json.loads(result.pop(column))
            except (TypeError, ValueError):
                result[public_key] = None
                result[f"{public_key}_error"] = "invalid_json"
        return result

    def list(self, *, statuses: tuple[str, ...] | None = None, limit: int = 100) -> list[dict[str, Any]]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1000:
            raise ValueError("limit must be an integer from 1 to 1000")
        if statuses is not None:
            if not statuses or any(status not in self._TRANSITIONS for status in statuses):
                raise ValueError("statuses contains an invalid job state")
            # All valid states are represented by five fixed bind parameters.
            # Padding uses an impossible state so SQL text is constant.
            params = (*statuses, *("__invalid_status__",) * (5 - len(statuses)), limit)
            query = ("SELECT job_id FROM job_checkpoints "
                     "WHERE status IN (?, ?, ?, ?, ?) ORDER BY updated_at DESC LIMIT ?")
        else:
            query = "SELECT job_id FROM job_checkpoints ORDER BY updated_at DESC LIMIT ?"
            params = (limit,)
        with self.database.read() as connection:
            ids = [row["job_id"] for row in connection.execute(query, params).fetchall()]
        return [self.get(job_id) for job_id in ids]

    def claim_next(self, *, worker_id: str, lease_seconds: int = 300) -> dict[str, Any] | None:
        worker_id = _validate_worker_id(worker_id)
        if isinstance(lease_seconds, bool) or not isinstance(lease_seconds, int) or not 5 <= lease_seconds <= 3600:
            raise ValueError("lease_seconds must be between 5 and 3600")
        now = datetime.now(timezone.utc)
        now_text = now.isoformat()
        lease_until = (now + timedelta(seconds=lease_seconds)).isoformat()
        claimed_id: str | None = None
        with self.database.transaction() as connection:
            # Poisoned or exhausted jobs are terminalized in-place and skipped. A
            # single malformed queue entry must never starve every newer job.
            while True:
                row = connection.execute("""SELECT * FROM job_checkpoints
                    WHERE status='pending' OR (status='running' AND (lease_expires_at IS NULL OR lease_expires_at <= ?))
                    ORDER BY created_at,job_id LIMIT 1""", (now_text,)).fetchone()
                if row is None:
                    break
                try:
                    config = json.loads(row["config_json"])
                except (TypeError, ValueError):
                    config = None
                max_attempts = config.get("max_attempts", 3) if isinstance(config, dict) else None
                if (isinstance(max_attempts, bool) or not isinstance(max_attempts, int)
                        or not 1 <= max_attempts <= 5):
                    connection.execute("""UPDATE job_checkpoints SET status='failed',error_text=?,
                        worker_id=NULL,lease_expires_at=NULL,updated_at=? WHERE job_id=?""",
                        ("invalid_job_config_json" if config is None else "invalid_max_attempts_config",
                         now_text, row["job_id"]))
                    continue
                if int(row["attempt_count"]) >= max_attempts:
                    connection.execute("""UPDATE job_checkpoints SET status='failed',error_text=?,
                        worker_id=NULL,lease_expires_at=NULL,updated_at=? WHERE job_id=?""",
                        ("max_attempts_exhausted", now_text, row["job_id"]))
                    continue
                connection.execute("""UPDATE job_checkpoints SET status='running',worker_id=?,lease_expires_at=?,
                    attempt_count=attempt_count+1,error_text=NULL,updated_at=? WHERE job_id=?""",
                    (worker_id, lease_until, now_text, row["job_id"]))
                claimed_id = str(row["job_id"])
                break
        return self.get(claimed_id) if claimed_id is not None else None

    def renew_lease(self, job_id: str, *, worker_id: str, lease_seconds: int = 300) -> bool:
        """Extend a live worker lease without changing the persisted checkpoint."""
        worker_id = _validate_worker_id(worker_id)
        if isinstance(lease_seconds, bool) or not isinstance(lease_seconds, int) or not 5 <= lease_seconds <= 3600:
            raise ValueError("lease_seconds must be between 5 and 3600")
        now = datetime.now(timezone.utc)
        now_text = now.isoformat()
        lease_until = (now + timedelta(seconds=lease_seconds)).isoformat()
        with self.database.transaction() as connection:
            cursor = connection.execute("""UPDATE job_checkpoints
                SET lease_expires_at=?,updated_at=?
                WHERE job_id=? AND status='running' AND worker_id=? AND lease_expires_at>?""",
                (lease_until, now_text, job_id, worker_id, now_text))
        return cursor.rowcount == 1

    def save_checkpoint(self, job_id: str, checkpoint: dict[str, Any], *,
                        worker_id: str | None = None, lease_seconds: int = 300) -> bool:
        if not isinstance(checkpoint, dict):
            raise ValueError("checkpoint must be an object")
        worker_id = _validate_worker_id(worker_id)
        if isinstance(lease_seconds, bool) or not isinstance(lease_seconds, int) or not 5 <= lease_seconds <= 3600:
            raise ValueError("lease_seconds must be between 5 and 3600")
        checkpoint_json = _json(checkpoint)
        if len(checkpoint_json.encode("utf-8")) > _MAX_JOB_PAYLOAD_BYTES:
            raise ValueError("job checkpoint exceeds the 1 MiB payload limit")
        now = datetime.now(timezone.utc)
        now_text = now.isoformat()
        query = "UPDATE job_checkpoints SET checkpoint_json=?,updated_at=?,lease_expires_at=? WHERE job_id=? AND status='running' AND worker_id=? AND lease_expires_at>?"
        params: tuple[Any, ...] = (checkpoint_json, now_text, (now + timedelta(seconds=lease_seconds)).isoformat(), job_id, worker_id, now_text)
        with self.database.transaction() as connection:
            cursor = connection.execute(query, params)
        return cursor.rowcount == 1

    def transition(self, job_id: str, new_status: str, *, error: str | None = None,
                   worker_id: str | None = None) -> bool:
        if new_status not in self._TRANSITIONS:
            raise ValueError("unknown job transition state")
        if new_status == "running":
            raise ValueError("jobs must enter running state through claim_next() to acquire a worker lease")
        if error is not None and (not isinstance(error, str) or not _JOB_ERROR_CODE.fullmatch(error)):
            raise ValueError("job error must be a bounded machine-readable error code")
        with self.database.transaction() as connection:
            row = connection.execute("SELECT status,worker_id,lease_expires_at FROM job_checkpoints WHERE job_id=?", (job_id,)).fetchone()
            if row is None:
                return False
            old_status = row["status"]
            if new_status not in self._TRANSITIONS[old_status]:
                raise ValueError(f"invalid job transition: {old_status} -> {new_status}")
            if old_status == "running":
                if worker_id is None:
                    raise ValueError("worker lease ownership is required for a running job transition")
                worker_id = _validate_worker_id(worker_id)
                if row["worker_id"] != worker_id:
                    raise ValueError("job lease is not owned by this worker")
                try:
                    lease_expiry = datetime.fromisoformat(row["lease_expires_at"] or "")
                except ValueError:
                    lease_expiry = datetime.min.replace(tzinfo=timezone.utc)
                if lease_expiry.tzinfo is None or lease_expiry <= datetime.now(timezone.utc):
                    raise ValueError("job lease has expired")
            elif worker_id is not None and row["worker_id"] != worker_id:
                raise ValueError("job lease is not owned by this worker")
            attempts = 0
            release_lease = new_status in {"paused", "completed", "failed", "pending"}
            connection.execute("""UPDATE job_checkpoints SET status=?,error_text=?,
                attempt_count=attempt_count+?,worker_id=CASE WHEN ? THEN NULL ELSE worker_id END,
                lease_expires_at=CASE WHEN ? THEN NULL ELSE lease_expires_at END,updated_at=? WHERE job_id=?""",
                (new_status, error, attempts, int(release_lease), int(release_lease),
                 datetime.now(timezone.utc).isoformat(), job_id))
        return True


class ExperimentRepository:
    """Idempotent experiment registry with explicit lifecycle transitions."""
    _TRANSITIONS = {
        "planned": {"running", "cancelled"},
        "running": {"paused", "completed", "failed", "cancelled"},
        "paused": {"running", "cancelled"},
        "failed": {"planned", "cancelled"},
        "completed": set(), "cancelled": set(),
    }

    def __init__(self, database: Database) -> None:
        self.database = database

    def create(self, *, experiment_id: str, idempotency_key: str, objective: str,
               primary_metric: str, config: dict[str, Any]) -> bool:
        values = (experiment_id, idempotency_key, objective, primary_metric)
        if any(not isinstance(value, str) or not value.strip() for value in values):
            raise ValueError("experiment identifiers, objective and primary_metric must be non-empty")
        if not isinstance(config, dict):
            raise ValueError("experiment config must be an object")
        now = datetime.now(timezone.utc).isoformat()
        with self.database.transaction() as connection:
            cursor = connection.execute("""INSERT OR IGNORE INTO experiment_registry
                (experiment_id,idempotency_key,objective,primary_metric,status,config_json,created_at,updated_at)
                VALUES(?,?,?,?,'planned',?,?,?)""",
                (experiment_id.strip(), idempotency_key.strip(), objective.strip(), primary_metric.strip(),
                 _json(config), now, now))
        return cursor.rowcount == 1

    def get(self, experiment_id: str) -> dict[str, Any] | None:
        with self.database.read() as connection:
            row = connection.execute("SELECT * FROM experiment_registry WHERE experiment_id=?", (experiment_id,)).fetchone()
        if row is None:
            return None
        result = dict(row)
        result["config"] = json.loads(result.pop("config_json"))
        result["result"] = json.loads(result.pop("result_json"))
        return result

    def record_result(self, experiment_id: str, result: dict[str, Any]) -> bool:
        if not isinstance(result, dict):
            raise ValueError("experiment result must be an object")
        with self.database.transaction() as connection:
            row = connection.execute("SELECT status FROM experiment_registry WHERE experiment_id=?", (experiment_id,)).fetchone()
            if row is None:
                return False
            if row["status"] != "running":
                raise ValueError("only running experiments can record a completed result")
            connection.execute("UPDATE experiment_registry SET status='completed',result_json=?,updated_at=? WHERE experiment_id=?",
                (_json(result), datetime.now(timezone.utc).isoformat(), experiment_id))
        return True

    def list(self, *, statuses: tuple[str, ...] | None = None, limit: int = 100) -> list[dict[str, Any]]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1000:
            raise ValueError("limit must be from 1 to 1000")
        if statuses is not None and (not statuses or any(item not in self._TRANSITIONS for item in statuses)):
            raise ValueError("invalid experiment status filter")
        with self.database.read() as connection:
            if statuses:
                # Six fixed bind parameters cover every declared experiment state.
                params = (*statuses, *("__invalid_status__",) * (6 - len(statuses)), limit)
                rows = connection.execute(
                    "SELECT experiment_id FROM experiment_registry "
                    "WHERE status IN (?, ?, ?, ?, ?, ?) ORDER BY updated_at DESC LIMIT ?",
                    params,
                ).fetchall()
            else:
                rows = connection.execute("SELECT experiment_id FROM experiment_registry ORDER BY updated_at DESC LIMIT ?", (limit,)).fetchall()
        return [self.get(row["experiment_id"]) for row in rows]

    def transition(self, experiment_id: str, new_status: str) -> bool:
        if new_status not in self._TRANSITIONS:
            raise ValueError("unknown experiment status")
        with self.database.transaction() as connection:
            row = connection.execute("SELECT status FROM experiment_registry WHERE experiment_id=?", (experiment_id,)).fetchone()
            if row is None:
                return False
            if new_status not in self._TRANSITIONS[row["status"]]:
                raise ValueError(f"invalid experiment transition: {row['status']} -> {new_status}")
            connection.execute("UPDATE experiment_registry SET status=?,updated_at=? WHERE experiment_id=?",
                (new_status, datetime.now(timezone.utc).isoformat(), experiment_id))
        return True


class DecisionLogRepository:
    """Idempotent strategic decision log with guarded lifecycle transitions."""
    _STATUSES = {"proposed", "accepted", "rejected", "implemented", "validated"}

    def __init__(self, database: Database) -> None:
        self.database = database

    def add(self, *, decision_id: str, idempotency_key: str, topic: str,
            recommendation: str, evidence_refs: list[str], expected_metric: str,
            status: str = "proposed", outcome: dict[str, Any] | None = None) -> bool:
        values = (decision_id, idempotency_key, topic, recommendation, expected_metric)
        if any(not isinstance(value, str) or not value.strip() for value in values):
            raise ValueError("decision identifiers, topic, recommendation and expected_metric must be non-empty")
        if not isinstance(evidence_refs, list) or any(not isinstance(item, str) or not item.strip() for item in evidence_refs):
            raise ValueError("evidence_refs must be a list of non-empty strings")
        if status not in self._STATUSES:
            raise ValueError("invalid decision status")
        outcome = outcome or {}
        if not isinstance(outcome, dict):
            raise ValueError("outcome must be an object")
        now = datetime.now(timezone.utc).isoformat()
        with self.database.transaction() as connection:
            cursor = connection.execute("""INSERT OR IGNORE INTO decision_log
                (decision_id,idempotency_key,topic,recommendation,evidence_refs_json,expected_metric,status,outcome_json,created_at,updated_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)""",
                (decision_id.strip(), idempotency_key.strip(), topic.strip(), recommendation.strip(),
                 _json(evidence_refs), expected_metric.strip(), status, _json(outcome), now, now))
        return cursor.rowcount == 1

    def transition(self, decision_id: str, new_status: str, *, outcome: dict[str, Any] | None = None) -> bool:
        transitions = {"proposed": {"accepted", "rejected"}, "accepted": {"implemented", "rejected"},
                       "implemented": {"validated", "rejected"}, "rejected": set(), "validated": set()}
        if new_status not in transitions:
            raise ValueError("unknown decision status")
        outcome = outcome or {}
        if not isinstance(outcome, dict):
            raise ValueError("outcome must be an object")
        with self.database.transaction() as connection:
            row = connection.execute("SELECT status,outcome_json FROM decision_log WHERE decision_id=?", (decision_id,)).fetchone()
            if row is None:
                return False
            if new_status not in transitions[row["status"]]:
                raise ValueError(f"invalid decision transition: {row['status']} -> {new_status}")
            connection.execute("UPDATE decision_log SET status=?,outcome_json=?,updated_at=? WHERE decision_id=?",
                (new_status, _json(outcome), datetime.now(timezone.utc).isoformat(), decision_id))
        return True

    def get(self, decision_id: str) -> dict[str, Any] | None:
        with self.database.read() as connection:
            row = connection.execute("SELECT * FROM decision_log WHERE decision_id=?", (decision_id,)).fetchone()
        if row is None:
            return None
        result = dict(row)
        result["evidence_refs"] = json.loads(result.pop("evidence_refs_json"))
        result["outcome"] = json.loads(result.pop("outcome_json"))
        return result

    def list(self, *, topic: str | None = None, limit: int = 100) -> list[dict[str, Any]]:
        if isinstance(limit, bool) or not isinstance(limit, int) or not 1 <= limit <= 1000:
            raise ValueError("limit must be from 1 to 1000")
        with self.database.read() as connection:
            if topic:
                rows = connection.execute("SELECT decision_id FROM decision_log WHERE topic=? ORDER BY created_at DESC LIMIT ?", (topic, limit)).fetchall()
            else:
                rows = connection.execute("SELECT decision_id FROM decision_log ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [self.get(row["decision_id"]) for row in rows]
