from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Mapping
from .enums import FormatLabel

@dataclass(frozen=True, slots=True)
class FormatClassification:
    label: str
    confidence: str
    method: str
    reason: str
    evidence: dict[str, Any]

def classify_video_format(*, duration_seconds: int | float | None,
                           live_broadcast_content: str | None = None,
                           live_streaming_details: Mapping[str, Any] | None = None,
                           aspect_ratio: float | None = None) -> FormatClassification:
    """Classify public video metadata without overstating Shorts certainty."""
    details = dict(live_streaming_details or {})
    live_state = (live_broadcast_content or "").strip().lower()
    evidence = {"duration_seconds": duration_seconds,
                "live_broadcast_content": live_state or None,
                "live_streaming_details": details, "aspect_ratio": aspect_ratio}
    if details.get("actualEndTime"):
        return FormatClassification(FormatLabel.COMPLETED_LIVE, "high", "youtube_live_metadata",
                                    "Actual end time is present in live-stream metadata.", evidence)
    if live_state == "live" or details.get("actualStartTime"):
        return FormatClassification(FormatLabel.LIVE_NOW, "high", "youtube_live_metadata",
                                    "The video is marked live or has an actual start time without an end time.", evidence)
    if live_state == "upcoming" or details.get("scheduledStartTime"):
        return FormatClassification(FormatLabel.UPCOMING_LIVE, "high", "youtube_live_metadata",
                                    "Upcoming state or scheduled start time is present.", evidence)
    try:
        duration = float(duration_seconds) if duration_seconds is not None else None
    except (TypeError, ValueError):
        duration = None
    if duration is None or duration <= 0:
        return FormatClassification(FormatLabel.UNKNOWN, "low", "insufficient_metadata",
                                    "A valid positive duration or live metadata is required.", evidence)
    if duration <= 180:
        if aspect_ratio is not None and aspect_ratio <= 1.0:
            return FormatClassification(FormatLabel.SHORTS_CANDIDATE, "medium", "duration_and_aspect_ratio",
                                        "Duration is at most 180 seconds and supplied aspect ratio is square or vertical; still a candidate, not platform-confirmed.", evidence)
        return FormatClassification(FormatLabel.SHORTS_CANDIDATE, "low", "duration_only",
                                    "Duration is at most 180 seconds; orientation is unavailable, so this is only a Shorts candidate.", evidence)
    return FormatClassification(FormatLabel.LONG_FORM_CANDIDATE, "medium", "duration_only",
                                "Duration exceeds 180 seconds and no live metadata is present.", evidence)
