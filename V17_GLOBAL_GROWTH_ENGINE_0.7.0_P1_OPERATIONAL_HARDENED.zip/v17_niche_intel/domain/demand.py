from __future__ import annotations
from statistics import mean, pstdev


def extract_trend_features(values: list[float] | tuple[float, ...]) -> dict:
    series=[float(x) for x in values if x is not None]
    if any(x < 0 or x > 100 for x in series): raise ValueError("Google Trends values must be between 0 and 100")
    if len(series) < 2:
        return {"status":"insufficient_data","direction":"unknown","relative_change_pct":None,
                "volatility":None,"absolute_search_volume":None,"metric_semantics":"relative_index"}
    midpoint=max(1,len(series)//2); earlier=mean(series[:midpoint]); later=mean(series[midpoint:])
    change=((later-earlier)/max(earlier,1))*100
    direction="rising" if change > 10 else "declining" if change < -10 else "stable"
    return {"status":"ok","direction":direction,"relative_change_pct":round(change,2),
            "volatility":round(pstdev(series),2),"mean_relative_interest":round(mean(series),2),
            "absolute_search_volume":None,"metric_semantics":"relative_index"}
