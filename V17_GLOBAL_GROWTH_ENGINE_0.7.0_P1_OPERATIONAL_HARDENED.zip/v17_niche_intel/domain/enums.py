from enum import StrEnum

class EvidenceStatus(StrEnum):
    OK = "ok"
    NO_DATA = "no_data"
    UNAVAILABLE = "unavailable"
    ERROR = "error"
    STALE = "stale"

class FormatLabel(StrEnum):
    SHORTS_CANDIDATE = "shorts_candidate"
    LONG_FORM_CANDIDATE = "long_form_candidate"
    LIVE_NOW = "live_now"
    UPCOMING_LIVE = "upcoming_live"
    COMPLETED_LIVE = "completed_live"
    UNKNOWN = "unknown"

class ConfidenceLevel(StrEnum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
