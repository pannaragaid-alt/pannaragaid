from __future__ import annotations
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

@dataclass(frozen=True, slots=True)
class VideoRecord:
    video_id: str
    title: str
    channel_id: str | None
    channel_title: str
    published_at: datetime
    views: int | None
    likes: int | None
    comments: int | None
    duration_seconds: int | None
    live_broadcast_content: str | None
    live_streaming_details: dict[str, Any] = field(default_factory=dict)
    url: str = ""

@dataclass(frozen=True, slots=True)
class VideoSearchBatch:
    videos: tuple[VideoRecord, ...]
    status: str
    requested_orders: tuple[str, ...]
    failed_orders: tuple[str, ...] = ()
    detail_failures: int = 0
