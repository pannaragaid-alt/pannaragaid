from __future__ import annotations
from dataclasses import dataclass
from typing import Mapping

ALGORITHM_VERSION = "v17-balanced-0.1.0"
SCORE_WEIGHTS: dict[str, float] = {
    "demand": 0.25, "competition_opportunity": 0.20, "momentum_stability": 0.15,
    "format_fit": 0.15, "business_feasibility": 0.15, "risk_resilience": 0.10,
}
MINIMUM_COVERAGE = 0.75

@dataclass(frozen=True, slots=True)
class ScoreResult:
    status: str
    score: float | None
    coverage: float
    contributions: dict[str, float]
    observed_dimensions: tuple[str, ...]
    missing_dimensions: tuple[str, ...]
    algorithm_version: str = ALGORITHM_VERSION

def score_opportunity(dimensions: Mapping[str, float | None], *,
                      minimum_coverage: float = MINIMUM_COVERAGE) -> ScoreResult:
    if not 0.0 <= minimum_coverage <= 1.0:
        raise ValueError("minimum_coverage must be between 0 and 1")
    unknown = set(dimensions) - set(SCORE_WEIGHTS)
    if unknown:
        raise ValueError(f"Unknown score dimensions: {', '.join(sorted(unknown))}")
    values: dict[str, float] = {}
    missing: list[str] = []
    for name in SCORE_WEIGHTS:
        value = dimensions.get(name)
        if value is None:
            missing.append(name)
            continue
        numeric = float(value)
        if not 0.0 <= numeric <= 100.0:
            raise ValueError(f"{name} must be between 0 and 100")
        values[name] = numeric
    coverage = round(sum(SCORE_WEIGHTS[name] for name in values), 8)
    if coverage < minimum_coverage or not values:
        return ScoreResult("insufficient_evidence", None, coverage, {}, tuple(values), tuple(missing))
    contributions = {name: round((SCORE_WEIGHTS[name] / coverage) * value, 4)
                     for name, value in values.items()}
    score = round(sum(contributions.values()), 2)
    return ScoreResult("scored", max(0.0, min(100.0, score)), coverage,
                       contributions, tuple(values), tuple(missing))
