from datetime import datetime, timezone, timedelta

import pytest

from v17_niche_intel.services.global_growth_engine import (
    build_localization_matrix,
    build_research_pipeline,
    calculate_channel_kpis,
    evaluate_distribution_surfaces,
    plan_proportion_experiment,
    score_market_economics,
    update_learning_proposal,
    run_global_growth_engine,
)


def test_market_economics_scores_markets_and_keeps_revenue_math_explicit():
    rows = [
        {"market_id": "US-en", "rpm_currency": "USD", "rpm_low": 4, "rpm_base": 6, "rpm_high": 8,
         "reachable_monthly_views": 100000, "production_cost": 100, "localization_cost": 20,
         "risk_reserve": 10, "demand_score": 80, "competitive_gap": 70, "creator_fit": 90, "confidence": .8},
        {"market_id": "GB-en", "rpm_currency": "USD", "rpm_low": 3, "rpm_base": 5, "rpm_high": 7,
         "reachable_monthly_views": 80000, "production_cost": 80, "localization_cost": 10,
         "risk_reserve": 5, "demand_score": 70, "competitive_gap": 80, "creator_fit": 80, "confidence": .7},
    ]
    result = score_market_economics(rows)
    assert result[0]["gross_revenue_base"] == 600
    assert result[0]["net_contribution_base"] == 470
    assert result[0]["opportunity_score"] > result[1]["opportunity_score"]
    assert result[0]["currency"] == "USD"


def test_market_economics_rejects_mixed_currency_without_conversion():
    rows = [
        {"market_id": "US-en", "rpm_currency": "USD", "rpm_base": 5, "reachable_monthly_views": 1000,
         "demand_score": 50, "competitive_gap": 50, "creator_fit": 50, "confidence": .5},
        {"market_id": "GB-en", "rpm_currency": "GBP", "rpm_base": 5, "reachable_monthly_views": 1000,
         "demand_score": 50, "competitive_gap": 50, "creator_fit": 50, "confidence": .5},
    ]
    with pytest.raises(ValueError, match="same reporting currency"):
        score_market_economics(rows)


def test_localization_matrix_requires_native_review_evidence_for_ready_status():
    result = build_localization_matrix([
        {"market_id": "ID-id", "locale": "id-ID", "language": "id", "query_variants": ["cara mengatur uang"],
         "translation_origin": "machine", "dialect_reviewed": False, "accent_reviewed": False, "cultural_reviewed": False},
        {"market_id": "GB-en", "locale": "en-GB", "language": "en", "query_variants": ["personal finance UK"],
         "translation_origin": "native", "native_reviewed": True, "review_source_ref": "https://review.example/1",
         "reviewed_at": datetime.now(timezone.utc).isoformat(), "dialect_reviewed": True,
         "accent_reviewed": True, "cultural_reviewed": True},
    ])
    assert result["ready_market_count"] == 1
    assert result["markets"][0]["status"] == "native_review_required"
    assert result["markets"][1]["status"] == "native_reviewed"


def test_research_pipeline_deduplicates_and_marks_stale_records():
    now = datetime.now(timezone.utc)
    rows = [
        {"market_id": "US-en", "source_ref": "https://example.com/a", "source_family": "serp",
         "observed_at": now.isoformat(), "metric": "rank", "value": 1},
        {"market_id": "US-en", "source_ref": "https://example.com/a", "source_family": "serp",
         "observed_at": now.isoformat(), "metric": "rank", "value": 1},
        {"market_id": "GB-en", "source_ref": "https://example.org/b", "source_family": "trend",
         "observed_at": (now - timedelta(days=400)).isoformat(), "metric": "index", "value": 20},
    ]
    result = build_research_pipeline(rows, allowed_hosts=["example.com", "example.org"], now=now, max_age_days=90)
    assert result["accepted_count"] == 2
    assert result["duplicate_count"] == 1
    assert result["stale_count"] == 1
    assert result["records"][1]["freshness"] == "stale"


def test_research_pipeline_rejects_non_https_and_unapproved_hosts():
    with pytest.raises(ValueError):
        build_research_pipeline([{"market_id": "US-en", "source_ref": "http://evil.test/x",
            "source_family": "serp", "observed_at": datetime.now(timezone.utc).isoformat(),
            "metric": "rank", "value": 1}], allowed_hosts=["example.com"])


def test_channel_kpis_use_explicit_owner_analytics_denominators():
    result = calculate_channel_kpis({"source": "owner_authorized_youtube_analytics", "views": 10000,
        "engaged_views": 5000, "impressions": 50000, "impressions_clicks": 2500, "clicks_semantics": "views_from_registered_impressions", "watch_time_minutes": 30000,
        "average_view_duration_seconds": 180, "video_duration_seconds": 300,
        "subscribers_gained": 100, "estimated_revenue": 75, "currency": "USD"})
    assert result["impressions_ctr_pct"] == 5
    assert result["average_percentage_viewed_pct"] == 60
    assert result["revenue_per_1000_views"] == 7.5
    assert result["source_verification"] == "declared_not_independently_authenticated"


def test_channel_kpis_do_not_infer_ctr_from_views_without_impression_click_semantics():
    result = calculate_channel_kpis({"source": "owner_authorized_youtube_analytics", "views": 1000})
    assert result["impressions_ctr_pct"] is None
    assert result["subscriber_conversion_per_1000_engaged_views"] is None


def test_distribution_scores_are_surface_specific_and_require_complete_inputs():
    result = evaluate_distribution_surfaces({
        "search": {"intent_match": 90, "topic_relevance": 80, "metadata_alignment": 70, "satisfaction": 75},
        "browse": {"audience_fit": 80, "packaging": 90, "early_retention": 70, "satisfaction": 75},
    })
    assert result["surfaces"]["search"]["status"] == "scored"
    assert result["surfaces"]["browse"]["score"] > 0
    assert result["surfaces"]["suggested"]["status"] == "insufficient_evidence"


def test_experiment_planner_reports_sample_size_and_non_conclusive_status():
    result = plan_proportion_experiment(baseline_rate=.05, minimum_detectable_effect=.01,
        alpha=.05, power=.8, baseline_successes=50, baseline_trials=1000,
        treatment_successes=60, treatment_trials=1000)
    assert result["required_sample_per_arm"] > 0
    assert result["observed_lift_percentage_points"] == pytest.approx(1)
    assert result["status"] in {"inconclusive", "promising_not_significant", "significant_review_guardrails"}


def test_learning_update_requires_minimum_observations_and_human_approval():
    result = update_learning_proposal(
        predictions=[100, 120, 140], actuals=[110, 115, 150], current_policy_version="v17-score-1",
        proposed_weights={"demand": .3, "monetization": .2, "competitive_gap": .2, "creator_fit": .2, "confidence": .1},
        minimum_observations=5)
    assert result["status"] == "insufficient_observations"
    assert result["apply_allowed"] is False


def test_orchestrator_can_invoke_multi_market_discovery_service():
    class FakeDiscovery:
        def discover(self, **kwargs):
            assert kwargs["topic"] == "coffee"
            assert len(kwargs["markets"]) == 2
            return {"status": "ok", "market_count": 2, "markets": []}
    result = run_global_growth_engine({"topic": "coffee"}, market_discovery_service=FakeDiscovery(),
        market_profiles=(object(), object()))
    assert result["capabilities"]["global_market"]["discovery"]["status"] == "ok"
    assert "global_market_inputs_missing" not in result["hard_gates"]


def test_orchestrator_runs_all_eight_capabilities_and_exposes_readiness():
    payload = {
        "topic": "personal finance",
        "markets": [{"market_id": "US-en", "rpm_currency": "USD", "rpm_base": 5,
            "reachable_monthly_views": 10000, "demand_score": 80, "competitive_gap": 70,
            "creator_fit": 90, "confidence": .7, "production_cost": 10}],
        "localization": [{"market_id": "US-en", "locale": "en-US", "language": "en",
            "query_variants": ["personal finance"], "native_reviewed": True,
            "review_source_ref": "https://review.example/us", "reviewed_at": datetime.now(timezone.utc).isoformat(),
            "dialect_reviewed": True, "accent_reviewed": True, "cultural_reviewed": True}],
        "research_records": [], "allowed_hosts": ["review.example"],
        "analytics": {"source": "owner_authorized_youtube_analytics", "views": 1000},
        "distribution": {"search": {"intent_match": 80, "topic_relevance": 80,
            "metadata_alignment": 80, "satisfaction": 80}},
        "experiment": {"baseline_rate": .05, "minimum_detectable_effect": .01},
        "learning": {"predictions": [1], "actuals": [1], "current_policy_version": "v1",
            "proposed_weights": {"demand": 1}, "minimum_observations": 3},
        "automation_jobs": [],
    }
    result = run_global_growth_engine(payload)
    assert set(result["capabilities"]) == {"global_market", "localization", "research_pipeline",
        "channel_analytics", "distribution", "experimentation", "continuous_learning", "automation"}
    assert result["status"] == "decision_support_ready_with_gates"


def test_daily_channel_analytics_aggregation_uses_weighted_rates():
    from v17_niche_intel.services.global_growth_engine import aggregate_channel_analytics_records
    result = aggregate_channel_analytics_records([
        {"day": "2025-01-01", "views": 120, "engagedViews": 100, "estimatedMinutesWatched": 100,
         "averageViewPercentage": 50, "subscribersGained": 2, "estimatedRevenue": 1},
        {"day": "2025-01-02", "views": 330, "engagedViews": 300, "estimatedMinutesWatched": 600,
         "averageViewPercentage": 75, "subscribersGained": 3, "estimatedRevenue": 4},
    ])
    assert result["views"] == 450
    assert result["engaged_views"] == 400
    assert result["average_view_duration_seconds"] == 105
    assert result["average_view_percentage_pct"] == 68.75
    assert result["impressions_ctr_pct"] is None
    assert result["estimated_revenue"] == 5


def test_market_economics_normalizes_currency_only_with_sourced_fx():
    rows = [
        {"market_id": "US-en", "rpm_currency": "USD", "rpm_base": 5, "reachable_monthly_views": 1000,
         "demand_score": 50, "competitive_gap": 50, "creator_fit": 50, "confidence": .5},
        {"market_id": "GB-en", "rpm_currency": "GBP", "rpm_base": 4, "reachable_monthly_views": 1000,
         "demand_score": 50, "competitive_gap": 50, "creator_fit": 50, "confidence": .5,
         "fx_conversion": {"to_currency": "USD", "rate_to_reporting": 1.25,
             "source_ref": "https://fx.example/rates", "observed_at": datetime.now(timezone.utc).isoformat()}},
    ]
    result = score_market_economics(rows, reporting_currency="USD")
    gb = next(row for row in result if row["market_id"] == "GB-en")
    assert gb["rpm_base"] == 5
    assert gb["currency"] == "USD"


def test_experiment_planner_blocks_sample_ratio_mismatch():
    result = plan_proportion_experiment(baseline_rate=.05, minimum_detectable_effect=.01,
        baseline_successes=10, baseline_trials=100, treatment_successes=100, treatment_trials=900)
    assert result["srm_status"] == "fail"
    assert result["status"] == "invalid_sample_ratio_mismatch"


def test_automation_contract_rejects_mutating_job_in_integrated_engine():
    payload = {"topic": "coffee", "automation_jobs": [{"job_id": "publish", "operation": "publish",
        "idempotency_key": "one", "max_attempts": 2, "timeout_seconds": 30, "max_items": 10,
        "budget_units": 100, "kill_switch_enabled": True, "target_domains": ["youtube.com"]}]}
    result = run_global_growth_engine(payload)
    job = result["capabilities"]["automation"]["jobs"][0]
    assert job["status"] == "blocked_human_approval_required"
    assert job["execution_status"] == "not_scheduled_or_executed"


def test_country_rpm_evidence_is_attached_but_not_used_as_market_forecast():
    result = run_global_growth_engine({"topic": "finance", "markets": [{"market_id": "US-en", "country_code": "US",
        "rpm_currency": "USD", "rpm_base": 4, "reachable_monthly_views": 10000,
        "demand_score": 70, "competitive_gap": 60, "creator_fit": 80, "confidence": .7}],
        "country_rpm_evidence": [{"country": "US", "views": 1000, "estimatedRevenue": 8, "rpm": 8, "currency": "USD", "source": "owner_authorized_youtube_analytics"}]})
    evidence = result["capabilities"]["global_market"]["markets"][0]["first_party_channel_rpm_evidence"]
    assert evidence["rpm"] == 8
    assert evidence["used_in_opportunity_score"] is False


def test_owner_channel_country_rpm_is_never_blended_into_external_market_opportunity_score():
    result = run_global_growth_engine({"topic": "finance", "markets": [{"market_id": "US-en", "country_code": "US",
        "rpm_currency": "USD", "reachable_monthly_views": 10000, "demand_score": 70,
        "competitive_gap": 60, "creator_fit": 80, "confidence": .7}],
        "country_rpm_evidence": [{"country": "US", "views": 1000, "estimatedRevenue": 8, "rpm": 8, "currency": "USD", "source": "owner_authorized_youtube_analytics"}],
        "country_rpm_period": ["2025-01-01", "2025-01-31"]})
    market = result["capabilities"]["global_market"]["markets"][0]
    assert market["status"] == "insufficient_evidence"
    assert "rpm_base" in market["missing_inputs"]
    assert market["first_party_channel_rpm_evidence"]["rpm"] == 8
    assert market["used_first_party_rpm_in_opportunity_score"] is False


def test_native_localization_evidence_is_forwarded_to_global_market_query_review():
    now = datetime.now(timezone.utc).isoformat()
    class FakeDiscovery:
        def discover(self, **kwargs):
            review = kwargs["localized_query_variants"]["US-en"]
            assert review["review_status"] == "native_reviewed"
            assert review["queries"] == ["personal finance"]
            return {"status": "ok", "market_count": 1, "markets": []}
    result = run_global_growth_engine({"topic": "personal finance", "localization": [{
        "market_id": "US-en", "locale": "en-US", "language": "en", "query_variants": ["personal finance"],
        "native_reviewed": True, "review_source_ref": "https://review.example/1", "reviewed_at": now,
        "dialect_reviewed": True, "accent_reviewed": True, "cultural_reviewed": True}]},
        market_discovery_service=FakeDiscovery(), market_profiles=(object(),))
    assert result["capabilities"]["global_market"]["discovery"]["status"] == "ok"


def test_market_economics_withholds_score_when_first_party_rpm_currency_does_not_match():
    result = run_global_growth_engine({"topic": "finance", "markets": [{"market_id": "GB-en", "country_code": "GB",
        "rpm_currency": "GBP", "reachable_monthly_views": 10000, "demand_score": 70,
        "competitive_gap": 60, "creator_fit": 80, "confidence": .7}],
        "country_rpm_evidence": [{"country": "GB", "views": 1000, "estimatedRevenue": 8, "rpm": 8, "currency": "USD", "source": "owner_authorized_youtube_analytics"}]})
    market = result["capabilities"]["global_market"]["markets"][0]
    assert market["status"] == "insufficient_evidence"
    assert "rpm_base" in market["missing_inputs"]
    assert market["first_party_channel_rpm_evidence"]["currency_comparable"] is False


def test_bounded_market_serp_collector_filters_unapproved_hosts_and_keeps_provenance():
    from v17_niche_intel.services.global_growth_engine import collect_market_serps
    class FakeSearch:
        def search(self, query, *, country, limit):
            return {"status": "ok", "observed_at": datetime.now(timezone.utc).isoformat(), "results": [
                {"url": "https://allowed.example/a", "title": "A"},
                {"url": "https://other.example/b", "title": "B"}]}
    result = collect_market_serps([{"market_id": "US-en", "country_code": "US",
        "localization": {"selected_query": "personal finance", "selected_query_source": "native_reviewed_curated"}}],
        provider=FakeSearch(), allowed_hosts=["allowed.example"], call_budget=1)
    assert result["status"] == "ok"
    assert result["attempted_calls"] == 1
    assert result["records"][0]["source_ref"] == "https://allowed.example/a"
    assert result["records"][0]["metadata"]["query"] == "personal finance"


def test_market_serp_collector_stops_at_budget_and_marks_partial():
    from v17_niche_intel.services.global_growth_engine import collect_market_serps
    class FakeSearch:
        def search(self, query, *, country, limit):
            return {"status": "ok", "observed_at": datetime.now(timezone.utc).isoformat(),
                "results": [{"url": f"https://allowed.example/{country}"}]}
    markets = [{"market_id": f"{code}-en", "country_code": code,
        "localization": {"selected_query": "finance"}} for code in ("US", "GB", "CA")]
    result = collect_market_serps(markets, provider=FakeSearch(), allowed_hosts=["allowed.example"], call_budget=2)
    assert result["status"] == "partial"
    assert result["attempted_calls"] == 2
    assert result["skipped_market_count"] == 1


def test_research_pipeline_rejects_nonstandard_ports_and_internal_hosts():
    now = datetime.now(timezone.utc).isoformat()
    for url, allowed in (("https://example.com:444/a", ["example.com"]),
                         ("https://127.0.0.1/a", ["127.0.0.1"]),
                         ("https://private.internal/a", ["private.internal"])):
        with pytest.raises(ValueError):
            build_research_pipeline([{"market_id": "US-en", "source_ref": url,
                "source_family": "serp", "observed_at": now, "metric": "rank", "value": 1}],
                allowed_hosts=allowed)


def test_experiment_requires_complete_observed_count_tuple_and_uses_alpha_confidence_level():
    with pytest.raises(ValueError, match="all four observed"):
        plan_proportion_experiment(baseline_rate=.05, minimum_detectable_effect=.01,
            baseline_successes=10, baseline_trials=100)
    result = plan_proportion_experiment(baseline_rate=.05, minimum_detectable_effect=.01,
        alpha=.01, expected_treatment_share=.4)
    assert result["confidence_level_pct"] == 99
    assert result["required_baseline_sample"] > result["required_treatment_sample"]


def test_direct_discovery_options_cannot_bypass_native_localization_review_gates():
    class FakeDiscovery:
        def discover(self, **kwargs):
            assert kwargs["localized_query_variants"]["US-en"]["review_status"] == "pending"
            return {"status": "ok", "market_count": 1, "markets": []}
    run_global_growth_engine({"topic": "finance", "market_discovery_options": {
        "localized_query_variants": {"US-en": {"queries": ["finance"], "review_status": "native_reviewed",
            "source_ref": "https://review.example/1", "reviewed_at": datetime.now(timezone.utc).isoformat()}}}},
        market_discovery_service=FakeDiscovery(), market_profiles=(object(),))


def test_research_allowlist_requires_bare_public_hostnames():
    now = datetime.now(timezone.utc).isoformat()
    record = [{"market_id": "US-en", "source_ref": "https://example.com/a", "source_family": "serp",
        "observed_at": now, "metric": "rank", "value": 1}]
    for host in ("https://example.com", "example.com/path", "example.com:8443", "localhost"):
        with pytest.raises(ValueError):
            build_research_pipeline(record, allowed_hosts=[host])


def test_engine_validates_payload_before_any_live_market_provider_call():
    called = {"value": False}
    class FakeDiscovery:
        def discover(self, **kwargs):
            called["value"] = True
            return {"status": "ok", "markets": []}
    with pytest.raises(ValueError, match="owner-authorized"):
        run_global_growth_engine({"topic": "coffee", "analytics": {"source": "untrusted", "views": 100}},
            market_discovery_service=FakeDiscovery(), market_profiles=(object(),))
    assert called["value"] is False


def test_execution_boundary_marks_only_explicit_or_configured_live_provider_calls():
    offline = run_global_growth_engine({"topic": "coffee"})
    live = run_global_growth_engine({"topic": "coffee"}, external_requests_made=True)
    assert offline["execution_boundary"]["external_requests_made"] is False
    assert live["execution_boundary"]["external_requests_made"] is True


def test_orchestrator_connects_discovery_to_bounded_web_serp_pipeline():
    class FakeDiscovery:
        def discover(self, **kwargs):
            return {"status": "ok", "markets": [{"market_id": "US-en", "country_code": "US",
                "localization": {"selected_query": "personal finance", "selected_query_source": "seed_only"}}]}
    class FakeSearch:
        def search(self, query, *, country, limit):
            return {"status": "ok", "observed_at": datetime.now(timezone.utc).isoformat(),
                "results": [{"url": "https://allowed.example/result", "title": "Research"}]}
    result = run_global_growth_engine({"topic": "personal finance", "allowed_hosts": ["allowed.example"]},
        market_discovery_service=FakeDiscovery(), market_profiles=(object(),), web_serp_provider=FakeSearch())
    assert result["execution_boundary"]["external_requests_made"] is True
    assert result["capabilities"]["research_pipeline"]["accepted_count"] == 1
    assert result["capabilities"]["research_pipeline"]["records"][0]["source_family"] == "firecrawl_web_serp"


def test_owner_country_rpm_is_attached_but_never_used_in_external_market_score():
    result = run_global_growth_engine({"topic": "finance", "markets": [{"market_id": "US-en", "country_code": "US",
        "rpm_currency": "USD", "reachable_monthly_views": 10000, "demand_score": 70,
        "competitive_gap": 60, "creator_fit": 80, "confidence": .7}],
        "country_rpm_evidence": [{"country": "US", "views": 1000, "estimatedRevenue": 8,
            "currency": "USD", "source": "owner_authorized_youtube_analytics"}]})
    market = result["capabilities"]["global_market"]["markets"][0]
    assert market["status"] == "insufficient_evidence"
    assert market["first_party_channel_rpm_evidence"]["rpm"] == 8
    assert market["used_first_party_rpm_in_opportunity_score"] is False
    assert market["first_party_channel_rpm_evidence"]["used_in_opportunity_score"] is False


def test_discovery_and_economics_are_joined_by_market_id_without_blending_scores():
    class FakeDiscovery:
        def discover(self, **kwargs):
            return {"status": "ok", "markets": [{"market_id": "US-en", "decision": {
                "status": "scored", "score": 81.5, "coverage": 1.0}, "ranking_eligible": True}]}
    result = run_global_growth_engine({"topic": "coffee", "markets": [{"market_id": "US-en", "country_code": "US",
        "rpm_currency": "USD", "rpm_base": 5, "reachable_monthly_views": 1000,
        "demand_score": 70, "competitive_gap": 60, "creator_fit": 80, "confidence": .7}]},
        market_discovery_service=FakeDiscovery(), market_profiles=(object(),))
    bridge = result["capabilities"]["global_market"]["discovery_economics_bridge"]
    assert bridge["matched_count"] == 1
    item = bridge["markets"][0]
    assert item["discovery_decision_score"] == 81.5
    assert item["economics_opportunity_score"] is not None
    assert item["scores_blended"] is False


def test_competitor_sample_metrics_are_sample_scoped_and_not_velocity():
    from v17_niche_intel.services.global_growth_engine import analyze_competitor_sample
    result = analyze_competitor_sample([
        {"video_id": "a", "channel_id": "c1", "views": 900, "published_at": "2026-11-04T00:00:00+00:00"},
        {"video_id": "b", "channel_id": "c1", "views": 100, "published_at": "2026-11-09T00:00:00+00:00"},
        {"video_id": "c", "channel_id": "c2", "views": 500, "published_at": "2026-11-10T00:00:00+00:00"},
    ], observed_at=datetime(2026, 11, 14, tzinfo=timezone.utc))
    assert result["sample_size"] == 3
    assert result["channel_count"] == 2
    assert result["channel_view_share_hhi"] > 0
    assert result["views_per_day_semantics"] == "lifetime_average_not_velocity"
    assert result["interpretation_scope"] == "sample_only_not_market_census"


def test_channel_kpis_expose_funnel_availability_without_claiming_satisfaction():
    result = calculate_channel_kpis({"source": "owner_authorized_youtube_analytics", "views": 100,
        "impressions": 1000, "impressions_clicks": 50, "clicks_semantics": "views_from_registered_impressions",
        "watch_time_minutes": 300, "average_view_percentage_pct": 45, "subscribers_gained": 2})
    assert result["funnel_diagnostics"]["packaging"]["value"] == 5
    assert result["funnel_diagnostics"]["consumption"]["status"] == "available"
    assert result["funnel_diagnostics"]["satisfaction"]["status"] == "not_measured_by_these_kpis"


def test_experiment_result_requires_human_guardrail_review_before_shipping():
    result = plan_proportion_experiment(baseline_rate=.05, minimum_detectable_effect=.01,
        baseline_successes=500, baseline_trials=10000, treatment_successes=650, treatment_trials=10000)
    assert result["guardrails_required"]
    assert result["ship_gate"] == "human_guardrail_review_required"


def test_learning_proposal_reports_calibration_and_holdout_gate():
    result = update_learning_proposal(predictions=list(range(1, 25)), actuals=list(range(2, 26)),
        current_policy_version="v17-policy-1", proposed_weights={"demand": .4, "fit": .6}, minimum_observations=20)
    assert result["calibration_status"] == "backtest_required"
    assert result["out_of_sample_validation_required"] is True
    assert result["holdout_required"] is True
    assert result["apply_allowed"] is False


def test_experiment_significant_negative_lift_is_not_a_ship_candidate():
    result = plan_proportion_experiment(baseline_rate=.05, minimum_detectable_effect=.01,
        baseline_successes=700, baseline_trials=10000, treatment_successes=500, treatment_trials=10000)
    assert result["status"] == "significant_negative_lift_review"
    assert result["ship_gate"] == "blocked"


def test_competitor_sample_skips_missing_public_view_counts_without_fabricating_zero():
    from v17_niche_intel.services.global_growth_engine import analyze_competitor_sample
    result = analyze_competitor_sample([{"video_id": "v1", "channel_id": "c1", "views": None,
        "published_at": "2026-11-10T00:00:00+00:00"}], observed_at=datetime(2026, 11, 14, tzinfo=timezone.utc))
    assert result["status"] == "insufficient_evidence"
    assert result["sample_size"] == 0
    assert result["excluded_or_invalid_count"] == 1


def test_competitor_sample_does_not_let_invalid_duplicate_hide_valid_public_row():
    from v17_niche_intel.services.global_growth_engine import analyze_competitor_sample
    rows = [
        {"video_id": "v1", "channel_id": "c1", "views": None, "published_at": "2026-11-10T00:00:00+00:00"},
        {"video_id": "v1", "channel_id": "c1", "views": 100, "published_at": "2026-11-10T00:00:00+00:00"},
    ]
    result = analyze_competitor_sample(rows, observed_at=datetime(2026, 11, 14, tzinfo=timezone.utc))
    assert result["sample_size"] == 1
    assert result["sampled_views"] == 100


def test_supplied_query_variants_preserve_native_review_only_when_localization_gates_pass():
    now = datetime.now(timezone.utc).isoformat()
    class FakeDiscovery:
        def discover(self, **kwargs):
            review = kwargs["localized_query_variants"]["US-en"]
            assert review["review_status"] == "native_reviewed"
            assert review["dialect_reviewed"] is True
            assert review["accent_reviewed"] is True
            assert review["cultural_reviewed"] is True
            return {"status": "ok", "markets": []}
    run_global_growth_engine({"topic": "finance", "localization": [{
        "market_id": "US-en", "locale": "en-US", "language": "en", "query_variants": ["personal finance"],
        "native_reviewed": True, "review_source_ref": "https://review.example/1", "reviewed_at": now,
        "dialect_reviewed": True, "accent_reviewed": True, "cultural_reviewed": True}],
        "market_discovery_options": {"localized_query_variants": {"US-en": {
            "queries": ["personal finance"], "review_status": "native_reviewed",
            "source_ref": "https://review.example/1", "reviewed_at": now}}}},
        market_discovery_service=FakeDiscovery(), market_profiles=(object(),))


def test_market_economics_rejects_owner_analytics_rpm_source_domain_blending():
    import pytest
    from v17_niche_intel.services.global_growth_engine import score_market_economics
    with pytest.raises(ValueError, match="must remain isolated"):
        score_market_economics([{"market_id": "US-en", "rpm_currency": "USD", "rpm_base": 8,
            "rpm_source": "owner_analytics_actual", "reachable_monthly_views": 10000,
            "demand_score": 70, "competitive_gap": 60, "creator_fit": 80, "confidence": .7}])
