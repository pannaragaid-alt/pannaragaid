import sys
import types
import pytest
from v17_niche_intel.credentials.oauth_flow import GoogleOAuthConsentFlow, ANALYTICS_READONLY_SCOPE, ANALYTICS_MONETARY_READONLY_SCOPE

VALID_CLIENT_CONFIG = {"installed": {"client_id": "test.apps.googleusercontent.com", "client_secret": "test-client-secret",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth", "token_uri": "https://oauth2.googleapis.com/token",
    "redirect_uris": ["http://localhost", "http://127.0.0.1"]}}


class FakeCredentials:
    scopes=[ANALYTICS_READONLY_SCOPE]
    token='access'; refresh_token='refresh'

class FakeFlow:
    credentials=FakeCredentials()
    class OAuthSession:
        def __init__(self):
            self.trust_env=True
            self.proxies={"https": "http://proxy.invalid"}
            self.verify=False
            self.cert="client-cert.pem"
            self.auth=("user", "password")
            self.cookies={"sid": "secret"}
            self.headers={"Authorization": "Bearer secret", "Cookie": "sid=secret"}
        def resolve_redirects(self, response, request, **kwargs): return iter(["followed"])
    def __init__(self,state): self.state=state; self.oauth2session=self.OAuthSession()
    def authorization_url(self,**kwargs): return 'https://accounts.google.com/o/oauth2/auth?state='+self.state, self.state
    def fetch_token(self,authorization_response): self.response=authorization_response

class FakeFlowClass:
    @staticmethod
    def from_client_config(config,scopes,state,redirect_uri,code_verifier):
        assert code_verifier
        return FakeFlow(state)


def test_oauth_state_is_single_use_and_callback_state_must_match(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG)
    auth=flow.begin()
    with pytest.raises(ValueError,match='state mismatch'):
        flow.complete(state=auth.state,authorization_response='http://127.0.0.1:8765/oauth2/callback?state=wrong&code=x')
    # A mismatched state is consumed and cannot be replayed.
    with pytest.raises(ValueError,match='already used'):
        flow.complete(state=auth.state,authorization_response='http://127.0.0.1:8765/oauth2/callback?state='+auth.state+'&code=x')


def test_oauth_requires_callback_state(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package); monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG); auth=flow.begin()
    with pytest.raises(ValueError): flow.complete(state=auth.state,authorization_response='http://127.0.0.1/callback?code=x')


def test_oauth_callback_must_match_registered_redirect_uri(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG); auth=flow.begin()
    callback=f'https://attacker.example/callback?state={auth.state}&code=x'
    with pytest.raises(ValueError, match='redirect URI'):
        flow.complete(state=auth.state,authorization_response=callback)


def test_oauth_provider_error_is_rejected(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG); auth=flow.begin()
    callback=f'http://127.0.0.1:8765/oauth2/callback?state={auth.state}&error=access_denied'
    with pytest.raises(PermissionError, match='denied'):
        flow.complete(state=auth.state,authorization_response=callback)


def test_oauth_consent_rejects_non_readonly_or_unapproved_scopes():
    flow=GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG)
    with pytest.raises(ValueError, match='read-only'):
        flow.begin(scopes=('https://www.googleapis.com/auth/youtube.upload',))


def test_oauth_state_expires_after_ten_minutes(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG); auth=flow.begin()
    pending=flow._pending[auth.state]
    flow._pending[auth.state]=(pending[0],pending[1],pending[2],0)
    with pytest.raises(ValueError, match='expired'):
        flow.complete(state=auth.state, authorization_response=f'http://127.0.0.1:8765/oauth2/callback?state={auth.state}&code=x')


def test_oauth_allows_monetary_analytics_scope_as_read_only(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow = GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG)
    auth = flow.begin(scopes=(ANALYTICS_READONLY_SCOPE, ANALYTICS_MONETARY_READONLY_SCOPE))
    assert auth.authorization_url.startswith("https://accounts.google.com/")


@pytest.mark.parametrize("redirect_uri", [
    "https:///oauth2/callback",
    "http://attacker.example/callback",
    "http://user@127.0.0.1:8765/oauth2/callback",
    "https://user@callback.example/oauth2/callback",
    "https://callback.example/oauth2/callback?next=https://attacker.example",
    "https://callback.example/oauth2/callback#fragment",
])
def test_oauth_constructor_rejects_malformed_or_credentialed_redirect_uris(redirect_uri):
    with pytest.raises(ValueError, match="redirect URI"):
        GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG, redirect_uri=redirect_uri)


def test_oauth_callback_rejects_duplicate_state_and_empty_authorization_code(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG)
    auth=flow.begin()
    duplicate=f'http://127.0.0.1:8765/oauth2/callback?state={auth.state}&state={auth.state}&code=x'
    with pytest.raises(ValueError, match="exactly one state"):
        flow.complete(state=auth.state, authorization_response=duplicate)
    flow=GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG)
    auth=flow.begin()
    empty=f'http://127.0.0.1:8765/oauth2/callback?state={auth.state}&code='
    with pytest.raises(ValueError, match="authorization code"):
        flow.complete(state=auth.state, authorization_response=empty)


@pytest.mark.parametrize("field,value", [
    ("token_uri", "http://127.0.0.1:8080/steal"),
    ("token_uri", "https://attacker.example.net/token"),
    ("auth_uri", "https://attacker.example.net/authorize"),
])
def test_oauth_rejects_untrusted_authorization_and_token_endpoints(field, value):
    config = {"installed": dict(VALID_CLIENT_CONFIG["installed"])}
    config["installed"][field] = value
    with pytest.raises(ValueError, match="Google OAuth endpoint"):
        GoogleOAuthConsentFlow(config)


def test_web_oauth_client_requires_exact_registered_https_redirect():
    web_config = {"web": {**VALID_CLIENT_CONFIG["installed"], "redirect_uris": ["https://app.example.com/oauth/callback"]}}
    GoogleOAuthConsentFlow(web_config, redirect_uri="https://app.example.com/oauth/callback")
    with pytest.raises(ValueError, match="registered HTTPS redirect"):
        GoogleOAuthConsentFlow(web_config, redirect_uri="https://attacker.example.net/oauth/callback")


def test_oauth_flow_hardens_library_session_before_authorization_and_token_exchange(monkeypatch):
    module=types.ModuleType('google_auth_oauthlib.flow'); module.Flow=FakeFlowClass
    package=types.ModuleType('google_auth_oauthlib'); package.flow=module
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib',package)
    monkeypatch.setitem(sys.modules,'google_auth_oauthlib.flow',module)
    flow=GoogleOAuthConsentFlow(VALID_CLIENT_CONFIG)
    auth=flow.begin()
    oauth_session=flow._pending[auth.state][0].oauth2session
    assert oauth_session.trust_env is False
    assert oauth_session.proxies == {}
    assert oauth_session.verify is True
    assert oauth_session.cert is None
    assert oauth_session.auth is None
    assert oauth_session.cookies == {}
    assert "Authorization" not in oauth_session.headers
    assert "Cookie" not in oauth_session.headers
