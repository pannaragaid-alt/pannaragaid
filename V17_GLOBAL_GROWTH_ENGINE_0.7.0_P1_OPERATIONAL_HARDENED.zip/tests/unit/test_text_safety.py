from v17_niche_intel.providers.text_safety import redact_basic_pii


def test_redact_basic_pii_masks_email_and_phone_without_changing_other_text():
    text = "Contact analyst@example.org or call +1 (555) 123-4567. Public topic: coffee roasting."
    result = redact_basic_pii(text)
    assert "analyst@example.org" not in result
    assert "+1 (555) 123-4567" not in result
    assert "[EMAIL]" in result and "[PHONE]" in result
    assert "coffee roasting" in result
