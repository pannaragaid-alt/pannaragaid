import tomllib
from pathlib import Path


def test_runtime_all_extra_excludes_build_and_security_scanners():
    project = tomllib.loads((Path(__file__).parents[2] / "pyproject.toml").read_text())
    extras = project["project"]["optional-dependencies"]
    all_deps = extras["all"]
    assert not any(dep.lower().startswith(("pytest", "ruff", "jsonschema", "bandit", "pip-audit", "semgrep"))
                   for dep in all_deps)
    assert not any("deep-translator" in dep.lower() for dep in all_deps)
    assert any(dep.startswith("Pillow>=13") for dep in all_deps)
    assert any(dep.startswith("cryptography>=50") for dep in all_deps)


def test_security_scanners_remain_isolated_in_security_extra():
    project = tomllib.loads((Path(__file__).parents[2] / "pyproject.toml").read_text())
    security = project["project"]["optional-dependencies"]["security"]
    assert any(dep.startswith("bandit") for dep in security)
    assert any(dep.startswith("pip-audit") for dep in security)
    assert any(dep.startswith("semgrep") for dep in security)


def test_build_backend_requires_patched_setuptools():
    project = tomllib.loads((Path(__file__).parents[2] / "pyproject.toml").read_text())
    build_requires = project["build-system"]["requires"]
    assert any(requirement.startswith("setuptools>=84.1.0") for requirement in build_requires)
