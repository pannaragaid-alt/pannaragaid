from pathlib import Path


ROOT = Path(__file__).parents[2]
ACCEPTANCE = ROOT / "docs" / "P1_OPERATIONAL_ACCEPTANCE.md"


def test_p1_acceptance_lists_all_seven_gates_and_requires_all_of_them():
    content = ACCEPTANCE.read_text(encoding="utf-8")
    gates = [line for line in content.splitlines() if line.startswith("## ")]
    assert gates == [
        "## 1. Backup and restore",
        "## 2. Runtime supervision and recovery",
        "## 3. Logs, metrics, dashboards, and alerting",
        "## 4. Authentication, authorization, and public exposure",
        "## 5. Staging integration, load, and resilience",
        "## 6. Rollback and change management",
        "## 7. Repository governance and CI enforcement",
        "## Evidence register",
        "## P1 exit criteria",
    ]
    assert "all seven gates pass" in content
