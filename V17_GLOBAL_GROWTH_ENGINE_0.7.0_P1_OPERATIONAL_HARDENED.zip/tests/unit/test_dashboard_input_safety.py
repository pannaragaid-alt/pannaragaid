import pytest

from v17_niche_intel.ui.input_safety import parse_bounded_json


def test_parse_bounded_json_accepts_small_valid_document():
    assert parse_bounded_json('{"markets": ["ID", "US"]}') == {"markets": ["ID", "US"]}


def test_parse_bounded_json_rejects_non_string_payload():
    with pytest.raises(ValueError, match="text"):
        parse_bounded_json(None)


def test_parse_bounded_json_rejects_payload_over_byte_limit():
    with pytest.raises(ValueError, match="byte limit"):
        parse_bounded_json('{"x":"12345"}', max_bytes=8)


def test_parse_bounded_json_rejects_excessive_nesting_before_decode():
    with pytest.raises(ValueError, match="nesting limit"):
        parse_bounded_json("[" * 5 + "0" + "]" * 5, max_depth=4)


def test_parse_bounded_json_ignores_brackets_inside_json_strings():
    assert parse_bounded_json('{"value": "[[[["}') == {"value": "[[[["}


def test_parse_bounded_json_handles_escaped_quotes_and_backslashes():
    assert parse_bounded_json(r'{"value": "quote: \\\" and bracket: ]"}') == {"value": 'quote: \\" and bracket: ]'}


def test_parse_bounded_json_counts_utf8_bytes_not_code_points():
    with pytest.raises(ValueError, match="byte limit"):
        parse_bounded_json('{"x":"é"}', max_bytes=9)


def test_parse_bounded_json_default_depth_limit_is_enforced():
    nested = "[" * 65 + "0" + "]" * 65
    with pytest.raises(ValueError, match="nesting limit"):
        parse_bounded_json(nested)


def test_parse_bounded_json_rejects_invalid_surrogate_text():
    with pytest.raises(ValueError, match="invalid Unicode"):
        parse_bounded_json('"\\ud800"' + "\ud800")


def test_parse_bounded_json_rejects_duplicate_object_keys():
    with pytest.raises(ValueError, match="duplicate object key"):
        parse_bounded_json('{"role":"reader","role":"admin"}')


def test_parse_bounded_json_rejects_nonstandard_nan_and_infinity():
    for value in ("NaN", "Infinity", "-Infinity"):
        with pytest.raises(ValueError, match="non-finite"):
            parse_bounded_json(value)


def test_load_bounded_json_file_reads_only_the_configured_limit(tmp_path):
    from v17_niche_intel.ui.input_safety import load_bounded_json_file

    source = tmp_path / "payload.json"
    source.write_bytes(b'{"value":"12345"}')
    with pytest.raises(ValueError, match="byte limit"):
        load_bounded_json_file(source, max_bytes=8)


def test_load_bounded_json_file_decodes_utf8_and_parses(tmp_path):
    from v17_niche_intel.ui.input_safety import load_bounded_json_file

    source = tmp_path / "payload.json"
    source.write_bytes('{"market":"Indonesia"}'.encode("utf-8"))
    assert load_bounded_json_file(source) == {"market": "Indonesia"}


def test_load_bounded_json_file_rejects_invalid_utf8(tmp_path):
    from v17_niche_intel.ui.input_safety import load_bounded_json_file

    source = tmp_path / "payload.json"
    source.write_bytes(b'{"value":"\xff"}')
    with pytest.raises(ValueError, match="UTF-8"):
        load_bounded_json_file(source)
