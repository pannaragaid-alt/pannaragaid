import csv

from v17_niche_intel.services.reporting import export_report


def test_csv_export_neutralizes_spreadsheet_formulas_in_untrusted_text(tmp_path):
    payload = {
        "videos": [{
            "video_id": "=HYPERLINK(\"https://attacker.example\")",
            "title": "\t=cmd|' /C calc'!A0",
            "channel_id": "+SUM(1,1)",
            "published_at": "@SUM(1,1)",
            "views": 12,
            "format": {"label": "-1+1"},
        }]
    }
    target = tmp_path / "export.csv"
    export_report(payload, target, format="csv")
    with target.open(newline="", encoding="utf-8") as stream:
        row = next(csv.DictReader(stream))
    assert row["video_id"].startswith("'=")
    assert row["title"].startswith("'\t=")
    assert row["channel_id"].startswith("'+")
    assert row["published_at"].startswith("'@")
    assert row["format"].startswith("'-")
    assert row["views"] == "12"


def test_csv_export_preserves_safe_text_and_numeric_values(tmp_path):
    payload = {"videos": [{"video_id": "UCabc123", "title": "Coffee guide", "channel_id": "UCxyz",
        "published_at": "2026-01-01", "views": 12, "format": {"label": "Long-form"}}]}
    target = tmp_path / "safe.csv"
    export_report(payload, target, format="csv")
    with target.open(newline="", encoding="utf-8") as stream:
        row = next(csv.DictReader(stream))
    assert row["title"] == "Coffee guide"
    assert row["views"] == "12"


def test_private_report_export_uses_owner_only_file_permissions(tmp_path):
    import os
    import stat
    if os.name != "posix":
        return
    target = tmp_path / "private.json"
    export_report({"private": "owner analytics"}, target, format="json")
    assert stat.S_IMODE(target.stat().st_mode) == 0o600


def test_markdown_export_escapes_untrusted_html_and_markdown_structure(tmp_path):
    payload = {
        "run": {"topic": "<img src=x onerror=alert(1)>\n## injected", "id": "`bad`", "mode": "test", "country_code": "US"},
        "analysis": {"status": "ok", "coverage": 1.0},
        "providers": {"<script>alert(1)</script>": {"status": "ok"}},
        "videos": [{"title": "[click](https://attacker.example)\n- injected", "format": {"label": "Long"}, "views": 1}],
        "limitations": ["<svg onload=alert(1)>"]
    }
    target = tmp_path / "report.md"
    export_report(payload, target, format="md")
    content = target.read_text(encoding="utf-8")
    assert "<img" not in content and "<script" not in content and "<svg" not in content
    assert "## injected" not in content
    assert "[click]" not in content
    assert "\\`bad\\`" in content
