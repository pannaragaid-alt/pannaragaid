import pytest

from v17_niche_intel.config import positive_int_setting, youtube_quota_limits


def test_positive_int_setting_uses_default_when_missing_or_blank():
    assert positive_int_setting("LIMIT", 10, environ={}) == 10
    assert positive_int_setting("LIMIT", 10, environ={"LIMIT": "  "}) == 10


@pytest.mark.parametrize("raw", ["0", "-1", "+1", "1.5", "abc", "1e3", "١٢"])
def test_positive_int_setting_rejects_invalid_values(raw):
    with pytest.raises(ValueError):
        positive_int_setting("LIMIT", 10, environ={"LIMIT": raw})


def test_positive_int_setting_enforces_upper_bound():
    with pytest.raises(ValueError, match="between 1 and 10"):
        positive_int_setting("LIMIT", 10, maximum=10, environ={"LIMIT": "11"})


def test_youtube_quota_limits_validate_both_independent_buckets():
    assert youtube_quota_limits(environ={}) == (10_000, 100)
    assert youtube_quota_limits(environ={"YOUTUBE_DAILY_QUOTA_LIMIT": "8000",
                                         "YOUTUBE_SEARCH_DAILY_LIMIT": "60"}) == (8000, 60)
    with pytest.raises(ValueError, match="YOUTUBE_SEARCH_DAILY_LIMIT"):
        youtube_quota_limits(environ={"YOUTUBE_SEARCH_DAILY_LIMIT": "invalid"})
