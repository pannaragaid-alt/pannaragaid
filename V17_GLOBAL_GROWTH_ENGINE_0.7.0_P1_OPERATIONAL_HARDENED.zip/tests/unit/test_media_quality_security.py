import pytest

from v17_niche_intel.providers import media_quality


def test_thumbnail_rejects_decompression_bomb_dimensions_before_decode(tmp_path, monkeypatch):
    from PIL import Image
    path = tmp_path / "oversized.png"
    path.write_bytes(b"fixture")
    class FakeImage:
        size = (100_000, 100_000)
        format = "PNG"
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def verify(self): raise AssertionError("verify must not run for oversized dimensions")
    monkeypatch.setattr(Image, "open", lambda target: FakeImage())
    with pytest.raises(ValueError, match="pixel limit"):
        media_quality.measure_thumbnail_file(path)


def test_audio_rejects_excessive_decoded_sample_count_before_read(tmp_path, monkeypatch):
    import soundfile as sf
    path = tmp_path / "large.flac"
    path.write_bytes(b"fixture")
    class Info:
        channels = 8
        samplerate = 192000
        duration = 60
        frames = 192000 * 60
    monkeypatch.setattr(sf, "info", lambda target: Info())
    monkeypatch.setattr(sf, "read", lambda *args, **kwargs: (_ for _ in ()).throw(AssertionError("audio must not be decoded")))
    with pytest.raises(ValueError, match="sample-count limit"):
        media_quality.measure_audio_file(path)
