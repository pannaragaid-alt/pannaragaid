from pathlib import Path


SERVICE = Path(__file__).parents[2] / "deploy" / "systemd" / "v17-dashboard.service"


def test_dashboard_service_binds_only_to_loopback_and_keeps_public_auth_gate():
    content = SERVICE.read_text(encoding="utf-8")
    assert "--server.address 127.0.0.1" in content
    assert "--server.enableXsrfProtection true" in content
    assert "--server.enableCORS true" in content
    assert "--server.address 0.0.0.0" not in content


def test_dashboard_service_has_bounded_supervision_and_resource_controls():
    content = SERVICE.read_text(encoding="utf-8")
    for directive in (
        "Restart=on-failure",
        "RestartSec=5s",
        "StartLimitIntervalSec=300s",
        "StartLimitBurst=5",
        "TimeoutStopSec=30s",
        "MemoryMax=2G",
        "CPUQuota=200%",
        "TasksMax=128",
        "NoNewPrivileges=yes",
        "ProtectSystem=strict",
        "ProtectHome=yes",
    ):
        assert directive in content


def test_dashboard_service_uses_dedicated_identity_and_private_database_path():
    content = SERVICE.read_text(encoding="utf-8")
    assert "User=v17" in content
    assert "Group=v17" in content
    assert "V17_DATABASE=/var/lib/v17/v17_niche_intel.sqlite3" in content
    assert "ReadWritePaths=/var/lib/v17" in content
