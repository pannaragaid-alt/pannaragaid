import pytest

from v17_niche_intel.credentials.secrets import CompositeSecretStore, EnvironmentSecretStore


def test_empty_environment_prefix_requires_an_exact_name_allowlist(monkeypatch):
    monkeypatch.setenv("YOUTUBE_API_KEY", "youtube-key")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "must-not-be-readable")
    store = EnvironmentSecretStore(prefix="", allowed_names={"YOUTUBE_API_KEY"})
    assert store.get("env://YOUTUBE_API_KEY") == "youtube-key"
    with pytest.raises(KeyError):
        store.get("env://AWS_SECRET_ACCESS_KEY")
    with pytest.raises(KeyError):
        store.get("AWS_SECRET_ACCESS_KEY")


def test_empty_environment_prefix_without_allowlist_is_rejected():
    with pytest.raises(ValueError, match="allowlist"):
        EnvironmentSecretStore(prefix="")


def test_composite_store_default_environment_namespace_is_scoped(monkeypatch):
    monkeypatch.setenv("V17_SECRET_ALLOWED", "ok")
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "blocked")
    store = CompositeSecretStore()
    assert store.get("env://V17_SECRET_ALLOWED") == "ok"
    with pytest.raises(KeyError):
        store.get("env://AWS_SECRET_ACCESS_KEY")
