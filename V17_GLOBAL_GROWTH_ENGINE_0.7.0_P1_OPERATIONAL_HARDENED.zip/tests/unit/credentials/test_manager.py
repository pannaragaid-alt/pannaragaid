from __future__ import annotations

import pytest

from v17_niche_intel.credentials import (
    CredentialManager,
    MemorySecretStore,
    QuotaExhaustedError,
    CredentialUnavailableError,
)
from v17_niche_intel.storage.database import Database


def make_manager():
    db = Database(":memory:")
    secrets = MemorySecretStore()
    return db, secrets, CredentialManager(db, secrets)


def test_api_keys_from_distinct_projects_are_registered_and_selected_by_use_case():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a")
    manager.add_api_key("key-b", project_id="project-b", use_case="research-b", environment="prod", secret="secret-b")

    selected = manager.select_api_key(use_case="research-b", environment="prod")
    assert selected.credential_id == "key-b"
    assert secrets.get(selected.secret_ref) == "secret-b"
    db.close()


def test_api_key_rotation_never_switches_project_after_quota_exhaustion():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a1", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a1")
    manager.add_api_key("key-a2", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a2")
    manager.add_api_key("key-b", project_id="project-b", use_case="research-b", environment="prod", secret="secret-b")

    manager.record_project_quota("project-a", used=100, limit=100, use_case="research-a")
    with pytest.raises(QuotaExhaustedError):
        manager.select_api_key(use_case="research-a", environment="prod")
    db.close()


def test_invalid_key_can_rotate_within_same_project():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a1", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a1")
    manager.add_api_key("key-a2", project_id="project-a", use_case="research-a", environment="prod", secret="secret-a2")
    manager.set_api_key_status("key-a1", "invalid")

    selected = manager.select_api_key(use_case="research-a", environment="prod")
    assert selected.credential_id == "key-a2"
    db.close()


def test_oauth_selection_is_bound_to_authorized_channel_and_scopes():
    db, secrets, manager = make_manager()
    manager.add_oauth_account(
        "google-1", account_label="owner-one", secret_access_token="access-one",
        secret_refresh_token="refresh-one", scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_ONE"},
    )
    manager.add_oauth_account(
        "google-2", account_label="owner-two", secret_access_token="access-two",
        secret_refresh_token="refresh-two", scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_TWO"},
    )

    selected = manager.select_oauth_account("UC_TWO", required_scopes={"https://www.googleapis.com/auth/youtube.readonly"})
    assert selected.account_id == "google-2"
    assert secrets.get(selected.access_token_ref) == "access-two"
    with pytest.raises(ValueError, match="approved read-only"):
        manager.select_oauth_account("UC_TWO", required_scopes={"https://www.googleapis.com/auth/youtube.upload"})
    db.close()


def test_oauth_revocation_blocks_account_selection():
    db, secrets, manager = make_manager()
    manager.add_oauth_account(
        "google-1", account_label="owner", secret_access_token="access",
        secret_refresh_token="refresh", scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_ONE"},
    )
    manager.set_oauth_status("google-1", "revoked")
    with pytest.raises(CredentialUnavailableError):
        manager.select_oauth_account("UC_ONE", required_scopes={"https://www.googleapis.com/auth/youtube.readonly"})
    db.close()


def test_secret_values_are_not_persisted_in_sqlite_metadata():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a", project_id="project-a", use_case="research-a", environment="prod", secret="TOP_SECRET")
    rows = db.connection.execute("SELECT * FROM api_credentials").fetchall()
    assert "TOP_SECRET" not in repr([dict(row) for row in rows])
    db.close()


def test_same_use_case_cannot_be_routed_across_multiple_projects():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a", project_id="project-a", use_case="shared", environment="prod", secret="a")
    manager.add_api_key("key-b", project_id="project-b", use_case="shared", environment="prod", secret="b")
    with pytest.raises(CredentialUnavailableError, match="Ambiguous project route"):
        manager.select_api_key(use_case="shared", environment="prod")
    db.close()


def test_expired_oauth_access_token_can_be_selected_for_refresh():
    db, secrets, manager = make_manager()
    manager.add_oauth_account(
        "google-expired", account_label="owner", secret_access_token="old-access",
        secret_refresh_token="refresh", scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_ONE"},
        expires_at="2000-01-01T00:00:00+00:00",
    )
    selected = manager.select_oauth_account("UC_ONE", required_scopes={"https://www.googleapis.com/auth/youtube.readonly"})
    assert selected.account_id == "google-expired"
    db.close()


def test_project_quota_units_are_shared_across_all_keys_in_project():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-1", project_id="project-a", use_case="research", environment="prod", secret="one")
    manager.add_api_key("key-2", project_id="project-a", use_case="research", environment="prod", secret="two")
    assert manager.consume_project_quota("project-a", units=90, limit=100, use_case="research") == 90
    with pytest.raises(QuotaExhaustedError):
        manager.consume_project_quota("project-a", units=11, limit=100, use_case="research")
    db.close()


def test_oauth_client_id_is_persisted_as_non_secret_metadata():
    db, secrets, manager = make_manager()
    manager.add_oauth_account(
        "google-client", account_label="owner", secret_access_token="access",
        secret_refresh_token="refresh", client_secret_ref=secrets.put("client-secret"),
        client_id="client-id.apps.googleusercontent.com", scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_ONE"},
    )
    row = db.connection.execute("SELECT client_id FROM oauth_accounts WHERE account_id='google-client'").fetchone()
    assert row["client_id"] == "client-id.apps.googleusercontent.com"
    db.close()


def test_project_quota_is_shared_across_distinct_use_cases_in_same_project():
    db, secrets, manager = make_manager()
    manager.add_api_key("key-a", project_id="shared-project", use_case="market-entry", environment="prod", secret="a")
    manager.add_api_key("key-b", project_id="shared-project", use_case="channel-audit", environment="prod", secret="b")
    assert manager.consume_project_quota("shared-project", units=80, limit=100, use_case="market-entry") == 80
    with pytest.raises(QuotaExhaustedError):
        manager.consume_project_quota("shared-project", units=21, limit=100, use_case="channel-audit")
    db.close()


def test_revoked_oauth_account_cannot_be_manually_reactivated():
    db, secrets, manager = make_manager()
    manager.add_oauth_account("revoked", account_label="owner", secret_access_token="access",
        secret_refresh_token="refresh", scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_ONE"})
    manager.set_oauth_status("revoked", "revoked")
    with pytest.raises(ValueError, match="terminal"):
        manager.set_oauth_status("revoked", "active")
    db.close()


def test_reauth_required_oauth_account_cannot_be_manually_reactivated():
    db, secrets, manager = make_manager()
    manager.add_oauth_account("reauth", account_label="owner", secret_access_token="access",
        secret_refresh_token="refresh", scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_ONE"})
    manager.set_oauth_status("reauth", "reauth_required")
    with pytest.raises(ValueError, match="new consent flow"):
        manager.set_oauth_status("reauth", "active")
    db.close()


def test_search_list_has_its_own_100_calls_daily_bucket_separate_from_general_units():
    db, secrets, manager = make_manager()
    assert manager.consume_project_quota("project-a", units=100, limit=100,
        use_case="research", bucket="search.list") == 100
    with pytest.raises(QuotaExhaustedError, match="search.list"):
        manager.consume_project_quota("project-a", units=1, limit=100,
            use_case="channel-audit", bucket="search.list")
    # The general 10,000-unit bucket remains independent.
    assert manager.consume_project_quota("project-a", units=9999, limit=10000,
        use_case="research", bucket="default") == 9999
    db.close()


def test_quota_inventory_reports_both_daily_buckets():
    db, secrets, manager = make_manager()
    manager.consume_project_quota("project-a", units=3, limit=10000, use_case="research")
    manager.consume_project_quota("project-a", units=2, limit=100, use_case="research", bucket="search.list")
    rows = manager.quota_inventory()
    assert {row["bucket"] for row in rows} == {"general", "search.list"}
    db.close()


def test_configured_project_quota_limit_can_reflect_an_approved_increase():
    db, secrets, manager = make_manager()
    manager.consume_project_quota("project-a", units=100, limit=100, use_case="research")
    assert manager.consume_project_quota("project-a", units=50, limit=200, use_case="research") == 150
    db.close()


def test_quota_day_uses_midnight_pacific_reset_boundary():
    from datetime import datetime
    from zoneinfo import ZoneInfo
    expected = datetime.now(ZoneInfo("America/Los_Angeles")).date().isoformat()
    assert CredentialManager._quota_date() == expected


def test_monetary_analytics_scope_is_required_for_revenue_reports():
    db, secrets, manager = make_manager()
    manager.add_oauth_account("readonly", account_label="owner", secret_access_token="a",
        secret_refresh_token="r", scopes={"https://www.googleapis.com/auth/yt-analytics.readonly"}, channel_ids={"UC_ONE"})
    manager.add_oauth_account("monetary", account_label="owner-revenue", secret_access_token="b",
        secret_refresh_token="s", scopes={"https://www.googleapis.com/auth/yt-analytics.readonly",
            "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"}, channel_ids={"UC_TWO"})
    required = {"https://www.googleapis.com/auth/yt-analytics.readonly",
                "https://www.googleapis.com/auth/yt-analytics-monetary.readonly"}
    with pytest.raises(CredentialUnavailableError):
        manager.select_oauth_account("UC_ONE", required_scopes=required)
    assert manager.select_oauth_account("UC_TWO", required_scopes=required).account_id == "monetary"
    db.close()


def test_oauth_revocation_disables_environment_proxy_and_never_follows_redirect(monkeypatch):
    import urllib.request
    db, secrets, manager = make_manager()
    manager.add_oauth_account("google-revoke", account_label="owner", secret_access_token="access-token",
        secret_refresh_token="refresh-token", scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_ONE"})
    captured = {}
    class Response:
        status = 200
        def __enter__(self): return self
        def __exit__(self, *args): return False
    class Opener:
        def open(self, request, timeout):
            captured["url"] = request.full_url
            captured["body"] = request.data
            captured["timeout"] = timeout
            return Response()
    def build_opener(*handlers):
        captured["handlers"] = handlers
        return Opener()
    monkeypatch.setattr(urllib.request, "build_opener", build_opener)
    manager.revoke_oauth_account("google-revoke")
    assert captured["url"] == "https://oauth2.googleapis.com/revoke"
    assert b"refresh-token" in captured["body"]
    assert any(isinstance(handler, urllib.request.ProxyHandler) and handler.proxies == {} for handler in captured["handlers"])
    redirect_handler = next(handler for handler in captured["handlers"] if handler.__class__.__name__ == "_NoRedirectHandler")
    request = urllib.request.Request("https://oauth2.googleapis.com/revoke")
    assert redirect_handler.redirect_request(request, None, 307, "Temporary Redirect", {}, "https://attacker.example.net/") is None
    row = db.connection.execute("SELECT status FROM oauth_accounts WHERE account_id='google-revoke'").fetchone()
    assert row["status"] == "revoked"
    db.close()


def test_oauth_revocation_redirect_failure_keeps_local_tokens_and_account_active(monkeypatch):
    import urllib.error
    import urllib.request
    db, secrets, manager = make_manager()
    manager.add_oauth_account("google-revoke-redirect", account_label="owner", secret_access_token="access-token",
        secret_refresh_token="refresh-token", scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_ONE"})
    def build_opener(*handlers):
        class Opener:
            def open(self, request, timeout):
                raise urllib.error.HTTPError(request.full_url, 307, "redirect refused", {}, None)
        return Opener()
    monkeypatch.setattr(urllib.request, "build_opener", build_opener)
    with pytest.raises(urllib.error.HTTPError):
        manager.revoke_oauth_account("google-revoke-redirect")
    row = db.connection.execute("SELECT status,refresh_token_ref FROM oauth_accounts WHERE account_id='google-revoke-redirect'").fetchone()
    assert row["status"] == "active"
    assert secrets.get(row["refresh_token_ref"]) == "refresh-token"
    db.close()


def test_google_oauth_refresh_rejects_non_google_token_endpoint_before_loading_credentials():
    db, secrets, manager = make_manager()
    with pytest.raises(ValueError, match="official HTTPS endpoint"):
        manager.build_google_oauth_credentials("missing-account", token_uri="https://attacker.example.net/token")
    db.close()


def test_credential_manager_rejects_write_scopes_even_when_oauth_is_added_directly():
    db, secrets, manager = make_manager()
    with pytest.raises(ValueError, match="read-only"):
        manager.add_oauth_account("write-scope", account_label="owner", secret_access_token="access",
            secret_refresh_token="refresh", scopes={"https://www.googleapis.com/auth/youtube.upload"},
            channel_ids={"UC_OWNER"})
    db.close()


def test_credential_manager_rejects_write_scopes_when_selecting_existing_oauth():
    db, secrets, manager = make_manager()
    with pytest.raises(ValueError, match="read-only"):
        manager.select_oauth_account("UC_OWNER", required_scopes={"https://www.googleapis.com/auth/youtube.upload"})
    db.close()


def test_analytics_api_client_uses_no_redirect_direct_authorized_transport(monkeypatch):
    import sys
    import types
    from v17_niche_intel.providers.youtube_analytics import READONLY_SCOPE
    db, secrets, manager = make_manager()
    client_secret_ref = secrets.put("google-client-secret")
    manager.add_oauth_account("analytics-secure", account_label="owner", secret_access_token="old-access",
        secret_refresh_token="refresh-token", client_secret_ref=client_secret_ref,
        client_id="test.apps.googleusercontent.com", scopes={READONLY_SCOPE}, channel_ids={"UC_ONE"})
    captured = {}
    class FakeRequest:
        def __init__(self, session):
            self.session = session
            captured["refresh_session"] = session
    class FakeCredentials:
        def __init__(self, **kwargs):
            self.token = None
            self.expiry = None
        def refresh(self, request):
            assert request.session.trust_env is False
            assert request.session.proxies == {}
            assert request.session.verify is True
            self.token = "new-access-token"
    class FakeAuthorizedHttp:
        def __init__(self, credentials, http):
            self.http = http
            captured["authorized_http"] = self
            captured["credentials"] = credentials
    class FakeHttp:
        def __init__(self, **kwargs): captured["http_init"] = kwargs
        def request(self, uri, method="GET", body=None, headers=None, redirections=5, connection_type=None):
            captured["redirections"] = redirections
            return {"status": "200"}, b"ok"
    def fake_build(service, version, *, http, cache_discovery):
        captured["build"] = (service, version, http, cache_discovery)
        return "analytics-client"
    google = types.ModuleType("google"); google.__path__ = []
    auth = types.ModuleType("google.auth"); auth.__path__ = []
    transport = types.ModuleType("google.auth.transport"); transport.__path__ = []
    request_module = types.ModuleType("google.auth.transport.requests"); request_module.Request = FakeRequest
    oauth2 = types.ModuleType("google.oauth2"); oauth2.__path__ = []
    credentials_module = types.ModuleType("google.oauth2.credentials"); credentials_module.Credentials = FakeCredentials
    auth_httplib2 = types.ModuleType("google_auth_httplib2"); auth_httplib2.AuthorizedHttp = FakeAuthorizedHttp
    googleapiclient = types.ModuleType("googleapiclient"); googleapiclient.__path__ = []
    discovery = types.ModuleType("googleapiclient.discovery"); discovery.build = fake_build
    httplib2 = types.ModuleType("httplib2"); httplib2.Http = FakeHttp
    modules = {
        "google": google, "google.auth": auth, "google.auth.transport": transport,
        "google.auth.transport.requests": request_module, "google.oauth2": oauth2,
        "google.oauth2.credentials": credentials_module, "google_auth_httplib2": auth_httplib2,
        "googleapiclient": googleapiclient, "googleapiclient.discovery": discovery, "httplib2": httplib2,
    }
    for name, module in modules.items(): monkeypatch.setitem(sys.modules, name, module)
    result = manager.build_youtube_analytics_client("UC_ONE", required_scopes={READONLY_SCOPE})
    assert result == "analytics-client"
    assert captured["http_init"] == {"timeout": 30, "proxy_info": None, "disable_ssl_certificate_validation": False}
    captured["authorized_http"].http.request("https://youtubeanalytics.googleapis.com/v2/reports")
    assert captured["redirections"] == 0
    assert captured["build"] == ("youtubeAnalytics", "v2", captured["authorized_http"], False)
    db.close()


def test_credential_manager_rejects_unapproved_environment_secret_references():
    db, secrets, manager = make_manager()
    with pytest.raises(ValueError, match="secret reference"):
        manager.add_api_key("bad-env", project_id="project", use_case="research", environment="prod",
                            secret_ref="env://AWS_SECRET_ACCESS_KEY")
    with pytest.raises(ValueError, match="secret reference"):
        manager.add_oauth_account("bad-oauth-ref", account_label="owner",
            access_token_ref="env://AWS_SECRET_ACCESS_KEY", secret_refresh_token="refresh-token",
            scopes={"https://www.googleapis.com/auth/youtube.readonly"}, channel_ids={"UC_OWNER"})
    db.close()
