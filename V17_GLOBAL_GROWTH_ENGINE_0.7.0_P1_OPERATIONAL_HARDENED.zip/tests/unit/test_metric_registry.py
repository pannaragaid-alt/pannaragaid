import pytest

from v17_niche_intel.services.metric_registry import (
    METRIC_REGISTRY,
    plan_daily_analytics_query,
    plan_country_analytics_query,
)


def test_registry_has_versioned_definitions_and_units():
    assert METRIC_REGISTRY.version
    views = METRIC_REGISTRY.get("views")
    assert views.api_name == "views"
    assert views.unit == "views"
    assert views.denominator is None


def test_daily_query_plan_accepts_current_provider_defaults():
    plan = plan_daily_analytics_query(
        "views,estimatedMinutesWatched,averageViewDuration,likes,comments"
    )
    assert plan.endpoint == "reports.query.daily"
    assert plan.dimensions == ("day",)
    assert len(plan.metrics) == 5


def test_daily_query_plan_rejects_unknown_and_duplicate_metrics():
    with pytest.raises(ValueError, match="unsupported Analytics metric"):
        plan_daily_analytics_query("views,secretMetric")
    with pytest.raises(ValueError, match="duplicate"):
        plan_daily_analytics_query("views,views")


def test_daily_query_plan_rejects_invalid_video_dimension_combination():
    with pytest.raises(ValueError, match="video dimension"):
        plan_daily_analytics_query("estimatedRevenue", video_ids=("video-1", "video-2"), allow_video_dimension=False)


def test_country_query_plan_declares_monetary_scope_and_compatibility():
    plan = plan_country_analytics_query("views,estimatedRevenue")
    assert plan.dimensions == ("country",)
    assert "yt-analytics-monetary.readonly" in " ".join(plan.required_scopes)
    with pytest.raises(ValueError, match="unsupported"):
        plan_country_analytics_query("averageViewDuration")


def test_reach_metrics_are_not_planned_through_analytics_query():
    with pytest.raises(ValueError, match="unsupported Analytics metric"):
        plan_daily_analytics_query("views,videoThumbnailImpressions")


def test_engaged_views_is_a_first_class_analytics_metric():
    metric = METRIC_REGISTRY.get("engagedViews")
    assert metric.api_name == "engagedViews"
    assert metric.unit == "views"
    assert metric.denominator is None
    assert plan_daily_analytics_query("views,engagedViews").metrics == ("views", "engagedViews")


def test_reporting_reach_planner_uses_bulk_report_contract():
    from v17_niche_intel.services.metric_registry import plan_reporting_reach_report
    plan = plan_reporting_reach_report()
    assert plan.endpoint == "reporting.jobs"
    assert plan.report_family == "reach"
    assert plan.metrics == ("video_thumbnail_impressions", "video_thumbnail_impressions_ctr")


def test_metric_registry_catalog_version_is_immutable():
    with pytest.raises(AttributeError):
        METRIC_REGISTRY.version = "tampered"
