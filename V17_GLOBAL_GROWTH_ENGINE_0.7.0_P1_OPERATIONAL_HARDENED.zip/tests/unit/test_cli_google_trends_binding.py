from v17_niche_intel import cli
from v17_niche_intel.providers.google_trends import GoogleTrendsProvider


def test_cli_exposes_google_trends_provider_for_cli_paths():
    assert cli.GoogleTrendsProvider is GoogleTrendsProvider
