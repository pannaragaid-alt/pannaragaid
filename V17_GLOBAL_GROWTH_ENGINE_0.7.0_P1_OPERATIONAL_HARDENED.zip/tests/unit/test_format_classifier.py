from v17_niche_intel.domain.format_classifier import classify_video_format


def test_live_now_takes_precedence_over_short_duration():
    result = classify_video_format(
        duration_seconds=90,
        live_broadcast_content="live",
        live_streaming_details={"actualStartTime": "2026-11-11T09:00:00Z"},
    )
    assert result.label == "live_now"
    assert result.confidence == "high"


def test_upcoming_live_is_classified_from_live_metadata():
    result = classify_video_format(
        duration_seconds=120,
        live_broadcast_content="upcoming",
        live_streaming_details={"scheduledStartTime": "2026-11-12T09:00:00Z"},
    )
    assert result.label == "upcoming_live"


def test_completed_live_uses_actual_end_time():
    result = classify_video_format(
        duration_seconds=3600,
        live_broadcast_content="none",
        live_streaming_details={"actualEndTime": "2026-11-11T10:00:00Z"},
    )
    assert result.label == "completed_live"


def test_short_duration_is_only_a_candidate_without_orientation_evidence():
    result = classify_video_format(duration_seconds=120)
    assert result.label == "shorts_candidate"
    assert result.confidence == "low"
    assert "orientation" in result.reason


def test_long_duration_is_a_long_form_candidate():
    result = classify_video_format(duration_seconds=181)
    assert result.label == "long_form_candidate"


def test_missing_or_invalid_duration_is_unknown():
    assert classify_video_format(duration_seconds=None).label == "unknown"
    assert classify_video_format(duration_seconds=-1).label == "unknown"
