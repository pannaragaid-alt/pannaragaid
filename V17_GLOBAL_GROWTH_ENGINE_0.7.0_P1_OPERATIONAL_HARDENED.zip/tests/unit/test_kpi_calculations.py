import pytest

from v17_niche_intel.services.kpi_calculations import (
    experiment_lift,
    forecast_error_metrics,
    portfolio_concentration_hhi,
)


def test_portfolio_hhi_and_effective_market_count_for_equal_allocations():
    result = portfolio_concentration_hhi({"US-en": 50, "GB-en": 50})
    assert result["hhi_0_10000"] == 5000
    assert result["effective_market_count"] == 2
    assert result["largest_market_share_pct"] == 50


def test_portfolio_hhi_detects_single_market_concentration():
    result = portfolio_concentration_hhi({"US-en": 100, "GB-en": 0})
    assert result["hhi_0_10000"] == 10000
    assert result["effective_market_count"] == 1


@pytest.mark.parametrize("allocations", [{}, {"US": 0}, {"US": -1}, {"US": float("nan")}])
def test_portfolio_hhi_rejects_invalid_allocations(allocations):
    with pytest.raises(ValueError):
        portfolio_concentration_hhi(allocations)


def test_forecast_errors_handle_zero_actuals_without_division_by_zero():
    result = forecast_error_metrics([100, 200, 0], [110, 180, 10])
    assert result["mae"] == pytest.approx(13.333333, rel=1e-5)
    assert result["wape_pct"] == pytest.approx(13.333333, rel=1e-5)
    assert result["mape_pct"] == pytest.approx(10)
    assert result["zero_actual_count"] == 1


def test_forecast_errors_return_undefined_percentage_errors_for_all_zero_actuals():
    result = forecast_error_metrics([0, 0], [2, 3])
    assert result["wape_pct"] is None
    assert result["mape_pct"] is None
    assert result["aggregate_bias_pct"] is None


def test_forecast_errors_reject_mismatched_or_negative_values():
    with pytest.raises(ValueError):
        forecast_error_metrics([1, 2], [1])
    with pytest.raises(ValueError):
        forecast_error_metrics([-1], [1])


def test_experiment_lift_is_descriptive_and_reports_sample_sizes():
    result = experiment_lift([100, 120], [110, 132])
    assert result["absolute_lift"] == 11
    assert result["relative_lift_pct"] == 10
    assert result["baseline_n"] == 2
    assert result["treatment_n"] == 2


def test_experiment_lift_does_not_divide_by_zero_baseline():
    result = experiment_lift([0, 0], [1, 2])
    assert result["relative_lift_pct"] is None
