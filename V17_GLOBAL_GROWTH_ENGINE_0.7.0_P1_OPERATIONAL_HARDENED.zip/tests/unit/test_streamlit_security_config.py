from pathlib import Path
import tomllib


def test_streamlit_defaults_to_loopback_with_csrf_and_bounded_uploads():
    config = tomllib.loads(Path(".streamlit/config.toml").read_text(encoding="utf-8"))
    server = config["server"]
    assert server["address"] == "127.0.0.1"
    assert server["enableCORS"] is True
    assert server["enableXsrfProtection"] is True
    assert server["maxUploadSize"] == 10
    assert server["maxMessageSize"] <= 20
    assert config["browser"]["gatherUsageStats"] is False
