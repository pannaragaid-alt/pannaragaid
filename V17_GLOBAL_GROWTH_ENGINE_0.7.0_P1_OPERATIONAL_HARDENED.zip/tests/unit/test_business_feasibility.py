import pytest

from v17_niche_intel.domain.business_feasibility import evaluate_channel_feasibility


def test_capacity_uses_weekly_hours_and_production_effort():
    result = evaluate_channel_feasibility({
        "weekly_hours": 10,
        "hours_per_video": 5,
        "target_videos_per_week": 2,
        "repeatable_idea_count": 20,
        "monetization_routes": ["affiliate"],
        "copyright_review": "complete",
        "reused_content_review": "complete",
    })
    assert result["status"] == "ok"
    assert result["capacity_videos_per_week"] == 2
    assert result["capacity_gap_per_week"] == 0
    assert result["business_feasibility_score"] is not None


def test_under_capacity_and_unreviewed_rights_raise_explicit_flags():
    result = evaluate_channel_feasibility({
        "weekly_hours": 4,
        "hours_per_video": 5,
        "target_videos_per_week": 3,
        "repeatable_idea_count": 2,
        "monetization_routes": [],
        "copyright_review": "not_reviewed",
        "reused_content_review": "not_reviewed",
    })
    assert result["capacity_gap_per_week"] == 2.2
    assert "publishing_capacity_gap" in result["risk_flags"]
    assert "copyright_not_reviewed" in result["risk_flags"]
    assert "reused_content_not_reviewed" in result["risk_flags"]
    assert result["business_feasibility_score"] < 50


def test_missing_inputs_are_not_neutral_filled():
    result = evaluate_channel_feasibility({})
    assert result["status"] == "insufficient_data"
    assert result["business_feasibility_score"] is None
    assert "weekly_hours" in result["missing_inputs"]


def test_invalid_effort_is_rejected():
    with pytest.raises(ValueError):
        evaluate_channel_feasibility({"weekly_hours": -1, "hours_per_video": 2, "target_videos_per_week": 1, "repeatable_idea_count": 10})


def test_market_intelligence_service_exposes_feasibility_when_supplied():
    from v17_niche_intel.services.market_intelligence import MarketIntelligenceService

    result = MarketIntelligenceService().analyze({
        "channel_constraints": {
            "weekly_hours": 8, "hours_per_video": 4,
            "target_videos_per_week": 2, "repeatable_idea_count": 24,
            "monetization_routes": ["affiliate"],
            "copyright_review": "complete", "reused_content_review": "complete",
        }
    })
    assert result["business_feasibility"]["status"] == "ok"
    assert result["business_feasibility"]["capacity_videos_per_week"] == 2
