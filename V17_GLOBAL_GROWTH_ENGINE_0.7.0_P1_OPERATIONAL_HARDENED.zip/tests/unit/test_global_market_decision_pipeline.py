from __future__ import annotations

from datetime import datetime, timezone
from types import SimpleNamespace

import pytest

from v17_niche_intel.services.global_market import (
    GlobalMarketDiscoveryService,
    MarketProfile,
    rank_market_decisions,
)


NOW = datetime.now(timezone.utc).isoformat()
ELIGIBILITY = {"status": "eligible", "source_ref": "market-access:assessment",
               "source_family": "market_access_review", "observed_at": NOW,
               "method": "verified platform, payment, policy, and legal-access checklist", "reasons": []}


def evidence(score: float, *, source_ref: str, source_family: str = "market_research",
             confidence: float = 0.9, method: str = "documented normalized rubric",
             **extra):
    return {
        "score": score,
        "source_ref": source_ref,
        "source_family": source_family,
        "observed_at": NOW,
        "confidence": confidence,
        "method": method,
        **extra,
    }


def complete_market_evidence(prefix: str = "us"):
    return {
        "audience_demand": {
            "search_interest": evidence(80, source_ref=f"{prefix}:trends"),
            "demand_growth": evidence(75, source_ref=f"{prefix}:growth"),
            "seasonality_stability": evidence(70, source_ref=f"{prefix}:seasonality"),
            "audience_pain_evidence": evidence(88, source_ref=f"{prefix}:pain"),
            "consumption_behavior": evidence(80, source_ref=f"{prefix}:consumption"),
        },
        "competitive_opening": {
            "competitor_concentration_opportunity": evidence(75, source_ref=f"{prefix}:hhi"),
            "median_views_opportunity": evidence(70, source_ref=f"{prefix}:median-views"),
            "validated_content_gaps": evidence(85, source_ref=f"{prefix}:gaps"),
        },
        "monetization_economics": {
            "first_party_rpm": evidence(65, source_ref=f"{prefix}:analytics", source_family="owner_authorized_youtube_analytics"),
            "advertiser_demand": evidence(75, source_ref=f"{prefix}:advertiser"),
            "revenue_route_diversity": evidence(78, source_ref=f"{prefix}:revenue-routes"),
            "purchase_intent": evidence(80, source_ref=f"{prefix}:intent"),
            "audience_purchasing_power": evidence(76, source_ref=f"{prefix}:purchasing-power"),
        },
        "creator_execution_fit": {
            "language_cultural_fluency": evidence(90, source_ref=f"{prefix}:native-review",
                source_family="native_speaker_review", native_review_status="native_reviewed"),
            "format_capability_fit": evidence(80, source_ref=f"{prefix}:format"),
            "production_feasibility": evidence(85, source_ref=f"{prefix}:capacity"),
            "policy_rights_resilience": evidence(85, source_ref=f"{prefix}:rights"),
        },
    }


class RecordingYouTube:
    def __init__(self):
        self.calls = []

    def search_videos(self, keyword, region, **kwargs):
        self.calls.append((keyword, region, kwargs))
        return SimpleNamespace(status="ok", videos=(), failed_orders=(), detail_failures=0)


def test_global_discovery_wires_provenanced_component_evidence_into_decision_and_ranking():
    youtube = RecordingYouTube()
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    result = GlobalMarketDiscoveryService(youtube_provider=youtube).discover(
        topic="home coffee", markets=(market,), decision_evidence={"US-en": complete_market_evidence()},
        market_eligibility={"US-en": ELIGIBILITY}
    )

    item = result["markets"][0]
    assert item["decision"]["status"] == "scored"
    assert item["decision"]["score"] is not None
    assert item["decision_layers"]["audience_demand"]["status"] == "scored"
    assert item["decision_evidence"]["creator_execution_fit"]["language_cultural_fluency"]["status"] == "accepted"
    assert result["ranked_markets"][0]["market_id"] == "US-en"
    assert item["confidence"] == pytest.approx(0.9)


def test_global_discovery_passes_market_language_to_youtube_relevance_language():
    youtube = RecordingYouTube()
    market = MarketProfile("JP", "Japan", "ja", "ja-JP", "JPY", "Asia/Tokyo")
    GlobalMarketDiscoveryService(youtube_provider=youtube).discover(topic="coffee", markets=(market,))
    assert youtube.calls[0][2]["relevance_language"] == "ja"


def test_unreviewed_native_fluency_evidence_is_not_scored():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    inputs = complete_market_evidence()
    inputs["creator_execution_fit"]["language_cultural_fluency"].pop("native_review_status")
    result = GlobalMarketDiscoveryService().discover(
        topic="coffee", markets=(market,), decision_evidence={"US-en": inputs}
    )
    item = result["markets"][0]
    assert item["decision_layers"]["creator_execution_fit"]["status"] == "insufficient_evidence"
    assert item["decision_evidence"]["creator_execution_fit"]["language_cultural_fluency"]["status"] == "rejected_native_review_required"


def test_stale_component_evidence_is_excluded_from_scoring():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    inputs = complete_market_evidence()
    inputs["audience_demand"]["search_interest"]["observed_at"] = "2020-01-01T00:00:00+00:00"
    result = GlobalMarketDiscoveryService().discover(
        topic="coffee", markets=(market,), decision_evidence={"US-en": inputs}, evidence_max_age_days=180
    )
    item = result["markets"][0]
    assert item["decision_evidence"]["audience_demand"]["search_interest"]["status"] == "stale"
    assert item["decision_layers"]["audience_demand"]["status"] == "insufficient_evidence"
    assert item["decision_layers"]["audience_demand"]["coverage"] == pytest.approx(0.70)


@pytest.mark.parametrize("mutate", [
    lambda row: row.update(score=101),
    lambda row: row.update(source_ref=""),
    lambda row: row.update(observed_at="2026-11-13T12:00:00"),
    lambda row: row.update(confidence=1.5),
    lambda row: row.update(method=""),
])
def test_invalid_component_evidence_fails_closed(mutate):
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    inputs = complete_market_evidence()
    mutate(inputs["audience_demand"]["search_interest"])
    with pytest.raises(ValueError):
        GlobalMarketDiscoveryService().discover(
            topic="coffee", markets=(market,), decision_evidence={"US-en": inputs}
        )


def test_quota_budget_prevents_partial_market_set_from_being_ranked():
    youtube = RecordingYouTube()
    markets = (
        MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York"),
        MarketProfile("JP", "Japan", "ja", "ja-JP", "JPY", "Asia/Tokyo"),
    )
    result = GlobalMarketDiscoveryService(youtube_provider=youtube).discover(
        topic="coffee", markets=markets, search_call_budget=1, other_quota_budget_units=2,
        other_quota_preconsumed_units=1
    )
    assert len(youtube.calls) == 1
    assert result["markets"][1]["youtube"]["status"] == "skipped_quota_budget"
    assert result["ranked_markets"] == []
    assert result["quota"]["search_bucket"]["estimated_calls"] == 2
    assert result["quota"]["search_bucket"]["attempted_calls"] == 1
    assert result["quota"]["search_bucket"]["budget_calls"] == 1
    assert result["quota"]["general_bucket"]["estimated_units"] == 3
    assert result["quota"]["general_bucket"]["attempted_or_reserved_units"] == 2
    assert result["quota"]["general_bucket"]["preconsumed_units"] == 1
    assert result["quota"]["general_bucket"]["budget_units"] == 2


def test_ranker_rejects_hard_ineligible_markets_even_when_scored():
    ranked = rank_market_decisions([
        {"market_id": "US-en", "decision": {"status": "scored", "score": 90, "coverage": 1.0}, "eligibility": {"status": "rejected"}, "ranking_eligible": True},
        {"market_id": "JP-ja", "decision": {"status": "scored", "score": 80, "coverage": 1.0}, "eligibility": {"status": "eligible"}, "ranking_eligible": True},
    ])
    assert [item["market_id"] for item in ranked] == ["JP-ja"]
    held = rank_market_decisions([
        {"market_id": "US-en", "decision": {"status": "scored", "score": 90, "coverage": 1.0}, "eligibility": {"status": "hold"}, "ranking_eligible": True},
    ])
    assert held == []


def test_dynamic_registry_covers_all_supported_regions_and_adds_official_language_segments():
    pytest.importorskip("babel")
    pytest.importorskip("pycountry")
    pytest.importorskip("pytz")
    from v17_niche_intel.services.global_market import build_market_registry

    registry = build_market_registry([
        {"code": "US", "name": "United States"},
        {"code": "IN", "name": "India"},
        {"code": "ZA", "name": "South Africa"},
    ])
    ids = {market.market_id for market in registry}
    countries = {market.country_code for market in registry}
    assert countries == {"US", "IN", "ZA"}
    assert {"IN-hi", "IN-en", "IN-bn", "IN-ta", "IN-te", "ZA-en", "ZA-zu", "ZA-xh"} <= ids
    assert all(market.currency and market.timezone and market.locale for market in registry)


def test_dynamic_registry_rejects_duplicate_or_invalid_supported_region_codes():
    pytest.importorskip("babel")
    pytest.importorskip("pycountry")
    pytest.importorskip("pytz")
    from v17_niche_intel.services.global_market import build_market_registry

    with pytest.raises(ValueError):
        build_market_registry([{"code": "US", "name": "United States"}, {"code": "US", "name": "Duplicate"}])
    with pytest.raises(ValueError):
        build_market_registry([{"code": "USA", "name": "United States"}])


def test_chinese_market_uses_script_specific_youtube_and_translation_targets():
    simplified = MarketProfile("SG", "Singapore", "zh", "zh-SG", "SGD", "Asia/Singapore")
    traditional = MarketProfile("TW", "Taiwan", "zh", "zh-Hant-TW", "TWD", "Asia/Taipei")
    assert simplified.youtube_relevance_language == "zh-Hans"
    assert simplified.translation_target == "zh-CN"
    assert traditional.youtube_relevance_language == "zh-Hant"
    assert traditional.translation_target == "zh-TW"


def test_provider_quota_exhaustion_stops_remaining_market_calls():
    class QuotaExhaustedError(RuntimeError):
        pass
    class ExhaustingYouTube:
        def __init__(self): self.calls = 0
        def search_videos(self, *args, **kwargs):
            self.calls += 1
            raise QuotaExhaustedError("project quota exhausted")
    youtube = ExhaustingYouTube()
    markets = (
        MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York"),
        MarketProfile("JP", "Japan", "ja", "ja-JP", "JPY", "Asia/Tokyo"),
    )
    result = GlobalMarketDiscoveryService(youtube_provider=youtube).discover(topic="coffee", markets=markets)
    assert youtube.calls == 1
    assert result["status"] == "partial_quota_limited"
    assert result["markets"][1]["youtube"]["status"] == "skipped_quota_budget"
    assert result["ranked_markets"] == []


def test_four_layer_ranking_requires_all_layers_even_when_three_of_four_can_be_scored():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    inputs = complete_market_evidence()
    inputs.pop("monetization_economics")
    result = GlobalMarketDiscoveryService().discover(
        topic="coffee", markets=(market,), decision_evidence={"US-en": inputs}
    )
    item = result["markets"][0]
    assert item["decision"]["status"] == "scored"
    assert item["decision"]["coverage"] == pytest.approx(0.75)
    assert item["ranking_eligible"] is False
    assert result["ranked_markets"] == []


def test_creator_fit_requires_native_review_and_policy_rights_resilience():
    from v17_niche_intel.services.global_market import score_layer_components
    result = score_layer_components({
        "creator_execution_fit": {
            "language_cultural_fluency": 90,
            "format_capability_fit": 80,
            "production_feasibility": 85,
        }
    })
    assert result["layers"]["creator_execution_fit"]["status"] == "insufficient_evidence"
    assert result["layers"]["creator_execution_fit"]["missing_required_components"] == ["policy_rights_resilience"]


def test_low_policy_rights_resilience_forces_market_hold():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    inputs = complete_market_evidence()
    inputs["creator_execution_fit"]["policy_rights_resilience"] = evidence(35, source_ref="us:rights")
    result = GlobalMarketDiscoveryService().discover(
        topic="coffee", markets=(market,), decision_evidence={"US-en": inputs},
        market_eligibility={"US-en": ELIGIBILITY}
    )
    item = result["markets"][0]
    assert item["eligibility"]["status"] == "hold"
    assert item["decision"]["status"] == "on_hold"
    assert item["ranking_eligible"] is False
    assert result["ranked_markets"] == []


def test_dynamic_registry_keeps_supported_regions_when_cldr_metadata_is_incomplete():
    pytest.importorskip("babel")
    pytest.importorskip("pycountry")
    pytest.importorskip("pytz")
    from v17_niche_intel.services.global_market import build_market_registry
    registry = build_market_registry([{"code": "AQ", "name": "Antarctica"}])
    assert len(registry) == 1
    assert registry[0].market_id == "AQ-en"
    assert registry[0].metadata_status == "partial_fallback"
    assert registry[0].currency == "UNKNOWN"
    assert "fallback only" in registry[0].localization_note


def test_google_reported_daily_quota_exhaustion_stops_following_markets():
    import json
    from v17_niche_intel.providers.youtube_data_api import YouTubeDataAPIProvider, YouTubeQuotaExceededError

    class HttpError(Exception):
        content = json.dumps({"error": {"message": "The request cannot be completed because you have exceeded your quota.",
            "errors": [{"reason": "quotaExceeded"}]}}).encode()

    class SearchRequest:
        def execute(self): raise HttpError("quota")
    class SearchResource:
        def list(self, **kwargs): return SearchRequest()
    class Client:
        def search(self): return SearchResource()
    provider = YouTubeDataAPIProvider(client=Client())
    with pytest.raises(YouTubeQuotaExceededError):
        provider.search_videos("coffee", "US", query_orders=("relevance",))


def test_market_is_not_ranked_without_source_verified_eligibility():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    result = GlobalMarketDiscoveryService().discover(
        topic="coffee", markets=(market,), decision_evidence={"US-en": complete_market_evidence()}
    )
    assert result["markets"][0]["decision"]["status"] == "scored"
    assert result["markets"][0]["eligibility"]["status"] == "not_evaluated"
    assert result["markets"][0]["ranking_eligible"] is False
    assert result["ranked_markets"] == []


def test_stale_market_eligibility_evidence_forces_hold():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    stale = {**ELIGIBILITY, "observed_at": "2020-01-01T00:00:00+00:00"}
    result = GlobalMarketDiscoveryService().discover(
        topic="coffee", markets=(market,), decision_evidence={"US-en": complete_market_evidence()},
        market_eligibility={"US-en": stale}, evidence_max_age_days=180
    )
    assert result["markets"][0]["eligibility"]["status"] == "hold"
    assert result["markets"][0]["eligibility"]["evidence_status"] == "stale"
    assert result["ranked_markets"] == []


def test_market_eligibility_requires_provenance_for_decisions():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    with pytest.raises(ValueError, match="source_ref"):
        GlobalMarketDiscoveryService().discover(
            topic="coffee", markets=(market,), market_eligibility={"US-en": {"status": "eligible"}}
        )


def test_dynamic_registry_builds_profiles_for_all_iso_countries_with_explicit_metadata_fallbacks():
    pytest.importorskip("babel")
    pycountry = pytest.importorskip("pycountry")
    pytest.importorskip("pytz")
    from v17_niche_intel.services.global_market import build_market_registry
    regions = [{"code": country.alpha_2, "name": country.name} for country in pycountry.countries]
    registry = build_market_registry(regions)
    assert {market.country_code for market in registry} == {region["code"] for region in regions}
    assert all(market.currency and market.timezone and market.locale for market in registry)
    assert all(market.metadata_status in {"cldr", "partial_fallback", "curated"} for market in registry)


def test_native_review_is_required_even_when_translation_is_unavailable():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    result = GlobalMarketDiscoveryService().discover(topic="coffee", markets=(market,))
    assert result["markets"][0]["localization"]["native_review_required"] is True
    assert result["markets"][0]["localization"]["native_validation_status"] == "not_verified"


def test_dynamic_registry_prioritizes_one_primary_language_profile_per_country_before_secondary_segments():
    pytest.importorskip("babel")
    pytest.importorskip("pycountry")
    pytest.importorskip("pytz")
    from v17_niche_intel.services.global_market import build_market_registry
    registry = build_market_registry([
        {"code": "US", "name": "United States"},
        {"code": "IN", "name": "India"},
    ])
    assert len({market.country_code for market in registry[:2]}) == 2
    assert registry[0].country_code == "IN"  # alphabetical ISO order
    assert registry[1].country_code == "US"


def test_first_party_rpm_requires_owner_authorized_analytics_source_family():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    inputs = complete_market_evidence()
    inputs["monetization_economics"]["first_party_rpm"]["source_family"] = "public_competitor_estimate"
    with pytest.raises(ValueError, match="owner-authorized YouTube Analytics"):
        GlobalMarketDiscoveryService().discover(
            topic="coffee", markets=(market,), decision_evidence={"US-en": inputs}
        )


def test_monetization_layer_can_score_without_first_party_rpm_when_other_evidence_is_complete():
    from v17_niche_intel.services.global_market import score_layer_components
    result = score_layer_components({
        "monetization_economics": {
            "advertiser_demand": 80,
            "revenue_route_diversity": 75,
            "purchase_intent": 70,
            "audience_purchasing_power": 68,
        }
    })
    assert result["layers"]["monetization_economics"]["status"] == "scored"
    assert result["layers"]["monetization_economics"]["coverage"] == pytest.approx(0.80)


def test_native_reviewed_language_evidence_requires_native_speaker_source_family():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    inputs = complete_market_evidence()
    inputs["creator_execution_fit"]["language_cultural_fluency"]["source_family"] = "machine_translation"
    with pytest.raises(ValueError, match="native_speaker_review"):
        GlobalMarketDiscoveryService().discover(
            topic="coffee", markets=(market,), decision_evidence={"US-en": inputs}
        )


def test_market_eligibility_rejects_non_string_timestamp_cleanly():
    market = MarketProfile("US", "United States", "en", "en-US", "USD", "America/New_York")
    invalid_eligibility = {**ELIGIBILITY, "observed_at": 12345}
    with pytest.raises(ValueError, match="non-empty string"):
        GlobalMarketDiscoveryService().discover(
            topic="coffee", markets=(market,), market_eligibility={"US-en": invalid_eligibility}
        )


def test_query_variant_limit_samples_multiple_native_curated_queries_with_deduped_results():
    from types import SimpleNamespace
    class VariantYouTube:
        def __init__(self): self.calls = []
        def search_videos(self, keyword, region, **kwargs):
            self.calls.append(keyword)
            video = SimpleNamespace(video_id="same", title=keyword, channel_id="channel",
                channel_title="Channel", views=10, published_at=datetime.now(timezone.utc),
                duration_seconds=60, url="https://youtube.com/watch?v=same")
            return SimpleNamespace(status="ok", videos=(video,), failed_orders=(), detail_failures=0)
    market = MarketProfile("ID", "Indonesia", "id", "id-ID", "IDR", "Asia/Jakarta")
    youtube = VariantYouTube()
    result = GlobalMarketDiscoveryService(youtube_provider=youtube).discover(topic="coffee", markets=(market,),
        query_variant_limit=2, localized_query_variants={"ID-id": {
            "queries": ["cara seduh kopi", "resep kopi rumahan"], "review_status": "pending"}})
    item = result["markets"][0]
    assert youtube.calls == ["cara seduh kopi", "resep kopi rumahan"]
    assert item["youtube"]["sample_size"] == 1
    assert item["youtube"]["query_variant_count"] == 2
    assert result["quota"]["search_bucket"]["attempted_calls"] == 2
