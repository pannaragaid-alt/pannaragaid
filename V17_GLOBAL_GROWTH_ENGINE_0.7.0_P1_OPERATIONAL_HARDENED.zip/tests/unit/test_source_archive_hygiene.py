import stat
import zipfile

import pytest

from tools.validate_source_archive import validate_source_archive


def _write_zip(path, entries):
    with zipfile.ZipFile(path, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        for name, content in entries:
            archive.writestr(name, content)


def test_source_archive_allows_source_and_example_environment_file(tmp_path):
    archive = tmp_path / "safe.zip"
    _write_zip(archive, [
        ("v17_niche_intel/__init__.py", b""),
        (".env.example", b"EXAMPLE=value"),
    ])
    assert validate_source_archive(str(archive)) == ()


@pytest.mark.parametrize("name", [
    "../escape.py",
    "/absolute.py",
    "C:/windows/system.ini",
    "state.sqlite3",
    "state.sqlite3-wal",
    ".env",
    ".env.production",
    "keys/private.pem",
    "id_rsa",
    "__pycache__/module.pyc",
    "v17_niche_intelligence.egg-info/PKG-INFO",
])
def test_source_archive_rejects_unsafe_or_runtime_files(tmp_path, name):
    archive = tmp_path / "bad.zip"
    _write_zip(archive, [(name, b"not safe")])
    assert validate_source_archive(str(archive))


def test_source_archive_rejects_duplicate_casefolded_names(tmp_path):
    archive = tmp_path / "duplicate.zip"
    _write_zip(archive, [("Readme.md", b"a"), ("README.md", b"b")])
    assert any("duplicate" in issue for issue in validate_source_archive(str(archive)))


def test_source_archive_rejects_symlinks(tmp_path):
    archive = tmp_path / "symlink.zip"
    info = zipfile.ZipInfo("link")
    info.create_system = 3
    info.external_attr = (stat.S_IFLNK | 0o777) << 16
    with zipfile.ZipFile(archive, "w") as output:
        output.writestr(info, "target")
    assert any("symlink" in issue for issue in validate_source_archive(str(archive)))


def test_source_archive_rejects_large_expansion_member(tmp_path):
    archive = tmp_path / "large.zip"
    _write_zip(archive, [("huge.txt", b"a" * (20 * 1024 * 1024 + 1))])
    assert any("exceeds" in issue for issue in validate_source_archive(str(archive)))


def test_source_archive_rejects_non_zip(tmp_path):
    archive = tmp_path / "not-a-zip.zip"
    archive.write_text("not a zip", encoding="utf-8")
    assert validate_source_archive(str(archive))
