from datetime import datetime, timezone

import pytest

from v17_niche_intel.domain.enums import EvidenceStatus
from v17_niche_intel.domain.models import Evidence


def test_successful_evidence_requires_a_value():
    with pytest.raises(ValueError, match="value"):
        Evidence(
            metric="search_interest",
            value=None,
            source_family="google_trends",
            observed_at=datetime.now(timezone.utc),
            status=EvidenceStatus.OK,
        )


def test_evidence_requires_timezone_aware_timestamp():
    with pytest.raises(ValueError, match="timezone"):
        Evidence(
            metric="search_interest",
            value=45.0,
            source_family="google_trends",
            observed_at=datetime(2026, 11, 11),
            status=EvidenceStatus.OK,
        )


def test_evidence_quality_is_bounded():
    with pytest.raises(ValueError, match="quality"):
        Evidence(
            metric="search_interest",
            value=45.0,
            source_family="google_trends",
            observed_at=datetime.now(timezone.utc),
            status=EvidenceStatus.OK,
            quality=1.5,
        )
