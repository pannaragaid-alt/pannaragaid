from datetime import datetime, timezone

import pytest

from v17_niche_intel.services.provenance import build_provenance_record


NOW = datetime(2026, 11, 14, 12, 0, tzinfo=timezone.utc)


def test_provenance_hash_is_stable_for_equivalent_mapping_order():
    left = build_provenance_record(source_family="youtube_data_api", source_ref="videos.list",
        raw_payload={"b": 2, "a": 1}, observed_at=NOW, fetched_at=NOW,
        request_params={"id": "x"}, transform_version="v1")
    right = build_provenance_record(source_family="youtube_data_api", source_ref="videos.list",
        raw_payload={"a": 1, "b": 2}, observed_at=NOW, fetched_at=NOW,
        request_params={"id": "x"}, transform_version="v1")
    assert left["raw_sha256"] == right["raw_sha256"]


def test_provenance_hash_changes_when_raw_payload_changes():
    first = build_provenance_record(source_family="provider", source_ref="ref",
        raw_payload={"views": 1}, observed_at=NOW, transform_version="v1")
    second = build_provenance_record(source_family="provider", source_ref="ref",
        raw_payload={"views": 2}, observed_at=NOW, transform_version="v1")
    assert first["raw_sha256"] != second["raw_sha256"]


def test_provenance_requires_timezone_aware_timestamps_and_source():
    with pytest.raises(ValueError, match="timezone-aware"):
        build_provenance_record(source_family="provider", source_ref="ref",
            raw_payload={}, observed_at=datetime(2026, 1, 1), transform_version="v1")
    with pytest.raises(ValueError, match="source_ref"):
        build_provenance_record(source_family="provider", source_ref="",
            raw_payload={}, observed_at=NOW, transform_version="v1")


def test_provenance_rejects_non_json_finite_payload_values():
    with pytest.raises(ValueError, match="JSON-serializable"):
        build_provenance_record(source_family="provider", source_ref="ref",
            raw_payload={"value": float("nan")}, observed_at=NOW, transform_version="v1")
