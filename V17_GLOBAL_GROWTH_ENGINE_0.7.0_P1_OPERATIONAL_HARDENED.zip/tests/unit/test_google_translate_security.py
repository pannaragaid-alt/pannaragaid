import pytest

from v17_niche_intel.providers.google_translate import GoogleCloudTranslator


class FakeResponse:
    status_code = 200
    headers = {"Content-Type": "application/json; charset=utf-8"}

    def __init__(self, payload):
        import json
        self.content = json.dumps(payload).encode("utf-8")

    def iter_content(self, chunk_size=65536):
        for offset in range(0, len(self.content), chunk_size):
            yield self.content[offset:offset + chunk_size]

    def close(self):
        self.closed = True


class FakeSession:
    def __init__(self, response=None):
        self.response = response or FakeResponse({"translations": [{"translatedText": "Halo dunia"}]})
        self.calls = []

    def post(self, url, **kwargs):
        self.calls.append((url, kwargs))
        return self.response


def test_translation_uses_fixed_google_endpoint_and_bounded_request():
    session = FakeSession()
    translator = GoogleCloudTranslator("v17-growth-123", session=session)
    assert translator.translate("Hello world", "id") == "Halo dunia"
    url, kwargs = session.calls[0]
    assert url == "https://translation.googleapis.com/v3/projects/v17-growth-123/locations/global:translateText"
    assert kwargs["json"] == {"contents": ["Hello world"], "mimeType": "text/plain", "targetLanguageCode": "id"}
    assert kwargs["timeout"] == (3, 15)
    assert kwargs["allow_redirects"] is False
    assert kwargs["stream"] is True


@pytest.mark.parametrize("project", ["", "bad/project", "UPPERCASE", "x" * 31])
def test_translation_rejects_invalid_project_id(project):
    with pytest.raises(ValueError):
        GoogleCloudTranslator(project, session=FakeSession())


@pytest.mark.parametrize("text", ["", "  ", "x" * 5001, None])
def test_translation_rejects_invalid_text(text):
    translator = GoogleCloudTranslator("v17-growth-123", session=FakeSession())
    with pytest.raises(ValueError):
        translator.translate(text, "id")


@pytest.mark.parametrize("language", ["", "../id", "en;https://evil.test", "x" * 36])
def test_translation_rejects_invalid_language_code(language):
    translator = GoogleCloudTranslator("v17-growth-123", session=FakeSession())
    with pytest.raises(ValueError):
        translator.translate("Hello", language)


def test_translation_rejects_redirects_and_oversized_responses():
    session = FakeSession()
    session.response.status_code = 302
    translator = GoogleCloudTranslator("v17-growth-123", session=session)
    with pytest.raises(RuntimeError, match="redirect"):
        translator.translate("Hello", "id")

    session = FakeSession()
    session.response.content = b" " * (1024 * 1024 + 1)
    translator = GoogleCloudTranslator("v17-growth-123", session=session)
    with pytest.raises(RuntimeError, match="response"):
        translator.translate("Hello", "id")


def test_translation_rejects_malformed_provider_payload():
    session = FakeSession(FakeResponse({"translations": []}))
    translator = GoogleCloudTranslator("v17-growth-123", session=session)
    with pytest.raises(RuntimeError, match="response"):
        translator.translate("Hello", "id")


def test_from_environment_requires_project_id(monkeypatch):
    monkeypatch.delenv("GOOGLE_CLOUD_PROJECT", raising=False)
    monkeypatch.delenv("GCLOUD_PROJECT", raising=False)
    with pytest.raises(RuntimeError, match="GOOGLE_CLOUD_PROJECT"):
        GoogleCloudTranslator.from_environment(session=FakeSession())


def test_from_environment_accepts_gcloud_project_fallback(monkeypatch):
    monkeypatch.delenv("GOOGLE_CLOUD_PROJECT", raising=False)
    monkeypatch.setenv("GCLOUD_PROJECT", "v17-growth-123")
    translator = GoogleCloudTranslator.from_environment(session=FakeSession())
    assert translator.project_id == "v17-growth-123"
