import pytest

from v17_niche_intel.credentials.transport import harden_requests_session


class FakeSession:
    def __init__(self):
        self.trust_env = True
        self.proxies = {"https": "http://proxy.invalid"}
        self.verify = False
        self.cert = "client-cert.pem"
        self.auth = ("user", "password")
        self.cookies = {"session": "secret"}
        self.headers = {"Authorization": "Bearer secret", "Cookie": "sid=secret", "User-Agent": "test"}
    def resolve_redirects(self, response, request, **kwargs):
        return iter(["would-follow"])


def test_harden_requests_session_removes_ambient_secrets_and_network_proxies():
    session = FakeSession()
    assert harden_requests_session(session) is session
    assert session.trust_env is False
    assert session.proxies == {}
    assert session.verify is True
    assert session.cert is None
    assert session.auth is None
    assert session.cookies == {}
    assert "Authorization" not in session.headers
    assert "Cookie" not in session.headers
    assert session.headers["User-Agent"] == "test"


def test_harden_requests_session_rejects_redirect_before_following_it():
    session = harden_requests_session(FakeSession())
    class Response:
        is_redirect = True
        is_permanent_redirect = False
    with pytest.raises(RuntimeError, match="redirect refused"):
        list(session.resolve_redirects(Response(), object()))
