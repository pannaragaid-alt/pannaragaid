import stat
import pytest

from v17_niche_intel.credentials import CredentialManager, MemorySecretStore
from v17_niche_intel.storage.database import Database
from v17_niche_intel.storage.secure_backup import create_encrypted_backup, restore_encrypted_backup, check_secret_store


def seeded_database():
    db = Database(":memory:")
    store = MemorySecretStore()
    manager = CredentialManager(db, store)
    manager.add_api_key("api-1", project_id="project-1", use_case="market", environment="local", secret="api-secret-value")
    client_secret_ref = store.put("oauth-client-secret")
    manager.add_oauth_account("oauth-1", account_label="owner", secret_access_token="access-secret",
        secret_refresh_token="refresh-secret", client_secret_ref=client_secret_ref,
        client_id="client-id.apps.googleusercontent.com", scopes={"https://www.googleapis.com/auth/yt-analytics.readonly"},
        channel_ids={"UC_OWNER"})
    return db, store


def test_encrypted_backup_restore_remaps_secret_references_and_preserves_database(tmp_path):
    source_db, source_store = seeded_database()
    backup = tmp_path / "v17-backup.enc"
    result = create_encrypted_backup(source_db, source_store, backup, passphrase="correct horse battery staple")
    assert result["encrypted"] is True
    assert stat.S_IMODE(backup.stat().st_mode) == 0o600
    target_store = MemorySecretStore()
    target = tmp_path / "restored.sqlite3"
    restored = restore_encrypted_backup(backup, target, target_store, passphrase="correct horse battery staple")
    assert restored["integrity"] == "ok"
    db = Database(target)
    rows = db.connection.execute("SELECT secret_ref FROM api_credentials").fetchall()
    assert target_store.get(rows[0]["secret_ref"]) == "api-secret-value"
    oauth = db.connection.execute("SELECT * FROM oauth_accounts WHERE account_id='oauth-1'").fetchone()
    assert target_store.get(oauth["access_token_ref"]) == "access-secret"
    assert target_store.get(oauth["refresh_token_ref"]) == "refresh-secret"
    assert target_store.get(oauth["client_secret_ref"]) == "oauth-client-secret"
    assert oauth["client_id"] == "client-id.apps.googleusercontent.com"
    db.close(); source_db.close()


def test_backup_rejects_short_passphrases_and_wrong_passphrase(tmp_path):
    db, store = seeded_database()
    backup = tmp_path / "backup.enc"
    with pytest.raises(ValueError, match="12 characters"):
        create_encrypted_backup(db, store, backup, passphrase="short")
    create_encrypted_backup(db, store, backup, passphrase="long enough passphrase")
    with pytest.raises(ValueError, match="authentication failed"):
        restore_encrypted_backup(backup, tmp_path / "wrong.sqlite3", MemorySecretStore(), passphrase="another wrong passphrase")
    assert not (tmp_path / "wrong.sqlite3").exists()
    db.close()


def test_restore_never_overwrites_existing_database(tmp_path):
    db, store = seeded_database()
    backup = tmp_path / "backup.enc"
    create_encrypted_backup(db, store, backup, passphrase="long enough passphrase")
    target = tmp_path / "existing.sqlite3"
    target.write_text("keep", encoding="utf-8")
    with pytest.raises(FileExistsError):
        restore_encrypted_backup(backup, target, MemorySecretStore(), passphrase="long enough passphrase")
    assert target.read_text(encoding="utf-8") == "keep"
    db.close()


def test_secret_store_health_check_writes_reads_and_deletes_probe():
    store = MemorySecretStore()
    assert check_secret_store(store)["status"] == "ok"


def test_backup_does_not_overwrite_existing_backup_file(tmp_path):
    db, store = seeded_database()
    backup = tmp_path / "existing.enc"
    backup.write_text("keep", encoding="utf-8")
    with pytest.raises(FileExistsError):
        create_encrypted_backup(db, store, backup, passphrase="long enough passphrase")
    assert backup.read_text(encoding="utf-8") == "keep"
    db.close()


def test_restore_rejects_duplicate_zip_members_even_when_authenticated(tmp_path):
    import io
    import json
    import secrets as random_secrets
    import zipfile
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM
    from v17_niche_intel.storage.secure_backup import _MAGIC, _derive_key
    salt, nonce = random_secrets.token_bytes(16), random_secrets.token_bytes(12)
    payload = io.BytesIO()
    with zipfile.ZipFile(payload, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("database.sqlite3", b"first")
        with pytest.warns(UserWarning, match="Duplicate name"):
            archive.writestr("database.sqlite3", b"second")
        archive.writestr("secrets.json", json.dumps({}).encode())
    encrypted = AESGCM(_derive_key("long enough passphrase", salt)).encrypt(nonce, payload.getvalue(), _MAGIC)
    backup = tmp_path / "duplicate-members.enc"
    backup.write_bytes(_MAGIC + salt + nonce + encrypted)
    with pytest.raises(ValueError, match="duplicate or unexpected"):
        restore_encrypted_backup(backup, tmp_path / "restore.sqlite3", MemorySecretStore(),
                                 passphrase="long enough passphrase")
