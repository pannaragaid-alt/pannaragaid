import pytest
from datetime import timezone

from v17_niche_intel.providers.youtube_data_api import YouTubeDataAPIProvider


class FakeRequest:
    def __init__(self, payload):
        self.payload = payload

    def execute(self):
        if isinstance(self.payload, Exception):
            raise self.payload
        return self.payload


class FakeResource:
    def __init__(self, handler):
        self.handler = handler

    def list(self, **kwargs):
        return FakeRequest(self.handler(kwargs))


class FakeClient:
    def __init__(self, searches, videos):
        self.searches = searches
        self.video_items = videos
        self.search_calls = []
        self.video_calls = []

    def search(self):
        def handler(kwargs):
            self.search_calls.append(kwargs)
            return self.searches[kwargs["order"]]
        return FakeResource(handler)

    def videos(self):
        def handler(kwargs):
            self.video_calls.append(kwargs)
            return {"items": [v for v in self.video_items if v["id"] in kwargs["id"].split(",")]}
        return FakeResource(handler)


def video(video_id, *, duration="PT2M", stats=None, live=None):
    return {
        "id": video_id,
        "snippet": {
            "title": f"Video {video_id}", "channelId": "channel-1",
            "channelTitle": "Creator", "publishedAt": "2026-11-01T00:00:00Z",
            "liveBroadcastContent": "none",
        },
        "statistics": stats if stats is not None else {"viewCount": "1200", "likeCount": "90", "commentCount": "8"},
        "contentDetails": {"duration": duration},
        **({"liveStreamingDetails": live} if live is not None else {}),
    }


def test_search_uses_multiple_orders_deduplicates_and_fetches_live_details():
    client = FakeClient(
        searches={
            "relevance": {"items": [{"id": {"videoId": "a"}}, {"id": {"videoId": "b"}}]},
            "date": {"items": [{"id": {"videoId": "b"}}, {"id": {"videoId": "c"}}]},
        },
        videos=[video("a"), video("b", live={"scheduledStartTime": "2026-11-12T00:00:00Z"}), video("c")],
    )
    provider = YouTubeDataAPIProvider(client=client)
    batch = provider.search_videos("coffee roasting", "ID", limit=3, relevance_language="id")
    assert batch.status == "ok"
    assert [v.video_id for v in batch.videos] == ["a", "b", "c"]
    assert [call["order"] for call in client.search_calls] == ["relevance", "date"]
    assert all(call["relevanceLanguage"] == "id" for call in client.search_calls)
    assert client.video_calls[0]["part"] == "snippet,statistics,contentDetails,liveStreamingDetails"
    assert batch.videos[1].live_streaming_details["scheduledStartTime"].startswith("2026-")
    assert batch.videos[0].published_at.tzinfo == timezone.utc


def test_missing_public_statistics_remain_none_not_zero():
    client = FakeClient(
        searches={"relevance": {"items": [{"id": {"videoId": "a"}}]}, "date": {"items": []}},
        videos=[video("a", stats={})],
    )
    batch = YouTubeDataAPIProvider(client=client).search_videos("topic", "US", limit=5)
    assert batch.videos[0].views is None
    assert batch.videos[0].likes is None
    assert batch.videos[0].comments is None


def test_provider_caps_limit_and_rejects_invalid_query_orders():
    client = FakeClient(searches={"relevance": {"items": []}}, videos=[])
    provider = YouTubeDataAPIProvider(client=client)
    batch = provider.search_videos("topic", "US", limit=500, query_orders=("relevance",))
    assert batch.status == "no_data"
    assert client.search_calls[0]["maxResults"] == 50
    try:
        provider.search_videos("topic", "US", query_orders=("invalid",))
    except ValueError:
        pass
    else:
        raise AssertionError("invalid order must be rejected")


def test_partial_search_failure_is_reported_when_another_order_succeeds():
    client = FakeClient(
        searches={"relevance": RuntimeError("quota"), "date": {"items": [{"id": {"videoId": "a"}}]}},
        videos=[video("a")],
    )
    batch = YouTubeDataAPIProvider(client=client).search_videos("topic", "US", limit=5)
    assert batch.status == "partial"
    assert batch.failed_orders == ("relevance",)
    assert len(batch.videos) == 1


def test_all_search_failures_are_not_reported_as_no_demand():
    client = FakeClient(searches={"relevance": RuntimeError("quota"), "date": RuntimeError("quota")}, videos=[])
    batch = YouTubeDataAPIProvider(client=client).search_videos("topic", "US", limit=5)
    assert batch.status == "error"
    assert not batch.videos
    assert len(batch.failed_orders) == 2


def test_multi_order_sampling_balances_rankings_before_applying_limit():
    client = FakeClient(
        searches={
            "relevance": {"items": [{"id": {"videoId": x}} for x in ("a", "b", "c", "d")]},
            "date": {"items": [{"id": {"videoId": x}} for x in ("e", "f", "g", "h")]},
        },
        videos=[video(x) for x in "abcdefgh"],
    )
    batch = YouTubeDataAPIProvider(client=client).search_videos("topic", "ID", limit=4)
    assert [v.video_id for v in batch.videos] == ["a", "e", "b", "f"]
    assert client.video_calls[0]["id"] == "a,e,b,f"


def test_quota_callback_accounts_for_each_api_request():
    charges=[]
    client=FakeClient(
        searches={'relevance': {'items':[{'id':{'videoId':'a'}}]}, 'date': {'items':[]}},
        videos=[video('a')],
    )
    provider=YouTubeDataAPIProvider(client=client,quota_callback=lambda method,units: charges.append((method,units)))
    provider.search_videos('topic','ID')
    assert charges==[('search.list',1),('search.list',1),('videos.list',1)]


def test_quota_exhaustion_is_not_swallowed_as_a_search_failure():
    class QuotaExhaustedError(RuntimeError):
        pass
    provider = YouTubeDataAPIProvider(client=FakeClient({}, []), quota_callback=lambda method, units: (_ for _ in ()).throw(QuotaExhaustedError("quota")))
    with pytest.raises(QuotaExhaustedError):
        provider.search_videos("coffee", "ID")


def test_google_invalid_api_key_response_is_classified_for_same_project_rotation():
    import json
    from v17_niche_intel.providers.youtube_data_api import APIKeyInvalidError
    class HttpError(Exception):
        content = json.dumps({"error": {"message": "API key not valid. Please pass a valid API key.",
            "errors": [{"reason": "keyInvalid"}]}}).encode()
    provider = YouTubeDataAPIProvider(client=FakeClient({"relevance": HttpError()}, []))
    with pytest.raises(APIKeyInvalidError):
        provider.search_videos("coffee", "ID", query_orders=("relevance",))


def test_public_comment_sampler_returns_redacted_text_only_and_meters_quota():
    class CommentRequest:
        def execute(self):
            return {"items": [
                {"snippet": {"topLevelComment": {"snippet": {
                    "textDisplay": "Noisy grinder is hard to use. Contact me at test@example.com or +1 555 123 4567",
                    "authorDisplayName": "private display name"}}}},
            ]}
    class CommentResource:
        def list(self, **kwargs):
            assert kwargs["textFormat"] == "plainText"
            return CommentRequest()
    class CommentClient(FakeClient):
        def commentThreads(self): return CommentResource()
    metered = []
    provider = YouTubeDataAPIProvider(client=CommentClient({}, []), quota_callback=lambda method, units: metered.append((method, units)))
    result = provider.fetch_public_comments("video-1", limit=20)
    assert result["status"] == "ok"
    assert result["author_metadata_returned"] is False
    assert result["raw_comments_should_be_persisted"] is False
    assert "[EMAIL]" in result["comments"][0]
    assert "[PHONE]" in result["comments"][0]
    assert "private display name" not in result["comments"][0]
    assert metered == [("commentThreads.list", 1)]


def test_list_supported_regions_is_metered_and_returns_region_codes():
    class RegionRequest:
        def execute(self):
            return {"items": [
                {"snippet": {"gl": "ID", "name": "Indonesia"}},
                {"snippet": {"gl": "US", "name": "United States"}},
            ]}
    class RegionResource:
        def list(self, **kwargs):
            assert kwargs == {"part": "snippet"}
            return RegionRequest()
    class RegionClient(FakeClient):
        def i18nRegions(self):
            return RegionResource()
    charges = []
    provider = YouTubeDataAPIProvider(client=RegionClient({}, []),
        quota_callback=lambda method, units: charges.append((method, units)))
    assert provider.list_supported_regions() == (
        {"code": "ID", "name": "Indonesia"}, {"code": "US", "name": "United States"})
    assert charges == [("i18nRegions.list", 1)]


def test_public_comment_fetch_stops_on_repeated_page_token():
    class CommentClient:
        def __init__(self): self.calls = 0
        def commentThreads(self): return self
        def list(self, **kwargs):
            self.calls += 1
            return self
        def execute(self):
            return {"items": [], "nextPageToken": "repeat-token"}
    client = CommentClient()
    result = YouTubeDataAPIProvider(client=client).fetch_public_comments("video-1", limit=50)
    assert result["pages_fetched"] == 2
    assert result["error_types"] == ["RepeatedPageToken"]
    assert client.calls == 2


def test_youtube_provider_rejects_invalid_api_key_and_timeout_before_client_creation():
    import pytest
    with pytest.raises(ValueError, match="visible ASCII"):
        YouTubeDataAPIProvider(api_key="bad\nkey")
    with pytest.raises(ValueError, match="between 1 and 120"):
        YouTubeDataAPIProvider(api_key="valid-visible-key", timeout_seconds=121)


def test_youtube_search_rejects_unbounded_query_and_invalid_region():
    import pytest
    provider = YouTubeDataAPIProvider(client=object())
    with pytest.raises(ValueError, match="512 characters"):
        provider.search_videos("x" * 513, "US")
    with pytest.raises(ValueError, match="two-letter"):
        provider.search_videos("coffee", "USA")
    with pytest.raises(ValueError, match="query_orders"):
        provider.search_videos("coffee", "US", query_orders="relevance")
