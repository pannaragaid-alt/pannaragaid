import sys
import types

from v17_niche_intel.providers.http_transport import build_no_redirect_httplib2


def test_httplib2_transport_forces_zero_redirects_and_tls_verification(monkeypatch):
    captured = {}
    class FakeHttp:
        def __init__(self, **kwargs):
            captured["init"] = kwargs
        def request(self, uri, method="GET", body=None, headers=None, redirections=5, connection_type=None):
            captured["redirections"] = redirections
            return {"status": "200"}, b"ok"
    monkeypatch.setitem(sys.modules, "httplib2", types.SimpleNamespace(Http=FakeHttp))
    http = build_no_redirect_httplib2(17)
    response, body = http.request("https://youtube.googleapis.com/youtube/v3/videos", redirections=10)
    assert response["status"] == "200" and body == b"ok"
    assert captured["init"] == {"timeout": 17, "proxy_info": None, "disable_ssl_certificate_validation": False}
    assert captured["redirections"] == 0
