from datetime import datetime, timedelta, timezone
import pytest

from v17_niche_intel.domain.market_intelligence import (
    classify_search_intent, cluster_topics, competitor_overlap,
    calculate_serp_volatility, detect_cannibalization, analyze_seasonality,
    segment_market, assess_freshness, benchmark_thumbnail_metadata,
    benchmark_audio_metrics, extract_audience_pain_points,
    validate_experiment,
)


def test_intent_classification_distinguishes_informational_and_transactional():
    assert classify_search_intent("how to roast coffee beans") == "informational"
    assert classify_search_intent("best espresso grinder review") == "commercial"
    assert classify_search_intent("buy espresso grinder") == "transactional"
    assert classify_search_intent("espresso grinder") == "mixed_or_unknown"


def test_topic_clustering_groups_similar_intents_deterministically():
    rows = cluster_topics(["how to roast coffee", "coffee roasting tutorial", "buy a coffee grinder"])
    assert rows[0]["topic"] == "how to roast coffee"
    assert rows[0]["cluster_id"] == rows[1]["cluster_id"]
    assert rows[0]["cluster_id"] != rows[2]["cluster_id"]


def test_competitor_overlap_counts_channels_across_keyword_sets():
    result = competitor_overlap({"coffee": ["a", "b"], "espresso": ["a", "c"]})
    assert result[0] == {"channel_id": "a", "keyword_count": 2, "keywords": ["coffee", "espresso"]}


def test_serp_volatility_uses_rank_snapshots_and_rejects_bad_ranks():
    result = calculate_serp_volatility([
        {"observed_at": "2025-01-01T00:00:00+00:00", "results": ["a", "b", "c"]},
        {"observed_at": "2025-01-02T00:00:00+00:00", "results": ["b", "a", "c"]},
    ])
    assert result["status"] == "ok"
    assert result["mean_absolute_rank_change"] == pytest.approx(2 / 3)
    with pytest.raises(ValueError):
        calculate_serp_volatility([{"observed_at": "2025-01-01T00:00:00+00:00", "results": ["a", "a"]},
                                  {"observed_at": "2025-01-02T00:00:00+00:00", "results": ["a"]}])


def test_cannibalization_flags_duplicate_intent_assignments_not_distinct_intents():
    result = detect_cannibalization([
        {"video_id": "1", "intent": "informational", "topic": "coffee roast"},
        {"video_id": "2", "intent": "informational", "topic": "coffee roasting"},
        {"video_id": "3", "intent": "transactional", "topic": "coffee machine"},
    ])
    assert result == [{"intent": "informational", "video_ids": ["1", "2"]}]


def test_seasonality_requires_a_year_of_monthly_observations():
    data = [{"date": f"2025-{month:02d}-01", "value": float(month)} for month in range(1, 13)]
    assert analyze_seasonality(data)["status"] == "ok"
    assert analyze_seasonality(data[:6])["status"] == "insufficient_data"


def test_market_segmentation_preserves_country_and_language_axes():
    result = segment_market([{"country": "ID", "language": "id", "value": 10},
                             {"country": "US", "language": "en", "value": 20}])
    assert result["by_country"]["ID"] == 10
    assert result["by_language"]["en"] == 20


def test_freshness_is_explicit_and_timezone_aware():
    now = datetime.now(timezone.utc)
    assert assess_freshness(now - timedelta(days=30), now=now, max_age_days=30)["status"] == "fresh"
    assert assess_freshness(now - timedelta(days=31), now=now, max_age_days=30)["status"] == "stale"
    with pytest.raises(ValueError):
        assess_freshness(datetime.now(), now=now, max_age_days=30)


def test_thumbnail_benchmark_uses_observed_visual_metadata_only():
    result = benchmark_thumbnail_metadata([{"width": 1280, "height": 720, "has_face": True,
        "text_coverage": 0.2, "contrast_score": 0.8}])
    assert result["sample_size"] == 1
    assert result["mean_text_coverage"] == pytest.approx(0.2)


def test_audio_benchmark_reports_measured_quality_features():
    result = benchmark_audio_metrics([{"integrated_lufs": -14, "true_peak_dbfs": -1,
        "clipping_ratio": 0.0, "silence_ratio": 0.05, "snr_db": 40}])
    assert result["sample_size"] == 1
    assert result["mean_snr_db"] == 40


def test_pain_point_extraction_returns_repeated_problem_phrases():
    result = extract_audience_pain_points([
        "I struggle with noisy coffee grinders and inconsistent grind size",
        "noisy grinder makes it hard to record and grind size is inconsistent",
    ])
    assert "noisy" in result["recurring_terms"]
    assert result["sample_size"] == 2


def test_experiment_validation_requires_sufficient_samples_and_reports_delta():
    result = validate_experiment(baseline=[10, 12, 11, 9, 10], treatment=[12, 14, 13, 11, 12], metric="ctr")
    assert result["status"] == "evaluated"
    assert result["relative_lift_pct"] > 0
    assert validate_experiment(baseline=[1], treatment=[2], metric="ctr")["status"] == "insufficient_data"


def test_historical_tracking_calculates_interval_growth_only_from_repeated_snapshots():
    from v17_niche_intel.services.market_intelligence import MarketIntelligenceService
    result = MarketIntelligenceService().analyze({"historical_snapshots": [
        {"video_id": "v1", "observed_at": "2025-01-01T00:00:00+00:00", "views": 100},
        {"video_id": "v1", "observed_at": "2025-01-03T00:00:00+00:00", "views": 160},
        {"video_id": "v2", "observed_at": "2025-01-03T00:00:00+00:00", "views": 10},
    ]})
    history = result["historical_tracking"]
    assert history["videos_with_growth_measurement"] == 1
    assert history["video_growth"][0]["views_per_day"] == 30


def test_market_intelligence_service_keeps_source_provenance_and_confidence_separate():
    from v17_niche_intel.services.market_intelligence import MarketIntelligenceService
    result = MarketIntelligenceService().analyze({"keywords": ["how to brew coffee"], "evidence": [
        {"metric": "trend", "value": 50, "source_family": "google_trends",
         "observed_at": datetime.now(timezone.utc).isoformat(), "source_ref": "trend:coffee"}
    ]})
    assert result["confidence"]["independent_source_count"] == 1
    assert result["data_provenance"][0]["source_ref"] == "trend:coffee"


def test_local_thumbnail_measurement_uses_image_metadata_without_ctr_claim(tmp_path):
    from PIL import Image
    from v17_niche_intel.providers.media_quality import measure_thumbnail_file
    path = tmp_path / "thumbnail.png"
    Image.new("RGB", (1280, 720), (30, 60, 90)).save(path)
    result = measure_thumbnail_file(path)
    assert result["aspect_ratio"] == pytest.approx(16 / 9, rel=1e-3)
    assert "no face" in result["measurement"]


def test_local_audio_measurement_reports_signal_features_without_lufs_claim(tmp_path):
    import numpy as np
    import soundfile as sf
    from v17_niche_intel.providers.media_quality import measure_audio_file
    path = tmp_path / "voice.wav"
    sf.write(path, np.zeros((4800, 1), dtype=np.float32), 48000)
    result = measure_audio_file(path)
    assert result["sample_rate_hz"] == 48000
    assert result["silence_ratio"] == 1.0
    assert "not LUFS" in result["measurement"]


def test_intent_classifier_supports_indonesian_keywords():
    assert classify_search_intent("cara membuat kopi susu") == "informational"
    assert classify_search_intent("harga mesin kopi") == "transactional"
    assert classify_search_intent("mesin kopi terbaik") == "commercial"


def test_topic_clustering_handles_unicode_and_empty_token_topics():
    rows = cluster_topics(["cara membuat kopi", "cara membuat kopi susu", "あいう", "えお"])
    assert rows[0]["cluster_id"] == rows[1]["cluster_id"]
    assert rows[2]["cluster_id"] != rows[3]["cluster_id"]


def test_content_freshness_separates_recent_upload_share_from_lifetime_average_rate():
    from v17_niche_intel.domain.market_intelligence import analyze_content_freshness
    now = datetime(2025, 2, 1, tzinfo=timezone.utc)
    result = analyze_content_freshness([
        {"published_at": "2025-01-20T00:00:00+00:00", "views": 120},
        {"published_at": "2024-10-01T00:00:00+00:00", "views": 1200},
    ], now=now)
    assert result["videos_published_within_30_days"] == 1
    assert result["recent_30_day_share"] == 0.5
    assert result["rate_semantics"] == "lifetime_average_not_real_time_velocity"


def test_serp_volatility_requires_timestamps_not_just_ordered_lists():
    result = calculate_serp_volatility([["a", "b"], ["b", "a"]])
    assert result["status"] == "insufficient_data"
    assert "observed_at" in result["reason"]


def test_market_intelligence_aggregates_serp_volatility_and_competitor_overlap_per_keyword():
    from v17_niche_intel.services.market_intelligence import MarketIntelligenceService
    result = MarketIntelligenceService().analyze({
        "keywords": ["coffee", "espresso"],
        "serp_snapshots_by_keyword": {
            "coffee": [
                {"observed_at": "2025-01-01T00:00:00+00:00", "results": [{"url": "https://a.example/1"}, {"url": "https://b.example/1"}]},
                {"observed_at": "2025-01-02T00:00:00+00:00", "results": [{"url": "https://b.example/1"}, {"url": "https://a.example/1"}]},
            ],
            "espresso": [{"observed_at": "2025-01-01T00:00:00+00:00", "results": [{"url": "https://a.example/espresso"}]}],
        },
    })
    assert result["serp_volatility"]["by_keyword"]["coffee"]["status"] == "ok"
    assert result["serp_volatility"]["by_keyword"]["espresso"]["status"] == "insufficient_data"
    assert result["competitor_overlap"][0]["channel_id"] == "a.example"
    assert result["competitor_overlap"][0]["keyword_count"] == 2


def test_market_intelligence_runs_growth_audit_only_when_explicitly_supplied():
    from v17_niche_intel.services.market_intelligence import MarketIntelligenceService
    result = MarketIntelligenceService().analyze({"growth_audit": {
        "search_intent_rows": [{"query": "best espresso grinder", "intent": "commercial", "video_id": "v1"}]
    }})
    assert result["growth_diagnostics"]["schema_version"] == "v17-growth-audit-1.2"
    assert result["growth_diagnostics"]["search_intent"]["assigned_query_count"] == 1
