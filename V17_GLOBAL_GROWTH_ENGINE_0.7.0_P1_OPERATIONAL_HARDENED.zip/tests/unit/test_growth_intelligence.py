from datetime import datetime, timezone
import pytest

from v17_niche_intel.services.growth_intelligence import (
    audit_localization_coverage,
    analyze_competitor_weaknesses,
    analyze_retention_curve,
    analyze_search_intent_map,
    analyze_ctr_experiment,
    evaluate_market_economics,
)


def test_retention_curve_finds_largest_drop_and_interpolates_30_seconds():
    result = analyze_retention_curve([
        {"time_seconds": 0, "retention_pct": 100},
        {"time_seconds": 15, "retention_pct": 80},
        {"time_seconds": 30, "retention_pct": 55},
        {"time_seconds": 60, "retention_pct": 50},
    ])
    assert result["status"] == "analyzed"
    assert result["retention_at_30s_pct"] == 55
    assert result["largest_drop"]["drop_pct_points"] == 25
    assert result["largest_drop"]["from_seconds"] == 15


def test_retention_curve_rejects_non_monotonic_time_and_invalid_percentages():
    with pytest.raises(ValueError):
        analyze_retention_curve([
            {"time_seconds": 10, "retention_pct": 90},
            {"time_seconds": 5, "retention_pct": 80},
        ])
    with pytest.raises(ValueError):
        analyze_retention_curve([{"time_seconds": 0, "retention_pct": 120}])


def test_search_intent_map_flags_unassigned_and_cannibalized_intents():
    result = analyze_search_intent_map([
        {"query": "best espresso grinder", "intent": "commercial", "video_id": "v1"},
        {"query": "espresso grinder review", "intent": "commercial", "video_id": "v2"},
        {"query": "how to clean grinder", "intent": "informational", "video_id": "v3"},
        {"query": "coffee grinder", "intent": "commercial", "video_id": None},
    ])
    assert result["unassigned_query_count"] == 1
    assert result["cannibalization_flags"][0]["intent"] == "commercial"
    assert result["cannibalization_flags"][0]["video_count"] == 2


def test_localization_audit_requires_native_review_and_explicit_dialect_coverage():
    from datetime import datetime, timezone
    result = audit_localization_coverage([
        {"market_id": "ID-id", "query_variants": ["cara seduh kopi"],
         "native_reviewed": True, "review_source_ref": "review-1",
         "reviewed_at": datetime.now(timezone.utc).isoformat(), "dialect_reviewed": False},
        {"market_id": "IN-hi", "query_variants": ["कॉफी कैसे बनाएं"],
         "native_reviewed": False, "dialect_reviewed": False},
    ])
    assert result["ready_market_count"] == 0
    assert result["markets"][0]["status"] == "native_reviewed_dialect_pending"
    assert result["markets"][1]["status"] == "machine_or_unreviewed"


def test_competitor_weakness_map_aggregates_only_source_backed_observations():
    result = analyze_competitor_weaknesses([
        {"competitor_id": "c1", "gap": "outdated_content", "severity": 80,
         "audience_evidence_count": 4, "source_ref": "serp-1"},
        {"competitor_id": "c2", "gap": "outdated_content", "severity": 60,
         "audience_evidence_count": 2, "source_ref": "comments-2"},
        {"competitor_id": "c1", "gap": "poor_explanation", "severity": 90,
         "audience_evidence_count": 0, "source_ref": "review-3"},
        {"competitor_id": "c3", "gap": "unsupported", "severity": 99,
         "audience_evidence_count": 1, "source_ref": ""},
    ])
    assert result["accepted_observation_count"] == 3
    assert result["opportunities"][0]["gap"] == "outdated_content"
    assert result["opportunities"][0]["weighted_severity"] == 73.33
    assert result["opportunities"][0]["audience_evidence_count"] == 6


def test_ctr_experiment_reports_descriptive_only_without_randomization():
    result = analyze_ctr_experiment(1000, 100, 1000, 120, randomized=False)
    assert result["relative_lift_pct"] == 20
    assert result["decision_status"] == "observational_only"
    assert result["p_value_two_sided"] is None


def test_ctr_experiment_tests_randomized_counts_and_validates_bounds():
    result = analyze_ctr_experiment(10000, 1000, 10000, 1200, randomized=True)
    assert result["decision_status"] == "statistically_detectable"
    assert result["p_value_two_sided"] < 0.05
    with pytest.raises(ValueError):
        analyze_ctr_experiment(100, 101, 100, 10)


def test_market_economics_calculates_scenarios_without_claiming_actual_rpm():
    result = evaluate_market_economics(
        expected_views=100_000, rpm_low=2, rpm_base=5, rpm_high=8,
        production_cost=100, localization_cost=50, risk_reserve=25,
        confidence=0.6, rpm_source="scenario_assumption",
    )
    assert result["revenue_scenarios"]["base"] == 500
    assert result["net_scenarios"]["base"] == 325
    assert result["break_even_rpm"] == 1.75
    assert result["rpm_evidence_status"] == "scenario_only"


def test_market_economics_rejects_bad_ranges_and_unverified_competitor_rpm():
    with pytest.raises(ValueError):
        evaluate_market_economics(1000, 5, 4, 8, 10, 10, 0, 0.5, "scenario")
    with pytest.raises(ValueError):
        evaluate_market_economics(1000, 5, 6, 8, 10, 10, 0, 0.5, "competitor_estimate")


def test_ctr_sample_size_estimate_uses_baseline_rate_and_minimum_detectable_effect():
    from v17_niche_intel.services.growth_intelligence import estimate_ctr_sample_size
    result = estimate_ctr_sample_size(0.05, 0.01, alpha=0.05, power=0.8)
    assert result["impressions_per_arm"] > 0
    assert result["baseline_ctr"] == 0.05
    assert result["target_ctr"] == pytest.approx(0.06)


def test_discovery_surface_diagnostics_flag_packaging_retention_mismatch():
    from v17_niche_intel.services.growth_intelligence import analyze_discovery_surface
    result = analyze_discovery_surface(
        surface="browse", impressions=10000, views=800, ctr_pct=8,
        avg_view_duration_seconds=45, avg_percentage_viewed=25,
        baseline_ctr_pct=5, baseline_avg_percentage_viewed=50,
    )
    assert result["diagnostic_flags"] == ["high_ctr_low_retention_review_promise_delivery"]


def test_content_readiness_requires_rights_and_native_localization_gates():
    from v17_niche_intel.services.growth_intelligence import evaluate_content_readiness
    result = evaluate_content_readiness({
        "hook_defined": True, "promise_clear": True, "proof_present": True,
        "payoff_delivered": True, "rights_reviewed": False,
        "localization_reviewed": True, "thumbnail_title_aligned": True,
        "cta_relevant": True,
    })
    assert result["readiness_score_pct"] == 87.5
    assert result["status"] == "hold_hard_gate"
    assert "rights_reviewed" in result["blocking_items"]


def test_growth_bundle_preserves_missing_sections_as_not_configured():
    from v17_niche_intel.services.growth_intelligence import analyze_growth_bundle
    result = analyze_growth_bundle({"search_intent_rows": []})
    assert result["localization"]["status"] == "not_configured"
    assert result["search_intent"]["status"] == "insufficient_data"


def test_market_economics_requires_source_reference_for_first_party_rpm():
    with pytest.raises(ValueError):
        evaluate_market_economics(1000, 1, 2, 3, 1, 1, 0, 0.8,
                                 "owner_authorized_youtube_analytics")
    result = evaluate_market_economics(1000, 1, 2, 3, 1, 1, 0, 0.8,
        "owner_authorized_youtube_analytics", rpm_source_ref="analytics-export:2026-11")
    assert result["rpm_evidence_status"] == "first_party_analytics"


def test_localization_audit_downgrades_stale_native_review():
    from datetime import datetime, timedelta, timezone
    stale = (datetime.now(timezone.utc) - timedelta(days=181)).isoformat()
    result = audit_localization_coverage([{
        "market_id": "BR-pt", "query_variants": ["como preparar cafe"],
        "native_reviewed": True, "review_source_ref": "review-old", "reviewed_at": stale,
        "dialect_reviewed": True, "accent_reviewed": True, "cultural_reviewed": True,
    }])
    assert result["markets"][0]["status"] == "stale_or_undated_native_review"
    assert result["ready_market_count"] == 0


def test_growth_bundle_rejects_malformed_section_types_with_clear_error():
    from v17_niche_intel.services.growth_intelligence import analyze_growth_bundle
    with pytest.raises(ValueError, match="retention_curves must be an object"):
        analyze_growth_bundle({"retention_curves": []})
    with pytest.raises(ValueError, match="search_intent_rows must be a list"):
        analyze_growth_bundle({"search_intent_rows": {}})


def test_growth_bundle_includes_ctr_sample_size_planning():
    from v17_niche_intel.services.growth_intelligence import analyze_growth_bundle
    result = analyze_growth_bundle({"ctr_sample_size_plans": {
        "thumb-test": {"baseline_ctr": 0.04, "minimum_detectable_effect": 0.01,
                       "alpha": 0.05, "power": 0.8}
    }})
    assert result["ctr_sample_size_plans"]["thumb-test"]["impressions_per_arm"] > 0


def test_growth_bundle_integrates_operating_system_workstreams():
    from v17_niche_intel.services.growth_intelligence import analyze_growth_bundle
    result = analyze_growth_bundle({
        "competitor_evidence_observations": [{"observation_id": "o1", "competitor_id": "c1",
            "gap": "missing tutorial", "source_ref": "https://example.com/video",
            "observed_at": "2026-11-12T00:00:00Z"}],
        "audience_samples": [{"text": "confusing setup", "theme": "setup", "language": "en", "source_ref": "comment:1"}],
        "editorial_backlog": {"capacity_hours": 4, "topics": [{"topic_id": "t1", "title": "Setup",
            "evidence_refs": ["comment:1"], "demand_signal": 80, "audience_pain": 90,
            "competitive_gap": 80, "creator_fit": 80, "freshness": 70, "effort_hours": 3}]},
        "video_briefs": {"t1": {"topic_id": "t1", "title": "Setup", "audience_problem": "confusing setup",
            "promise": "clear setup", "evidence_refs": ["comment:1"]}},
        "first_party_kpis": {"channel": {"source": "owner_authorized_youtube_analytics", "source_ref": "analytics:1",
            "impressions": 1000, "impressions_ctr_pct": 5.0, "views": 200}},
        "experiment_integrity": {"thumb": {"randomized": True, "control_impressions": 500,
            "treatment_impressions": 500, "allocation_control": 0.5, "predeclared_primary_metric": True}},
        "portfolio_resource_allocation": {"capacity_hours": 4, "markets": [{"market_id": "us",
            "opportunity_score": 80, "confidence": .8, "risk": 10, "effort_hours": 4}]},
        "automation_jobs": [{"job_id": "daily", "operation": "read_only", "idempotency_key": "daily:1",
            "max_attempts": 2, "timeout_seconds": 30, "max_items": 50, "budget_units": 20,
            "kill_switch_enabled": True, "target_domains": ["youtube.com"]}],
    })
    assert result["schema_version"] == "v17-growth-audit-1.2"
    assert result["competitor_evidence_graph"]["accepted_count"] == 1
    assert result["audience_voice"]["cluster_count"] == 1
    assert result["editorial_backlog"]["allocated_hours"] == 3
    assert result["video_briefs"]["t1"]["claim_policy"] == "claims_must_be_supported_by_brief_evidence"
    assert result["first_party_kpis"]["channel"]["metrics"]["impressions_ctr_pct"]["value"] == 5
    assert result["experiment_integrity"]["thumb"]["decision_status"] == "integrity_checks_passed_pending_power_and_guardrails"
    assert result["portfolio_resource_allocation"]["allocated_hours"] == 4
    assert result["automation_job_reviews"][0]["execution_status"] == "not_scheduled_or_executed"


def test_growth_bundle_integrates_advanced_global_and_predictive_diagnostics():
    from v17_niche_intel.services.growth_intelligence import analyze_growth_bundle
    result = analyze_growth_bundle({
        "market_coverage": {"expected_market_ids": ["US-en", "BR-pt"],
            "attempts": [{"market_id": "US-en", "status": "ok", "sample_count": 10}]},
        "localized_query_plan": {"seed": "home coffee", "markets": [
            {"market_id": "BR-pt", "locale": "pt-BR", "language": "pt"}], "max_variants": 3},
        "competitor_snapshots": [
            {"video_id": "v1", "observed_at": "2026-01-01T00:00:00Z", "views": 100},
            {"video_id": "v1", "observed_at": "2026-01-02T00:00:00Z", "views": 200}],
        "originality_items": [{"content_id": "a", "title": "Same", "script": "same words"},
            {"content_id": "b", "title": "Same", "script": "same words"}],
        "audience_cohorts": [{"cohort": "new", "views": 100, "watch_time_seconds": 600,
            "returning_viewers": 2}],
        "source_quality_records": [{"source_id": "s1", "source_ref": "https://example.com", 
            "observed_at": datetime.now(timezone.utc).isoformat(), "quality": .9}],
        "multiple_testing_families": {"thumb": {"p_values": [.01, .04, .2]}},
        "forecast_intervals": {"views": {"actuals": [10, 20], "lower_bounds": [8, 15],
            "upper_bounds": [12, 25]}},
        "risk_adjusted_economics": {"us": {"scenarios": [
            {"probability": .5, "gross_revenue": 100}, {"probability": .5, "gross_revenue": 200}],
            "costs": 50, "risk_reserve": 10}},
    })
    assert result["schema_version"] == "v17-growth-audit-1.2"
    assert result["market_coverage"]["markets"]["BR-pt"]["status"] == "not_attempted"
    assert result["competitor_velocity"]["videos"]["v1"]["latest_views_per_day"] == 100
    assert result["originality_risk"]["flagged_pair_count"] == 1
    assert result["audience_cohorts"]["cohorts"]["new"]["average_view_duration_seconds"] == 6
    assert result["forecast_intervals"]["views"]["coverage_pct"] == 100
    assert result["risk_adjusted_economics"]["us"]["expected_net_contribution"] == 90


def test_first_party_kpi_tree_expands_cohort_journey_and_surface_metrics():
    from v17_niche_intel.services.growth_operations import calculate_first_party_kpi_tree
    result = calculate_first_party_kpi_tree({
        "source": "owner_authorized_youtube_analytics", "source_ref": "analytics:owner:1",
        "views": 1000, "watch_time_seconds": 60000, "impressions": 5000,
        "unique_viewers": 800, "returning_viewers": 200,
        "end_screen_clicks": 50, "end_screen_element_impressions": 1000,
        "shorts_stayed_to_watch": 600, "shorts_shown_in_feed": 1000,
        "estimated_revenue": 20,
    })
    metrics = result["metrics"]
    assert metrics["watch_time_per_impression_seconds"]["value"] == 12
    assert metrics["views_per_unique_viewer"]["value"] == 1.25
    assert metrics["returning_viewer_share_pct"]["value"] == 25
    assert metrics["end_screen_click_rate_pct"]["value"] == 5
    assert metrics["shorts_stayed_to_watch_pct"]["value"] == 60
    assert metrics["revenue_per_watch_hour"]["value"] == 1.2


def test_growth_bundle_integrates_topic_satisfaction_and_drift_diagnostics():
    from v17_niche_intel.services.growth_intelligence import analyze_growth_bundle
    result = analyze_growth_bundle({
        "topic_saturation": {"coffee": {"demand_index": 75, "competitor_uploads": 15,
            "competitor_median_views": 2000, "audience_pain_evidence_count": 8}},
        "satisfaction_surveys": {"post_view": {"responses": [{"score": 10}, {"score": 8}, {"score": 4}]}},
        "forecast_drift": {"views": {"baseline_actuals": [100] * 10, "baseline_predictions": [110] * 10,
            "recent_actuals": [100] * 10, "recent_predictions": [140] * 10,
            "degradation_threshold_pct": 20, "minimum_observations": 10}},
    })
    assert result["topic_saturation"]["coffee"]["demand_index_per_competitor_upload"] == 5
    assert result["satisfaction_surveys"]["post_view"]["response_count"] == 3
    assert result["forecast_drift"]["views"]["status"] == "degradation_alert"
