from datetime import datetime, timedelta, timezone

import pytest

from v17_niche_intel.services.advanced_intelligence import (
    analyze_competitor_velocity,
    analyze_forecast_intervals,
    analyze_originality_risk,
    audit_market_coverage,
    calculate_risk_adjusted_contribution,
    correct_multiple_testing,
    generate_localized_query_plan,
    summarize_audience_cohorts,
    audit_source_quality,
)


def test_market_coverage_distinguishes_all_attempt_states():
    result = audit_market_coverage(
        ["US-en", "BR-pt", "IN-hi", "JP-ja"],
        [
            {"market_id": "US-en", "status": "ok", "sample_count": 10},
            {"market_id": "BR-pt", "status": "partial", "sample_count": 2},
            {"market_id": "IN-hi", "status": "failed", "error_code": "quota"},
        ],
    )
    assert result["coverage_pct"] == 75
    assert result["markets"]["JP-ja"]["status"] == "not_attempted"
    assert result["markets"]["BR-pt"]["rankable"] is False


def test_localized_query_plan_keeps_machine_translation_unreviewed():
    result = generate_localized_query_plan(
        "home coffee roasting",
        [{"market_id": "BR-pt", "locale": "pt-BR", "language": "pt"}],
        translator=lambda seed, language: "torra de café em casa",
        curated_variants={"BR-pt": ["como torrar café em casa"]},
        max_variants=3,
    )
    market = result["markets"][0]
    assert market["variant_count"] == 3
    assert market["native_review_status"] == "required_or_stale"
    assert {row["origin"] for row in market["variants"]} == {"machine_translation", "human_curated", "seed_fallback"}


def test_competitor_velocity_requires_repeated_timestamped_snapshots():
    t0 = datetime(2026, 1, 1, tzinfo=timezone.utc)
    rows = [
        {"video_id": "v1", "observed_at": t0.isoformat(), "views": 100},
        {"video_id": "v1", "observed_at": (t0 + timedelta(days=1)).isoformat(), "views": 160},
        {"video_id": "v1", "observed_at": (t0 + timedelta(days=2)).isoformat(), "views": 250},
    ]
    result = analyze_competitor_velocity(rows)
    assert result["videos"]["v1"]["intervals"][0]["views_per_day"] == 60
    assert result["videos"]["v1"]["acceleration_views_per_day2"] == 30


def test_originality_risk_is_a_review_signal_not_a_copyright_verdict():
    result = analyze_originality_risk([
        {"content_id": "a", "title": "Amazing coffee roasting tips", "script": "Step one roast beans carefully."},
        {"content_id": "b", "title": "Amazing coffee roasting tips", "script": "Step one roast beans carefully."},
    ])
    assert result["pairs"][0]["similarity_pct"] == 100
    assert result["pairs"][0]["review_required"] is True
    assert "not_a_copyright_determination" in result["interpretation_limit"]


def test_risk_adjusted_contribution_uses_probabilities_and_costs():
    result = calculate_risk_adjusted_contribution(
        scenarios=[{"probability": .25, "gross_revenue": 100}, {"probability": .75, "gross_revenue": 200}],
        costs=50, risk_reserve=10,
    )
    assert result["expected_gross_revenue"] == 175
    assert result["expected_net_contribution"] == 115


def test_forecast_interval_reports_empirical_coverage():
    result = analyze_forecast_intervals([10, 20, 40], [8, 18, 25], [12, 22, 35])
    assert result["coverage_pct"] == pytest.approx(66.6667, abs=.001)
    assert result["mean_interval_width"] == pytest.approx(6.0, abs=.001)


def test_multiple_testing_uses_benjamini_hochberg_monotonic_adjustment():
    result = correct_multiple_testing([.01, .04, .03, .2])
    adjusted = [row["adjusted_p_value"] for row in result["results"]]
    assert adjusted == sorted(adjusted)
    assert adjusted[0] == pytest.approx(.04)


def test_audience_cohort_summary_keeps_unknown_values_missing():
    result = summarize_audience_cohorts([
        {"cohort": "new", "views": 100, "watch_time_seconds": 500, "returning_viewers": 5},
        {"cohort": "new", "views": 100, "watch_time_seconds": 700, "returning_viewers": 7},
        {"cohort": "returning", "views": 50, "watch_time_seconds": 600},
    ])
    assert result["cohorts"]["new"]["average_view_duration_seconds"] == 6
    assert result["cohorts"]["returning"]["returning_viewers"] is None


def test_source_quality_audit_flags_stale_and_missing_provenance():
    now = datetime(2026, 1, 10, tzinfo=timezone.utc)
    result = audit_source_quality([
        {"source_id": "fresh", "source_ref": "https://example.com/a", "observed_at": now.isoformat(), "quality": 1},
        {"source_id": "stale", "source_ref": "https://example.com/b", "observed_at": "2025-01-01T00:00:00Z", "quality": .8},
        {"source_id": "missing", "observed_at": now.isoformat()},
    ], now=now, freshness_days=30)
    assert result["status_counts"] == {"fresh": 1, "stale": 1, "missing_provenance": 1}


def test_robust_experiment_analysis_withholds_inference_when_observational_or_srm():
    from v17_niche_intel.services.advanced_intelligence import analyze_proportion_experiment
    observational = analyze_proportion_experiment(10000, 500, 10000, 600, randomized=False)
    assert observational["status"] == "observational_only"
    assert observational["p_value_two_sided"] is None
    srm = analyze_proportion_experiment(9000, 450, 11000, 660, randomized=True, allocation_control=.5)
    assert srm["status"] == "invalid_sample_ratio_mismatch"
    assert srm["p_value_two_sided"] is None


def test_robust_experiment_reports_wilson_and_newcombe_intervals():
    from v17_niche_intel.services.advanced_intelligence import analyze_proportion_experiment
    result = analyze_proportion_experiment(10000, 500, 10000, 650, randomized=True)
    assert result["control_wilson_ci_pct"][0] < 5 < result["control_wilson_ci_pct"][1]
    assert result["newcombe_difference_ci_pct_points"][0] > 0
    assert result["p_value_two_sided"] < .05


def test_forecast_model_comparison_requires_holdout_and_never_auto_promotes():
    from v17_niche_intel.services.advanced_intelligence import compare_forecast_models
    small = compare_forecast_models([10, 20], [11, 22], [10, 20], minimum_observations=3)
    assert small["status"] == "insufficient_holdout_observations"
    assert small["promotion_allowed"] is False
    result = compare_forecast_models([10, 20, 30], [12, 22, 32], [10, 21, 29], minimum_observations=3)
    assert result["status"] == "challenger_lower_wape_on_holdout"
    assert result["challenger_wape_improvement_pct"] > 0
    assert result["promotion_allowed"] is False


def test_topic_saturation_keeps_relative_demand_semantics_and_missing_supply():
    from v17_niche_intel.services.advanced_intelligence import analyze_topic_saturation
    result = analyze_topic_saturation(demand_index=80, competitor_uploads=20,
        competitor_median_views=5000, audience_pain_evidence_count=12, observation_days=30)
    assert result["demand_index_per_competitor_upload"] == 4
    assert result["demand_metric_semantics"] == "provider_relative_index_not_absolute_search_volume"
    missing = analyze_topic_saturation(demand_index=80, competitor_uploads=0)
    assert missing["demand_index_per_competitor_upload"] is None


def test_satisfaction_requires_explicit_survey_responses():
    from v17_niche_intel.services.advanced_intelligence import analyze_satisfaction_survey
    result = analyze_satisfaction_survey([{"score": 10}, {"score": 9}, {"score": 7}, {"score": 4}])
    assert result["net_promoter_score"] == 25
    assert result["response_count"] == 4


def test_forecast_drift_flags_wape_degradation_without_auto_retraining():
    from v17_niche_intel.services.advanced_intelligence import analyze_forecast_drift
    result = analyze_forecast_drift([100] * 10, [110] * 10, [100] * 10, [140] * 10,
        degradation_threshold_pct=20, minimum_observations=10)
    assert result["status"] == "degradation_alert"
    assert result["auto_retrain_or_promote"] is False


def test_localized_query_plan_requires_fresh_native_dialect_accent_and_cultural_gates():
    from datetime import datetime, timezone
    market = {"market_id": "ID-id", "locale": "id-ID", "language": "id",
        "native_reviewed": True, "review_source_ref": "https://review.example/id",
        "reviewed_at": datetime.now(timezone.utc).isoformat(), "dialect_reviewed": True,
        "accent_reviewed": True, "cultural_reviewed": True}
    result = generate_localized_query_plan("coffee", [market])
    assert result["markets"][0]["native_review_status"] == "recorded_native_review_gates_passed_unverified"
    assert result["markets"][0]["native_review_verified"] is False
