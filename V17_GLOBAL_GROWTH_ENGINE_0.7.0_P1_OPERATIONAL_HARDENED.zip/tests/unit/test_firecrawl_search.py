import json
from v17_niche_intel.providers.firecrawl_search import FirecrawlSearchProvider


def test_firecrawl_search_uses_public_ephemeral_search_request(monkeypatch):
    from v17_niche_intel.providers import firecrawl_search as module
    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self, limit=-1):
            payload = json.dumps({"data": {"web": [
                {"url": "https://example.com/coffee", "title": "Coffee", "description": "Public page"}
            ]}}).encode()
            return payload if limit < 0 else payload[:limit]
    captured = {}
    def fake_urlopen(request, timeout):
        captured["payload"] = json.loads(request.data.decode())
        captured["headers"] = dict(request.header_items())
        return Response()
    monkeypatch.setattr(module, "_open_firecrawl_request", lambda request, timeout: fake_urlopen(request, timeout))
    result = FirecrawlSearchProvider("test-key").search("coffee roasting", country="ID", location="Surabaya", limit=5)
    assert result["status"] == "ok"
    assert result["results"][0]["url"] == "https://example.com/coffee"
    payload = captured["payload"]
    assert payload["country"] == "ID"
    assert payload["location"] == "Surabaya"
    assert "scrapeOptions" not in payload
    assert "profile" not in payload and "cookies" not in payload
    assert result["cache_policy"] == "provider_managed"
    assert result["client_network_proxy"] == "disabled"
    assert "Authorization" in captured["headers"]


def test_firecrawl_search_rejects_oversized_provider_response(monkeypatch):
    import pytest
    from v17_niche_intel.providers import firecrawl_search as module

    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self, limit=-1):
            payload = json.dumps({"data": {"web": []}, "padding": "x" * (11 * 1024 * 1024)}).encode()
            self.read_limit = limit
            return payload if limit < 0 else payload[:limit]

    response = Response()
    monkeypatch.setattr(module, "_open_firecrawl_request", lambda *args, **kwargs: response)
    with pytest.raises(RuntimeError, match="response exceeds the configured size limit"):
        FirecrawlSearchProvider("fixture-key").search("coffee")
    assert response.read_limit == 10 * 1024 * 1024 + 1


def test_firecrawl_search_disables_proxy_and_redirect_forwarding(monkeypatch):
    from v17_niche_intel.providers import firecrawl_search as module
    captured = {}
    class FakeOpener:
        def open(self, request, timeout):
            captured["request"] = request
            captured["timeout"] = timeout
            return object()
    def build_opener(*handlers):
        captured["handlers"] = handlers
        return FakeOpener()
    monkeypatch.setattr(module.urllib.request, "build_opener", build_opener)
    request = module.urllib.request.Request("https://api.firecrawl.dev/v2/search", headers={"Authorization": "Bearer fixture"})
    module._open_firecrawl_request(request, 5)
    assert any(isinstance(handler, module.urllib.request.ProxyHandler) and handler.proxies == {} for handler in captured["handlers"])
    redirect_handler = next(handler for handler in captured["handlers"] if isinstance(handler, module._NoRedirectHandler))
    assert redirect_handler.redirect_request(request, None, 307, "Temporary Redirect", {}, "https://attacker.example/") is None


def test_firecrawl_search_bounds_query_inputs():
    import pytest
    provider = FirecrawlSearchProvider("fixture")
    with pytest.raises(ValueError, match="length limit"):
        provider.search("x" * 513)
    with pytest.raises(ValueError, match="two-letter"):
        provider.search("coffee", country="Indonesia")


def test_firecrawl_search_rejects_invalid_api_keys_and_timeout():
    import pytest
    with pytest.raises(ValueError, match="visible ASCII"):
        FirecrawlSearchProvider("bad\nkey")
    with pytest.raises(ValueError, match="between 1 and 120"):
        FirecrawlSearchProvider("fixture-key", timeout_seconds=121)


def test_firecrawl_search_drops_non_https_credentialed_and_ip_literal_result_urls(monkeypatch):
    from v17_niche_intel.providers import firecrawl_search as module
    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self, limit=-1):
            return json.dumps({"data": {"web": [
                {"url": "javascript:alert(1)", "title": "script"},
                {"url": "https://user:pass@example.com/", "title": "userinfo"},
                {"url": "https://127.0.0.1/admin", "title": "loopback"},
                {"url": "https://example.com:8443/", "title": "port"},
                {"url": "https://example.com/public", "title": "valid"},
            ]}}).encode()
    monkeypatch.setattr(module, "_open_firecrawl_request", lambda *args, **kwargs: Response())
    result = FirecrawlSearchProvider("fixture-key").search("coffee")
    assert [item["title"] for item in result["results"]] == ["valid"]


def test_firecrawl_search_rejects_duplicate_keys_in_provider_json(monkeypatch):
    import pytest
    from v17_niche_intel.providers import firecrawl_search as module

    class Response:
        def __enter__(self): return self
        def __exit__(self, *args): return False
        def read(self, limit=-1): return b'{"data":{"web":[]},"data":{"web":[]}}'

    monkeypatch.setattr(module, "_open_firecrawl_request", lambda *args, **kwargs: Response())
    with pytest.raises(ValueError, match="duplicate object key"):
        FirecrawlSearchProvider("fixture-key").search("coffee")
