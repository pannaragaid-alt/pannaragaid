from v17_niche_intel.providers.google_trends import GoogleTrendsProvider


def test_explicit_market_locale_overrides_language_default():
    class Client:
        pass

    provider = GoogleTrendsProvider(client=Client(), language_code="zh", locale="zh-SG")
    assert provider.locale == "zh-SG"


def test_google_trends_defaults_to_youtube_search_property():
    class Client:
        def __init__(self): self.kwargs = None
        def build_payload(self, keywords, **kwargs): self.kwargs = kwargs
        def interest_over_time(self):
            import pandas as pd
            return pd.DataFrame({"coffee": [50]}, index=[pd.Timestamp("2025-01-01")])
    client = Client()
    provider = GoogleTrendsProvider(client=client)
    provider.interest_over_time("coffee", geo="US")
    assert client.kwargs["gprop"] == "youtube"


def test_google_trends_can_explicitly_select_web_search_property():
    class Client:
        def __init__(self): self.kwargs = None
        def build_payload(self, keywords, **kwargs): self.kwargs = kwargs
        def interest_over_time(self):
            import pandas as pd
            return pd.DataFrame({"coffee": [50]}, index=[pd.Timestamp("2025-01-01")])
    client = Client()
    provider = GoogleTrendsProvider(client=client, property="google_web_search")
    provider.interest_over_time("coffee", geo="US")
    assert client.kwargs["gprop"] == ""
