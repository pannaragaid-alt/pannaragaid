import pytest

from v17_niche_intel.ui.theme import build_theme_css


def test_light_theme_emits_light_semantic_tokens():
    css = build_theme_css("light")
    assert '--v17-canvas: #F4F5F1' in css
    assert '--v17-surface: #FFFFFF' in css
    assert '--v17-focus: #176B62' in css
    assert 'data-v17-theme="light"' in css


def test_dark_theme_emits_dark_semantic_tokens():
    css = build_theme_css("dark")
    assert '--v17-canvas: #101719' in css
    assert '--v17-focus: #C6E86B' in css
    assert '--v17-surface: #182326' in css
    assert '--v17-focus: #C6E86B' in css
    assert 'data-v17-theme="dark"' in css


def test_system_theme_respects_operating_system_preference():
    css = build_theme_css("system")
    assert '@media (prefers-color-scheme: dark)' in css
    assert '--v17-canvas: #101719' in css
    assert '--v17-focus: #C6E86B' in css


def test_all_themes_include_responsive_focus_and_reduced_motion_rules():
    for theme in ("light", "dark", "system"):
        css = build_theme_css(theme)
        assert '@media (max-width: 768px)' in css
        assert ':focus-visible' in css
        assert '@media (prefers-reduced-motion: reduce)' in css


def test_unknown_theme_is_rejected():
    with pytest.raises(ValueError, match="Unsupported theme"):
        build_theme_css("neon")
