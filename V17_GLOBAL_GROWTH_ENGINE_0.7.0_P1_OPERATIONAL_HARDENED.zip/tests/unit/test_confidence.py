from datetime import datetime, timedelta, timezone

from v17_niche_intel.domain.confidence import assess_confidence
from v17_niche_intel.domain.enums import EvidenceStatus
from v17_niche_intel.domain.models import Evidence


def ev(metric, family, *, age_hours=1, quality=1.0):
    return Evidence(
        metric=metric,
        value=50.0,
        source_family=family,
        observed_at=datetime.now(timezone.utc) - timedelta(hours=age_hours),
        status=EvidenceStatus.OK,
        quality=quality,
    )


def test_multiple_metrics_from_same_family_count_as_one_independent_source():
    result = assess_confidence([
        ev("trend_level", "google_trends"),
        ev("trend_momentum", "google_trends"),
    ])
    assert result.independent_source_count == 1
    assert result.level == "low"


def test_independent_fresh_sources_raise_confidence():
    result = assess_confidence([
        ev("trend_level", "google_trends"),
        ev("video_sample", "youtube_data_api"),
        ev("community_activity", "reddit"),
    ])
    assert result.independent_source_count == 3
    assert result.level in {"medium", "high"}


def test_stale_and_low_quality_evidence_reduces_confidence():
    fresh = assess_confidence([ev("demand", "google_trends"), ev("supply", "youtube_data_api")])
    weak = assess_confidence([
        ev("demand", "google_trends", age_hours=24 * 60, quality=0.2),
        ev("supply", "youtube_data_api", age_hours=24 * 60, quality=0.2),
    ])
    assert weak.quality_index < fresh.quality_index


def test_empty_evidence_is_low_confidence():
    result = assess_confidence([])
    assert result.level == "low"
    assert result.independent_source_count == 0
