import json

from v17_niche_intel.cli import main


def test_metrics_cli_emits_versioned_catalog_json(capsys):
    assert main(["metrics", "--json"]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["registry_version"] == "youtube-analytics-v1"
    assert any(metric["api_name"] == "estimatedRevenue" for metric in result["metrics"])
