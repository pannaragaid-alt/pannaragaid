from v17_niche_intel.cli import main


def test_strategy_cli_rejects_json_file_larger_than_input_limit(tmp_path, capsys):
    source = tmp_path / "oversized.json"
    source.write_bytes(b" " * (10 * 1024 * 1024 + 1))

    assert main(["strategy", str(source)]) == 2
    assert "byte limit" in capsys.readouterr().err
