import json
from v17_niche_intel.cli import main


def test_doctor_json_reports_configuration_without_secrets(capsys,monkeypatch):
    monkeypatch.delenv('YOUTUBE_API_KEY',raising=False)
    assert main(['doctor','--json'])==0
    output=json.loads(capsys.readouterr().out)
    assert output['youtube_api_key_configured'] is False
    assert output['database_status'] == 'ok'
    assert output['database_health']['integrity_check'] == ['ok']
    assert output['database_health']['synchronous'] in {'FULL', 'EXTRA'}
    assert output['runtime_config']['status'] == 'ok'
    assert output['runtime_config']['youtube_daily_quota_limit'] == 10000
    assert 'api_key' not in output


def test_doctor_fails_closed_on_invalid_quota_environment(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv('YOUTUBE_SEARCH_DAILY_LIMIT', 'not-a-number')
    assert main(['--database', str(tmp_path / 'invalid-config.sqlite3'), 'doctor', '--json']) == 7
    output = json.loads(capsys.readouterr().out)
    assert output['runtime_config']['status'] == 'invalid'
    assert 'YOUTUBE_SEARCH_DAILY_LIMIT' in output['runtime_config']['errors'][0]


def test_backup_and_restore_cli_round_trip_secret_material(tmp_path, monkeypatch, capsys):
    from v17_niche_intel.credentials import CredentialManager
    from v17_niche_intel.storage.database import Database
    import v17_niche_intel.cli as cli
    class FakeKeyring:
        def __init__(self): self.values = {}
        def put(self, value):
            reference = "keyring://" + f"{len(self.values) + 1:032x}"
            self.values[reference] = value
            return reference
        def get(self, reference): return self.values[reference]
        def delete(self, reference): self.values.pop(reference, None)
    store = FakeKeyring()
    source = tmp_path / "source.sqlite3"
    db = Database(source)
    CredentialManager(db, store).add_api_key("key", project_id="project", use_case="market_research",
        environment="local", secret="private-key-material")
    db.close()
    monkeypatch.setattr(cli, "KeyringSecretStore", lambda: store)
    import getpass
    monkeypatch.setattr(getpass, "getpass", lambda prompt: "a sufficiently long passphrase")
    backup = tmp_path / "v17.enc"
    assert main(["--database", str(source), "backup", "--output", str(backup)]) == 0
    assert json.loads(capsys.readouterr().out)["encrypted"] is True
    target = tmp_path / "restored.sqlite3"
    assert main(["restore", str(backup), "--target-database", str(target)]) == 0
    assert json.loads(capsys.readouterr().out)["integrity"] == "ok"
    restored = Database(target)
    row = restored.connection.execute("SELECT secret_ref FROM api_credentials").fetchone()
    assert store.get(row["secret_ref"]) == "private-key-material"
    restored.close()


def test_serp_collect_cli_persists_timestamped_history_and_computes_volatility(tmp_path, monkeypatch, capsys):
    from datetime import datetime, timezone, timedelta
    import v17_niche_intel.cli as cli
    monkeypatch.setenv("FIRECRAWL_API_KEY", "test-firecrawl-key")
    class FakeSearch:
        calls = 0
        def __init__(self, key): pass
        def search(self, keyword, **kwargs):
            type(self).calls += 1
            results = ([{"url": "https://a.example/one"}, {"url": "https://b.example/two"}]
                       if type(self).calls == 1 else [{"url": "https://b.example/two"}, {"url": "https://a.example/one"}])
            return {"status": "ok", "observed_at": (datetime.now(timezone.utc) + timedelta(seconds=type(self).calls)).isoformat(), "results": results}
    monkeypatch.setattr(cli, "FirecrawlSearchProvider", FakeSearch)
    db_path = tmp_path / "serp.sqlite3"
    args = ["--database", str(db_path), "serp-collect", "--keyword", "coffee", "--country", "ID"]
    assert main(args) == 0
    capsys.readouterr()
    assert main(args) == 0
    report = json.loads(capsys.readouterr().out)
    assert report["serp_volatility"]["by_keyword"]["coffee"]["status"] == "ok"
    assert report["collection"]["snapshots_saved"] == 2


def test_strategy_cli_writes_evidence_linked_channel_blueprint(tmp_path, capsys):
    brief = {
        "niche": "home coffee brewing",
        "target_audience": "beginner home baristas in Indonesia",
        "audience_problem": "they cannot repeat cafe-quality results",
        "desired_outcome": "brew consistently at home",
        "unique_method": "tested recipes with local equipment",
        "audience_signals": [{"problem": "grinder settings are confusing", "source_family": "youtube_comments",
            "evidence_refs": ["comment:1"], "frequency": "high"}],
        "competitor_gaps": [{"competitor_id": "channel-a", "gap": "no budget grinder tests",
            "audience_impact": "high", "source_family": "competitor_video_review", "evidence_refs": ["video:1"]}],
    }
    source = tmp_path / "brief.json"
    output = tmp_path / "strategy.json"
    source.write_text(json.dumps(brief), encoding="utf-8")

    assert main(["strategy", str(source), "--output", str(output)]) == 0
    result = json.loads(output.read_text(encoding="utf-8"))
    capsys.readouterr()
    assert result["status"] == "ready_for_validation"
    assert result["opportunity_map"][0]["evidence_refs"] == ["video:1"]


def test_growth_audit_cli_runs_evidence_bundle_and_writes_json(tmp_path, capsys):
    source = tmp_path / "growth.json"
    output = tmp_path / "growth-report.json"
    source.write_text(json.dumps({
        "localization_markets": [{"market_id": "ID-id", "query_variants": ["cara seduh kopi"],
            "native_reviewed": True, "review_source_ref": "review-1",
            "reviewed_at": __import__("datetime").datetime.now(__import__("datetime").timezone.utc).isoformat(),
            "dialect_reviewed": True, "accent_reviewed": True, "cultural_reviewed": True}],
        "market_economics": {"ID-id": {"expected_views": 10000, "rpm_low": 1, "rpm_base": 2,
            "rpm_high": 3, "production_cost": 5, "localization_cost": 2,
            "risk_reserve": 1, "confidence": 0.5, "rpm_source": "scenario_assumption"}}
    }), encoding="utf-8")
    assert main(["growth-audit", str(source), "--output", str(output)]) == 0
    report = json.loads(output.read_text(encoding="utf-8"))
    capsys.readouterr()
    assert report["schema_version"] == "v17-growth-audit-1.2"
    assert report["localization"]["ready_market_count"] == 1
    assert report["market_economics"]["ID-id"]["rpm_evidence_status"] == "scenario_only"


def test_global_growth_cli_runs_integrated_engine_without_external_connections(tmp_path, capsys):
    source = tmp_path / "global-growth.json"
    output = tmp_path / "global-growth-report.json"
    source.write_text(json.dumps({"topic": "personal finance", "markets": [], "localization": [],
        "research_records": [], "allowed_hosts": [], "analytics": None, "distribution": {},
        "experiment": None, "learning": None, "automation_jobs": []}), encoding="utf-8")
    assert main(["global-growth", str(source), "--output", str(output)]) == 0
    report = json.loads(output.read_text(encoding="utf-8"))
    capsys.readouterr()
    assert report["engine_version"] == "v17-global-growth-engine-1.0.0"
    assert len(report["capabilities"]) == 8
    assert report["execution_boundary"]["external_requests_made"] is False


def test_global_growth_cli_requires_market_discovery_for_live_serp(tmp_path, capsys):
    source = tmp_path / "global-growth.json"
    source.write_text(json.dumps({"topic": "coffee"}), encoding="utf-8")
    assert main(["global-growth", str(source), "--live-web-serp"]) == 2
    assert "require --live-market-discovery" in capsys.readouterr().err


def test_experiment_cli_persists_registry_and_transitions(tmp_path, capsys):
    database = tmp_path / "v17.sqlite3"
    assert main(["--database", str(database), "experiment", "create", "thumb-1",
        "--idempotency-key", "thumb-1:v1", "--objective", "Improve watch time",
        "--primary-metric", "watch_time_per_impression"]) == 0
    created = json.loads(capsys.readouterr().out)
    assert created["created"] is True
    assert main(["--database", str(database), "experiment", "transition", "thumb-1", "running"]) == 0
    changed = json.loads(capsys.readouterr().out)
    assert changed["experiment"]["status"] == "running"


def test_growth_audit_cli_can_persist_explicit_decision_records(tmp_path, capsys):
    source = tmp_path / "growth.json"
    database = tmp_path / "v17.sqlite3"
    source.write_text(json.dumps({"decision_records": [{
        "decision_id": "d-1", "idempotency_key": "d-1:v1", "topic": "coffee",
        "recommendation": "Test a beginner guide", "evidence_refs": ["analytics:owner:1"],
        "expected_metric": "watch_time_per_impression", "status": "proposed"}]}), encoding="utf-8")
    assert main(["--database", str(database), "growth-audit", str(source), "--persist-decisions"]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["decision_log_inputs"]["inserted_count"] == 1
    assert result["decision_log_inputs"]["status"] == "persisted"


def test_decision_log_cli_lists_persisted_decisions(tmp_path, capsys):
    source = tmp_path / "growth.json"
    database = tmp_path / "v17.sqlite3"
    source.write_text(json.dumps({"decision_records": [{
        "decision_id": "d-2", "idempotency_key": "d-2:v1", "topic": "coffee",
        "recommendation": "Test a comparison format", "evidence_refs": ["analytics:owner:2"],
        "expected_metric": "watch_time_per_impression", "status": "proposed"}]}), encoding="utf-8")
    assert main(["--database", str(database), "growth-audit", str(source), "--persist-decisions"]) == 0
    capsys.readouterr()
    assert main(["--database", str(database), "decision-log", "--topic", "coffee"]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result[0]["decision_id"] == "d-2"


def test_cli_records_experiment_result_and_decision_validation(tmp_path, capsys):
    database = tmp_path / "v17.sqlite3"
    assert main(["--database", str(database), "experiment", "create", "e-final",
        "--idempotency-key", "e-final:v1", "--objective", "Improve AVD",
        "--primary-metric", "average_view_duration"]) == 0
    capsys.readouterr()
    assert main(["--database", str(database), "experiment", "transition", "e-final", "running"]) == 0
    capsys.readouterr()
    assert main(["--database", str(database), "experiment", "record-result", "e-final",
        "--result-json", '{"lift_pct":3.5,"guardrails_passed":true}']) == 0
    experiment = json.loads(capsys.readouterr().out)["experiment"]
    assert experiment["status"] == "completed"
    assert experiment["result"]["lift_pct"] == 3.5

    source = tmp_path / "decisions.json"
    source.write_text(json.dumps({"decision_records": [{"decision_id": "d-final",
        "idempotency_key": "d-final:v1", "topic": "coffee", "recommendation": "Test series",
        "evidence_refs": ["analytics:owner"], "expected_metric": "returning_viewers"}]}), encoding="utf-8")
    assert main(["--database", str(database), "growth-audit", str(source), "--persist-decisions"]) == 0
    capsys.readouterr()
    assert main(["--database", str(database), "decision-log", "transition", "d-final", "accepted"]) == 0
    decision = json.loads(capsys.readouterr().out)["decision"]
    assert decision["status"] == "accepted"


def test_scrape_cli_fails_closed_without_owner_allowlist(monkeypatch, capsys):
    monkeypatch.delenv("V17_SCRAPE_ALLOWED_HOSTS", raising=False)
    assert main(["scrape", "https://example.com/"]) == 5
    assert "allowlist" in capsys.readouterr().err.lower()


def test_scrape_cli_rejects_non_allowlisted_host_before_network(monkeypatch, capsys):
    monkeypatch.setenv("V17_SCRAPE_ALLOWED_HOSTS", "approved.example.com")
    monkeypatch.setenv("V17_SCRAPE_ALLOWED_PATHS", "approved.example.com=/public")
    assert main(["scrape", "https://attacker.example.net/public"]) == 5
    assert "allowlist" in capsys.readouterr().err.lower()


def test_scrape_cli_fails_closed_without_path_policy(monkeypatch, capsys):
    monkeypatch.setenv("V17_SCRAPE_ALLOWED_HOSTS", "approved.example.com")
    monkeypatch.delenv("V17_SCRAPE_ALLOWED_PATHS", raising=False)
    assert main(["scrape", "https://approved.example.com/public"]) == 5
    assert "path-prefix policy" in capsys.readouterr().err.lower()


def test_doctor_rejects_partial_youtube_environment_credentials(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv('YOUTUBE_API_KEY', 'not-a-real-key')
    monkeypatch.delenv('YOUTUBE_API_PROJECT_ID', raising=False)
    assert main(['--database', str(tmp_path / 'partial-youtube.sqlite3'), 'doctor', '--json']) == 7
    output = json.loads(capsys.readouterr().out)
    assert any('must be configured together' in error for error in output['runtime_config']['errors'])


def test_doctor_rejects_incomplete_scrape_allowlist_policy(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv('V17_SCRAPE_ALLOWED_HOSTS', 'example.com')
    monkeypatch.delenv('V17_SCRAPE_ALLOWED_PATHS', raising=False)
    assert main(['--database', str(tmp_path / 'partial-scrape.sqlite3'), 'doctor', '--json']) == 7
    output = json.loads(capsys.readouterr().out)
    assert output['runtime_config']['scrape_policy_configured'] is True
    assert any('Scrape policy' in error for error in output['runtime_config']['errors'])
