# V17 Global Growth Intelligence Engine 0.4.0 — Implementation Report

**Date:** 2026-11-14  
**Base:** V17 Niche Intelligence 0.3.0 / P1-P10 upgrade  
**Release:** 0.4.0  
**Engine:** `v17-global-growth-engine-1.0.0`

## Executive result

Implemented the eight requested capability upgrades as an integrated, evidence-aware decision engine and preserved the existing P1-P10 growth-audit path. The engine has offline mode plus opt-in live adapters for YouTube market discovery, Google Trends, Firecrawl public SERP sampling and owner-authorized YouTube Analytics. All eight capability outputs are emitted by one orchestration call.

**Verification:** 280 tests passed; compile checks, CLI smoke tests, input/output JSON Schema validation and legacy growth-audit regression passed. Wheel build, isolated wheel-install smoke test and clean-archive extraction verification passed; hashes are included in the release manifest and checksum files.

**Not production-certified.** No live API calls, Google OAuth consent, native-speaker certification, live A/B experiment, scheduler/worker deployment or production deployment were performed in this environment.

## Eight-priority delivery status

| Priority | Delivered | Status / remaining external gate |
|---|---|---|
| 1. Global Market Discovery & Economics | Dynamic YouTube-supported region registry + CLDR profiles; one seed topic across market profiles; optional translation; YouTube search, market-local Google Trends and separate quota budgets; four-layer model preserved; RPM scenarios and confidence-adjusted economics | Code complete. Live scan requires configured YouTube API credentials and remaining quota. Partial scans withhold final rankings. Coverage is supported YouTube regions plus metadata-supported locales, not every language spoken in every country. |
| 2. Native Localization | Query variants, locale metadata, native/dialect/accent/culture gates, review provenance and 180-day freshness gate; machine translation is discovery-only | Code complete. Native reviewer evidence is declared, not independently authenticated; actual review must be done by qualified native speakers. |
| 3. Research Data Pipeline | HTTPS-only standard-port public URL validation, explicit hostname allowlist, internal-host/IP rejection, timezone-aware timestamps, future-date checks, freshness, SHA-256 dedupe, evidence metadata; bounded Firecrawl SERP adapter | Code complete. Live Firecrawl collection requires `FIRECRAWL_API_KEY`, explicit `allowed_hosts`, and opt-in CLI flags. No arbitrary crawl is started. |
| 4. Channel Analytics & Country RPM | Daily owner Analytics provider query, denominator-aware KPI aggregation, country-level views/revenue/RPM query, private daily and country tables, monetary read-only OAuth scope, opt-in dashboard consent checkbox | Code complete. Live use requires the owner to grant `yt-analytics.readonly` and `yt-analytics-monetary.readonly`. No OAuth session or channel data was available/run here. |
| 5. Distribution Optimization | Separate diagnostic scores for Search, Browse, Suggested and Shorts; missing inputs withhold scores | Code complete. Scores are transparent operator diagnostics, not YouTube ranking weights or distribution predictions. |
| 6. Experimentation | Two-proportion sample-size planning, allocation-aware sample requirements, SRM chi-square, lift, p-value and alpha-aligned confidence interval | Code complete. No platform-side randomized experiment was launched; assumptions such as clustering, repeated exposure and multiple comparisons still require design review. |
| 7. Continuous Learning | MAE, WAPE, MAPE, aggregate bias; minimum sample gate; versioned policy proposal and out-of-sample review requirement | Code complete. No automatic policy update; human approval and holdout backtest required. |
| 8. Automation & QA | Idempotency, explicit host allowlist, kill switch, retry/timeout/item/budget bounds; read-only-only contract gate | Validator complete. Mutating jobs are blocked pending approval. No scheduler, worker or background process is deployed. |

## Integrated workflow

1. Accept one seed keyword/topic and structured evidence.
2. Optionally fetch YouTube-supported regions and construct country-language profiles from CLDR metadata.
3. Build locale query sets from curated/native-reviewed variants or optional machine translation; unreviewed variants remain flagged.
4. Run country-specific YouTube search and optional market-local Google Trends within separate quotas.
5. Optionally collect public web SERP samples per discovered market through Firecrawl, filtering results to explicit host allowlists.
6. Normalize source evidence, timestamp, freshness and deduplication state.
7. Score market economics from supplied RPM/demand/gap/fit/confidence inputs; use first-party country RPM only when matching country and currency evidence is supplied.
8. Fetch and persist owner-authorized channel Analytics privately; aggregate counts and rates using their correct denominators.
9. Score Search/Browse/Suggested/Shorts diagnostics from supplied first-party or validated operator metrics.
10. Plan and evaluate experiments; block SRM/underpowered interpretations.
11. Produce a versioned learning proposal from forecast errors; require human review.
12. Validate automation contracts; do not schedule or execute them.

## Formulas and scoring logic

### Existing four-layer market decision model

- Audience demand: 25%
- Competitive opening: 25%
- Monetization economics: 25%
- Creator execution fit: 25%

Within-layer component weights remain in `v17_niche_intel/services/global_market.py`. A layer requires at least 75% weighted component coverage; final ranking requires 100% coverage across all four layers, current evidence and verified market eligibility. Missing evidence is not neutral-filled. Creator fit requires language/cultural fluency and policy/rights resilience; policy/rights resilience below 50 triggers a hold.

### Market economics

`GrossRevenue_scenario = reachable_monthly_views / 1,000 × RPM_scenario`

`NetContribution_base = gross_revenue_base − production_cost − localization_cost − risk_reserve`

`OpportunityScore = 0.25×Demand + 0.20×RelativeMonetization + 0.20×CompetitiveGap + 0.20×CreatorFit + 0.15×Confidence`

`ConfidenceAdjustedScore = OpportunityScore × confidence`

All score components are normalized to 0–100; confidence is supplied as 0–1. Relative monetization is normalized only within a common reporting currency. Mixed currencies require a sourced HTTPS FX rate observed within seven days. RPM and revenue scenarios are not guaranteed future revenue. First-party country RPM can fill a missing RPM only if the source is declared owner-authorized and the currency matches; the calculation layer labels provenance as declared, not independently authenticated.

### Channel KPI formulas

- Thumbnail impressions CTR: YouTube `videoThumbnailImpressionsClickRate`, weighted by thumbnail impressions when aggregating days.
- AVD: total estimated watch-time minutes × 60 / total views.
- APV: view-weighted mean of YouTube `averageViewPercentage`.
- Watch time hours: estimated minutes watched / 60.
- Subscribers gained per 1,000 views: subscribers gained / views × 1,000 (channel-level ratio, not causal video attribution).
- Revenue per 1,000 views: estimated revenue / views × 1,000.
- Country RPM: country estimated revenue / country views × 1,000 for this channel and period only.

### Distribution diagnostic weights

| Surface | Formula |
|---|---|
| Search | 0.35×intent match + 0.30×topic relevance + 0.15×metadata alignment + 0.20×satisfaction |
| Browse | 0.25×audience fit + 0.25×packaging + 0.25×early retention + 0.25×satisfaction |
| Suggested | 0.30×topic adjacency + 0.25×viewer overlap + 0.20×session continuity + 0.25×satisfaction |
| Shorts | 0.25×swipe-stop + 0.25×viewed-vs-swiped + 0.25×retention + 0.25×satisfaction |

Every component is 0–100. Scores are diagnostics only; no ranking guarantee or disclosed YouTube weight is implied.

### Experimentation

For two independent proportions, the planning approximation is:

`n ≈ [z(1−α/2)√(2p̄(1−p̄)) + z(power)√(p1(1−p1)+p2(1−p2))]² / (p2−p1)²`

It reports sample requirements by allocation share, SRM chi-square (two arms, 1 degree of freedom, 3.841 threshold at 5%), observed lift, p-value and confidence interval at the selected alpha. It requires all four observed success/trial counts together. This is not a substitute for a full experiment design where there is clustering, repeated exposure, sequential monitoring or multiple testing.

### Continuous learning

Forecast metrics: `MAE = mean(|forecast−actual|)`; `WAPE = sum(|error|)/sum(actual)`; `MAPE = mean(|error|/actual)` over non-zero actuals; `AggregateBias = sum(forecast−actual)/sum(actual)`. A policy proposal requires a minimum observation count and proposed weights summing to one. No policy is automatically changed.

### Automation guardrails

Read-only operations only; idempotency key required; explicit hostname allowlist; kill switch required; 1–5 attempts; 1–300 second timeout; 1–1,000 items; 1–10,000 budget units. Mutating operations are blocked. No scheduler exists in this release.

## CLI usage

Offline integrated report (no external request):

```bash
v17 global-growth examples/global_growth_engine.template.json --output global-growth-report.json
```

Live global market scan (YouTube API credentials and quota required):

```bash
v17 global-growth input.json --live-market-discovery --search-call-budget 80
```

Optional public web SERP sampling (Firecrawl key + explicit `allowed_hosts` in input):

```bash
v17 global-growth input.json --live-market-discovery --live-web-serp --serp-call-budget 40
```

Optional machine translation and Google Trends:

```bash
v17 global-growth input.json --live-market-discovery --machine-translate --google-trends --trends-call-budget 40
```

Owner Analytics and country RPM (existing OAuth account must have both read-only scopes):

```bash
v17 global-growth input.json --channel-analytics --channel-id UC... --analytics-start-date 2026-10-01 --analytics-end-date 2026-10-31
```

The dashboard Connections tab has an opt-in checkbox to request the additional monetary read-only permission. It does not grant publishing or channel-management permissions.

## Skills selected and applied

Skills were selected by relevance to backend/data pipelines, evidence quality, marketing analytics, experimentation, security, TDD and delivery. Skill loading does not mean agents were spawned or external apps were connected.

- **Superpowers:** `using-superpowers`, `brainstorming`, `writing-plans`, `test-driven-development`, `executing-plans`, `verification-before-completion`.
- **Caveman Development:** `cavecrew` (small-change/delegation discipline; no subagents were launched).
- **Agency Agents:** `agency-orchestrator`, `agency-academic`, `agency-marketing` (strategy/evidence review; no separate agents were launched).
- **Matt Pocock Engineering Studio:** `tdd`.
- **ECC Agent Harness:** `ecc-agentic-engineering`, `ecc-backend-data-engineering`, `ecc-defensive-security`, `ecc-evaluation-benchmarking`, `ecc-tdd-verification`, `ecc-documentation-governance`.
- **Marketing Growth Studio:** `analytics`, `content-strategy`, `competitor-profiling`, `ab-testing`.
- **Scrapling:** `scrapling-core`, `scrapling-parsing`, `scrapling-safety-compliance` (used for safety/pipeline design; no Scrapling browser/MCP runtime was connected).
- **Spec Kit:** `requirements-specification`, `technical-planning`, `self-test-and-validation`.
- **UI/UX Pro Max:** `charts-data-visualization` (metric integrity applied; no chart redesign was required).
- **Ponytail:** `ponytail`, `ponytail-audit`, `ponytail-python-verification`.
- **Anti-Slop:** `antislop`, `antislop-code`, `antislop-delivery-gate` (claim/evidence and delivery review; no full UI redesign).
- **I Have ADHD:** `i-have-adhd` (execution/reporting structure).

## Verification evidence

- `python -m pytest -q`: **280 passed** (source tree and clean archive extraction).
- `python -m compileall -q v17_niche_intel tests`: passed.
- `python -m py_compile v17_niche_intel/dashboard.py`: passed.
- `python -m v17_niche_intel.cli --help`: passed.
- `python -m v17_niche_intel.cli global-growth examples/global_growth_engine.template.json`: passed; all eight capability blocks present.
- `python -m v17_niche_intel.cli growth-audit examples/growth_audit.template.json`: passed; legacy P1-P10 path remains functional.
- JSON Schema Draft 2020-12: input schema, output schema, example template and generated report all validated.
- Wheel: built with `pip wheel . --no-deps --no-build-isolation`; installed into an isolated target directory; CLI help and engine import/smoke passed.
- Source ZIP: `unzip -t` passed; clean extraction full test suite passed (280 tests); archive scan found no SQLite databases, `.env`, key, PEM or bytecode artifacts.
- Ruff lint: **not run**; Ruff is not installed in the environment.
- Streamlit browser/accessibility QA: **not run**; Streamlit is not installed in the environment.
- Live YouTube, Google Trends, Firecrawl and OAuth calls: **not run**; credentials/provider access were not available or explicitly authorized in this execution.

## Explicit limitations

1. No system can guarantee page-one placement, recommendation volume, algorithm dominance or revenue.
2. The engine does not infer competitor-private RPM, CTR, retention or demographics.
3. Supported-region and CLDR profiles are not a claim of complete coverage of every language, dialect or subculture worldwide.
4. Machine translation is not native-speaker validation.
5. Country RPM is first-party to the authenticated channel and selected period, not a market-wide RPM benchmark.
6. Partial quota scans do not produce final rankings; persistent multi-day scan orchestration is not deployed.
7. No automatic publishing, scheduling, account mutation, production deployment or autonomous scoring-policy update is included.
