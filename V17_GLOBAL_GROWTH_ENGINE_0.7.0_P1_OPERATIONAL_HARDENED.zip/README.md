# V17 YouTube Niche Intelligence

V17 is an evidence-aware research engine for building a YouTube channel from zero or improving an existing owner-authorized channel. It separates public competitor evidence from private first-party Analytics, supports Shorts candidates, long-form, and live content, and withholds aggregate scores when evidence coverage is insufficient.

## Current capabilities

- **Research:** read-only YouTube Data API sampling, public comment pain-point sampling, Google Trends relative-interest adapter, multi-market inputs, format classification, and reproducible research runs.
- **SERP tracking:** Firecrawl Search collection by keyword/country/location, timestamped SERP snapshots, rank volatility, and competitor-domain overlap. Re-run `serp-collect` to build a history; language is retained as an annotation because Firecrawl Search does not guarantee language filtering.
- **Market intelligence:** search-intent classification, topic clustering, competitor overlap, SERP rank volatility, cannibalization checks, seasonality, country/language segmentation, freshness, audience pain-point term discovery, thumbnail/audio measurements, experiment validation, and operator-input channel feasibility/risk scoring.
- **Growth diagnostics:** source-backed competitor weakness aggregation and dated evidence graph, audience pain-theme clusters, evidence-linked editorial backlog and video briefs, native localization/dialect/accent/cultural freshness gates, retention-curve analysis, Search intent overlap, Search/Browse/Suggested/Shorts diagnostics, first-party KPI tree, CTR sample-size/SRM/experiment checks, RPM scenario economics, risk-adjusted portfolio capacity allocation, and pre-publication rights/localization gates.
- **Automation governance:** validates bounded read-only job contracts with idempotency keys, explicit domain allowlists, retry/time/budget caps and kill-switch requirements. SQLite stores persistent job checkpoints and expiring worker leases; the runner skips malformed/exhausted queue entries, and handlers can renew a live lease without changing checkpoint data by calling `save_checkpoint()` with no argument. The runner is manually invoked; no background scheduler or publishing worker is deployed.
- **History and provenance:** SQLite research history, source references, quality/freshness metadata, video snapshots, and deterministic raw-payload provenance hashes with request, locale, region, time-window, and transform metadata.
- **Metric contracts:** versioned Analytics metric catalog, required-scope declarations, endpoint/dimension compatibility planning, and a `v17 metrics --json` inspection command.
- **Bounded async:** `BoundedAsyncExecutor` offloads synchronous providers with bounded concurrency and cancellation-safe slot accounting; provider HTTP timeouts remain mandatory.
- **Channel analytics:** validated Analytics CSV import and opt-in Google OAuth using read-only scopes, single-use state, PKCE, explicit channel binding, refresh, account disable, and remote revocation.
- **Credential safety:** multi-key registry, per-project shared quota ledger, same-project invalid-key failover, OAuth account registry, OS keyring, encrypted AES-GCM backup/restore, and secret references rather than secret values in SQLite.
- **Incognito scraping:** direct local HTTPS fetches only; exact owner-approved hostname and path-prefix allowlists, DNS-to-IP pinning, TLS hostname verification, per-hop redirect revalidation, no cookies/profile/auth session, bounded response bytes, bounded redirects, timeout, strict content types, and heuristic email/phone redaction. It is stateless, not anonymous: the target sees the client network IP. Hosted Firecrawl target fetching is deliberately disabled; Firecrawl Search is SERP-only and omits scrape options.
- **Interfaces:** CLI and Streamlit dashboard share the service layer. JSON evidence bundles enable repeatable advanced analyses. The dashboard uses the Signal Atelier UI system with Light / Dark / System themes and focused workspace navigation.

## Dashboard UI / UX

The Streamlit workspace uses a custom **Signal Atelier** visual system rather than a generic admin template:

- **Appearance:** System, Light, or Dark. System follows the operating-system color preference.
- **Workspace navigation:** Overview, Connections, Public Intelligence, and Advanced Lab.
- **Focused research setup:** the primary research controls stay in the sidebar; channel-specific inputs appear only for Existing Channel / Both modes.
- **Evidence-first results:** coverage, score status, sample size, provider readiness, video evidence, and limitations are prioritized; detailed JSON is progressively disclosed.
- **UI implementation targets:** source includes fluid layouts, visible keyboard focus and reduced-motion handling. Browser, assistive-technology and breakpoint verification must be run in the target environment; source presence alone is not a conformance claim.

Design tokens and page guidance live in `design-system/v17-niche-intelligence/MASTER.md`; the implementation review is in `docs/UI_UX_REDESIGN_REPORT.md`.

## Install

```bash
python -m venv .venv
# activate the environment
pip install -e '.[all]'
```

`.[all]` includes the app, YouTube, Trends, translation, global locale metadata (Babel/pycountry/pytz), OAuth, keyring, and local media-analysis dependencies. For a smaller install, use `.[app,youtube,trends,translation,global,oauth,secrets,media]` as needed.

## Run

```bash
# Validate database integrity, durability settings, quota configuration and provider policy
v17 doctor --json

# Public market research (no OAuth required)
v17 metrics --json

v17 research "home coffee roasting" --country ID --language id --mode market_entry --limit 25 --output report.json

# Fetch owner-authorized daily channel Analytics (requires a connected OAuth account)
v17 analytics --channel-id UCxxxxxxxxxxxxxxxxxxxxxx --start-date 2025-01-01 --end-date 2025-01-31

# Or validate and import owner-exported YouTube Analytics CSV
v17 import-analytics analytics.csv --channel-id UCxxxxxxxxxxxxxxxxxxxxxx

# Collect public web SERPs; repeat later to calculate volatility and overlap
v17 --database v17_niche_intel.sqlite3 serp-collect --keyword "coffee roasting" --keyword "espresso grinder" --country ID --location Surabaya --output serp-report.json

# Analyze an evidence bundle containing keywords, competitor sets, SERP snapshots,
# content plan, monthly trend observations, market observations, media files,
# audience text, historical snapshots, experiment samples and optional channel strategy
v17 intelligence evidence.json --output intelligence-report.json

# Build a channel foundation and evidence-linked positioning blueprint
# Start from examples/channel_strategy.template.json and attach real source references
v17 strategy channel-brief.json --output channel-strategy.json

# Run the full evidence-backed P1-P10 growth operating audit
# Optional sections cover competitor evidence, audience voice, editorial backlog,
# video briefs, first-party KPI tree, experiment integrity, portfolio allocation,
# and read-only automation contract reviews.
v17 growth-audit examples/growth_audit.template.json --output growth-audit-report.json

# Configure exact hostnames you own or are explicitly authorized to research.
# No wildcard, suffix matching, IP literal, or empty allowlist is accepted.
export V17_SCRAPE_ALLOWED_HOSTS="example.com,docs.example.org"
export V17_SCRAPE_ALLOWED_PATHS="example.com=/public|/articles;docs.example.org=/guides"
# Direct local HTTPS fetch; no Firecrawl API key is required for this command.
v17 scrape https://example.com/public-page --output page.md

# Purge public YouTube API-derived data older than the policy retention window
v17 --database v17_niche_intel.sqlite3 purge-expired --retention-days 30

# Encrypted backup (includes SQLite metadata and secret material inside AES-GCM envelope)
v17 --database v17_niche_intel.sqlite3 backup --output v17-backup.v17enc

# Restore into a new database and remap secrets into the OS keyring
v17 restore v17-backup.v17enc --target-database restored-v17.sqlite3

# Local app
streamlit run v17_niche_intel/dashboard.py
```



### Runtime quota configuration and operational checks

`YOUTUBE_DAILY_QUOTA_LIMIT` and `YOUTUBE_SEARCH_DAILY_LIMIT` are bounded positive-integer settings shared by the CLI, provider factory and dashboard. The default values are `10000` general quota units and `100` `search.list` calls per day. `YOUTUBE_API_KEY` and `YOUTUBE_API_PROJECT_ID` must be configured together. The scrape hostname and path policy must also be configured as a complete pair when enabled. Start with `v17 doctor --json`; it reports database integrity, foreign-key health, WAL/durability settings, schema version, file permissions, and configuration errors without printing secret values. SQLite 3.31.0 or newer is required.

The source archive intentionally excludes the local runtime database. A fresh database is created on first run; never package a developer's live SQLite database into a source release.

### Incognito scrape egress policy

`V17_SCRAPE_ALLOWED_HOSTS` and `V17_SCRAPE_ALLOWED_PATHS` are mandatory for `v17 scrape` and the dashboard Incognito panel. The host variable is a comma-separated list of exact DNS hostnames (IDNA is normalized). The path variable maps every host to one or more exact path prefixes, using `host=/prefix|/other;docs.example.org=/docs`. Wildcards, suffix matching, trailing-dot names, IP literals, credentials, nonstandard ports, HTTP, fragments, encoded paths, duplicate separators, and dot segments are rejected. Each redirect is revalidated against both policies and independently resolved; the TCP connection is pinned to the validated IP while TLS certificate verification and SNI use the canonical hostname. Any private, reserved, special-purpose, NAT64, IPv4-mapped, 6to4, or Teredo address in the DNS answer set causes the request to fail closed. The fetcher accepts only HTML/XHTML/plain text, sends no cookies or authorization headers, bypasses environment proxies, caps bodies at 5 MiB, limits redirects to three, applies a 15-second per-hop socket timeout, and heuristically masks email/phone-like text. This is not comprehensive PII detection or network anonymity: the target sees the client's public IP.

The hostname/path allowlists are operator authorization boundaries, not permission to bypass a site's terms, robots directives, authentication, paywalls, CAPTCHAs, quotas, or rate limits. Only fetch pages you are authorized to access. `FirecrawlHTTPClient.scrape` intentionally raises a policy error; Firecrawl Search sends no `scrapeOptions`, so it records SERP metadata only and does not ask the hosted provider to fetch result URLs.


### P0 security boundaries

- Google OAuth client JSON is bounded to 16 KiB and must use official Google authorization/token endpoints. Installed clients are loopback-only; web clients must use an exact registered HTTPS redirect. Only read-only YouTube/Analytics scopes are accepted by both the consent flow and credential manager.
- OAuth code exchange, refresh, and revocation disable ambient proxy inheritance and reject redirects. YouTube Data API and Analytics transports use TLS verification, direct connections, and zero redirects.
- SQLite databases, backups, and report exports are owner-only (`0600` on POSIX). Report writes are atomic. CSV exports neutralize spreadsheet formulas; Markdown exports escape untrusted content.
- Job state transitions into `running` require `claim_next()` lease acquisition. Checkpoint and completion writes require the owning, unexpired worker lease; config/checkpoint payloads are limited to 1 MiB.
- CSV imports reject duplicate headers and extra cells, and count invalid physical rows toward the row cap. Media analysis bounds image pixels and decoded audio sample counts before full decode.
- Environment-backed secret references are restricted to the `V17_SECRET_` namespace or exact application allowlists; an empty namespace without an explicit allowlist is rejected. Dashboard JSON text inputs are capped at 1 MiB and 64 nesting levels before decoding; CLI JSON files are read with a 10 MiB hard ceiling; parser boundaries reject duplicate object keys and non-standard NaN/Infinity values. Provider error/search JSON and encrypted-backup secret maps use strict bounded parsing. Evidence uploads retain a 5 MiB application cap and OAuth client JSON a 16 KiB cap. The Streamlit dashboard binds to `127.0.0.1`, enables CORS/XSRF protections, bounds uploads/messages, and disables usage telemetry by default. It has no built-in multi-user authentication; public deployment requires a separately reviewed authenticated reverse proxy/identity layer.

## Channel strategy blueprint

The `strategy` command and Channel Strategy dashboard tab build a positioning draft, evidence-linked competitor opportunity map, audience-derived content pillars, launch sequence and measurement contract. Required positioning inputs are never defaulted. Competitor claims without source references are excluded. The engine does not generate opportunity scores or growth forecasts. See [the growth operating system](docs/V17_GROWTH_OPERATING_SYSTEM.md) and [the blank brief template](examples/channel_strategy.template.json).

## Evidence bundle schema

All sections are optional. Missing sections return `not_configured` or `insufficient_data` rather than fabricated values. A focused growth audit can also be nested under `growth_audit` in this bundle; see `examples/growth_audit.template.json` and `docs/GROWTH_INTELLIGENCE_UPGRADE.md`.

```json
{
  "keywords": ["how to brew coffee", "best espresso grinder"],
  "keyword_channels": {"coffee": ["UC_A", "UC_B"], "espresso": ["UC_A"]},
  "serp_snapshots": [{"observed_at": "2025-01-01T00:00:00+00:00", "results": ["UC_A", "UC_B"]}, {"observed_at": "2025-01-02T00:00:00+00:00", "results": ["UC_B", "UC_A"]}],
  "content_plan": [{"video_id": "video-1", "intent": "informational"}],
  "trend_observations": [{"date": "2025-01-01", "value": 42}],
  "market_observations": [{"country": "ID", "language": "id", "value": 42}],
  "thumbnail_files": ["./owned-thumbnail.png"],
  "audio_files": ["./owned-audio.wav"],
  "audience_texts": ["I struggle with noisy grinders"],
  "historical_snapshots": [{"video_id": "video-1", "observed_at": "2025-01-01T00:00:00+00:00", "views": 100}],
  "experiment": {"baseline": [1, 2, 3, 4, 5], "treatment": [2, 3, 4, 5, 6], "metric": "ctr"},
  "channel_constraints": {"weekly_hours": 10, "hours_per_video": 5, "target_videos_per_week": 2, "repeatable_idea_count": 24, "monetization_routes": ["affiliate"], "copyright_review": "complete", "reused_content_review": "not_reviewed"},
  "evidence": [{"metric": "trend_interest", "value": 42, "source_family": "google_trends", "observed_at": "2025-01-01T00:00:00+00:00", "source_ref": "source-id", "quality": 0.8}]
}
```

## Credentials and policy boundaries

Register API keys in the credential manager or set both `YOUTUBE_API_KEY` and `YOUTUBE_API_PROJECT_ID` for a metered environment-variable route. An environment key without its Google Cloud project ID is not used. Persistent credentials use the OS keyring. OAuth consent uses a loopback-only callback listener for local dashboard sessions (manual callback URL fallback for hosted deployments), only approved YouTube/Analytics read-only scopes, and explicit owner binding of the authorized channel. OAuth accounts do not multiply Data API quota. Multiple keys in one Google Cloud project share that project's quota. The system does not switch projects to evade quota exhaustion.

Public YouTube API-derived research runs, evidence, video snapshots, and comment-derived insights are automatically purged after 30 days when a new research run starts; run `purge-expired` daily (for example via cron) to enforce retention while idle. Example: `0 3 * * * /path/to/venv/bin/v17 --database /path/to/v17.sqlite3 purge-expired --retention-days 30`. Private owner Analytics and Firecrawl SERP snapshots are stored separately. Never commit real keys, client secrets, refresh tokens, exported private Analytics, or `.env` files. Do not scrape private/login-gated pages, bypass CAPTCHAs, defeat rate limits, or collect data contrary to platform terms. Thumbnail/audio analyzers inspect local files supplied by the owner; V17 does not download YouTube video/audio.

## Integrated global growth engine (eight priorities)

Run one evidence-aware workflow across global market discovery, native localization gates, research provenance, owner Analytics KPIs, Search/Browse/Suggested/Shorts diagnostics, experiment planning, continuous-learning proposals and automation QA:

```bash
v17 global-growth examples/global_growth_engine.template.json --output global-growth-report.json
```

Live multi-market discovery is opt-in and uses all country/language profiles derived from YouTube-supported regions and local CLDR metadata. It requires configured YouTube Data API credentials and the optional global metadata dependencies:

```bash
v17 global-growth input.json --live-market-discovery --search-call-budget 80 --query-variant-limit 2
```

Optional bounded web SERP sampling (requires `FIRECRAWL_API_KEY` and explicit `allowed_hosts` in the input):

```bash
v17 global-growth input.json --live-market-discovery --live-web-serp --serp-call-budget 40
```

Optional `--machine-translate` is discovery-only and never bypasses native-speaker review. Optional `--google-trends` collects market-local relative indices with a separate `--trends-call-budget` (default 40). Optional owner Analytics collection uses `--channel-analytics --channel-id ... --analytics-start-date YYYY-MM-DD --analytics-end-date YYYY-MM-DD` and requires already-authorized `yt-analytics.readonly` plus `yt-analytics-monetary.readonly` scopes. Mutating automation is blocked; no scheduler is deployed. Full formulas, assumptions and boundaries: `docs/V17_EIGHT_PRIORITY_GLOBAL_GROWTH_ENGINE.md`.

## V17 0.7.0 engineering contracts

See `docs/V17_0.7.0_SPEC.md`, `docs/V17_0.7.0_METRIC_REGISTRY.md`, and `V17_0.7.0_IMPLEMENTATION_REPORT_2026-11-15.md` for the 0.7.0 contracts, changes, verification and remaining release gates.

## Verification

```bash
python -m pytest -q
python -m compileall -q v17_niche_intel tests
```

Scores are decision aids, not predictions of views, subscribers, revenue, monetization, or guaranteed growth. Google Trends 0–100 values are relative indices, not absolute search volume. Thumbnail image statistics do not predict CTR; audio signal measurements do not replace listening tests. Cross-country comparison is withheld when independent source normalization is not comparable.

## Global market discovery

The dashboard defaults to a single-seed global discovery pass. With a configured YouTube provider and the `global` metadata extra, it discovers current supported content regions through `i18nRegions.list`, builds country-language profiles from CLDR metadata, and preserves curated multilingual segments. Without live region discovery it falls back to 50 curated profiles across 37 countries. Each market uses its localized query, `regionCode`, and `relevanceLanguage`; Google Trends receives the matching country and locale when available.

Machine translation is only query discovery. Operators can supply up to 12 localized query variants per market through `localized_query_variants` in the source-linked JSON upload. A fresh native-reviewed variant takes priority and requires a public HTTPS `source_ref`, timezone-aware `reviewed_at`, and explicit dialect, accent/pronunciation, and cultural review gates; stale or incomplete variants are visibly downgraded. The live CLI and dashboard sample up to two curated/localized query variants per market by default (configurable from 1 to 12). Every variant consumes its own explicit search-call and detail quota reserve; partial scans are never ranked. Other variants remain retained for audit and are not silently treated as searched. Native review remains mandatory for audience-facing copy and for the creator-fit decision layer. The same JSON upload can supply normalized evidence for the four decision layers. Missing/stale evidence is not filled with guesses. Provisional scores may be shown, but ranking requires all four layers, a passed rights gate, and a complete quota scan. See `docs/GLOBAL_MARKET_DISCOVERY_AND_FOUR_LAYER_DECISIONS.md` for formulas, KPI definitions, evidence requirements, quota costs, and limitations, and `docs/YOUTUBE_DISCOVERY_OPTIMIZATION_FRAMEWORK.md` for the Search/Recommendations measurement and experimentation playbook.

## V17 0.7.0 evidence audit and experiment operations

Run the expanded P0-P2 evidence diagnostics from a JSON bundle:

```bash
v17 growth-audit examples/growth_audit.template.json --output growth-report.json
```

Persist explicitly supplied decision records only when requested:

```bash
v17 --database v17.sqlite3 growth-audit growth-input.json --persist-decisions
v17 --database v17.sqlite3 decision-log --topic "home coffee"
```

Manage the experiment lifecycle:

```bash
v17 --database v17.sqlite3 experiment create thumbnail-01 \
  --idempotency-key thumbnail-01:v1 \
  --objective "Improve watch time" \
  --primary-metric watch_time_per_impression
v17 --database v17.sqlite3 experiment transition thumbnail-01 running
v17 --database v17.sqlite3 experiment record-result thumbnail-01 \
  --result-json '{"lift_pct":3.2,"guardrails_passed":true}'
```

Machine-translated query candidates remain unreviewed. Market coverage, competitor velocity, forecast calibration, and satisfaction diagnostics are computed only from the supplied evidence and preserve missing-data states. The persistent worker supports bounded batches, but a recurring host scheduler must be configured separately.
