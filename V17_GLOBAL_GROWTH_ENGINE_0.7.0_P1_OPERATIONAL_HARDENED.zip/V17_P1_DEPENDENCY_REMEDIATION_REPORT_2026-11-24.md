# V17 P1 Dependency and Translation Security Remediation

Date: 2026-11-24
Scope: V17 Global Growth Engine 0.7.0 — P1 remediation increment
Status: **IMPLEMENTED LOCALLY — HOSTED CI VALIDATION PENDING**

## Findings from hosted dependency audit

The first meaningful `pip-audit --strict --local` run installed the application and scanner extras in the same interpreter. It found 58 advisory records across six packages. Inspection of the install log showed that Semgrep's own dependency chain introduced `mcp`, `opentelemetry`, and `wcmatch`; those are scanner-tool dependencies, not V17 runtime dependencies. The same environment also contained application dependencies that were genuinely vulnerable or unsafe to retain:

- `Pillow 12.3.0` was below the fixed `13.0.0` release.
- `cryptography 46.0.7` was constrained below the available fix versions.
- `deep-translator 1.11.4` was listed in PYSEC-2022-252, an advisory describing a compromised package release that exfiltrated environment variables and downloaded/executed malware at install time.

## Changes implemented

1. Raised media extra to `Pillow>=13,<14`.
2. Raised backup crypto extra to `cryptography>=50,<51`.
3. Removed `deep-translator` from all dependency sets and removed its runtime imports.
4. Replaced the unofficial translation package with a first-party adapter for authenticated Google Cloud Translation API v3:
   - Google Application Default Credentials only;
   - explicit `GOOGLE_CLOUD_PROJECT` / `GCLOUD_PROJECT`;
   - fixed HTTPS origin and fixed v3 resource path;
   - TLS verification enabled, ambient proxies disabled, redirects refused;
   - strict project/language/text validation;
   - bounded 15-second read timeout and 1 MiB streaming response ceiling;
   - strict bounded JSON parsing and response-shape validation;
   - no response body, user text, or credentials in raised error messages.
5. Dashboard translation is disabled when no Google Cloud project is configured; CLI `--machine-translate` fails early with a configuration error.
6. Added 17 security-focused translation tests covering validation, endpoint pinning, redirects, streaming bounds, malformed payloads, and environment configuration.
7. CI dependency audit is being separated from scanner tooling so that it audits the installed V17 runtime dependency set rather than Semgrep's own transitive dependencies.

## Local verification

- `pytest -q`: **510 passed**.
- Translation adapter tests: **17 passed**; source-archive hygiene tests: **15 passed**.
- `compileall` for application, tests, and tools: passed.
- Wheel build: passed using locally installed build tools with `--no-build-isolation` (network unavailable for isolated build-dependency download).
- CLI help and `doctor --json`: passed; database integrity/config checks were healthy. The local container has no configured secret-store backend, so the doctor correctly reported `secret_vault=unavailable`.
- Hosted Python 3.11/3.12 validation and dependency audit: pending rebuilt artifact.
- Live Google Cloud Translation request: not run; no Google Cloud project, API enablement, or ADC credentials were supplied.

## Remaining external acceptance gates

This remediation does not complete the P1 operational acceptance runbook. Backup/restore drills, RPO/RTO evidence, system supervision/recovery drills, centralized observability/alerting, OIDC/RBAC and session security, staging load/soak/security tests, and rollback drills still require the target infrastructure, identity provider, storage, monitoring destination, provider credentials, and authorized reviewers. Public deployment remains blocked until those gates pass.
