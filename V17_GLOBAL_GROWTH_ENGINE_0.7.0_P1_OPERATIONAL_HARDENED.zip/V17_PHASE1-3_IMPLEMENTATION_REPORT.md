# V17 implementation report — Phases 0–3 (historical snapshot)

> **Superseded:** This report records the early Phase 0–3 state only. Its “not implemented yet” and “next implementation sequence” sections are historical and do not describe the current V17 build. See `V17_CREDENTIAL_MANAGEMENT_IMPLEMENTATION_REPORT.md` and `BUILD_MANIFEST.txt` for current status.


**As of:** 2026-11-11  
**Status:** Foundation implemented; not production-ready.

## Completed

### Phase 0 — V16 baseline audit
- Extracted the original V16 ZIP to a separate work directory; V16 source was not modified.
- Baseline: 9 tests passed; `compileall` passed.
- Identified missing-data neutral fill, false-positive competition score on empty samples, confidence double-counting, simplistic sample competition, missing content-format classification, lifetime views/day misuse, and absent Analytics OAuth/CSV and persistence.
- Full findings: `docs/V16_BASELINE_AUDIT.md`.

### Phase 1 — Domain core
- Evidence model with provenance, status, timestamp, and quality validation.
- Conservative Shorts/long-form/live classifier.
- Versioned six-dimension scoring model with 75% minimum evidence coverage.
- Confidence model based on independent source families and freshness.
- 18 initial unit tests passed after implementation.

### Phase 2 — SQLite persistence
- Research-run and source-observation tables.
- Algorithm/config snapshots stored with each run.
- Evidence provenance round-trip, foreign-key enforcement, transactions, rollback, and idempotent writes.
- File-backed database creates parent directories and persists across reopen.
- 7 storage tests passed.

### Phase 3 — Public YouTube provider
- Read-only adapter with injectable client for tests.
- Default `relevance` + `date` search sampling, deduplication, balanced interleaving, and detail lookup.
- Retrieves snippet, statistics, content details, and live streaming details.
- Missing public statistics remain null.
- Partial provider failures remain visible; all failed searches are not mislabeled as no demand.
- Configured HTTP timeout and 50-ID details batching.
- 6 provider tests passed.

## Verification evidence

Commands executed from this project directory:

```bash
python -m pytest -q
python -m compileall -q v17_niche_intel tests
python -m pip install -e . --no-deps --no-build-isolation
```

Results:
- `python -m pytest -q`: **31 passed**.
- `python -m compileall -q v17_niche_intel tests`: **passed**.
- Editable local install without dependency resolution: **passed**; import tested from `/tmp`.
- An initial isolated editable install attempted to download build dependencies and failed because this environment has no network/DNS access. No claim is made that optional third-party dependencies were installed.
- No live YouTube API call was run; no user API key was supplied.

## Explicitly not implemented yet

- Google Trends provider and time-series analysis beyond the domain interfaces.
- Localized keyword expansion/review workflow.
- Competition profile, channel concentration, content gaps, and interval video snapshots.
- Business feasibility and risk assessment engines beyond score dimensions.
- Existing Channel YouTube Analytics OAuth (read-only) and CSV importer.
- Market Entry / Existing Channel / Both research orchestration.
- CLI, Streamlit dashboard, export/report service, history browser.
- Full integration/contract/evaluation suites and production hardening.

## Important measurement boundaries

- YouTube Data API search sampling is not a census of market supply.
- Official YouTube documentation lists a default 100-call/day separate bucket for `search.list`, with one quota unit per call; `videos.list` costs one unit per call. The provider defaults to two search calls per keyword-region sample. A future orchestrator must budget calls across countries/topics before execution.
- `views/day` remains a lifetime average until repeated snapshots of the same video are collected.
- A duration-only short video is a `shorts_candidate`, not a confirmed Short.
- YouTube Analytics data is private channel-owner data and must remain separate from public competitor observations.
- Score weights are provisional heuristics; no predictive accuracy, revenue, or monetization outcome is claimed.

## Next implementation sequence

1. Phase 4: Google Trends adapter, query localization/review, and demand time-series features.
2. Phase 5: competition profiling, repeated video snapshots, and content-gap features.
3. Phase 6: business feasibility, policy/copyright risk, and evidence-aware scoring integration.
4. Phase 7: authorized read-only YouTube Analytics OAuth and validated CSV import.
5. Phase 8: shared research service and CLI.
6. Phase 9: Streamlit dashboard, history, and exports.
7. Phase 10: integration/evaluation/security verification and release packaging.
