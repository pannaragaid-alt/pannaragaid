"""Pre-extraction safety gate for V17 source distribution ZIPs."""
from __future__ import annotations

import argparse
import stat
import sys
import zipfile
from pathlib import PurePosixPath

_MAX_ENTRIES = 10_000
_MAX_TOTAL_BYTES = 100 * 1024 * 1024
_MAX_MEMBER_BYTES = 20 * 1024 * 1024
_MAX_COMPRESSION_RATIO = 1_000
_BLOCKED_SUFFIXES = (
    ".sqlite3", ".sqlite", ".sqlite3-wal", ".sqlite3-shm", ".db",
    ".pem", ".key", ".p12", ".pfx", ".jks",
)
_BLOCKED_DIRS = {
    ".git", "__pycache__", ".pytest_cache", ".ruff_cache", ".venv",
    "venv", "build", "dist",
}
_BLOCKED_SECRET_NAMES = {
    "id_rsa", "id_ed25519", "credentials.json", "client_secret.json",
    "token.json",
}


def validate_source_archive(path: str) -> tuple[str, ...]:
    """Return all archive policy violations; an empty tuple means safe to extract."""
    violations: list[str] = []
    try:
        archive = zipfile.ZipFile(path, "r")
    except (OSError, zipfile.BadZipFile) as exc:
        return (f"archive cannot be opened: {type(exc).__name__}",)

    with archive:
        infos = archive.infolist()
        if len(infos) > _MAX_ENTRIES:
            violations.append(f"archive has more than {_MAX_ENTRIES} entries")
        seen: set[str] = set()
        total_size = 0
        for info in infos:
            name = info.filename
            if not name or "\\\\" in name:
                violations.append(f"invalid archive path: {name!r}")
                continue
            path_name = name[:-1] if info.is_dir() and name.endswith("/") else name
            pure = PurePosixPath(path_name)
            if (pure.is_absolute() or not pure.parts or ".." in pure.parts
                    or "." in pure.parts or (pure.parts and ":" in pure.parts[0])):
                violations.append(f"unsafe archive path: {name!r}")
                continue
            canonical = "/".join(pure.parts).casefold()
            if canonical in seen:
                violations.append(f"duplicate or case-colliding archive path: {name!r}")
            seen.add(canonical)

            mode = info.external_attr >> 16
            if stat.S_ISLNK(mode):
                violations.append(f"symlink is not allowed: {name!r}")
            if info.flag_bits & 0x1:
                violations.append(f"encrypted ZIP members are not allowed: {name!r}")

            parts = {part.casefold() for part in pure.parts}
            if parts & _BLOCKED_DIRS or any(part.endswith(".egg-info") for part in parts):
                violations.append(f"build/cache directory is not allowed: {name!r}")
            base = pure.name.casefold()
            if base != ".env.example" and (base == ".env" or base.startswith(".env.")):
                violations.append(f"environment file is not allowed: {name!r}")
            if base.endswith(_BLOCKED_SUFFIXES) or base in _BLOCKED_SECRET_NAMES:
                violations.append(f"runtime database or secret file is not allowed: {name!r}")

            if not info.is_dir():
                total_size += info.file_size
                if info.file_size > _MAX_MEMBER_BYTES:
                    violations.append(f"member exceeds {_MAX_MEMBER_BYTES} bytes: {name!r}")
                if info.file_size and info.compress_size == 0:
                    violations.append(f"invalid compression size: {name!r}")
                elif info.compress_size and info.file_size / info.compress_size > _MAX_COMPRESSION_RATIO:
                    violations.append(f"suspicious compression ratio: {name!r}")
        if total_size > _MAX_TOTAL_BYTES:
            violations.append(f"archive expands beyond {_MAX_TOTAL_BYTES} bytes")
    return tuple(violations)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", help="source ZIP to validate before extraction")
    args = parser.parse_args()
    violations = validate_source_archive(args.archive)
    if violations:
        for violation in violations:
            print(f"FAIL: {violation}", file=sys.stderr)
        return 1
    print("Source archive hygiene: PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
