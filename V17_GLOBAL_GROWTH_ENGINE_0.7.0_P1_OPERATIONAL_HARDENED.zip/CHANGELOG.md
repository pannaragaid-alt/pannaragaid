# Changelog

## 0.7.0 — P1.4 operational backup automation (2026-11-24)

- Add restricted `--passphrase-file` support to backup/restore for unattended execution without argv/environment secret exposure.
- Reject symlink/non-regular credential files, group/world access, oversized or malformed credentials, and short passphrases.
- Add a hardened systemd oneshot service and daily timer example using `LoadCredential=` and a dedicated non-root service account.
- Document operator provisioning and explicitly retain off-host replication, retention, restore drills, RPO/RTO, and reviewer evidence as open acceptance gates.


## 0.7.0 — 2026-11-15

- Separate Analytics API metrics from Reporting API Reach metrics; thumbnail Reach fields are no longer sent through `reports.query`.
- Add first-class `engagedViews` and keep it distinct from public `views`.
- Use engaged views as the consumption denominator for aggregated AVD/APV and subscriber conversion diagnostics.
- Purge expired SERP snapshots under the public-data retention window instead of preserving them indefinitely.
- Make Google Trends property explicit and default the provider to YouTube Search (`gprop=youtube`); Web Search is opt-in.
- Expose an observed report-date freshness status so delayed Analytics data is not presented as real-time.


## 0.6.0 - 2026-11-14

- Added a versioned YouTube Analytics metric catalog and conservative query planner.
- Analytics provider now validates metric/dimension combinations before API calls and returns required-scope/query-plan metadata.
- Added deterministic provenance records with canonical raw-payload SHA-256, request parameters, observation/fetch timestamps, locale/region and transform version.
- Added a bounded asyncio facade for synchronous provider calls, retaining capacity until a cancelled worker thread exits.
- Added `v17 metrics --json` for inspecting the active metric registry.
- Added CI workflow and architecture, audit, spec, data dictionary, metric, localization, discovery, experiment, security and skill-routing documentation.
- Retained SQLite local architecture and existing public/private evidence boundaries.

### Verification limits

No live API/OAuth/native-reviewer/browser/production-scheduler/deployment validation is implied by local tests or package build.
