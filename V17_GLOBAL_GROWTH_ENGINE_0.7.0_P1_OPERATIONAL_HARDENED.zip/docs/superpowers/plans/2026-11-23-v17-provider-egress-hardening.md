# V17 Provider Egress Hardening — P0 Slice

## Objective and architecture context
Harden the existing Python modular monolith's Firecrawl HTTP adapters without changing domain contracts, SQLite schema, user workflows, or provider selection. The current implementation posts the Firecrawl bearer key to a constructor-supplied `base_url` and reads the entire provider response into memory. Both behaviors violate the project's secret-hygiene and bounded-execution invariants (V17-C12, C14, C17).

## Approved design decisions
- Keep the production Firecrawl origin fixed to `https://api.firecrawl.dev`; reject any custom scheme, host, port, credentials, path, query, or fragment. The current application does not expose custom Firecrawl origins, so no production use case is removed.
- Bound Firecrawl Scrape and Search response bodies to 10 MiB. Read at most `limit + 1` bytes and fail closed when the response exceeds the limit.
- Preserve generic, redacted provider errors. Never include response bodies or bearer values in exceptions.
- Keep target URL validation and the existing provider flow unchanged in this slice. A separate gateway design is required to enforce hostname allowlists and fetch-time DNS/redirect controls; client-side DNS preflight alone is not claimed to enforce the remote Firecrawl fetcher's egress.
- No CAPTCHA/login/paywall/access-control/rate-limit/quota bypass. Pentest only local fixtures in this phase.

## Scope
1. `tests/unit/test_incognito_scraping.py`: RED tests for untrusted/non-TLS Firecrawl API origins and oversized scrape responses.
2. `tests/unit/test_firecrawl_search.py`: RED test for oversized search responses.
3. `v17_niche_intel/providers/incognito_scraper.py`: exact-origin validation and bounded response read.
4. `v17_niche_intel/providers/firecrawl_search.py`: bounded response read.
5. `docs/security/V17_PROVIDER_EGRESS_HARDENING.md`: findings, remediation, verification evidence, and residual risks.

## Ordered TDD tasks
1. Add a failing test proving `base_url=http://127.0.0.1:<port>` is rejected before any request is sent.
2. Add a failing test proving noncanonical HTTPS origins are rejected and the canonical Firecrawl origin remains accepted.
3. Add a failing scrape test proving a response larger than 10 MiB is rejected after a bounded read.
4. Add a failing search test proving the same response cap applies to Search.
5. Run the focused tests and capture expected RED failures.
6. Implement the smallest changes in the two provider adapters.
7. Run focused tests, then the full test suite and compile checks.
8. Run local red-team regression fixtures: API-key exfiltration endpoint, oversized response, private/loopback/IPv4-mapped IPv6 URL literals, and redirect behavior. No external hosts or credentials.
9. Build a wheel with `--no-build-isolation` when the environment lacks build-network access; record exact artifact checksum.
10. Review the diff against the immutable contract and document remaining risks.

## Acceptance criteria
- The API key cannot be sent to an arbitrary `base_url` or plaintext endpoint.
- Both Firecrawl adapters enforce a strict response byte ceiling before decoding/parsing.
- Existing valid adapter behavior and all existing tests remain green.
- No real API key, live Firecrawl call, external pentest, or deployment is used.
- The report distinguishes PASS, FAIL, BLOCKED, and NOT RUN.

## Rollback
Revert only the two provider adapter changes and their tests if a provider compatibility regression appears. No database migration or persistent data mutation is involved.


## Execution evidence (2026-11-23)

- RED: 7 newly added test cases failed against the baseline implementation (5 origin cases, Scrape response cap, Search response cap).
- GREEN: focused suite `python -m pytest -q tests/unit/test_incognito_scraping.py tests/unit/test_firecrawl_search.py` — 16 passed.
- Full suite: `python -m pytest -q` — 359 passed in 4.83s.
- Compile: `python -m compileall -q v17_niche_intel tests` — exit 0.
- CLI: `python -m v17_niche_intel.cli --help` — exit 0.
- Wheel: built with `--no-build-isolation`; SHA-256 `ba1ec87365e1004ad55a88ed64fcc0150e3f7dcfb7b86d28eb601f4471830416`.
- Residuals: hostname allowlist and hosted fetch-time DNS/redirect enforcement remain open; no live provider or external pentest was run.
