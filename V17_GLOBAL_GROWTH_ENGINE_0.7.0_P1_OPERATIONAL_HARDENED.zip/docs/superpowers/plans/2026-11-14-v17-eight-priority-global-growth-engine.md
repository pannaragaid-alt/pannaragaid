# V17 Eight-Priority Global Growth Engine

## Objective
Integrate the eight requested capabilities into one evidence-aware workflow while preserving V17 P1-P10 compatibility. Deliver deterministic analysis, explicit missing-data states, CLI entry point, tests, schema/template, and operator documentation. No live external collection, account mutation, or deployment is implied.

## Architecture
Add `services/global_growth_engine.py` as an orchestration/composition layer over the existing market discovery, growth operations, KPI calculations, Analytics provider, and storage boundaries. Keep calculations pure and provider-independent. Reuse existing `GlobalMarketDiscoveryService`, `YouTubeAnalyticsProvider`, `forecast_error_metrics`, `assess_experiment_integrity`, and `validate_automation_job` where appropriate.

## Workstreams
1. Global market economics: normalize only same-currency RPM evidence; calculate gross revenue, contribution after cost, confidence-adjusted opportunity and explicit eligibility.
2. Native localization: require locale-specific variants and reviewer evidence; machine translation remains unverified; report dialect/accent/culture review gates.
3. Research pipeline: normalize source provenance, HTTPS allowlists, timestamps, freshness, deduplication and missingness; do not initiate network calls.
4. Channel Analytics: calculate denominator-safe first-party KPI tree from owner-authorized aggregates; keep public competitor metrics separate.
5. Distribution optimization: surface-specific Search/Browse/Suggested/Shorts diagnostic scores with complete-input checks; never claim ranking guarantees.
6. Experimentation: two-proportion sample-size planning, SRM check, effect estimate and confidence interval; descriptive outputs only unless assumptions pass.
7. Continuous learning: forecast error, versioned policy proposals, minimum sample gates and human approval before changing scoring policy.
8. Automation: bounded read-only job contract, explicit hostname allowlist, idempotency, retries/timeouts/budget and kill switch; no scheduler execution.

## TDD sequence
- Add failing tests for each pure function and orchestration contract.
- Implement minimum behavior and rerun focused tests after each slice.
- Add CLI/schema/template/docs integration tests.
- Run full test suite, compileall, CLI smoke tests, schema checks, archive scan and checksum.

## Acceptance criteria
- One seed topic can be evaluated against multiple supplied country-language markets in one call.
- No cross-currency RPM comparison without explicit conversion evidence.
- Unreviewed localization never receives native-reviewed status.
- Research evidence has provenance, timestamp, freshness and dedupe state.
- Private channel Analytics KPIs are calculated only from declared owner-authorized inputs.
- Distribution outputs are diagnostics, not algorithm/ranking predictions.
- Experiment planning reports sample assumptions and SRM; underpowered data cannot be marked conclusive.
- Learning outputs are proposals requiring human approval; no self-modifying production weights.
- Automation validator rejects mutating jobs and unsafe/unbounded configurations.
- Existing P1-P10 tests and CLI remain compatible.

## Non-goals / external gates
No live YouTube/Google Trends/Firecrawl requests, native-speaker certification, OAuth credential provisioning, foreign-exchange provider, scheduler/worker, deployment, or claim of production readiness. These require authorized credentials, external provider access, or operator review.

## Execution record (2026-11-14)

- [x] Global market/economics engine and supported-region/CLDR registry integration
- [x] Native localization review gates and discovery-query provenance bridge
- [x] HTTPS/allowlist/freshness/dedupe research pipeline and bounded Firecrawl SERP adapter
- [x] Owner Analytics daily + country RPM provider, private persistence and opt-in monetary OAuth scope
- [x] Four-surface distribution diagnostics
- [x] Proportion experiment planning, SRM and confidence interval checks
- [x] Forecast-error learning proposals with human approval
- [x] Bounded read-only automation contract validator
- [x] CLI, input/output schemas, template, docs and release report
- [x] Full regression suite: 280 passed; compile, CLI and schema checks passed
- [ ] Live provider/authentication/browser/deployment checks (external credentials/runtime not available; explicitly not claimed)
