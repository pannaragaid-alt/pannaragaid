# P1: unattended backup credential injection

## Objective
Enable unattended encrypted backups/restores under a service supervisor without putting the backup passphrase in argv, environment variables, shell history, or logs.

## Scope and design
- Add `--passphrase-file` to `v17 backup` and `v17 restore`.
- Read only a regular, non-symlink file with restrictive permissions (no group/world bits), a bounded size, strict UTF-8, and the existing minimum passphrase length.
- Keep interactive `getpass` as the default for operator use.
- Add tests for successful noninteractive backup/restore and unsafe-file rejection.
- Document systemd `LoadCredential=` integration; the service manager owns credential provisioning and external/off-host storage policy.

## Non-goals
- Do not add cloud-storage credentials or silently upload backups.
- Do not claim backup/restore acceptance without an isolated restore drill, measured RPO/RTO, and off-host copy verification.

## Execution sequence
1. Add failing CLI tests for file-based backup/restore and unsafe permissions.
2. Implement bounded, no-symlink passphrase-file reader and CLI flags.
3. Add systemd deployment example and operator procedure.
4. Run targeted tests, full test suite, Ruff, Bandit, Semgrep, archive validation, and wheel build.
5. Rebuild archive and record new SHA-256; do not publish to any package registry.

## Acceptance
- Passphrase is never present in process arguments or environment.
- Credential file must be regular, non-symlink, <=4096 bytes, UTF-8, and have mode 0600/0400-equivalent (no group/world access).
- Both CLI backup and restore work without TTY when a valid credential file is supplied.
- Interactive behavior remains unchanged when no credential file is supplied.
