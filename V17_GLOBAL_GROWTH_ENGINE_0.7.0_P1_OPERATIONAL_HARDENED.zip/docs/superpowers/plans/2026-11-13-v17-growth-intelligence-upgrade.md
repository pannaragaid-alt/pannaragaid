# V17 Growth Intelligence Upgrade Plan

## Objective

Extend the existing V17 market research and four-layer decision engine with executable, evidence-aware growth diagnostics while preserving compatibility and withholding unsupported conclusions.

## Acceptance criteria

- New diagnostics are pure deterministic functions with validation and boundary tests.
- Competitor weaknesses require stable source references; no private competitor RPM is inferred.
- Localization readiness requires fresh, timezone-aware human review and separate dialect/accent/cultural checks.
- Retention and discovery diagnostics are explicitly descriptive and surface/cohort aware.
- CTR inference is withheld for observational samples; sample-size planning states its statistical approximation.
- Market economics are scenario-labelled unless first-party RPM is sourced from owner-authorized Analytics.
- Rights and localization are hard pre-publication gates.
- The feature is callable through `v17 growth-audit` and the existing `v17 intelligence` service payload.
- Example input validates against the JSON Schema; all tests pass; package builds.

## Implementation sequence

1. Add failing unit tests for retention, intent overlap, localization, competitor gaps, CTR analysis, and economics.
2. Implement the pure growth-intelligence service with strict input validation.
3. Add failing tests for sample-size planning, discovery-surface diagnostics, content readiness, and missing-data semantics.
4. Implement those diagnostics and the growth-bundle orchestrator.
5. Add CLI integration and integration tests for JSON output.
6. Wire optional `growth_audit` into the existing market-intelligence service without changing the existing scoring algorithm.
7. Add schema, blank template, usage documentation, and operational limitations.
8. Run focused tests, complete test suite, compile, CLI smoke, schema validation, package build, archive extraction and checksum verification.

## Non-goals / external gates

No live API calls, Google OAuth, Scrapling MCP session, native speaker validation, automated publishing, scheduler configuration, or Streamlit browser QA are claimed. These require external credentials, runtime dependencies, human reviewers, or a connected service.
