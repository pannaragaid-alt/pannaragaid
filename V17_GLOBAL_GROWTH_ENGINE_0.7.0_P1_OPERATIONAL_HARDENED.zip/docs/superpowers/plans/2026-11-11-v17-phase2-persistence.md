# V17 Phase 2 — SQLite persistence and provenance

## Objective
Persist research runs and source observations with reproducible algorithm/configuration metadata, safe serialization, transaction boundaries, and idempotent observation writes.

## Design
- SQLite is the first local persistence backend; service code will depend on a repository boundary rather than SQLite details.
- Schema uses explicit foreign keys and JSON serialization for structured values/configuration.
- Every run records mode, topic, optional country, algorithm version, configuration, and UTC creation time.
- Evidence records retain source family, metric, source status, timestamp, quality, source reference, and metadata.
- Observation writes use a deterministic key and `INSERT ... ON CONFLICT DO NOTHING` so retrying a provider batch does not duplicate observations.
- No OAuth tokens, API keys, or other credentials are stored in the research database.

## Tasks (RED → GREEN)
1. Write repository tests for run creation, evidence round-trip, foreign-key enforcement, idempotent duplicate insertion, and transaction rollback.
2. Run focused tests and confirm they fail because repository/schema do not exist.
3. Implement `storage/database.py` with schema initialization, per-connection foreign keys, WAL for file databases, and context-managed transactions.
4. Implement `storage/repositories.py` with typed run/evidence persistence and deterministic observation keys.
5. Run focused tests, then full unit suite and compileall.
6. Document schema, migration policy, and explicit secret exclusion.

## Acceptance criteria
- Repository can use both `:memory:` and file-backed SQLite.
- Run/evidence round-trip preserves all required provenance.
- Duplicate evidence insert is idempotent.
- Invalid run references fail due to foreign-key enforcement.
- Exceptions roll back writes in the transaction.
- No credentials are accepted or persisted by these repositories.
