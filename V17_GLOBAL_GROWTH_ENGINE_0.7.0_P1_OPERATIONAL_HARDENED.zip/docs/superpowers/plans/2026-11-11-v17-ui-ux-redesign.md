# V17 UI/UX redesign — implementation plan

## Objective
Redesign the existing Streamlit dashboard into a distinctive, responsive intelligence workspace with light/dark themes while preserving research, OAuth, credential, SERP, scraping, and evidence-analysis behavior.

## Design decisions
- Product pattern: evidence-first analytics workspace, not a generic admin template.
- Visual direction: **Signal Atelier** — editorial typography, restrained geometric details, crisp data surfaces, deep ink + mineral teal accent; warm porcelain light theme and midnight graphite dark theme.
- Theme: user-selectable Light / Dark / System, session-persistent. System follows CSS `prefers-color-scheme`.
- Information architecture: Overview, Connections, Public Intelligence, Advanced Lab. Research controls remain in a compact sidebar.
- Interaction: clear active navigation, visible status/feedback, progressive disclosure for sensitive/advanced controls, no fabricated KPI values.
- Accessibility: keyboard-visible focus, semantic labels, responsive reflow, touch-friendly controls, reduced-motion support, non-color status cues.
- Non-goals: change research algorithms, credential security model, provider behavior, or add runtime dependencies.

## Implementation sequence
1. Add theme tokens/CSS renderer and unit tests (RED → GREEN).
2. Integrate theme selection and visual system into the Streamlit dashboard.
3. Reorganize content into Overview / Connections / Public Intelligence / Advanced Lab; preserve existing service calls and state.
4. Add design-system and UX handoff documentation.
5. Run unit/integration suite, Python compile, package checks; inspect changed code and archive the updated release.

## Acceptance criteria
- Light and dark themes render distinct coherent surfaces; System follows OS preference.
- Existing research and credential actions remain connected to the same services and callbacks.
- Secret values remain masked and are never included in new UI inventory views.
- All existing automated tests and new theme tests pass.
- CSS supports narrow widths, visible focus, and reduced motion.
- Dashboard runtime/browser visual QA is marked unverified if Streamlit is unavailable.
