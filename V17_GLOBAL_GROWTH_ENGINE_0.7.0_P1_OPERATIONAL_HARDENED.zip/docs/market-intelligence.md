# Market Intelligence Methods

## Inputs and output contract

`MarketIntelligenceService.analyze(payload)` accepts a JSON-compatible evidence bundle. Each analytic is deterministic and returns explicit `not_configured`, `insufficient_data`, `non_comparable`, or `ok` states. The service never fabricates missing data.

## Method inventory

| Requirement | Method | Important limitation |
|---|---|---|
| Search intent | Rule-based informational/commercial/transactional classifier | Validate against actual SERPs and query context |
| Topic clustering | Token normalization + Jaccard similarity | Heuristic; multilingual tokenization is limited |
| Competitor overlap | Unique competitor-domain/channel identifier count across keyword result sets | Sample overlap, not market share |
| SERP collection | Firecrawl Search results persisted with country, language annotation, location, and UTC timestamp | Language is metadata only; provider does not guarantee language filtering |
| SERP volatility | Mean absolute rank movement for matched results across timestamped snapshots | Requires `observed_at` and ordered `results`; additions/removals are not equivalent to rank changes |
| Cannibalization | Multiple planned videos assigned to the same intent | Human review should confirm distinct value propositions |
| Seasonality | Month-of-year profile from dated observations | Two years required to confirm recurrence |
| Geo/language segmentation | Aggregation by country and language axes | No cross-market comparison of independently normalized Trends indices |
| Freshness | Observation age against a declared threshold | Threshold is use-case specific |
| Thumbnail benchmarking | Local image dimensions, RGB means and channel dispersion | No face/OCR detection; no CTR inference |
| Audio benchmarking | Local sample peak, RMS, clipping and silence ratios | Not LUFS, true peak, SNR, or subjective quality |
| Audience pain points | Repeated terms across supplied text | Discovery aid only; inspect context and sample bias |
| Provenance/confidence | Source family, source ref, observation time, quality and status | Confidence is separate from opportunity score |
| Historical tracking | Per-video view delta and views/day between repeated snapshots | Not real-time velocity; interval is explicitly reported |
| Experiment validation | Baseline/treatment mean lift and approximate interval | Directional estimate; causal claims require randomized design |

## Evidence provenance

Each evidence item should include `metric`, `value`, `source_family`, timezone-aware `observed_at`, `quality` in [0,1], optional `source_ref`, and optional metadata. Independent source count is by source family, not by number of metrics. Stale evidence loses confidence weight.

## Incognito collection policy

Incognito uses a direct local HTTPS fetcher rather than delegating arbitrary target URLs to a hosted scraper. Exact hostname and host-bound path-prefix allowlists are mandatory. Hostnames are IDNA-normalized; wildcard and suffix matching are not supported. URL scheme, credentials, port, fragment, and canonical hostname are validated before DNS. Every DNS answer must be a public routable address; private, reserved, special-purpose, NAT64, IPv4-mapped, 6to4, and Teredo addresses are rejected. The TCP connection is pinned to one validated IP, while TLS SNI and certificate validation retain the requested hostname. Redirects are limited to three and each redirect is revalidated and resolved again.

The fetcher sends no cookies, authorization headers, browser profile, or proxy-environment credentials; it accepts only HTML/XHTML/plain text, does not accept compressed bodies, caps response size at 5 MiB, applies a 15-second per-request timeout, and heuristically masks email/phone-like strings. This PII redaction is not comprehensive and the direct connection is not anonymous: the target sees the client network IP. Hosted Firecrawl target scraping is disabled because client-side DNS preflight cannot enforce the remote fetcher's DNS resolution or redirect chain. Firecrawl Search omits `scrapeOptions`, so it is SERP-only and does not ask the hosted provider to fetch arbitrary result URLs.

`V17_SCRAPE_ALLOWED_HOSTS` and `V17_SCRAPE_ALLOWED_PATHS` are required for CLI/dashboard Incognito fetches. The path variable uses `host=/prefix|/other;docs.example.org=/docs` syntax, and every allowlisted host must have at least one path prefix. The allowlist records operator-approved hosts and paths; it does not override site terms, robots directives, authentication, paywalls, CAPTCHAs, quotas, or rate limits. No access-control bypass, CAPTCHA bypass, proxy rotation for evasion, or rate-limit circumvention is implemented.

## Reproducibility

Keep raw inputs and source IDs, collection timestamps, country, language, timeframe, and method version alongside derived outputs. Use repeat snapshots to measure change. Never compare independently normalized country series as absolute demand. Do not use competitor public metrics to infer private channel retention, impressions, or revenue.


## YouTube API data retention

Public YouTube API-derived research runs, source observations, video snapshots, and comment-derived pain-point terms are purged after 30 days. Research execution invokes the purge before creating a new run; operators should also schedule `v17 purge-expired` daily so idle databases are cleaned. The CLI refuses a retention window longer than 30 days. First-party owner Analytics is isolated in private tables; Firecrawl SERP snapshots are stored separately.

## Channel operating feasibility inputs

The evidence-bundle service accepts an optional `channel_constraints` object. It evaluates operator-supplied production capacity, repeatable idea runway, monetization route planning, and copyright/reused-content review readiness. Example:

```json
{
  "channel_constraints": {
    "weekly_hours": 12,
    "hours_per_video": 4,
    "target_videos_per_week": 3,
    "repeatable_idea_count": 36,
    "monetization_routes": ["affiliate", "sponsorship"],
    "copyright_review": "complete",
    "reused_content_review": "not_reviewed"
  }
}
```

The output reports `business_feasibility_score`, `risk_resilience_score`, estimated weekly capacity, capacity gap, repeatable-content runway, score components, and explicit risk flags. The required numeric inputs are never defaulted; missing values return `insufficient_data`. Review states are operator attestations, not legal advice or a YouTube monetization approval. Scores are heuristic planning aids, not probabilities or outcome guarantees.
