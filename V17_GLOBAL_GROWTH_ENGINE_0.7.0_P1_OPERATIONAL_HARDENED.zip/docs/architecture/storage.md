# Storage contract — V17

SQLite is the first local persistence adapter. `Database` owns schema initialization, foreign-key enforcement, transaction boundaries, and WAL mode for file-backed databases. Repositories persist domain records without exposing SQL to services.

Tables:
- `research_runs`: topic, mode, country, algorithm version, config snapshot, creation time.
- `source_observations`: run-scoped evidence with provenance, status, quality, metadata, and deterministic idempotency key.

Evidence insertion is idempotent for an identical observation payload. Foreign keys prevent orphan observations. Structured values are JSON-serialized with NaN/Infinity rejected. Credentials are explicitly out of scope.

Future schema changes must use numbered migrations and be tested against both a fresh database and a copy of the previous schema. Do not silently mutate existing research runs or their algorithm version.
