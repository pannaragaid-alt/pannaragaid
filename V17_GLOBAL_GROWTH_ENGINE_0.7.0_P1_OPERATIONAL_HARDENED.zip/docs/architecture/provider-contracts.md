# Provider contract — YouTube Data API

`YouTubeDataAPIProvider` is read-only and returns `VideoSearchBatch`, preserving batch status (`ok`, `partial`, `no_data`, `error`), requested search orders, and failed orders. Video records preserve nullable public statistics and the live metadata needed by the domain classifier.

## Sampling
Default query orders are `relevance` and `date`. `viewCount` and other documented sort orders can be explicitly requested. Results from ranking surfaces are interleaved before applying the sample limit so relevance does not crowd out recency. IDs are deduplicated before `videos.list`; details are fetched in batches of at most 50 IDs and restored to the selected sample order. The provider requests `snippet`, `statistics`, `contentDetails`, and `liveStreamingDetails`.

## Quota guardrails
The official quota documentation states that `search.list` has a separate default daily bucket of 100 calls, one call per quota unit; `videos.list` costs one unit per call. V17 defaults to two search calls per keyword-region sample. A multi-country research run must estimate search calls before execution and stop or reduce sample strategy before exceeding the configured budget. This is a quota guard, not a guarantee that Google's project quota has not been changed.

References:
- [Search: list](https://developers.google.com/youtube/data/reference/rest/v3/search/list)
- [Quota costs](https://developers.google.com/youtube/data/determine_quota_cost)
- [Videos resource](https://developers.google.com/youtube/data/reference/rest/v3/videos)

## Reliability
The client supports injected test doubles and a configured HTTP timeout. A failed search order does not erase successful orders; the batch is marked `partial`. If all search orders fail, status is `error`, never `no_data`. Missing statistics remain `None`.
