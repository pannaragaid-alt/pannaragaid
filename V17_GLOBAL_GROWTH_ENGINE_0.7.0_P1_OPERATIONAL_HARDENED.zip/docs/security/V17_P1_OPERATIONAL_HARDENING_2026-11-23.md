# V17 0.7.0 — P1 Operational Hardening

**Date:** 2026-11-23  
**Phase:** P1.1 — operational readiness / repository-side controls  
**Status:** implementation complete locally; hosted CI and deployment acceptance remain OPEN.  
**Baseline:** P0 archive validated by GitHub Actions run #7; P1 edits are a new, distinct source archive.

## Audit findings and remediation

### P1-OPS-001 — SQLite migration was not atomic

**Severity:** High (data integrity / recoverability)  
**Finding:** schema setup used `executescript`, which can implicitly commit and leave partial DDL/migration state if a later migration fails.  
**Remediation:** schema statements and additive migrations now run under one `BEGIN IMMEDIATE`; failure rolls back and closes the failed connection. `PRAGMA user_version` records schema version 1.  
**Regression evidence:** a deliberately invalid second DDL statement proves that the first table is not left behind.

### P1-OPS-002 — SQLite durability and lock waiting were implicit

**Severity:** Medium  
**Finding:** busy timeout and synchronous durability were not explicitly set.  
**Remediation:** require SQLite 3.31+, set `busy_timeout=5000`, WAL, `synchronous=FULL`, `wal_autocheckpoint=1000`, and `trusted_schema=OFF`.  
**Regression evidence:** tests assert the configured PRAGMAs and reject an unsupported SQLite version before creating a database file.

### P1-OPS-003 — Database health was not machine-verifiable

**Severity:** Medium  
**Finding:** `doctor` reported database status as `ok` without running integrity or foreign-key checks.  
**Remediation:** `Database.health_check()` reports integrity, foreign-key state/violations, journal mode, synchronous level, busy timeout, schema version, SQLite version, and POSIX main/sidecar file modes. `v17 doctor --json` includes this report and exits non-zero on database degradation.  
**Regression evidence:** healthy DB and deliberately introduced foreign-key violation cases.

### P1-OPS-004 — Runtime quota configuration failed late and inconsistently

**Severity:** Medium  
**Finding:** dashboard and provider code converted environment values directly with `int()`, and the dashboard displayed fixed default quota figures even when configured limits differed. Partial YouTube key/project configuration could be reported as configured despite being unusable.  
**Remediation:** centralized bounded positive-integer parsing; dashboard stops with an explicit configuration error; provider factory uses the same parser; doctor detects invalid quota values, partial YouTube key/project pairs, and incomplete scrape allowlist/path policies. Dashboard quota text now reflects configured values.  
**Regression evidence:** malformed, zero, signed, decimal, exponent, out-of-range, and partial-provider configuration tests.

### P1-OPS-005 — Poison job could starve the persistent queue

**Severity:** High (worker availability)  
**Finding:** `claim_next()` selected one oldest candidate; malformed config or exhausted attempts could prevent a later valid job from being claimed.  
**Remediation:** claim logic terminalizes malformed/exhausted candidates and continues scanning within the same transaction until it claims a valid job or exhausts the queue. Corrupt JSON remains observable as a parse error instead of making `get()` crash.  
**Regression evidence:** poison JSON, invalid retry configuration, exhausted attempts, and healthy-job-after-poison tests.

### P1-OPS-006 — Long-running job had no heartbeat-only API

**Severity:** Medium  
**Finding:** lease renewal was coupled to checkpoint writes, so handlers with long intervals between checkpoint changes could lose ownership.  
**Remediation:** `JobCheckpointRepository.renew_lease()` extends only a currently live lease owned by the exact worker. Existing handler API remains compatible: call `save_checkpoint()` with no argument to heartbeat without changing checkpoint data. Stale/non-owner workers are rejected.  
**Regression evidence:** lease extension, unchanged checkpoint, expiry, and ownership tests.

## Changed files

- `v17_niche_intel/config.py` (new)
- `v17_niche_intel/storage/database.py`
- `v17_niche_intel/storage/repositories.py`
- `v17_niche_intel/services/job_runner.py`
- `v17_niche_intel/credentials/providers.py`
- `v17_niche_intel/dashboard.py`
- `v17_niche_intel/cli.py`
- `.env.example`
- `tests/unit/test_storage.py`
- `tests/unit/test_runtime_config.py` (new)
- `tests/integration/test_cli_commands.py`
- `V17_P0_CONTINUATION_STATUS_2026-11-23.md`

## Local verification

| Check | Result |
|---|---|
| Full pytest suite | **475 passed** |
| `compileall` | PASS |
| CLI help | PASS |
| `doctor --json` healthy default configuration | PASS |
| Invalid runtime config fails closed | PASS |
| Wheel build | PASS |
| Install wheel in clean virtualenv | PASS |
| `pip check` in clean virtualenv | PASS |
| Installed wheel database health smoke | PASS |

The local environment uses Python 3.13.5. The P1 archive still requires hosted Python 3.11/3.12 matrix validation and Ruff, Bandit, Semgrep, and pip-audit. P0 run #7 does not cover these P1 edits.

## Acceptance boundaries / remaining gaps

This increment closes repository-side defects listed above. It does **not** claim that the whole P1 operational-readiness phase is closed. The following require external infrastructure, credentials, or human acceptance:

- Upload the exact P1 archive to the repository root on `main`, then dispatch the checksum-pinned [hosted workflow](https://github.com/pannaragaid-alt/pannaragaid/blob/main/.github/workflows/v17-p0-validation.yml); review all scanner findings.
- Actual encrypted backup/restore and disaster-recovery drill against deployment storage and the real secret backend.
- Recurring scheduler/process supervision, graceful shutdown, retry policy, and alert routing.
- Production identity/authentication, RBAC, session controls, tenant isolation, and network policy.
- Centralized structured logs, metrics, health probes, and actionable alerts.
- Authorized live provider integration tests and staging load/failure/accessibility/security acceptance.

**No P2 work or public deployment should begin until these gates are evidenced and all resulting findings are fixed and reverified.**
