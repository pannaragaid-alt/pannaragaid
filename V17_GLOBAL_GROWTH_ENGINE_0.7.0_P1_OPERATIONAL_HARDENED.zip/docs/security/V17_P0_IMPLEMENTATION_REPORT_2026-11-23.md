# V17 0.7.0 — P0 Security Hardening Continuation

**Date:** 2026-11-23  
**Source:** isolated continuation of the previously P0-hardened 0.7.0 archive  
**Version:** 0.7.0 (no semantic version bump; this is an unreleased hardening build)  
**Status:** P0 implementation and hosted CI gate PASS for the exact P0 archive; public production deployment remains BLOCKED pending external identity/access controls.

> **Superseding verification (2026-11-23):** GitHub Actions run [#7 / 45200186096](https://github.com/pannaragaid-alt/pannaragaid/actions/runs/45200186096/workflow) passed all six jobs: Ruff, Python 3.11 tests/build (452 passed), Python 3.12 tests/build (452 passed), Bandit, Semgrep (zero findings), and pip-audit (no known vulnerabilities). The verified P0 archive SHA-256 was `782ecf1c4587d965221c6101d40a55c3f80601b1fb99e324fa22c5afc36234a3`. This closes SEC-005 for that archive only. See `V17_P0_CONTINUATION_STATUS_2026-11-23.md` for the current P1 status; P1 edits require a new CI run.

**Continuation addendum:** V17-SEC-022 (bounded dashboard JSON parsing) and V17-SEC-023 (bounded CLI/provider/backup JSON parsing with duplicate-key and non-finite-value rejection) were remediated. At the time of this historical report, 450 tests passed; hosted run #7 subsequently passed 452 tests on each supported Python matrix version.

## Delivered in this continuation

### Provider egress and scraping

- Exact owner-approved host and path-prefix allowlists are mandatory for Incognito.
- DNS answers are checked for public routability and special-use ranges; TCP is pinned to a validated IP while TLS SNI/certificate verification uses the canonical host.
- Every redirect is revalidated and re-resolved; redirect count, timeout, content type, compression, and response bytes are bounded.
- No cookies, Authorization headers, browser profile, or ambient proxy settings are used by the direct fetcher.
- Firecrawl target scraping is disabled. Firecrawl Search omits `scrapeOptions`, so it returns SERP metadata only and does not ask the hosted provider to fetch result URLs.
- Search result URLs are constrained to canonical HTTPS FQDNs on the default port; titles/snippets and scraped text receive heuristic email/phone redaction.

### OAuth, API transport, and secrets

- OAuth client JSON is limited to 16 KiB and accepts only official Google auth/token/certificate endpoints.
- Installed OAuth clients are loopback-only; web clients must use an exact registered HTTPS redirect URI.
- OAuth code exchange, refresh, and revocation disable ambient proxies and refuse redirects; sessions clear cookies and authorization state and keep TLS verification enabled.
- OAuth scope enforcement is repeated in the credential manager; only the approved read-only YouTube/Analytics scopes and `youtube_analytics` provider are accepted.
- YouTube Data API and Analytics requests use direct TLS-verified `httplib2` transport with redirects forced to zero.
- Secret references are restricted to approved `keyring://`, `memory://`, `env://YOUTUBE_API_KEY`, or `env://V17_SECRET_*` forms. Empty environment prefixes require exact allowlists.

### Storage, imports, jobs, and exports

- SQLite files and sidecars are owner-only (`0600` on POSIX); new DB directories request `0700`.
- Backups reject duplicate/unexpected ZIP members and remain AES-GCM encrypted; report exports are atomic and owner-only.
- CSV exports neutralize spreadsheet formulas; Markdown exports escape untrusted HTML/Markdown structure.
- CSV imports reject duplicate headers and extra cells and count invalid physical rows against the row ceiling.
- Image decode is capped at 40 million pixels; audio decode is capped at 40 million samples before full allocation.
- Job execution can enter `running` only through `claim_next()`. Checkpoint/terminal transitions require the exact, unexpired worker lease; job config/checkpoints are limited to 1 MiB.
- YouTube comment pagination has a five-page ceiling and repeated-token detection.
- Dashboard JSON text inputs are capped at 1 MiB and 64 nesting levels before decoding; evidence uploads retain a 5 MiB application cap and OAuth client JSON a 16 KiB cap. OAuth callback URL input is capped at 4 KiB. These controls reduce parser/resource-exhaustion exposure at the dashboard boundary.
- Streamlit defaults to loopback-only (`127.0.0.1`), enables CORS/XSRF protections, limits uploads/messages, and disables usage telemetry. It has no built-in multi-user authentication; public deployment is blocked without a separately reviewed identity/authentication layer.

## Verification evidence

| Check | Result |
|---|---|
| `python -m pytest -q` | **450 passed** (includes dashboard, CLI, provider, and backup JSON-boundary regression tests) |
| `python -m compileall -q v17_niche_intel tests` | PASS |
| Clean ZIP extract: `pytest -q` | **450 passed** |
| ZIP integrity | PASS |
| AST parse of all package Python files | PASS |
| `python -m v17_niche_intel.cli --help` | PASS |
| CLI rejects oversized JSON file before full read | PASS |
| Strict JSON rejects duplicate keys and NaN/Infinity | PASS |
| YAML parse of `.github/workflows/ci.yml` | PASS |
| Wheel build (Python 3.13.5) | PASS |
| Install wheel into clean isolated venv | PASS |
| `uv pip check` in clean isolated venv | PASS — all installed packages compatible |
| CLI help from installed wheel | PASS |
| Static reconnaissance for eval/exec/shell/subprocess/pickle/yaml.load/disabled TLS | No matches |
| Shared runtime `pip check` | FAIL — unrelated global `moviepy 2.2.1` requires `pillow<12`, runtime has `pillow 12.3.0` |
| Ruff / Bandit / pip-audit / Semgrep | NOT RUN — not installed; package-index DNS resolution failed during install attempt |
| Python 3.11 / 3.12 matrix | NOT RUN — only Python 3.13.5 is installed locally |
| Hosted GitHub Actions | NOT RUN — linked GitHub account exposes `pannaragaid-alt/pannaragaid`, but it contains only a minimal README and no V17 source or CI workflow; do not publish source there without owner confirmation |
| Live OAuth, YouTube API, Firecrawl Search, external staging, production | NOT RUN |

**Wheel:** `v17_niche_intelligence-0.7.0-py3-none-any.whl`  
**SHA-256:** `0fb393b497e2f4c48273189e59e9d2a78e7d89cb983725089d9974437cbd1526`

## Remaining blockers — do not start the next phase

1. **SEC-005: hosted scanner and supported-Python evidence.** Run the committed `security-scan` job and Python 3.11/3.12 test/build matrix in a network-enabled GitHub Actions runner. The only currently linked repo is not the V17 source repository; provide/authorize the correct repository before source publication. Review and remediate every finding, then rerun CI.
2. **Conditional public deployment:** Dashboard loopback binding is the safe local default. Any network deployment needs an authenticated identity layer, deployment-specific security review, and staging pentest.
3. **Conditional live-integration and external acceptance:** no live OAuth, YouTube API, Firecrawl Search, external staging, browser/a11y, load/fault, or production deployment test was run. Run these only if they are part of the intended release acceptance, with credentials in the secret manager and an explicitly authorized staging scope.

P0 is therefore **not declared complete**. This build contains the local remediations and evidence above, but the release gate remains blocked. No P1/P2 implementation was started.
