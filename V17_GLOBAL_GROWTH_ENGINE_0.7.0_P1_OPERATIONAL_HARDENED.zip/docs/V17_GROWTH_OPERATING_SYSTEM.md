# V17 Channel Intelligence & Growth Operating System

## Product direction

V17 should evolve from a research dashboard into a decision-support operating system for launching and improving YouTube channels. It must connect market evidence to channel positioning, audience-led editorial strategy, repeatable production, first-party performance learning, and safe automation.

**Core loop:** Discover demand → map competitors → identify audience pain → formulate a differentiated position → plan content → publish (human-approved) → measure owner-authorized Analytics → run controlled experiments → update strategy.

V17 is a decision-support system, not an autopilot that promises views, subscribers, revenue, monetization, or guaranteed growth.

## Skill operating model

Use specialist workflows by stage. Do not run every skill on every ticket, and do not pretend that a plugin catalogue is a running team of agents.

| Workstream | Primary skills | V17 responsibility |
|---|---|---|
| Strategy orchestration | Marketing Growth `marketing-orchestrator`, `marketing-plan`, Agency `agency-orchestrator`, `agency-marketing`, `agency-product` | One strategy, shared assumptions, priorities, channel roles, capacity and decision log |
| Audience and positioning | Marketing `customer-research`, `product-marketing`, `content-strategy`; Agency `agency-research`, `agency-marketing` | Jobs-to-be-done, audience language, audience segments, positioning, proof and differentiation |
| Competitor intelligence | Marketing `competitor-profiling`, `competitors`, `reverse-engineer-marketing`; Scrapling `scrapling-core`, `scrapling-parsing`, `scrapling-safety-compliance` | Dated public competitor observations, content patterns, source references, extraction quality and gap hypotheses |
| Editorial and creative | Marketing `content-strategy`, `video`, `ad-creative`, `ab-testing`; Agency marketing specialists | Content pillars, topic backlog, series, hooks, scripts, packaging variants and learning agenda |
| Measurement | Marketing `analytics`, `ab-testing`, `attribution`; UI UX `charts-data-visualization`; ECC `ecc-evaluation-benchmarking` | KPI tree, metric definitions, experiment design, uncertainty and quality gates |
| Product engineering | Matt `codebase-design`, `domain-modeling`, `implement`, `tdd`, `code-review`; ECC `ecc-backend-data-engineering`, `ecc-agentic-engineering`, `ecc-tdd-verification` | Deep modules, typed contracts, reproducible tests, observability and release discipline |
| Agent automation | ECC `ecc-agent-harness-architecture`, `ecc-multi-agent-orchestration`, `ecc-defensive-security`, `ecc-tooling-integration`; Scrapling MCP only when connected | Bounded workflows, idempotency, approvals, retries, budgets, cancellation and audit trails |
| UX quality | UI UX `design-system-generator`, `frontend-ui-implementation`, `ux-accessibility-audit`; Anti Slop `antislop-ui`, `antislop-human`, `antislop-layoutmobile`, `antislop-delivery-gate` | Task-first interface, accessible evidence display, responsive forms, complete states and honest claims |
| Delivery discipline | Superpowers `brainstorming`, `writing-plans`, `test-driven-development`, `requesting-code-review`, `verification-before-completion`; Ponytail `ponytail-audit`, `ponytail-review`; Caveman `caveman-explore`, `surgical-patch`, `verify-and-stop`; I Have ADHD | Small milestones, evidence-first review, visible progress and concise operator actions |

Agency Agents profiles are specialist references, not proof that separate agents ran. Only use independent agent delegation when the host exposes a real subagent runtime.

## Strategic workflow and product modules

### 1. Channel foundation

Collect niche, target audience, problem, desired outcome, creator advantages, unique method, geography, language, production constraints, and monetization hypotheses. Keep operator assertions distinct from observed evidence.

Deliverables: positioning statement, audience promise, differentiation hypotheses, content pillars, launch sequence, production feasibility, and validation questions.

### 2. Competitor evidence graph

For each competitor observation, persist: competitor/channel ID, video or page reference, URL, observed timestamp, country/language, content format, title/description/topic, visible engagement snapshot, evidence source, extraction method, freshness, and confidence metadata.

A competitor gap must cite one or more source references. Separate:
- observed fact (what the source visibly contains);
- interpretation (what it may imply);
- opportunity hypothesis (what the new channel could test);
- decision (what the operator chooses to do).

Do not infer private CTR, retention, impressions, demographics, revenue, or algorithmic distribution from public competitor data.

### 3. Audience voice and demand

Cluster questions, comments and search intents into jobs-to-be-done, pain points, desired outcomes, objections and awareness stages. Preserve source context, sample size, sampling window, language, duplicate handling and privacy minimization. Do not treat comment frequency as population prevalence.

### 4. Editorial operating system

Turn validated audience problems and competitor gaps into:
- content pillars and repeatable series;
- topic backlog with audience problem, intent, evidence, differentiation, production effort and format;
- video brief with promise, proof, hook, narrative beats, visual plan, CTA and sources;
- title/thumbnail hypotheses and variants;
- Shorts/long-form/live role assignments;
- content freshness and cannibalization review.

No idea should receive a precise demand score until its inputs, normalization, geography, time window and sample quality are explicit.

### 5. First-party performance loop

Use only owner-authorized YouTube Analytics for private channel metrics. Build a KPI tree:
- discovery: impressions, traffic sources, search terms and unique viewers;
- packaging: impressions CTR, segmented by surface and format where available;
- satisfaction: retention curve, average view duration, watch time and returning viewers;
- audience value: subscribers gained per view/session, repeat viewing and qualitative feedback;
- operating guardrails: production hours, cadence reliability, policy/rights review and cost per video.

A/B or sequential experiments must declare hypothesis, primary metric, guardrails, randomization unit, sample-size/power assumptions, duration, segmentation and stopping rule. Avoid early peeking, multiple-comparison traps and causal claims from non-randomized observations.

### 6. Automation and agents

Automate read-only, repeatable work first: scheduled SERP snapshots, public-source refresh, stale-evidence alerts, topic clustering, report generation, and Analytics summaries after authorized retrieval.

Every automated job needs:
- typed input/output contract and schema version;
- idempotency key and deduplication;
- bounded pages, timeouts, retries, concurrency and cost;
- per-provider quota accounting and backoff;
- explicit state transitions, cancellation and resumability;
- structured logs, traces, source provenance and audit history;
- least-privilege credentials and a kill switch;
- human approval before publishing, contacting, spending, deleting, changing accounts, or mutating production data.

Scrapling MCP is not assumed available unless its separate server is actually connected. Existing Firecrawl integrations remain governed by target authorization, terms, robots policies, rate limits and data minimization. Never bypass login, paywalls, CAPTCHA, access controls or rate limits.

### 7. Enterprise hardening

Before multi-user production: tenant isolation, RBAC, workspace-scoped secrets, encryption and rotation, audit logs, migrations and rollback, backups/restore drills, retention enforcement, data export/deletion workflows, provider outage handling, SLOs, alerting, dependency pinning, CI, vulnerability scanning, disaster recovery and documented incident response.

## Evidence and scoring policy

Do not collapse uncertainty into one opaque “viral potential” number. Keep separate dimensions for demand signal, competitive saturation, gap evidence quality, audience fit, differentiation strength, production feasibility, policy risk and first-party performance.

For every dimension store: metric definition, numerator/denominator, unit, source family, sample size, observed-at timestamp, geography, language, timeframe, freshness, missingness, normalization method, confidence and limitations. Only aggregate compatible measurements. If required evidence is absent, return `not_configured` or `insufficient_data`.

Use ranked recommendations only when the ordering rule is documented and the inputs are comparable. Keep growth forecasts null unless a validated model and representative training/holdout evidence exist.

## Delivery sequence

| Priority | Capability | Acceptance evidence |
|---|---|---|
| P0 | Channel foundation and evidence-linked positioning | Unit/integration tests; unsupported competitor claims excluded; JSON export |
| P1 | Competitor evidence graph and structured snapshots | Source references, timestamps, freshness, duplicate and parser tests |
| P1 | Audience voice clustering and intent-to-topic mapping | Sampling metadata, multilingual test set, human review and error taxonomy |
| P1 | Editorial backlog and video brief generator | Evidence-linked briefs, effort/capacity checks, no fabricated metrics |
| P2 | First-party analytics KPI tree and experiment integrity ledger | Metric definitions, source declarations, SRM/power checks, audit trail; OAuth scope binding remains in the credential layer |
| P2 | Scheduled jobs and agent orchestration | Bounded read-only job contract validator is implemented; scheduler, retries, cancellation, quota execution and kill switch runtime remain external |
| P3 | Multi-user enterprise controls | Tenant isolation tests, RBAC tests, restore drill, security review, operational runbooks |

## Current implementation in this release

- Added `ChannelStrategyService` for evidence-linked positioning, competitor-gap mapping, audience-derived content pillars, launch sequence and measurement contract.
- Integrated the strategy result into `MarketIntelligenceService` and added `v17 strategy` CLI command.
- Added a Channel Strategy dashboard tab with JSON evidence inputs and export.
- Added deterministic tests for missing inputs, unsupported claims, invalid impact labels, evidence-linked outputs and CLI export.

## Known blockers before production claims

- Streamlit is not installed in the current build environment; browser runtime, screenshots, keyboard flow and responsive visual QA are not verified.
- Scrapling MCP is a separate server and was not connected in this environment. Existing Firecrawl support is not evidence of Scrapling MCP availability.
- Live YouTube, Google OAuth, Firecrawl and Analytics behavior still requires real authorized credentials and provider-side testing.
- The current channel strategy is a deterministic foundation builder, not an LLM content studio, publisher, scheduler or autonomous growth agent.
- Multi-tenant access control, centralized audit/observability and production deployment controls are future work.


## Executable growth diagnostics (2026-11-13 upgrade)

Use `v17 growth-audit examples/growth_audit.template.json --output growth-audit-report.json` to run the new evidence-aware checks. The same payload can be embedded under `growth_audit` in `v17 intelligence` input. It adds competitor gap aggregation, Search intent overlap review, native localization freshness gates, retention drop diagnostics, discovery-surface packaging/retention checks, CTR sample-size planning and randomized-test analysis, per-market RPM scenario economics, portfolio concentration, and content readiness hard gates. See `docs/GROWTH_INTELLIGENCE_UPGRADE.md` for formulas, schemas and limitations.


## P1-P10 execution status (v0.3.0)

The P1-P10 labels below map to the ten workstreams from the growth-intelligence diagnostic, not to a separate ten-level priority list. The original product roadmap above retains its P0-P3 priority labels.

1. **Market and monetization intelligence:** existing four-layer decision model plus scenario RPM economics and break-even. Country-level RPM is not treated as public fact; verified first-party RPM requires authorized Analytics evidence.
2. **Native localization intelligence:** freshness and native/dialect/accent/cultural review gates. Actual linguistic quality still requires qualified human review.
3. **Competitor weakness intelligence:** dated HTTPS evidence graph, deduplication, conflict detection, stale evidence labels, and source-linked gaps. Automated recurring collection remains unconfigured.
4. **Audience and retention intelligence:** labelled audience pain clusters with language/sample-window metadata plus first-party retention curve diagnostics. Clusters are exact human labels, not automatic semantic truth or population estimates.
5. **Search intelligence:** query-to-intent mapping, unassigned query detection, overlap review, SERP volatility and freshness diagnostics. Search samples remain biased samples, not a census.
6. **Recommendation intelligence:** surface-specific Browse, Suggested, Search and Shorts diagnostics comparing packaging and retention in matched cohorts. These are descriptive diagnostics, not ranking rules.
7. **Content production intelligence:** capacity-bounded editorial backlog, evidence-linked video brief scaffold, title/thumbnail hypotheses, and rights/localization pre-publication gates. Human editorial and factual review remain required.
8. **Portfolio optimization:** risk-adjusted market hour allocation, allocation concentration and existing portfolio HHI. Scores are operator inputs, not predicted returns.
9. **Experimentation and learning:** CTR sample-size planning, randomized two-proportion analysis and sample-ratio mismatch screening. Platform experiment execution, multiple-testing governance and power validation remain operator responsibilities.
10. **Automation and QA:** bounded read-only job contract validation with idempotency, domain allowlist, retry/time/item/budget limits and kill-switch requirement. No scheduler or background worker is deployed by this release.
