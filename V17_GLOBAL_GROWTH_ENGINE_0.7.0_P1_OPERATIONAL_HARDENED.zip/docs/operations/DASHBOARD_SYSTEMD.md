# Local-only dashboard supervision with systemd

This unit provides a supervised, non-root Streamlit process for a single-host deployment. It binds explicitly to `127.0.0.1`; it is not a public deployment recipe and does not provide OIDC, SSO, RBAC, or a trusted reverse-proxy authentication boundary.

## Security boundary

- Keep the dashboard reachable only from the local host until an independently configured authentication boundary is reviewed and tested.
- Do not change the bind address to `0.0.0.0` or expose port `8501` through a firewall, container port mapping, or cloud load balancer.
- If remote access is required, use a separately managed reverse proxy that enforces OIDC/SSO, server-side authorization, TLS, secure session handling, rate limits, and audit logging. Keep the Streamlit upstream bound to loopback.
- The service requires outbound network access for configured providers. Enforce egress allowlists outside this unit; do not assume systemd's address-family restriction is a destination allowlist.
- `V17_DATABASE` is the dashboard's database setting. The backup CLI uses `V17_DATABASE_PATH` in its separate unit; do not interchange these names.

## Preconditions

- Linux with systemd and a supported Python runtime.
- Dedicated `v17` user and group; no interactive login and no sudo privileges.
- Application installed in `/opt/v17/venv` and source tree installed at `/opt/v17/app` so the Streamlit entry point is present.
- `/var/lib/v17` owned by `v17:v17`, mode `0700`; no production data is copied into staging.
- Provider and secret-manager credentials provisioned using an approved secret backend. Do not put secret values in `Environment=`, command-line arguments, or this unit.
- The `v17 doctor --json` preflight must pass before startup.

## Install

```bash
sudo useradd --system --home-dir /var/lib/v17 --create-home --shell /usr/sbin/nologin v17
sudo install -d -o v17 -g v17 -m 0700 /var/lib/v17
sudo install -d -o root -g root -m 0755 /opt/v17
sudo install -o root -g root -m 0644 deploy/systemd/v17-dashboard.service /etc/systemd/system/v17-dashboard.service
sudo systemctl daemon-reload
sudo systemctl enable --now v17-dashboard.service
```

Install the application and source tree before enabling the service. Provisioning commands for the virtual environment and source directory are intentionally environment-specific; use the approved immutable artifact and verify its SHA-256 before installation.

## Verify and operate

```bash
sudo systemctl status v17-dashboard.service --no-pager
sudo systemctl show v17-dashboard.service -p ActiveState -p SubState -p Result -p ExecMainStatus
sudo journalctl -u v17-dashboard.service --since today --no-pager
curl --fail --silent http://127.0.0.1:8501/_stcore/health
sudo ss -ltnp 'sport = :8501'
```

The listener must be `127.0.0.1:8501`, never `0.0.0.0:8501` or `[::]:8501`. Verify from a separate host that port `8501` is unreachable. The health endpoint is a process-level readiness signal only; it does not replace dependency, authorization, or end-to-end provider checks.

The unit applies bounded restart behavior (five starts per 300 seconds), a five-second restart delay, a 30-second stop timeout, a 2 GiB memory ceiling, a 200% CPU quota, and a 128-task limit. Logs go to the system journal. These controls are defaults, not capacity conclusions; validate them against measured staging workloads before production use.

## Rollback

```bash
sudo systemctl disable --now v17-dashboard.service
sudo journalctl -u v17-dashboard.service --since today --no-pager
```

Restore the previous immutable application artifact and compatible configuration, rerun `v17 --database /var/lib/v17/v17_niche_intel.sqlite3 doctor --json`, then re-enable the service. Do not roll back across a database migration unless the migration's documented compatibility and recovery procedure has been verified. Preserve the database and backups during application rollback.

## Acceptance status

Adding this unit closes part of the repository-side supervision implementation gap only. Gate 2 remains open until it is installed on an authorized staging host and start/stop/restart, graceful termination, crash/lease recovery, repeated-crash rate limiting, resource behavior, and database-write interruption drills are executed and evidenced. Gate 4 remains open: this unit is loopback-only and does not add application authentication.
