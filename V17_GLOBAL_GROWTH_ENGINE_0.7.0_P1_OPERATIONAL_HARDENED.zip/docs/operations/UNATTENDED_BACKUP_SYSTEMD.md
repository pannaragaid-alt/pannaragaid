# Unattended encrypted backup with systemd

This deployment example removes the interactive TTY requirement while keeping the backup passphrase out of argv and environment variables. It does **not** by itself satisfy P1 backup acceptance: an off-host copy, retention policy, restore drill, measured RPO/RTO, and reviewer evidence remain mandatory.

## Preconditions

- Install the V17 wheel/application into a dedicated virtual environment and ensure `v17` is available to the service.
- Create dedicated OS user/group `v17`; do not run the application as root.
- Ensure the database and backup directories are on encrypted storage with restrictive ownership.
- Configure the application's secret backend so the service identity can read the referenced secrets.
- Choose an approved passphrase from an independent secret manager. Never place it in a shell command, unit environment, or source control.

## Install

```bash
sudo install -d -o root -g root -m 0700 /etc/v17
sudo install -d -o v17 -g v17 -m 0700 /var/backups/v17
sudo install -o root -g root -m 0600 /secure/provisioning/backup-passphrase /etc/v17/backup-passphrase
sudo install -o root -g root -m 0755 scripts/v17-backup.sh /usr/local/libexec/v17-backup.sh
sudo install -o root -g root -m 0644 deploy/systemd/v17-backup.service /etc/systemd/system/v17-backup.service
sudo install -o root -g root -m 0644 deploy/systemd/v17-backup.timer /etc/systemd/system/v17-backup.timer
sudo systemctl daemon-reload
sudo systemctl enable --now v17-backup.timer
```

The source credential file must be provisioned through an approved secret-management channel. The unit uses `LoadCredential=` so systemd exposes a protected per-service credential copy through `CREDENTIALS_DIRECTORY`.

## Validate a scheduled run

```bash
sudo systemctl start v17-backup.service
sudo systemctl show v17-backup.service -p Result -p ExecMainStatus
sudo journalctl -u v17-backup.service --since today --no-pager
sudo find /var/backups/v17 -maxdepth 1 -type f -name '*.v17enc' -printf '%f %s bytes\n'
```

Confirm the output is mode `0600`, non-empty, and decryptable in an isolated restore environment. Do not perform restore into the live database path.

## Mandatory off-host and recovery controls

- Copy the completed encrypted artifact to a separately administered storage account/failure domain using an approved transfer mechanism with TLS and destination-side encryption.
- Keep encryption key material separate from the backup destination; enforce least-privilege access and immutable/versioned retention where available.
- Alert on a missed timer, non-zero service result, missing artifact, failed integrity check, or failed off-host replication.
- Retain a known-good prior backup and test selecting it when the newest backup is corrupt/incomplete.
- Execute the isolated restore drill, run `v17 --database <restored-db> doctor --json`, verify representative application records and secret references, and record actual RPO/RTO.
- Define and approve retention and deletion policy before automating pruning. This example deliberately does not delete backups.

## Hardening review before deployment

The unit's `RestrictAddressFamilies=AF_UNIX` intentionally blocks network access for local backup creation. If a future approved off-host replication job needs networking, run it as a separate, separately constrained service with narrowly scoped credentials and egress policy; do not widen the database backup unit's network permissions.
