#!/usr/bin/env bash
set -euo pipefail
umask 077

: "${CREDENTIALS_DIRECTORY:?systemd credential directory is required}"
: "${V17_DATABASE_PATH:=/var/lib/v17/v17_niche_intel.sqlite3}"
: "${V17_BACKUP_DIRECTORY:=/var/backups/v17}"

credential_file="${CREDENTIALS_DIRECTORY}/backup-passphrase"
if [[ ! -f "$credential_file" || -L "$credential_file" ]]; then
  echo "backup credential is missing or not a regular file" >&2
  exit 20
fi

install -d -m 0700 "$V17_BACKUP_DIRECTORY"
timestamp="$(date -u +%Y%m%dT%H%M%SZ)"
output="${V17_BACKUP_DIRECTORY}/v17-${timestamp}.v17enc"

# The passphrase is read by the CLI from the systemd credential file; it is
# never passed in argv or exported into the process environment.
exec v17 --database "$V17_DATABASE_PATH" backup \
  --output "$output" \
  --passphrase-file "$credential_file"
