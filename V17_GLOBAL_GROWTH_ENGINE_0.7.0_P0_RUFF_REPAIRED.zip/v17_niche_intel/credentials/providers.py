from __future__ import annotations

from ..providers.youtube_data_api import YouTubeDataAPIProvider, APIKeyInvalidError


class RotatingYouTubeDataAPIProvider:
    """Retry an invalid key only with another active key in the same project route."""
    def __init__(self, manager, credential, *, use_case: str, environment: str,
                 timeout_seconds: int = 20, quota_limit: int = 10000,
                 search_quota_limit: int = 100):
        self.manager = manager
        self.credential = credential
        self.use_case = use_case
        self.environment = environment
        self.timeout_seconds = timeout_seconds
        self.quota_limit = quota_limit
        self.search_quota_limit = search_quota_limit

    def _provider(self):
        credential = self.credential
        api_key = self.manager.secrets.get(credential.secret_ref)
        def meter(method, units):
            bucket = "search.list" if method == "search.list" else "default"
            limit = self.search_quota_limit if bucket == "search.list" else self.quota_limit
            return self.manager.consume_project_quota(
                credential.project_id, units=units, limit=limit, use_case=self.use_case, bucket=bucket)
        return YouTubeDataAPIProvider(api_key=api_key, timeout_seconds=self.timeout_seconds,
                                      quota_callback=meter)

    def search_videos(self, *args, **kwargs):
        for _ in range(20):
            try:
                return self._provider().search_videos(*args, **kwargs)
            except APIKeyInvalidError:
                self.manager.set_api_key_status(self.credential.credential_id, "invalid")
                # select_api_key enforces one project per route and checks the shared project quota.
                self.credential = self.manager.select_api_key(
                    use_case=self.use_case, environment=self.environment, quota_limit=self.quota_limit)
        raise RuntimeError("API-key failover limit reached")

    def list_supported_regions(self):
        for _ in range(20):
            try:
                return self._provider().list_supported_regions()
            except APIKeyInvalidError:
                self.manager.set_api_key_status(self.credential.credential_id, "invalid")
                self.credential = self.manager.select_api_key(
                    use_case=self.use_case, environment=self.environment, quota_limit=self.quota_limit)
        raise RuntimeError("API-key failover limit reached")

    def fetch_public_comments(self, *args, **kwargs):
        for _ in range(20):
            try:
                return self._provider().fetch_public_comments(*args, **kwargs)
            except APIKeyInvalidError:
                self.manager.set_api_key_status(self.credential.credential_id, "invalid")
                self.credential = self.manager.select_api_key(
                    use_case=self.use_case, environment=self.environment, quota_limit=self.quota_limit)
        raise RuntimeError("API-key failover limit reached")


def build_youtube_data_api_provider(manager, *, use_case: str, environment: str,
                                   timeout_seconds: int = 20, quota_limit: int = 10000,
                                   search_quota_limit: int = 100) -> RotatingYouTubeDataAPIProvider:
    """Resolve a metered key and configure same-project invalid-key failover."""
    credential = manager.select_api_key(use_case=use_case, environment=environment, quota_limit=quota_limit)
    return RotatingYouTubeDataAPIProvider(manager, credential, use_case=use_case,
        environment=environment, timeout_seconds=timeout_seconds, quota_limit=quota_limit,
        search_quota_limit=search_quota_limit)


def build_configured_youtube_data_api_provider(database, *, use_case: str = "market_research",
                                                environment: str = "local", quota_limit: int | None = None,
                                                search_quota_limit: int | None = None):
    """Resolve keyring credentials first, or a project-identified env key; never bypass a registered quota route."""
    import os
    from .manager import CredentialManager
    from .secrets import EnvironmentSecretStore, KeyringSecretStore

    quota_limit = int(os.getenv("YOUTUBE_DAILY_QUOTA_LIMIT", str(quota_limit or 10000)))
    search_quota_limit = int(os.getenv("YOUTUBE_SEARCH_DAILY_LIMIT", str(search_quota_limit or 100)))
    if quota_limit < 1 or search_quota_limit < 1:
        raise ValueError("YouTube quota limits must be positive integers")
    try:
        keyring_store = KeyringSecretStore()
    except RuntimeError:
        keyring_store = None
    if keyring_store is not None:
        keyring_manager = CredentialManager(database, keyring_store)
        routes = [item for item in keyring_manager.list_api_credentials()
                  if item["provider"] == "youtube_data_api" and item["use_case"] == use_case
                  and item["environment"] == environment]
        if routes:
            # Do not fall back to an environment key if a registered route is ambiguous,
            # inactive, or quota-exhausted. That would silently bypass project policy.
            return build_youtube_data_api_provider(keyring_manager, use_case=use_case,
                environment=environment, quota_limit=quota_limit, search_quota_limit=search_quota_limit)

    api_key = os.getenv("YOUTUBE_API_KEY")
    project_id = os.getenv("YOUTUBE_API_PROJECT_ID")
    if not api_key or not project_id:
        return None
    env_store = EnvironmentSecretStore(prefix="", allowed_names={"YOUTUBE_API_KEY"})
    env_manager = CredentialManager(database, env_store)
    routes = [item for item in env_manager.list_api_credentials()
              if item["provider"] == "youtube_data_api" and item["use_case"] == use_case
              and item["environment"] == environment]
    if not routes:
        credential_id = f"env-{project_id}-{use_case}-{environment}"
        env_manager.add_api_key(credential_id, project_id=project_id, use_case=use_case,
            environment=environment, secret_ref="env://YOUTUBE_API_KEY")
    return build_youtube_data_api_provider(env_manager, use_case=use_case,
        environment=environment, quota_limit=quota_limit, search_quota_limit=search_quota_limit)
