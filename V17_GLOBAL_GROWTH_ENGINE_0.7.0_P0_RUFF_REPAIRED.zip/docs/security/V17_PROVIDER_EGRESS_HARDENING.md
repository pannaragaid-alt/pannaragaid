# V17 Provider Egress Hardening — P0 Pentest Report

**Assessment date:** 2026-11-23  
**Baseline:** V17 0.7.0 P0-hardened source archive  
**Scope:** repository code, unit/integration tests, and controlled local fixtures  
**Authorization:** owner authorized implementation and local security testing; no third-party host was probed  
**Disposition:** provider egress findings SEC-001..004 remediated in code and regression-tested; scanner/hosted-CI gate SEC-005 remains BLOCKED pending execution in a network-enabled CI runner.

## Executive summary

The first P0 increment found that Firecrawl's target-scrape adapter accepted a caller-supplied API origin and delegated arbitrary target fetching to a hosted service after only local DNS preflight. The first issue could disclose a bearer key to an arbitrary API origin; the second could not enforce DNS and redirect policy at the actual remote fetch point. Both are addressed structurally:

- Firecrawl API origin is fixed to the official HTTPS origin; the compatibility scrape method is now fail-closed and does not retain or transmit the key.
- Incognito target retrieval no longer uses hosted Firecrawl. It uses a local HTTPS fetcher with exact hostname **and path-prefix** allowlists, DNS validation, IP-pinned TCP connections, TLS hostname verification, redirect revalidation, hard resource limits, and no cookie/auth/proxy state.
- Firecrawl Search remains a separate SERP discovery integration. Its API request uses the fixed origin, disables environment proxy inheritance, refuses redirects, bounds the response body, and limits user-controlled query inputs. Search results are recorded as URLs; this code path does not fetch those URLs.

No live Firecrawl request, OAuth session, Scrapling MCP session, external staging target, or production system was used.

## Findings and disposition

### V17-SEC-001 — Arbitrary Firecrawl API origin could receive bearer token

- **Severity:** Medium
- **Status:** FIXED
- **Root cause:** the previous client accepted arbitrary `base_url` values and sent the API key in an Authorization header.
- **Remediation:** the compatibility constructor accepts only `https://api.firecrawl.dev` on the default HTTPS port and rejects userinfo, path, query, and fragment. Its `scrape()` method now raises a policy error and performs no network request. The API key is not retained in the compatibility instance. Search uses a constant endpoint.
- **Verification:** constructor-origin regression tests; hosted target fetch disabled test; Search origin is a literal constant. No actual API key was used.

### V17-SEC-002 — Unbounded provider response allocation

- **Severity:** Medium
- **Status:** FIXED
- **Root cause:** provider response bodies were previously read without a hard byte ceiling.
- **Remediation:** Firecrawl Search reads at most 10 MiB + 1 byte and rejects overflow before JSON parsing. Direct Incognito fetch reads at most 5 MiB + 1 byte, rejects oversized Content-Length before body read, rejects compressed responses, and only accepts HTML/XHTML/plain text.
- **Verification:** oversized Search response tests, oversized direct-fetch response tests (with and without Content-Length), and exact bounded-read assertions.

### V17-SEC-003 — No owner-approved hostname allowlist

- **Severity:** Medium
- **Status:** FIXED
- **Remediation:** `V17_SCRAPE_ALLOWED_HOSTS` is mandatory and exact-match only. Wildcards, suffix matching, IP literals, trailing dots, and noncanonical hostnames are rejected. IDNA normalization is applied consistently. `V17_SCRAPE_ALLOWED_PATHS` is also mandatory and binds one or more absolute path prefixes to every allowlisted host. Prefix matching uses path-segment boundaries; encoded paths, duplicate separators, backslashes, dot segments, wildcard prefixes, and unapproved paths are rejected. CLI and dashboard fail closed if either variable is absent or invalid.
- **Verification:** exact-host, lookalike-host, IDNA, wildcard, missing-policy, path-boundary, encoded-path, dot-segment, and CLI fail-closed tests.

### V17-SEC-004 — Hosted fetch-time DNS/redirect enforcement could not be proven

- **Severity:** Medium
- **Status:** FIXED BY REMOVING THE UNVERIFIABLE HOSTED FETCH PATH
- **Root cause:** local DNS preflight cannot prove which IP a remote provider fetcher resolves or which redirects it follows.
- **Remediation:** Incognito no longer sends target URLs to hosted Firecrawl. DirectHTTPSFetcher resolves every hop locally, rejects any non-public or special-purpose DNS answer, pins TCP to the selected validated IP, and preserves the canonical hostname for TLS SNI/certificate verification. It revalidates hostname and path policy and resolves DNS again for every redirect. It bypasses environment proxies, sends no cookies or Authorization header, permits at most three redirects, applies a 15-second per-hop socket timeout, caps the body at 5 MiB, and refuses compressed/non-text responses. IPv4/IPv6 special-use ranges, NAT64, IPv4-mapped IPv6, 6to4, and Teredo are rejected.
- **Verification:** local red-team fixtures cover mixed public/private DNS answers, DNS rebinding between redirect hops, cross-origin redirect, redirect to private IP literal, special-purpose/NAT64/ORCHID IPv6, actual pinned socket destination with hostname TLS SNI, and redirect ceiling.
- **Boundary:** this closes the application's hosted-fetch uncertainty by not using that fetch path. It does not claim that Firecrawl's remote infrastructure itself is secure; Firecrawl is Search-only in this application path.

### V17-SEC-005 — Security scanner and clean CI verification gap

- **Severity:** Verification blocker
- **Status:** OPEN / BLOCKED
- **Evidence:** local attempts to install Ruff, Bandit, pip-audit, and Semgrep failed because the execution environment could not resolve the package index (`Temporary failure in name resolution`). The runtime does not have those scanner executables. A dedicated CI `security-scan` job and optional `security` dependency extra have been added, but hosted GitHub Actions has not been executed from this workspace.
- **Required evidence to close:** successful hosted execution of Ruff, Bandit, pip-audit, Semgrep and the Python 3.11/3.12 test/build matrix; review and remediation of every finding; repeat CI after fixes.
- **Environment note:** the shared runtime's `pip check` previously reported MoviePy/Pillow conflict unrelated to V17 core dependencies. An isolated V17 wheel install and `pip check` are included in this continuation's verification; the shared global environment must not be treated as the project's clean dependency environment.

## Local red-team matrix

| Test | Expected control | Status |
|---|---|---|
| Arbitrary Firecrawl API origin / plaintext loopback | Reject before request | PASS |
| Firecrawl API lookalike, userinfo, nonstandard port | Reject | PASS |
| Hosted Firecrawl target URL fetch | Fail closed | PASS |
| Empty hostname allowlist | Reject | PASS |
| Wildcard/suffix host matching | Reject | PASS |
| Host/path policy mismatch | Reject | PASS |
| Encoded path, `..`, duplicate slash, backslash | Reject | PASS |
| DNS answer set containing loopback/private | Reject entire set | PASS |
| DNS rebinding on redirect hop | Resolve again and reject | PASS |
| Redirect to non-allowlisted host | Reject before second connection | PASS |
| Redirect to private IP literal | Reject | PASS |
| IPv4-mapped/NAT64/6to4/Teredo/special IPv6 | Reject | PASS |
| TCP connection destination pinning | Connect to validated IP | PASS |
| TLS SNI/certificate hostname | Preserve canonical hostname | PASS |
| Cross-origin Firecrawl Search redirect | Do not follow | PASS (handler fixture) |
| Firecrawl Search proxy env inheritance | Disable | PASS (opener fixture) |
| Direct fetch cookies/Authorization | Never send | PASS |
| Direct fetch response overflow | Reject before parse | PASS |
| Direct fetch redirect ceiling | Stop after three redirects | PASS |
| OAuth, live Firecrawl API, Scrapling MCP, external staging | Requires credentials/target authorization | NOT RUN |

## Resource and trust limits

| Control | Value |
|---|---:|
| Incognito allowed hosts | Explicit exact host list, mandatory |
| Incognito allowed paths | Explicit host-bound path prefixes, mandatory |
| Incognito redirects | 3 maximum |
| Incognito timeout | 15 seconds per hop |
| Incognito body | 5 MiB maximum |
| Incognito content types | HTML, XHTML, plain text |
| Firecrawl Search result count | 1–10 |
| Firecrawl Search query | 512 characters maximum |
| Firecrawl Search location | 256 characters maximum |
| Firecrawl Search response | 10 MiB maximum |

## Verification still required before P0 can be marked complete

1. Run the new hosted `security-scan` CI job and the Python 3.11/3.12 matrix.
2. Resolve every scanner finding or document an explicit reviewed exception with evidence.
3. Confirm the installed wheel in a clean environment on supported Python versions.
4. If the owner later enables a Scrapling fetcher or browser session, route it through the same host/path/DNS/redirect egress policy; do not expose a direct bypass path.
5. Obtain signed scope/ROE before testing any external staging or production hostname.

**Current release gate: BLOCKED.** SEC-001 through SEC-004 are locally remediated and regression-tested. SEC-005 remains open until the network-enabled CI evidence exists. Do not start the next implementation phase while this gate remains open.

## Additional P0 red-team findings discovered during continuation

The following were found by reviewing adjacent trust boundaries after the initial egress patch. They were added to the same P0 hardening scope and now have regression coverage.

| ID | Finding | Remediation | Status |
|---|---|---|---|
| V17-SEC-006 | OAuth client JSON could select a non-Google authorization/token endpoint or malformed redirect URI | 16 KiB client-config cap; strict installed/web config shape; official Google auth/token/cert endpoints only; installed loopback-only; web redirect must exactly match registered HTTPS URI | FIXED |
| V17-SEC-007 | OAuth library sessions could inherit proxy/cookie/auth state or follow token-exchange redirects | Hardened OAuth2Session: `trust_env=False`, no proxies/cookies/auth, TLS verification on, redirects refused; same policy for token refresh and revocation | FIXED |
| V17-SEC-008 | Credential manager could accept write scopes outside the consent flow | Manager now independently enforces only approved YouTube/Analytics read-only scopes and the `youtube_analytics` provider | FIXED |
| V17-SEC-009 | YouTube Data API and Analytics HTTP clients could follow redirects | Direct TLS-verified `httplib2` transport forces `redirections=0`; OAuth Analytics uses `AuthorizedHttp` over that transport | FIXED |
| V17-SEC-010 | Job repository allowed direct `running` transitions and ownerless checkpoint/transition writes | `claim_next()` is the only way to acquire a lease; writes require the exact worker and an unexpired lease; config/checkpoint <=1 MiB; bounded worker/error fields | FIXED |
| V17-SEC-011 | CSV export could trigger spreadsheet formulas; Markdown export could inject HTML/Markdown structure | Formula neutralization; HTML/Markdown escaping; atomic owner-only report writes | FIXED |
| V17-SEC-012 | SQLite database files inherited permissive umask defaults | POSIX database files and SQLite sidecars use owner-only permissions; new parent directories request mode 0700 | FIXED |
| V17-SEC-013 | Media inputs could trigger excessive image/audio decode allocation | JPEG/PNG/WEBP only; image pixel ceiling 40 million; decoded audio sample ceiling 40 million before full decode | FIXED |
| V17-SEC-014 | CSV parser accepted duplicate normalized headers and ignored extra cells; invalid rows did not count toward row ceiling | Duplicate-header rejection, extra-cell rejection, physical row count limit | FIXED |
| V17-SEC-015 | Environment secret references could resolve arbitrary process environment variables | Empty prefix requires exact allowlist; default composite namespace restricted to `V17_SECRET_`; application YouTube key path is exact-name allowlisted | FIXED |
| V17-SEC-016 | Authenticated backup could contain duplicate ZIP member names | Restore rejects duplicate, unexpected, directory, or missing members before reading payloads | FIXED |
| V17-SEC-017 | Firecrawl Search request still included `scrapeOptions`, allowing hosted result-page fetching outside local egress enforcement | Removed `scrapeOptions`; Search is SERP-only; target URLs are not submitted for hosted scraping | FIXED |
| V17-SEC-018 | Search provider could return unsafe URL schemes, credentials, IP literals, or nonstandard ports | Result URLs restricted to canonical HTTPS FQDNs on default port; title/description bounded and email/phone heuristically redacted | FIXED |
| V17-SEC-019 | OAuth revocation endpoint could follow redirects while carrying token form data | Direct TLS request with proxy environment disabled and redirects refused; token length bounded | FIXED |
| V17-SEC-020 | Repeated YouTube comment page tokens could loop indefinitely | Five-page ceiling, repeated-token detection, comment text cap | FIXED |
| V17-SEC-021 | Dashboard could be exposed on a network interface without an application-level authentication layer | Streamlit defaults pinned to loopback `127.0.0.1`, CORS/XSRF protections enabled, uploads/messages bounded, telemetry disabled; public deployment remains blocked pending external authentication/identity layer | LOCAL DEFAULT FIXED / PUBLIC DEPLOYMENT BLOCKED |

### Additional local test evidence

- Historical suite at the SEC-021 checkpoint: **434 passed in 3.58s**, with the intentional duplicate-ZIP warning captured explicitly by its test. Subsequent SEC-022/023 additions bring the current suite to 450 passed.
- Focused security tests cover OAuth session hardening, token endpoint allowlisting, no-redirect Google API transport, write-scope rejection, worker lease expiry, formula injection, private file permissions, image/audio decode limits, CSV malformed structure, environment-secret allowlists, duplicate backup members, SERP URL validation, and repeated pagination tokens.
- Static source reconnaissance found no direct uses of `eval`, `exec`, `os.system`, `subprocess`, `shell=True`, `pickle.load(s)`, `yaml.load`, disabled TLS verification, or secret-bearing log statements in `v17_niche_intel`.

## Explicitly unimplemented or unverified capabilities

- **Scrapling adapter/browser integration is not active in this source tree.** It must not be enabled as an independent network path. Any future integration must consume the same exact host/path policy, DNS/IP pinning, redirect refusal/revalidation, response limits, and no-credential boundary. This is a capability gap, not an active egress bypass.
- Firecrawl is Search-only. Hosted Firecrawl target scraping is intentionally disabled. No live Firecrawl key was used.
- Heuristic PII masking covers email/phone-like strings only; it is not comprehensive PII detection, and direct Incognito connections are not anonymous.
- OAuth live consent/refresh/revocation, live YouTube API calls, live Firecrawl Search, external staging, browser automation, and production deployment were not run.
- Ruff, Bandit, pip-audit, and Semgrep remain unexecuted locally because package-index DNS resolution failed. The hosted workflow is authored but has not run.

**P0 release gate remains BLOCKED** until SEC-005 hosted scanner/matrix evidence is reviewed and any resulting findings are fixed and retested. The V17 source documentation explicitly treats Scrapling MCP/browser sessions as optional and not required; no direct Scrapling network path is active. Public deployment and live provider/staging tests are conditional operational acceptance gates, not claims satisfied by local unit tests. No P1/P2 work should begin while SEC-005 remains open.



### V17-SEC-022 — Unbounded dashboard JSON text inputs

- **Severity:** Low–Medium (local dashboard resource exhaustion boundary)
- **Status:** FIXED locally; full dashboard browser runtime remains NOT VERIFIED
- **Root cause:** multiple user-editable JSON text areas were passed directly to `json.loads` without a common input-byte or nesting-depth limit.
- **Remediation:** added `parse_bounded_json`, which checks UTF-8 byte length before decoding, enforces a maximum structural nesting depth, rejects invalid Unicode, and converts parser recursion failures into a controlled validation error. Dashboard JSON text areas are capped at 1 MiB / 64 levels; uploaded evidence is capped at 5 MiB / 64 levels; OAuth client JSON remains capped at 16 KiB; manual OAuth callback input is capped at 4 KiB.
- **Verification:** nine dedicated unit tests cover valid input, non-text input, byte overflow, UTF-8 byte accounting, nesting overflow, default depth, brackets inside strings, escaped quotes/backslashes, and invalid Unicode. This count is a historical snapshot before SEC-023; current full local suite: 450 passed.

### V17-SEC-023 — Unbounded CLI JSON file reads and ambiguous/non-standard JSON values

- **Severity:** Low–Medium (local CLI memory exhaustion and parser ambiguity)
- **Status:** FIXED locally; external scanner confirmation remains pending under SEC-005
- **Root cause:** CLI commands loaded complete user-supplied JSON files before enforcing a size limit. Python's default JSON decoder also accepts duplicate object keys (last value wins) and non-standard `NaN`/`Infinity` constants.
- **Remediation:** introduced `load_bounded_json_file`, which reads at most 10 MiB + 1 byte before decoding, requires strict UTF-8, and enforces a 64-level nesting limit. `parse_bounded_json` now rejects duplicate keys and non-finite constants. Applied strict bounded parsing to CLI JSON files and inline JSON arguments, OAuth dashboard client configuration (16 KiB / 16 levels), Firecrawl Search responses (10 MiB / 64 levels), YouTube API error payloads (64 KiB / 16 levels), and encrypted-backup secret maps (10 MiB / 16 levels).
- **Verification:** seven new regression tests cover duplicate keys, non-finite constants, bounded file reads, valid UTF-8, invalid UTF-8, Firecrawl duplicate-key rejection, and CLI oversized-file rejection. Full local suite: 450 passed.
- **Residual boundary:** Streamlit's browser/server runtime and actual deployment authentication were not exercised in this workspace.
