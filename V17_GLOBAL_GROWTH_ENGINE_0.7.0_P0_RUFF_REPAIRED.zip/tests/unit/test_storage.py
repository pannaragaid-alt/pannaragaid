from datetime import datetime, timezone

import pytest

from v17_niche_intel.domain.enums import EvidenceStatus
from v17_niche_intel.domain.models import Evidence
from v17_niche_intel.storage.database import Database
from v17_niche_intel.storage.repositories import EvidenceRepository, ResearchRunRepository


def test_research_run_round_trip_and_algorithm_metadata():
    db = Database(":memory:")
    runs = ResearchRunRepository(db)
    run_id = runs.create(
        topic="home coffee roasting",
        mode="market_entry",
        country_code="ID",
        algorithm_version="v17-balanced-0.1.0",
        config={"formats": ["shorts", "long_form", "live"]},
    )
    row = runs.get(run_id)
    assert row["topic"] == "home coffee roasting"
    assert row["country_code"] == "ID"
    assert row["config"]["formats"] == ["shorts", "long_form", "live"]
    assert row["algorithm_version"] == "v17-balanced-0.1.0"
    db.close()


def test_evidence_round_trip_preserves_provenance():
    db = Database(":memory:")
    run_id = ResearchRunRepository(db).create(
        topic="coffee", mode="market_entry", country_code="ID",
        algorithm_version="v17-balanced-0.1.0", config={},
    )
    repo = EvidenceRepository(db)
    evidence = Evidence(
        metric="trend_level", value=64.0, source_family="google_trends",
        observed_at=datetime(2026, 11, 11, tzinfo=timezone.utc),
        status=EvidenceStatus.OK, quality=0.9,
        source_ref="trends:coffee:ID", metadata={"timeframe": "12m"},
    )
    repo.add(run_id, evidence)
    rows = repo.list_for_run(run_id)
    assert len(rows) == 1
    assert rows[0]["value"] == 64.0
    assert rows[0]["source_family"] == "google_trends"
    assert rows[0]["metadata"] == {"timeframe": "12m"}
    assert rows[0]["quality"] == 0.9
    db.close()


def test_duplicate_evidence_insert_is_idempotent():
    db = Database(":memory:")
    run_id = ResearchRunRepository(db).create(
        topic="coffee", mode="market_entry", country_code="ID",
        algorithm_version="v17-balanced-0.1.0", config={},
    )
    repo = EvidenceRepository(db)
    evidence = Evidence(
        metric="trend_level", value=64.0, source_family="google_trends",
        observed_at=datetime(2026, 11, 11, tzinfo=timezone.utc),
        status=EvidenceStatus.OK, source_ref="same-observation",
    )
    assert repo.add(run_id, evidence) is True
    assert repo.add(run_id, evidence) is False
    assert len(repo.list_for_run(run_id)) == 1
    db.close()


def test_foreign_keys_reject_evidence_for_unknown_run():
    db = Database(":memory:")
    evidence = Evidence(
        metric="trend_level", value=64.0, source_family="google_trends",
        observed_at=datetime.now(timezone.utc), status=EvidenceStatus.OK,
    )
    with pytest.raises(Exception):
        EvidenceRepository(db).add("missing-run", evidence)
    db.close()


def test_transaction_rolls_back_on_error():
    db = Database(":memory:")
    with pytest.raises(RuntimeError):
        with db.transaction() as connection:
            connection.execute(
                "INSERT INTO research_runs (id, topic, mode, country_code, algorithm_version, config_json, created_at) "
                "VALUES ('rollback', 'coffee', 'market_entry', 'ID', 'v1', '{}', '2026-11-11T00:00:00+00:00')"
            )
            raise RuntimeError("force rollback")
    assert ResearchRunRepository(db).get("rollback") is None
    db.close()


def test_file_database_creates_parent_and_persists_runs(tmp_path):
    path = tmp_path / "nested" / "research.sqlite3"
    db = Database(path)
    run_id = ResearchRunRepository(db).create(
        topic="coffee", mode="existing_channel", country_code="ID",
        algorithm_version="v17-balanced-0.1.0", config={"channel": "owned"},
    )
    db.close()
    reopened = Database(path)
    row = ResearchRunRepository(reopened).get(run_id)
    assert row["config"] == {"channel": "owned"}
    reopened.close()


def test_run_repository_rejects_empty_topic_and_unknown_mode():
    db = Database(":memory:")
    repo = ResearchRunRepository(db)
    with pytest.raises(ValueError, match="topic"):
        repo.create(topic=" ", mode="market_entry", country_code=None,
                    algorithm_version="v1", config={})
    with pytest.raises(ValueError, match="mode"):
        repo.create(topic="coffee", mode="other", country_code=None,
                    algorithm_version="v1", config={})
    db.close()


def test_private_analytics_are_stored_separately_from_public_evidence():
    from v17_niche_intel.storage.repositories import PrivateAnalyticsRepository
    db=Database(':memory:')
    repo=PrivateAnalyticsRepository(db)
    rows=({'date':'2026-11-01','video_id':'v1','views':100},)
    assert repo.import_rows(channel_id='owned-channel',rows=rows)==1
    assert repo.import_rows(channel_id='owned-channel',rows=rows)==0
    assert repo.list_for_channel('owned-channel')[0]['metrics']['views']==100
    with db.read() as conn:
        assert conn.execute('SELECT COUNT(*) FROM source_observations').fetchone()[0]==0
    db.close()


def test_research_result_round_trip():
    from v17_niche_intel.storage.repositories import ResultRepository
    db=Database(':memory:')
    run_id=ResearchRunRepository(db).create(topic='coffee',mode='market_entry',country_code='ID',algorithm_version='v1',config={})
    repo=ResultRepository(db); repo.save(run_id,{'score':None,'status':'insufficient_evidence'})
    assert repo.get(run_id)['status']=='insufficient_evidence'
    db.close()


def test_legacy_per_use_case_quota_rows_migrate_to_project_wide_daily_usage(tmp_path):
    import sqlite3
    path = tmp_path / "legacy-quota.sqlite3"
    connection = sqlite3.connect(path)
    connection.execute("CREATE TABLE project_quota_daily (project_id TEXT, use_case TEXT, quota_date TEXT, used INTEGER, quota_limit INTEGER, updated_at TEXT, PRIMARY KEY(project_id,use_case,quota_date))")
    connection.executemany("INSERT INTO project_quota_daily VALUES (?,?,?,?,?,?)", [
        ("project-a", "market", "2025-01-01", 30, 100, "2025-01-01T00:00:00+00:00"),
        ("project-a", "channel", "2025-01-01", 40, 100, "2025-01-01T01:00:00+00:00"),
    ])
    connection.commit(); connection.close()
    db = Database(path)
    row = db.connection.execute("SELECT * FROM project_quota_daily WHERE project_id='project-a'").fetchone()
    assert row["used"] == 70
    assert row["quota_limit"] == 100
    assert "use_case" not in {column[1] for column in db.connection.execute("PRAGMA table_info(project_quota_daily)")}
    db.close()


def test_serp_snapshot_repository_persists_timestamped_ordered_results():
    from datetime import datetime, timezone
    from v17_niche_intel.storage.repositories import SERPSnapshotRepository
    db = Database(":memory:")
    repo = SERPSnapshotRepository(db)
    assert repo.add(keyword="coffee", country="ID", language="id",
        observed_at=datetime(2025, 1, 1, tzinfo=timezone.utc), results=[{"url": "https://a.example"}])
    assert repo.list_for_keyword("coffee", country="ID")[0]["results"][0]["url"] == "https://a.example"
    db.close()


def test_public_youtube_data_retention_purges_old_runs_and_expired_serp_but_preserves_private_data():
    from datetime import datetime, timezone
    from v17_niche_intel.storage.repositories import ResearchRunRepository, PrivateAnalyticsRepository, SERPSnapshotRepository
    from v17_niche_intel.services.retention import purge_expired_public_youtube_data
    db = Database(":memory:")
    runs = ResearchRunRepository(db)
    old_id = runs.create(topic="old", mode="market_entry", country_code="ID", algorithm_version="v1",
        config={}, created_at=datetime(2025, 1, 1, tzinfo=timezone.utc))
    fresh_id = runs.create(topic="fresh", mode="market_entry", country_code="ID", algorithm_version="v1",
        config={}, created_at=datetime(2025, 1, 30, tzinfo=timezone.utc))
    PrivateAnalyticsRepository(db).import_daily_rows(channel_id="UC_OWNER", rows=({"date":"2025-01-01","views":5},))
    SERPSnapshotRepository(db).add(keyword="coffee", country="ID", language="id",
        observed_at=datetime(2025, 1, 1, tzinfo=timezone.utc), results=[{"url":"https://a.example"}])
    result = purge_expired_public_youtube_data(db, now=datetime(2025, 3, 1, tzinfo=timezone.utc), retention_days=30)
    assert result["expired_research_runs_deleted"] == 1
    assert runs.get(old_id) is None
    assert runs.get(fresh_id) is not None
    assert db.connection.execute("SELECT COUNT(*) FROM channel_analytics_daily_private").fetchone()[0] == 1
    assert db.connection.execute("SELECT COUNT(*) FROM serp_snapshots").fetchone()[0] == 0
    assert result["expired_serp_snapshots_deleted"] == 1
    db.close()


def test_youtube_retention_policy_rejects_windows_over_thirty_days():
    from v17_niche_intel.services.retention import purge_expired_public_youtube_data
    db = Database(":memory:")
    with pytest.raises(ValueError, match="30 days"):
        purge_expired_public_youtube_data(db, retention_days=31)
    db.close()


def test_legacy_general_quota_migrates_conservative_search_call_estimate(tmp_path):
    import sqlite3
    from datetime import datetime
    from zoneinfo import ZoneInfo
    path = tmp_path / "legacy-quota.sqlite3"
    from datetime import timezone
    now_utc = datetime.now(timezone.utc)
    today_pt = now_utc.astimezone(ZoneInfo("America/Los_Angeles")).date().isoformat()
    legacy_utc_date = now_utc.date().isoformat()
    connection = sqlite3.connect(path)
    connection.execute("""CREATE TABLE project_quota_daily (
        project_id TEXT NOT NULL, quota_date TEXT NOT NULL, used INTEGER NOT NULL,
        quota_limit INTEGER NOT NULL, updated_at TEXT NOT NULL,
        PRIMARY KEY(project_id,quota_date))""")
    connection.execute("INSERT INTO project_quota_daily VALUES (?,?,?,?,?)",
        ("project-a", legacy_utc_date, 301, 10000, now_utc.isoformat()))
    connection.commit()
    connection.close()

    db = Database(path)
    general = db.connection.execute("SELECT used,quota_date FROM project_quota_daily WHERE project_id='project-a'").fetchone()
    search = db.connection.execute("SELECT used,quota_limit FROM project_search_quota_daily WHERE project_id='project-a'").fetchone()
    assert general["used"] == 301  # preserve old usage conservatively
    assert general["quota_date"] == today_pt  # convert the legacy UTC date to the PT reset boundary
    assert search["used"] == 3  # 301 old units imply at least three old search calls
    assert search["quota_limit"] == 100
    db.close()


def test_private_country_analytics_are_persisted_separately_from_public_evidence():
    from v17_niche_intel.storage.repositories import PrivateAnalyticsRepository
    db = Database(":memory:")
    repo = PrivateAnalyticsRepository(db)
    inserted = repo.import_country_rows(channel_id="UC_OWNER", start_date="2025-01-01", end_date="2025-01-31",
        currency="USD", rows=({"country": "US", "views": 2000, "estimatedRevenue": 10, "rpm": 5},))
    assert inserted == 1
    assert repo.list_country_for_channel("UC_OWNER")[0]["rpm"] == 5
    assert db.connection.execute("SELECT COUNT(*) FROM source_observations").fetchone()[0] == 0
    db.close()


def test_private_country_analytics_rejects_non_finite_values():
    from v17_niche_intel.storage.repositories import PrivateAnalyticsRepository
    db = Database(":memory:")
    repo = PrivateAnalyticsRepository(db)
    with pytest.raises(ValueError, match="non-negative numbers"):
        repo.import_country_rows(channel_id="UC_OWNER", start_date="2025-01-01", end_date="2025-01-31",
            currency="USD", rows=({"country": "US", "views": float("nan"), "estimatedRevenue": 1, "rpm": 1},))
    db.close()


def test_job_checkpoint_repository_is_idempotent_and_enforces_state_transitions():
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    assert repo.create(job_id="scan-1", idempotency_key="key-1", job_type="global_market_scan",
        config={"topic": "coffee"}) is True
    assert repo.create(job_id="scan-1", idempotency_key="key-1", job_type="global_market_scan",
        config={"topic": "coffee"}) is False
    claimed = repo.claim_next(worker_id="storage-worker")
    assert claimed["worker_id"] == "storage-worker"
    assert repo.save_checkpoint("scan-1", {"last_market_id": "US-en", "completed_markets": 1},
                                worker_id="storage-worker") is True
    assert repo.get("scan-1")["checkpoint"]["last_market_id"] == "US-en"
    assert repo.transition("scan-1", "completed", worker_id="storage-worker") is True
    with pytest.raises(ValueError, match="claim_next"):
        repo.transition("scan-1", "running", worker_id="storage-worker")
    db.close()


def test_job_and_experiment_status_filters_use_bounded_fixed_parameter_sets():
    from v17_niche_intel.storage.repositories import JobCheckpointRepository, ExperimentRepository

    db = Database(":memory:")
    jobs = JobCheckpointRepository(db)
    jobs.create(job_id="pending-job", idempotency_key="pending-key", job_type="scan", config={})
    assert [item["job_id"] for item in jobs.list(statuses=("pending",))] == ["pending-job"]
    assert [item["job_id"] for item in jobs.list(statuses=("pending", "failed", "paused", "running", "completed"))] == ["pending-job"]

    experiments = ExperimentRepository(db)
    experiments.create(experiment_id="planned-exp", idempotency_key="planned-key",
        objective="Validate filter", primary_metric="retention", config={})
    assert [item["experiment_id"] for item in experiments.list(statuses=("planned",))] == ["planned-exp"]
    assert [item["experiment_id"] for item in experiments.list(
        statuses=("planned", "running", "paused", "failed", "completed", "cancelled")
    )] == ["planned-exp"]
    db.close()


def test_persistent_job_runner_executes_one_registered_job_and_persists_resume_checkpoint():
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    from v17_niche_intel.services.job_runner import PersistentJobRunner
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    repo.create(job_id="job-1", idempotency_key="idem-1", job_type="test_scan",
        config={"topic": "coffee", "max_attempts": 2})
    def handler(config, checkpoint, save_checkpoint):
        assert config["topic"] == "coffee"
        save_checkpoint({"completed_markets": ["US-en"]})
        return {"status": "completed"}
    result = PersistentJobRunner(repo, {"test_scan": handler}).run_once(worker_id="worker-a")
    assert result["status"] == "completed"
    job = repo.get("job-1")
    assert job["status"] == "completed"
    assert job["checkpoint"]["completed_markets"] == ["US-en"]
    assert job["attempt_count"] == 1
    db.close()


def test_persistent_job_runner_fails_closed_when_no_handler_is_registered():
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    from v17_niche_intel.services.job_runner import PersistentJobRunner
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    repo.create(job_id="job-2", idempotency_key="idem-2", job_type="unknown",
        config={"max_attempts": 1})
    result = PersistentJobRunner(repo, {}).run_once(worker_id="worker-a")
    assert result["status"] == "failed"
    assert repo.get("job-2")["status"] == "failed"
    db.close()


def test_job_checkpoint_lease_prevents_parallel_claim_and_allows_expired_reclaim():
    from datetime import datetime, timedelta, timezone
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    repo.create(job_id="lease-1", idempotency_key="lease-key", job_type="scan", config={})
    first = repo.claim_next(worker_id="worker-a", lease_seconds=30)
    assert first["worker_id"] == "worker-a"
    assert repo.claim_next(worker_id="worker-b", lease_seconds=30) is None
    with db.transaction() as connection:
        connection.execute("UPDATE job_checkpoints SET lease_expires_at=? WHERE job_id=?",
            ((datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(), "lease-1"))
    second = repo.claim_next(worker_id="worker-b", lease_seconds=30)
    assert second["worker_id"] == "worker-b"
    assert second["attempt_count"] == 2
    assert repo.save_checkpoint("lease-1", {"step": 1}, worker_id="worker-a") is False
    db.close()


def test_persistent_job_runner_records_failure_without_persisting_exception_message():
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    from v17_niche_intel.services.job_runner import PersistentJobRunner
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    repo.create(job_id="job-fail", idempotency_key="idem-fail", job_type="failing",
        config={"max_attempts": 2})
    def handler(config, checkpoint, save_checkpoint):
        raise RuntimeError("token=super-secret-value")
    result = PersistentJobRunner(repo, {"failing": handler}).run_once(worker_id="worker-a")
    assert result["status"] == "failed"
    assert repo.get("job-fail")["error_text"] == "RuntimeError"
    assert "super-secret-value" not in str(repo.get("job-fail"))
    db.close()


def test_experiment_and_decision_repositories_are_idempotent_and_auditable():
    from v17_niche_intel.storage.repositories import ExperimentRepository, DecisionLogRepository
    db = Database(":memory:")
    experiments = ExperimentRepository(db)
    assert experiments.create(experiment_id="thumb-1", idempotency_key="thumb-1:v1",
        objective="Improve watch time", primary_metric="watch_time_per_impression",
        config={"randomized": True}) is True
    assert experiments.create(experiment_id="thumb-1", idempotency_key="thumb-1:v1",
        objective="Improve watch time", primary_metric="watch_time_per_impression",
        config={"randomized": True}) is False
    assert experiments.get("thumb-1")["status"] == "planned"
    assert experiments.transition("thumb-1", "running") is True
    assert experiments.get("thumb-1")["status"] == "running"
    decisions = DecisionLogRepository(db)
    assert decisions.add(decision_id="d1", idempotency_key="d1:v1", topic="coffee",
        recommendation="Test tutorial format", evidence_refs=["analytics:2026-01"],
        expected_metric="watch_time_per_impression", status="proposed") is True
    assert decisions.add(decision_id="d1", idempotency_key="d1:v1", topic="coffee",
        recommendation="Test tutorial format", evidence_refs=["analytics:2026-01"],
        expected_metric="watch_time_per_impression", status="proposed") is False
    assert decisions.get("d1")["evidence_refs"] == ["analytics:2026-01"]
    db.close()


def test_experiment_results_and_decision_outcomes_close_the_learning_loop():
    from v17_niche_intel.storage.repositories import ExperimentRepository, DecisionLogRepository
    db = Database(":memory:")
    experiments = ExperimentRepository(db)
    experiments.create(experiment_id="e1", idempotency_key="e1:v1", objective="Improve retention",
        primary_metric="average_view_duration", config={})
    experiments.transition("e1", "running")
    assert experiments.record_result("e1", {"lift_pct": 4.2, "guardrails_passed": True}) is True
    assert experiments.get("e1")["result"]["lift_pct"] == 4.2
    decisions = DecisionLogRepository(db)
    decisions.add(decision_id="d3", idempotency_key="d3:v1", topic="coffee",
        recommendation="Create comparison video", evidence_refs=["analytics:1"],
        expected_metric="watch_time_per_impression")
    assert decisions.transition("d3", "accepted") is True
    assert decisions.transition("d3", "implemented", outcome={"video_id": "owned-video-1"}) is True
    assert decisions.transition("d3", "validated", outcome={"wape": 12.4, "reviewed": True}) is True
    assert decisions.get("d3")["outcome"]["reviewed"] is True
    db.close()


def test_legacy_private_analytics_tables_receive_additive_provenance_columns(tmp_path):
    import sqlite3
    path = tmp_path / "legacy-private-analytics.sqlite3"
    connection = sqlite3.connect(path)
    connection.executescript("""
        CREATE TABLE channel_analytics_private (
            id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, channel_id TEXT NOT NULL,
            video_id TEXT NOT NULL, report_date TEXT NOT NULL, metrics_json TEXT NOT NULL,
            imported_at TEXT NOT NULL, UNIQUE(channel_id,video_id,report_date));
        CREATE TABLE channel_analytics_daily_private (
            id INTEGER PRIMARY KEY AUTOINCREMENT, channel_id TEXT NOT NULL, report_date TEXT NOT NULL,
            metrics_json TEXT NOT NULL, imported_at TEXT NOT NULL, UNIQUE(channel_id,report_date));
        CREATE TABLE channel_analytics_country_private (
            id INTEGER PRIMARY KEY AUTOINCREMENT, channel_id TEXT NOT NULL, country_code TEXT NOT NULL,
            start_date TEXT NOT NULL, end_date TEXT NOT NULL, currency TEXT NOT NULL,
            views REAL NOT NULL, estimated_revenue REAL NOT NULL, rpm REAL, imported_at TEXT NOT NULL,
            UNIQUE(channel_id,country_code,start_date,end_date,currency));
    """)
    connection.execute("INSERT INTO channel_analytics_daily_private(channel_id,report_date,metrics_json,imported_at) VALUES(?,?,?,?)",
        ("UC_LEGACY", "2025-01-01", '{"views":7}', "2025-01-02T00:00:00+00:00"))
    connection.commit()
    connection.close()
    db = Database(path)
    preserved = db.connection.execute("SELECT metrics_json,provenance_json FROM channel_analytics_daily_private WHERE channel_id='UC_LEGACY'").fetchone()
    assert preserved["metrics_json"] == '{"views":7}'
    assert preserved["provenance_json"] == "{}"
    for table in ("channel_analytics_private", "channel_analytics_daily_private", "channel_analytics_country_private"):
        columns = {row[1] for row in db.connection.execute(f"PRAGMA table_info({table})")}
        assert "provenance_json" in columns
    db.close()


def test_job_checkpoint_running_state_requires_claimed_worker_ownership():
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    repo.create(job_id="owner-1", idempotency_key="owner-key", job_type="scan", config={})
    claimed = repo.claim_next(worker_id="worker-a")
    assert claimed["worker_id"] == "worker-a"
    with pytest.raises(ValueError, match="worker_id must be a non-empty string"):
        repo.save_checkpoint("owner-1", {"step": 1})
    with pytest.raises(ValueError, match="worker lease"):
        repo.transition("owner-1", "completed")
    with pytest.raises(ValueError, match="claim_next"):
        repo.transition("owner-1", "running", worker_id="worker-a")
    assert repo.save_checkpoint("owner-1", {"step": 1}, worker_id="worker-a") is True
    assert repo.transition("owner-1", "completed", worker_id="worker-a") is True
    db.close()


def test_job_checkpoint_config_and_checkpoint_payloads_are_bounded():
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    with pytest.raises(ValueError, match="1 MiB"):
        repo.create(job_id="large-1", idempotency_key="large-key", job_type="scan",
                    config={"payload": "x" * (1024 * 1024 + 1)})
    repo.create(job_id="small-1", idempotency_key="small-key", job_type="scan", config={})
    repo.claim_next(worker_id="worker-a")
    with pytest.raises(ValueError, match="1 MiB"):
        repo.save_checkpoint("small-1", {"payload": "x" * (1024 * 1024 + 1)}, worker_id="worker-a")
    db.close()


def test_job_checkpoint_transition_rejects_unbounded_error_text_and_worker_ids():
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    repo.create(job_id="error-1", idempotency_key="error-key", job_type="scan", config={})
    with pytest.raises(ValueError, match="worker_id"):
        repo.claim_next(worker_id="worker\nattacker")
    with pytest.raises(ValueError, match="error code"):
        repo.transition("error-1", "failed", error="token=super-secret")
    db.close()


def test_expired_job_lease_owner_cannot_checkpoint_or_complete_before_reclaim():
    from datetime import datetime, timedelta, timezone
    from v17_niche_intel.storage.repositories import JobCheckpointRepository
    db = Database(":memory:")
    repo = JobCheckpointRepository(db)
    repo.create(job_id="expired-1", idempotency_key="expired-key", job_type="scan", config={})
    repo.claim_next(worker_id="worker-a", lease_seconds=5)
    with db.transaction() as connection:
        connection.execute("UPDATE job_checkpoints SET lease_expires_at=? WHERE job_id=?",
            ((datetime.now(timezone.utc) - timedelta(seconds=1)).isoformat(), "expired-1"))
    assert repo.save_checkpoint("expired-1", {"step": 2}, worker_id="worker-a") is False
    with pytest.raises(ValueError, match="expired"):
        repo.transition("expired-1", "completed", worker_id="worker-a")
    db.close()


def test_sqlite_database_file_is_created_with_private_permissions(tmp_path):
    import os
    import stat
    if os.name != "posix":
        pytest.skip("POSIX permission bits are not portable to this platform")
    path = tmp_path / "private.sqlite3"
    db = Database(path)
    db.connection.execute("INSERT INTO decision_log(decision_id,idempotency_key,topic,recommendation,evidence_refs_json,expected_metric,status,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)",
        ("d1", "i1", "topic", "rec", "[]", "views", "proposed", "now", "now"))
    assert stat.S_IMODE(path.stat().st_mode) == 0o600
    for sidecar in (path.with_name(path.name + "-wal"), path.with_name(path.name + "-shm")):
        if sidecar.exists():
            assert stat.S_IMODE(sidecar.stat().st_mode) == 0o600
    db.close()
